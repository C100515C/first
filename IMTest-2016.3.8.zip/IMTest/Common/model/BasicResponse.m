//
//  BasicModel.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface BasicResponse ()

@end

@implementation BasicResponse

-(CGSize)getStringSizeWith:(NSString *)str fontSize:(CGFloat)font showSize:(CGSize)size{
    return [CC_NSStringHandle getSizeWithString:str andFont:font andSetStartSize:size];
}

-(void)setCellHeight:(CGFloat)cellHeight{
}

-(CGFloat)cellHeight{
    return 0;
}

@end
