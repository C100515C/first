//
//  LoginVC.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LoginVC.h"
#import "UserProfileManager.h"
#import "RegisterVC.h"

@interface LoginVC ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIScrollView *backScrollView;
@property (weak, nonatomic) IBOutlet UIView *scrollContentView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *scrollContentViewHeight;

@property (weak, nonatomic) IBOutlet UITextField *phoneNumber;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UIButton *forgetPassword;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UIButton *weiboLoginAction;

- (IBAction)loginAction:(UIButton *)sender;
- (IBAction)registerAction:(UIButton *)sender;
- (IBAction)weichatLoginAction:(UIButton *)sender;
- (IBAction)QQLoginAction:(UIButton *)sender;

@end

@implementation LoginVC

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = YES;
    
    [self setScrollSize];
    
    self.phoneNumber.delegate = self;
    self.password.delegate = self;
    
    [self setNav];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setScrollSize{
    self.backScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 2.0*SCREEN_WIDTH);
    self.scrollContentViewHeight.constant = 2.0*SCREEN_WIDTH;
    self.backScrollView.scrollEnabled = YES;
}

-(void)setNav{
    // 设置navigationBar的背景颜色，根据需要自己设置
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
//     设置navigationController的title的字体颜色
    NSDictionary * dict=[NSDictionary dictionaryWithObject:[UIColor darkGrayColor] forKey:NSForegroundColorAttributeName];
    self.navigationController.navigationBar.titleTextAttributes = dict;
    self.title = @"登录";
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
    [nav setNavBarBtnItemImageWith:@"faceDelete.png" andRightItem:NO andAction:@selector(dismissVC:) andTarget:self andVCIndex:0];

}

#pragma mark - text field

#pragma mark - btn action

-(void)dismissVC:(UIButton*)btn{
    [self dismissViewControllerAnimated:YES completion:^{
        
    }];
}

- (IBAction)loginAction:(UIButton *)sender {
}

- (IBAction)registerAction:(UIButton *)sender {
    RegisterVC *vc = [[RegisterVC alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)weichatLoginAction:(UIButton *)sender {
}

- (IBAction)QQLoginAction:(UIButton *)sender {
}

@end
