//
//  PostRepeatCell.h
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString * const PostsRepeatCellIdentifier = @"postrepeat";

typedef void (^longPressBlock)(UILongPressGestureRecognizer *sender);
@class  PostRepeatListResponse;
@interface PostRepeatCell : BasicTableViewCell

@property (nonatomic,copy) longPressBlock longPressBlock;

-(void)setCellWith:(PostRepeatListResponse*)model;
@end
