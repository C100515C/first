//
//  PostDetailHeaderView.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostDetailHeaderView.h"
#import "BasicUIImageView.h"
#import "BasicLabel.h"
#import "PostDetailHeaderResponse.h"

@interface PostDetailHeaderView ()<BasicUIImageTapProtocol>

@property (weak, nonatomic) IBOutlet BasicUIImageView *icon;
@property (weak, nonatomic) IBOutlet UILabel *nickname;
@property (weak, nonatomic) IBOutlet BasicLabel *postType;
@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *content;
@property (weak, nonatomic) IBOutlet UIImageView *desImage;
@property (weak, nonatomic) IBOutlet UIButton *collectBtn;
@property (weak, nonatomic) IBOutlet UIButton *shareBtn;
@property (weak, nonatomic) IBOutlet UIButton *focusBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *middleViewHeight;
@property (weak, nonatomic) IBOutlet UIView *topBackView;
@property (weak, nonatomic) IBOutlet UIView *middleBackView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *picHeight;

@end

@implementation PostDetailHeaderView
-(void)awakeFromNib{
    [self.icon setRaduis];
    [self.postType setBorder];
    [self.icon setTapUse];
    self.icon.lyj_delegate = self;
}

-(void)setHeaerViewWith:(PostDetailHeaderResponse *)model{

    CGRect frame = self.frame;
    frame.size.height = model.cellHeight;
    
    self.frame = frame;
    
    self.topViewHeight.constant = model.topnewHeight;
    self.middleViewHeight.constant = model.middleNewHeight;
    self.picHeight.constant = model.picHeight;
    [self.desImage layoutIfNeeded];
    [self.topBackView layoutIfNeeded];
    [self.middleBackView layoutIfNeeded];
    
    self.title.text = model.title;
    [self.title layoutIfNeeded];
    self.content.text = model.content;
    [self.content layoutIfNeeded];
    
    [self layoutIfNeeded];

}

#pragma mark - image tap
-(void)imageTapWith:(UITapGestureRecognizer *)sender{

    if (_tapBlock) {
        _tapBlock(sender);
    }
}

@end
