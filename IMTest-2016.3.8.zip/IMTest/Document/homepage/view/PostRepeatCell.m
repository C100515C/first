//
//  PostRepeatCell.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostRepeatCell.h"
#import "PostRepeatListResponse.h"
#import "BasicUIButton.h"

@interface PostRepeatCell ()
@property (weak, nonatomic) IBOutlet UILabel *nicknameLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet BasicUIButton *praiseBtn;
@property (weak, nonatomic) IBOutlet BasicUIButton *repeatCount;

@end

@implementation PostRepeatCell

-(void)awakeFromNib{
    [super awakeFromNib];

    self.userInteractionEnabled = YES;
    UILongPressGestureRecognizer *longpress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(cellLongPressAction:)];
    
    [self addGestureRecognizer:longpress];
}

-(void)setCellWith:(PostRepeatListResponse *)model{
    MOSLog(@"评论");
    self.contentLabel.text = model.content;
    self.nicknameLabel.text = model.nickname;
    
    [self.praiseBtn setTitle:model.count forState:UIControlStateNormal];
    [self.repeatCount setTitle:model.count forState:UIControlStateNormal];

    self.timeLabel.text = model.time;
}

-(void)cellLongPressAction:(UILongPressGestureRecognizer*)sender{
    
    if (_longPressBlock) {
        _longPressBlock(sender);
    }
}


@end
