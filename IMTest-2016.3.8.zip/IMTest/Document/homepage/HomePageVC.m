//
//  HomePageVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "HomePageVC.h"
#import "PostsCell.h"
#import "PostsResponse.h"
#import "BasicUITableView.h"
#import "PostDetailVC.h"

//#import "LoginVC.h"

@interface HomePageVC (){
    NSMutableArray *_dataSource;
    
}

@property (weak, nonatomic) IBOutlet BasicUITableView *myTable;
@end

@implementation HomePageVC


- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    [super viewDidLoad];
    
    self.title = @"同病相连";
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
//    self.tableView.delegate = self;
//    self.tableView.dataSource = self;
//    self.showSearchBar = YES;
    
    _dataSource = [[NSMutableArray alloc] init];
    [self.tableView registerNib:[UINib nibWithNibName:@"PostsCell" bundle:nil] forCellReuseIdentifier:PostsCellIdentifier];
    [self makeModel];
    
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)makeModel{
    self.dataSearchSource = [NSMutableArray array];

    for (int i=0 ; i<5; i++) {
        PostsResponse *model = [[PostsResponse alloc] init];
        model.content = @"但肯定没卡读书噶开始的感觉啊卡是的公司打工发撒高发但是搜噶是股份撒过烦噶生股份搜噶傻瓜是";
        model.time = @"两天前来自心脏圈";
        model.type = @"lyj 关注了该问题";
        model.nickname = @"cc";
        model.label = @"吐槽";
        model.title = @"跟本不知道是什么";
        model.count = @"1234";
        [_dataSource addObject:model];
//        [self.dataSearchSource addObject:model.type];
    }
    [_myTable reloadData];
}

- (void)tableViewDidTriggerHeaderRefresh{
    
    [self tableViewDidFinishTriggerHeader:YES reload:NO];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    [self tableViewDidFinishTriggerHeader:NO reload:NO];

}//上拉加载事件

#pragma mark - table

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    PostsResponse *model = (PostsResponse*)[_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    PostsCell *cell = [tableView dequeueReusableCellWithIdentifier:PostsCellIdentifier];
    
    if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"PostsCell" owner:nil options:nil] firstObject];
    }
    PostsResponse *model = (PostsResponse*)[_dataSource objectAtIndex:indexPath.row];

    [cell setCellWith:model];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    PostsResponse *model = (PostsResponse*)[_dataSource objectAtIndex:indexPath.row];
    
    PostDetailVC *vc = [[PostDetailVC alloc] init];
    vc.hidesBottomBarWhenPushed = YES;
    vc.title = [NSString stringWithFormat:@"%@详情",model.nickname];
    [self.navigationController pushViewController:vc animated:YES];
    
    
//    LoginVC *vc = [[LoginVC alloc] init];
//    vc.hidesBottomBarWhenPushed = YES;
//    [self.navigationController pushViewController:vc animated:YES];
}

@end
