//
//  PostRepeatsVC.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostRepeatsVC.h"
#import "PostRepeatsResponse.h"
#import "PostRepeatsCell.h"
#import "LYJToolbar.h"

@interface PostRepeatsVC ()<LYJToolBarDelegate>{
    NSMutableArray *_dataSource;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (nonatomic, strong) LYJToolbar *inputBar;

@end

@implementation PostRepeatsVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    [super viewDidLoad];
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _dataSource = [[NSMutableArray alloc] init];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"PostRepeatsCell" bundle:nil] forCellReuseIdentifier:PostRepeatsCell_id];
    
    LYJToolbar *bar = [[LYJToolbar alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-44, self.view.frame.size.width, 44)];
    bar.sendDelegate = self;
    bar.textPlaceholder = @"请输入您回复的内容";
    [self.view addSubview:bar];
    self.inputBar = bar;
    
    [self makeModel];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)makeModel{
    
    for (int i=0 ; i<5; i++) {
        PostRepeatsResponse *model = [[PostRepeatsResponse alloc] init];
        model.content = @"但肯定没卡读书噶开始的感觉啊卡是的公司打工发撒高发但是搜噶是股份撒过烦噶生f发生噶发给发噶舒服噶是嘎嘎嘎撒给个说法股份 撒干撒啊公司法股份搜噶傻瓜是";
        model.time = @"两天前来自心脏圈";
        model.type = @"lyj 关注了该问题";
        model.nickname = @"cc";
        model.label = @"吐槽";
        model.title = @"跟本不知道是什么";
        model.count = @"1234";
        [_dataSource addObject:model];
    }
    [self.tableView reloadData];

    
}

- (void)tableViewDidTriggerHeaderRefresh{
    
    [self tableViewDidFinishTriggerHeader:YES reload:NO];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    [self tableViewDidFinishTriggerHeader:NO reload:NO];
    
}//上拉加载事件

#pragma mark - table

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    PostRepeatsResponse *model = [_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    PostRepeatsCell *cell = [tableView dequeueReusableCellWithIdentifier:PostRepeatsCell_id];
    
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"PostRepeatsCell" owner:nil options:nil] firstObject];
    }
    PostRepeatsResponse *model = [_dataSource objectAtIndex:indexPath.row];
    
    [cell setCellWithModel:model];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [_inputBar keybaordAppear];
    PostRepeatsResponse *model = [_dataSource objectAtIndex:indexPath.row];
    NSString *text = [NSString stringWithFormat:@"回复 %@的评论",model.nickname];
    _inputBar.textPlaceholder = text;
    
    
}

-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [_inputBar takeBackKeyboard];
}

#pragma mark - lyj bar
-(void)clickedSendBtn:(NSString *)currentText{
    MOSLog(@"%@",currentText);
}

@end
