//
//  PostDetailHeaderResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostDetailHeaderResponse.h"

static const CGFloat BasicHeight = 55.0f;

@implementation PostDetailHeaderResponse

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size_content = [self getStringSizeWith:_content fontSize:14.0f showSize:CGSizeMake(SCREEN_WIDTH-16, 2000)];
        CGSize size_title = [self getStringSizeWith:_title fontSize:14.0f showSize:CGSizeMake(SCREEN_WIDTH-90, 2000)];
        _picHeight = 151.0f;
//        _cellHeight = size_content.height+BasicHeight+size_title.height+image_height;
        
        _topnewHeight = size_title.height+33.0;
        _middleNewHeight = size_content.height+_picHeight;
        _cellHeight = _topnewHeight+_middleNewHeight+BasicHeight;
        return _cellHeight;
    }
}

@end
