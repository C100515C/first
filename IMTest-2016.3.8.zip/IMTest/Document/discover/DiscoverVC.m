//
//  DiscoverVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "DiscoverVC.h"

static const CGFloat edgeSpace = 50.0f;
static const CGFloat menuBtnWidth = 80.0f;
static const CGFloat menuBtnSpace = 10.0f;


@interface DiscoverVC (){
    NSMutableArray *_menuBtnsArr;
}

@property (nonatomic,strong) UIView *backMenuView;

@end

@implementation DiscoverVC

- (void)viewDidLoad {
    [super viewDidLoad];
    _menuBtnsArr = [[NSMutableArray alloc] init];
    self.title = @"发现";
    for (int i=0; i<9; i++) {
        [_menuBtnsArr addObject: @"chat_item_file"];

    }
    [self backMenuView];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(CGSize )getBackMenuSize{
    CGSize size;
    int x = 0,y = 0;
    
    x= ((int)_menuBtnsArr.count)%3;
    y = ((int)_menuBtnsArr.count)/3;
    
    if (y==0) {
        size.height = menuBtnWidth;
        size.width = x*(menuBtnSpace+menuBtnWidth)-menuBtnSpace;
    }else{
        size.width = 3*(menuBtnSpace+menuBtnWidth)-menuBtnSpace;
        size.height = y*(menuBtnSpace+menuBtnWidth)-menuBtnSpace;
        
    }
    
    return size;
}

-(UIView*)backMenuView{
    
    if (!_backMenuView) {
       CGSize size = [self getBackMenuSize];
        _backMenuView =[[UIView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        _backMenuView.backgroundColor = [UIColor whiteColor];
        _backMenuView.center = CGPointMake(self.view.frame.size.width/2.0, (self.view.frame.size.height-APP_STATUSBAR_NVIGATIONBAR_HEIGHT)/2.0-edgeSpace);
        [self.view addSubview:_backMenuView];
        
        for (int i=0; i<_menuBtnsArr.count; i++) {
            
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [_backMenuView addSubview:btn];
//            [btn setTitle:_menuBtnsArr[i] forState:UIControlStateNormal];
            btn.frame = CGRectMake(i%3*(menuBtnWidth+menuBtnSpace), i/3*(menuBtnWidth+menuBtnSpace), menuBtnWidth, menuBtnWidth);
            btn.tag = 1+i;
            [btn setBackgroundImage:[UIImage imageNamed:_menuBtnsArr[i]] forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(menuBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
            
        }
        
    }
    
    return _backMenuView;
}

-(void)menuBtnClicked:(UIButton*)sender{
    
    MOSLog(@"%ld",sender.tag);
}

@end
