//
//  SelectTableMenuView.m
//  IMTest
//
//  Created by chenchen on 16/3/3.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SelectTableMenuView.h"



@interface SelectTableMenuView ()

- (IBAction)notice:(UIButton *)sender;
- (IBAction)message:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UIView *markView;
@end

@implementation SelectTableMenuView

-(void)awakeFromNib{

}

-(void)moveMarkLabelWith:(SelectMenuSelectBtn)selectBtn andBtn:(UIButton*)btn{
    CGPoint point = btn.center;
    CGPoint newPoint = self.markView.center;
    
    newPoint.x = point.x;
    
    [UIView animateWithDuration:0.3f animations:^{
        self.markView.center = newPoint;
    }];
    
}


- (IBAction)notice:(UIButton *)sender {
    [self moveMarkLabelWith:SelectMenuNoticBtn andBtn:sender];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(selectBtnClickedWith:)]) {
        [self.delegate selectBtnClickedWith:SelectMenuNoticBtn];
    }
}

- (IBAction)message:(UIButton *)sender {
    [self moveMarkLabelWith:SelectMenuMessageBtn andBtn:sender];
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(selectBtnClickedWith:)]) {
        [self.delegate selectBtnClickedWith:SelectMenuMessageBtn];
    }

}
@end
