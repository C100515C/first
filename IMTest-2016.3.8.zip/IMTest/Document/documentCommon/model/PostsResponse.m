//
//  PostsModel.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostsResponse.h"

static const CGFloat BasicHeight = 98.0f;
@implementation PostsResponse

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
    
        CGSize size = [self getStringSizeWith:_content fontSize:17.0f showSize:CGSizeMake(SCREEN_WIDTH, 2000)];
        MOSLog(@"%f--%f",size.width,size.height);
        _cellHeight = size.height+BasicHeight;
        return _cellHeight;
    }
}

@end
