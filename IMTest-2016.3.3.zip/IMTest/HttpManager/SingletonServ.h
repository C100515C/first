//
//  SingletonServ.h
//  ufenqiDemo
//
//  Created by uchange on 14/12/4.
//  Copyright (c) 2014年 youthcode. All rights reserved.
//

#import <Foundation/Foundation.h>

#import "BaseRequest.h"
#import "BaseResponse.h"

#import "ErrorResponse.h"

#import "AFHTTPRequestOperationManager.h"


// 网络请求处理blockType
typedef void (^ProcessCompleteBlockType)(Jastor *responseDataModel, ErrorResponse *responeseError);

@interface SingletonServ : NSObject

/**
 *  返回网络模块单例
 */
+(SingletonServ*)sharedInstance;

@property (strong, nonatomic) AFHTTPRequestOperationManager *netWorkManager;

/**
 *  处理网络请求
 *
 *  @param requestModel  网络请求对象
 *  @param completeBlock 请求结束Block
 */
- (AFHTTPRequestOperation *)processDataWithReqModel:(BaseRequest *)requestModel
                  completeBlock:(ProcessCompleteBlockType)completeBlock;



@end
