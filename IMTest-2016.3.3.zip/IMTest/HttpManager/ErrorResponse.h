//
//  ErrorResponse.h
//  ufenqi
//
//  Created by mac on 15/1/26.
//  Copyright (c) 2015年 mac. All rights reserved.
//

#import "Jastor.h"

@interface ErrorResponse : Jastor

@property(nonatomic,strong)NSNumber *code;
@property(nonatomic,copy)NSString *message;

@end
