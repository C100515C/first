//
//  ViewController.m
//  IMTest
//
//  Created by chenchen on 16/2/24.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "ViewController.h"
#import "EaseUsersListViewController.h"
#import "EaseMessageViewController.h"
#import "ContactListViewController.h"
#import "ConversationListController.h"
#import "BlackListVC.h"
#import "LYJToolbar.h"

@interface ViewController ()<EMClientDelegate>
- (IBAction)loginAction:(id)sender;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
- (IBAction)getFriendsListVC:(id)sender;
- (IBAction)outLineAction:(id)sender;
- (IBAction)chatlist:(id)sender;
- (IBAction)getBlackList:(id)sender;

@end

@implementation ViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    
    BOOL isAutoLogin = [EMClient sharedClient].options.isAutoLogin;
    self.loginBtn.hidden = isAutoLogin;
    
    LYJToolbar *bar = [[LYJToolbar alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT-44, SCREEN_WIDTH, 44)];
    [self.view addSubview:bar];
    // Do any additional setup after loading the view, typically from a nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (IBAction)loginAction:(id)sender {
    
    BOOL isAutoLogin = [EMClient sharedClient].options.isAutoLogin;
    if (!isAutoLogin) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            EMError *error = [[EMClient sharedClient] loginWithUsername:@"lyj" password:@"11"];
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!error) {
                    MOSLog(@"登陆成功");
                    //设置成自动登陆
                    [[EMClient sharedClient].options setIsAutoLogin:YES];
                    
                }else{
                    MOSLog(@"登陆失败=%@",error.errorDescription);
                }
            });
            
        });
       
    }
}

-(void)didAutoLoginWithError:(EMError*)error{
    MOSLog(@"自动登陆回掉");
}

- (IBAction)getFriendsListVC:(id)sender {
    
    EMError *error = nil;
    NSArray *userlist = [[EMClient sharedClient].contactManager getContactsFromServerWithError:&error];
//    NSArray *userlist = [[EMClient sharedClient].contactManager getContactsFromDB];

    if (!error) {
        NSLog(@"获取成功 -- %@",userlist);
    }
    ContactListViewController *vc = [[ContactListViewController alloc] init];
    
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)outLineAction:(id)sender {
    
    EMError *error = [[EMClient sharedClient] logout:YES];
    if (!error) {
        MOSLog(@"退出成功");
    }

}

- (IBAction)chatlist:(id)sender {
    
    ConversationListController *vc = [[ConversationListController alloc] initWithStyle:UITableViewStylePlain];
    [self.navigationController pushViewController:vc
                                         animated:YES];
    
}

- (IBAction)getBlackList:(id)sender {
    
    BlackListVC *vc = [[BlackListVC alloc] initWithStyle:UITableViewStylePlain];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc
                                         animated:YES];
    
}
@end
