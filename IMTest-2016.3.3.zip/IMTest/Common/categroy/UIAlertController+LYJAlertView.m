//
//  UIAlertController+LYJAlertView.m
//  IMTest
//
//  Created by chenchen on 16/2/25.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "UIAlertController+LYJAlertView.h"

@implementation UIAlertController (LYJAlertView)

+(void)showAlertTltileWith:(NSString *)title andMessage:(NSString *)message andActions:(NSDictionary *)actions andShowVC:(id)showVC andAlertStyle:(UIAlertControllerStyle)style {

    UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(style)];
    
    for (NSString *s in [actions allKeys]) {
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:s style:(UIAlertActionStyleDefault) handler:[actions objectForKey:s]];
        [alertController addAction:okAction];

    }

    [showVC presentViewController:alertController animated:YES completion:nil];
}

@end
