/************************************************************
 *  * EaseMob CONFIDENTIAL
 * __________________
 * Copyright (C) 2013-2014 EaseMob Technologies. All rights reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of EaseMob Technologies.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from EaseMob Technologies.
 */

#import "UserProfileManager.h"

#define kCURRENT_USERNAME [[EMClient sharedClient] currentUsername]

@implementation UIImage (UIImageExt)

- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize
{
    UIImage *sourceImage = self;
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
    if (CGSizeEqualToSize(imageSize, targetSize) == NO)
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        if (widthFactor > heightFactor)
            scaleFactor = widthFactor; // scale to fit height
        else
            scaleFactor = heightFactor; // scale to fit width
        scaledWidth= width * scaleFactor;
        scaledHeight = height * scaleFactor;
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }
        else if (widthFactor < heightFactor)
        {
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }
    UIGraphicsBeginImageContext(targetSize); // this will crop
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width= scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    [sourceImage drawInRect:thumbnailRect];
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil)
        MOSLog(@"could not scale image");
    //pop the context to get back to the default
    UIGraphicsEndImageContext();
    return newImage;
}

@end
static NSString *const user_infor_key = @"user_infor";
static NSString *const user_file = @"user";
static UserProfileManager *sharedInstance = nil;
@interface UserProfileManager ()
{
    NSString *_curusername;
}

@property (nonatomic, strong) NSMutableDictionary *users;
@property (nonatomic, strong) NSString *objectId;

@end

@implementation UserProfileManager

+ (instancetype)sharedInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
    });
    return sharedInstance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
        
    }
    return self;
}

-(void)storeUserInfor:(NSDictionary *)dic{
    
    UserProfileEntity *model = [[UserProfileEntity alloc] initWith:dic];
    //归档
    NSMutableData *aD_data = [[NSMutableData alloc] init];
    NSKeyedArchiver *achiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:aD_data];
    [achiver encodeObject:model forKey:user_infor_key];
    [achiver finishEncoding];
    
    //存数据
    [aD_data writeToFile:[self filePathWith:user_file] atomically:YES];
    
}

//获取文件路径
-(NSString *)filePathWith:(NSString*)filename
{
    NSString *docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)objectAtIndex:0];
    NSString *path = [docPath stringByAppendingPathComponent:filename];
    
    //  NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Caches/texts"]; //两种方法都可以
    
    
    return path;
}

- (void)uploadUserHeadImageProfileInBackground:(UIImage*)image
                           completion:(void (^)(BOOL success, NSError *error))completion
{

}

- (void)updateUserProfileInBackground:(NSDictionary*)param
                           completion:(void (^)(BOOL success, NSError *error))completion
{

}

- (void)loadUserProfileInBackgroundWithBuddy:(NSArray*)buddyList
                                saveToLoacal:(BOOL)save
                                  completion:(void (^)(BOOL success, NSError *error))completion
{
    NSMutableArray *usernames = [NSMutableArray array];
    for (NSString *buddy in buddyList)
    {
        if ([buddy length])
        {
            if (![self getUserProfileByUsername:buddy]) {
                [usernames addObject:buddy];
            }
        }
    }
    if ([usernames count] == 0) {
        if (completion) {
            completion(YES,nil);
        }
        return;
    }
    [self loadUserProfileInBackground:usernames saveToLoacal:save completion:completion];
}

- (void)loadUserProfileInBackground:(NSArray*)usernames
                       saveToLoacal:(BOOL)save
                         completion:(void (^)(BOOL success, NSError *error))completion
{

}

- (UserProfileEntity*)getUserProfileByUsername:(NSString*)username
{
    
    
    return nil;
}

- (UserProfileEntity*)getCurUserProfile
{
    NSMutableData *data1 = [NSMutableData dataWithContentsOfFile:[self filePathWith:user_file]];
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc]initForReadingWithData:data1];
    UserProfileEntity *model  = [unarchiver decodeObjectForKey:user_infor_key];
    
    return model;
}

-(NSString*)getNickNameWithUsername:(NSString*)username{
    UserProfileEntity* entity = [self getUserProfileByUsername:username];
    if (entity.nickname && entity.nickname.length > 0) {
        return entity.nickname;
    } else {
        return username;
    }
}
- (NSString*)getCurUsername
{
    UserProfileEntity* entity = [self getCurUserProfile];
    if (entity.nickname && entity.nickname.length > 0) {
        return entity.nickname;
    } else {
        return @"";
    }
}


@end

@implementation UserProfileEntity


-(id)initWith:(NSDictionary*)dic{
    self = [super init];
    
    if (self) {
        self.objectId = dic[@"objectId"];
        self.username = dic[@"username"];
        self.nickname = dic[@"nickname"];
        self.imageUrl = dic[@"imageUrl"];
        self.signature = dic[@"signature"];
        self.gender = dic[@"gender"];
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder{
    
    NSArray *keys = @[@"objectId",@"username",@"imageUrl",@"nickname",@"signature",@"gender"];
    NSString *objectId = [aDecoder decodeObjectForKey:@"objectId"];
    NSString *username = [aDecoder decodeObjectForKey: @"username"];
    NSString *imageUrl = [aDecoder decodeObjectForKey: @"imageUrl"];
    NSString *nickname = [aDecoder decodeObjectForKey: @"nickname"];
    NSString *signature = [aDecoder decodeObjectForKey: @"signature"];
    NSString *gender = [aDecoder decodeObjectForKey: @"gender"];
    NSArray *values = @[objectId,username,imageUrl,nickname,signature,gender];
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    
    for (int i=0; i<keys.count; i++) {
        [dic setObject:values[i] forKey:keys[i]];
    }
    
    self = [self initWith:dic];
    
    return self;
}

-(void)encodeWithCoder:(NSCoder *)aCoder{
    
    [aCoder encodeObject:self.objectId forKey:@"objectId"];
    [aCoder encodeObject:self.username forKey:@"username"];
    [aCoder encodeObject:self.imageUrl forKey:@"imageUrl"];
    [aCoder encodeObject:self.nickname forKey:@"nickname"];

    [aCoder encodeObject:self.signature forKey:@"signature"];

    [aCoder encodeObject:self.gender forKey:@"gender"];

    
}

@end
