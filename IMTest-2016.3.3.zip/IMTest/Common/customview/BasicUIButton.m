//
//  BasicUIButton.m
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicUIButton.h"

@implementation BasicUIButton

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

-(UIEdgeInsets)imageEdgeInsets{
    UIEdgeInsets  edge = UIEdgeInsetsMake(0, -5, 0, 0);
    return edge;
}

@end
