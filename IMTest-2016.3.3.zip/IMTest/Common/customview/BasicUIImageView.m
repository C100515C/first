//
//  BasicUIImageView.m
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicUIImageView.h"

@implementation BasicUIImageView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super init];
    if (self) {
    
    }
    return self;
}

-(void)setRaduis{
    self.clipsToBounds = YES;
    self.layer.cornerRadius = self.frame.size.width/2.0f;
}
/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
