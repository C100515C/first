//
//  BasicUIImageView.h
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BasicUIImageView : UIImageView

-(void)setRaduis;

@end
