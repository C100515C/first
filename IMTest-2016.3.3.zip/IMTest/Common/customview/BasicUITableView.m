//
//  BasicUITableView.m
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicUITableView.h"

@implementation BasicUITableView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

-(void)awakeFromNib{
    [self tableViewConfig:self];
}
/**
 *  让tableview 线顶着左边
 *
 *  @param table table
 */
-(void)tableViewConfig:(BasicUITableView*)table{
    if ([table respondsToSelector:@selector(setSeparatorInset:)]) {
        [table setSeparatorInset:UIEdgeInsetsZero];
    }
    
    if ([table respondsToSelector:@selector(setLayoutMargins:)]) {
        [table setLayoutMargins:UIEdgeInsetsZero];
    }
}

/**
 *  去掉多余的线
 *
 *  @param table table
 */
-(void)tableViewDeleteBottomLine:(BasicUITableView*)table{
    table.tableFooterView = [[UIView alloc] init];
}



@end
