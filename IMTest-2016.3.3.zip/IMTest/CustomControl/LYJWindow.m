//
//  LYJWindow.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJWindow.h"

@implementation LYJWindow

- (void)sendEvent:(UIEvent *)event {
    
    [super sendEvent:event]; // 《＝＝＝ 不干扰原来的event chain
    
    if(_m_pDelegate) {
        [_m_pDelegate sendEvent:event];
    }
}

@end
