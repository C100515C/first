//
//  UserInforCell.h
//  IMTest
//
//  Created by chenchen on 16/3/3.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"
#import "BasicUIImageView.h"

@class UserProfileEntity;
@interface UserInforCell : BasicTableViewCell

@property (weak, nonatomic) IBOutlet BasicUIImageView *header;
@property (weak, nonatomic) IBOutlet UILabel *nickname;

@property (weak, nonatomic) IBOutlet UIImageView *gender;
@property (weak, nonatomic) IBOutlet UILabel *signature;
@property (weak, nonatomic) IBOutlet UILabel *publishCount;
@property (weak, nonatomic) IBOutlet UILabel *illFriendsCount;

@property (weak, nonatomic) IBOutlet UILabel *anwserCount;

-(void)setCellWithModel:(UserProfileEntity*)model;
@end
