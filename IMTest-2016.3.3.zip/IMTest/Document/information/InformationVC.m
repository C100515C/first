//
//  InformationVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "InformationVC.h"
#import "SelectTableMenuView.h"


@interface InformationVC ()

@property (nonatomic,strong) SelectTableMenuView *menuView;

@end

@implementation InformationVC

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.menuView = [[[NSBundle mainBundle] loadNibNamed:@"SelectTableMenuView" owner:nil options:nil]firstObject];
        [self.view addSubview:_menuView];
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.shouSearch = NO;
    
    self.title = @"消息";
   
    [self moveTablePosition];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)moveTablePosition{
    CGRect frame = self.tableView.frame;
    
    frame.origin.y = frame.origin.y+_menuView.frame.size.height;
    frame.size.height = frame.size.height-_menuView.frame.size.height;
    self.tableView.frame = frame;
}

@end
