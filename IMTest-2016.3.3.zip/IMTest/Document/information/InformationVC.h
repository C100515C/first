//
//  InformationVC.h
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

//#import "BasicVC.h"
#import "ConversationListController.h"


@interface InformationVC : ConversationListController

@end
