//
//  SelectTableMenuView.m
//  IMTest
//
//  Created by chenchen on 16/3/3.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SelectTableMenuView.h"

@interface SelectTableMenuView ()

- (IBAction)noticeAction:(id)sender;

- (IBAction)messageAction:(id)sender;

@property (weak, nonatomic) IBOutlet UILabel *markLabel;
@end

@implementation SelectTableMenuView

-(void)awakeFromNib{
    
}

- (IBAction)noticeAction:(id)sender {
}

- (IBAction)messageAction:(id)sender {
}
@end
