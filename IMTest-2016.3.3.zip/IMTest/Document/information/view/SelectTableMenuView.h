//
//  SelectTableMenuView.h
//  IMTest
//
//  Created by chenchen on 16/3/3.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface SelectTableMenuView : UIView

@end
