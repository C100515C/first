//
//  ContactListViewController.m
//  ChatDemo-UI3.0
//
//  Created by dhc on 15/6/24.
//  Copyright (c) 2015年 easemob.com. All rights reserved.
//

#import "ContactListViewController.h"
//屏蔽群组和 聊天室相关东西  群组和聊天室相关类文件也为导入
//#import "EaseChineseToPinyin.h"
#import "ChatViewController.h"
//#import "RobotListViewController.h"
//#import "ChatroomListViewController.h"
#import "AddFriendViewController.h"
#import "ApplyViewController.h"
#import "EMSearchBar.h"
#import "EMSearchDisplayController.h"
#import "UserProfileManager.h"
#import "RealtimeSearchUtil.h"
#import "UIViewController+HUD.h"
#import "EaseChineseToPinyin.h"

#import "UIAlertController+LYJAlertView.h"

@implementation NSString (search)

//根据用户昵称进行搜索
- (NSString*)showName
{
    return [[UserProfileManager sharedInstance] getNickNameWithUsername:self];
}

@end

@interface ContactListViewController ()<UISearchBarDelegate, UISearchDisplayDelegate,BaseTableCellDelegate,UIActionSheetDelegate,EaseUserCellDelegate>
{
    NSIndexPath *_currentLongPressIndex;
}

@property (strong, nonatomic) NSMutableArray *sectionTitles;
@property (strong, nonatomic) NSMutableArray *contactsSource;

@property (nonatomic) NSInteger unapplyCount;
@property (strong, nonatomic) EMSearchBar *searchBar;

@property (strong, nonatomic) EMSearchDisplayController *searchController;

@end

@implementation ContactListViewController

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
    self.showRefreshHeader = YES;
    
    _contactsSource = [NSMutableArray array];
    _sectionTitles = [NSMutableArray array];
    
    [self tableViewDidTriggerHeaderRefresh];
    
    [self searchController];
    self.searchBar.frame = CGRectMake(0, 0, self.view.frame.size.width, 44);
    [self.view addSubview:self.searchBar];
    
    self.tableView.frame = CGRectMake(0, self.searchBar.frame.size.height, self.view.frame.size.width, self.view.frame.size.height - self.searchBar.frame.size.height);
    
    // 环信UIdemo中有用到Parse, 加载用户好友个人信息
//    [[UserProfileManager sharedInstance] loadUserProfileInBackgroundWithBuddy:self.contactsSource saveToLoacal:YES completion:NULL];
    

}

- (void)viewWillAppear:(BOOL)animated
{
    [super viewWillAppear:animated];
    
    [self reloadApplyView];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - getter

- (NSArray *)rightItems
{
    if (_rightItems == nil) {
        UIButton *addButton = [[UIButton alloc] initWithFrame:CGRectMake(0, 0, 44, 44)];
        [addButton setImage:[UIImage imageNamed:@"addContact.png"] forState:UIControlStateNormal];
        [addButton addTarget:self action:@selector(addContactAction) forControlEvents:UIControlEventTouchUpInside];
        UIBarButtonItem *addItem = [[UIBarButtonItem alloc] initWithCustomView:addButton];
        _rightItems = @[addItem];
    }
    
    return _rightItems;
}

- (UISearchBar *)searchBar
{
    if (_searchBar == nil) {
        _searchBar = [[EMSearchBar alloc] init];
        _searchBar.delegate = self;
        _searchBar.placeholder = NSLocalizedString(@"search", @"Search");
        _searchBar.backgroundColor = [UIColor colorWithRed:0.747 green:0.756 blue:0.751 alpha:1.000];
    }
    
    return _searchBar;
}

- (EMSearchDisplayController *)searchController
{
    if (_searchController == nil) {
        _searchController = [[EMSearchDisplayController alloc] initWithSearchBar:self.searchBar contentsController:self];
        _searchController.delegate = self;
        _searchController.searchResultsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        __weak ContactListViewController *weakSelf = self;
        [_searchController setCellForRowAtIndexPathCompletion:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
            static NSString *CellIdentifier = @"ContactListCell";
            BaseTableViewCell *cell = (BaseTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            
            // Configure the cell...
            if (cell == nil) {
                cell = [[BaseTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            
            NSString *buddy = [weakSelf.searchController.resultsSource objectAtIndex:indexPath.row];
            cell.imageView.image = [UIImage imageNamed:@"chatListCellHead.png"];
            cell.textLabel.text = buddy;
            cell.username = buddy;
            
            return cell;
        }];
        
        [_searchController setHeightForRowAtIndexPathCompletion:^CGFloat(UITableView *tableView, NSIndexPath *indexPath) {
            return 50;
        }];
        
        [_searchController setDidSelectRowAtIndexPathCompletion:^(UITableView *tableView, NSIndexPath *indexPath) {
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            
            NSString *buddy = [weakSelf.searchController.resultsSource objectAtIndex:indexPath.row];
            NSString *loginUsername = [[EMClient sharedClient] currentUsername];
            if (loginUsername && loginUsername.length > 0) {
                if ([loginUsername isEqualToString:buddy]) {
                    
                    UIAlertControllerActionBlock ok=^(UIAlertAction *acton){
                        MOSLog(@"ok");
                    };
                    [UIAlertController showAlertTltileWith:NSLocalizedString(@"prompt", @"Prompt") andMessage:NSLocalizedString(@"friend.notChatSelf", @"can't talk to yourself") andActions:@{NSLocalizedString(@"ok", @"OK"):ok} andShowVC:weakSelf andAlertStyle:UIAlertControllerStyleAlert];
//                    UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"prompt", @"Prompt") message:NSLocalizedString(@"friend.notChatSelf", @"can't talk to yourself") delegate:nil cancelButtonTitle:NSLocalizedString(@"ok", @"OK") otherButtonTitles:nil, nil];
//                    [alertView show];
                    
                    return;
                }
            }
            
            [weakSelf.searchController.searchBar endEditing:YES];
            ChatViewController *chatVC = [[ChatViewController alloc] initWithConversationChatter:buddy
                                                                                conversationType:EMConversationTypeChat];
            chatVC.title = [[UserProfileManager sharedInstance] getNickNameWithUsername:buddy];
            [weakSelf.navigationController pushViewController:chatVC animated:YES];
        }];
    }
    
    return _searchController;
}

#pragma mark - Table view data source
- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.dataArray count] + 1;
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.
    if (section == 0) {
        return 1;//原来为3 但是现在屏蔽掉群组 会话室 改为1
    }
    
    return [[self.dataArray objectAtIndex:(section - 1)] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    NSString *CellIdentifier = [EaseUserCell cellIdentifierWithModel:nil];
    EaseUserCell *cell = (EaseUserCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // Configure the cell...
    if (cell == nil) {
        cell = [[EaseUserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
    }
    
    if (indexPath.section == 0) {
        cell.model = nil;
        if (indexPath.row == 0) {
            NSString *CellIdentifier = @"addFriend";
            EaseUserCell *cell = (EaseUserCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            if (cell == nil) {
                cell = [[EaseUserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            cell.avatarView.image = [UIImage imageNamed:@"newFriends"];
            cell.titleLabel.text = NSLocalizedString(@"title.apply", @"Application and notification");
            cell.avatarView.badge = self.unapplyCount;
            return cell;
        }
        //屏蔽掉 群组和会话室
       /*
        else if (indexPath.row == 1) {
            cell.avatarView.image = [UIImage imageNamed:@"EaseUIResource.bundle/group"];
            cell.titleLabel.text = NSLocalizedString(@"title.group", @"Group");
        }
        else if (indexPath.row == 2) {
            cell.avatarView.image = [UIImage imageNamed:@"EaseUIResource.bundle/group"];
            cell.titleLabel.text = NSLocalizedString(@"title.chatroomlist",@"chatroom list");
        }
        else if (indexPath.row == 3) {
            cell.avatarView.image = [UIImage imageNamed:@"EaseUIResource.bundle/group"];
            cell.titleLabel.text = NSLocalizedString(@"title.robotlist",@"robot list");
        }//*/
    }
    else{
        NSArray *userSection = [self.dataArray objectAtIndex:(indexPath.section - 1)];
        EaseUserModel *model = [userSection objectAtIndex:indexPath.row];
        UserProfileEntity *profileEntity = [[UserProfileManager sharedInstance] getUserProfileByUsername:model.buddy];
        if (profileEntity) {
            model.avatarURLPath = profileEntity.imageUrl;
            model.nickname = profileEntity.nickname == nil ? profileEntity.username : profileEntity.nickname;
        }
        cell.indexPath = indexPath;
        cell.delegate = self;
        cell.model = model;
    }
    
    return cell;
}

#pragma mark - Table view delegate

- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return self.sectionTitles;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        return 0;
    }
    else{
        return 22;
    }
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    if (section == 0)
    {
        return nil;
    }
    
    UIView *contentView = [[UIView alloc] init];
    [contentView setBackgroundColor:[UIColor colorWithRed:0.88 green:0.88 blue:0.88 alpha:1.0]];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 100, 22)];
    label.backgroundColor = [UIColor clearColor];
    [label setText:[self.sectionTitles objectAtIndex:(section - 1)]];
    [contentView addSubview:label];
    return contentView;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
    if (section == 0) {
        if (row == 0) {
            [self.navigationController pushViewController:[ApplyViewController shareController] animated:YES];
        }
        else if (row == 1)
        {
//            if (_groupController == nil) {
//                _groupController = [[GroupListViewController alloc] initWithStyle:UITableViewStylePlain];
//            }
//            else{
//                [_groupController reloadDataSource];
//            }
//            [self.navigationController pushViewController:_groupController animated:YES];
        }
        else if (row == 2)
        {
//            ChatroomListViewController *controller = [[ChatroomListViewController alloc] initWithStyle:UITableViewStylePlain];
//            [self.navigationController pushViewController:controller animated:YES];
        }
        else if (row == 3) {
//            RobotListViewController *robot = [[RobotListViewController alloc] init];
//            [self.navigationController pushViewController:robot animated:YES];
        }
    }
    else{
        EaseUserModel *model = [[self.dataArray objectAtIndex:(section - 1)] objectAtIndex:row];
        NSString *loginUsername = [[EMClient sharedClient] currentUsername];
        if (loginUsername && loginUsername.length > 0) {
            if ([loginUsername isEqualToString:model.buddy]) {
                
                UIAlertControllerActionBlock ok=^(UIAlertAction *acton){
                    MOSLog(@"ok");
                };
                [UIAlertController showAlertTltileWith:NSLocalizedString(@"prompt", @"Prompt") andMessage:NSLocalizedString(@"friend.notChatSelf", @"can't talk to yourself") andActions:@{NSLocalizedString(@"ok", @"OK"):ok} andShowVC:self andAlertStyle:UIAlertControllerStyleAlert];
                
//                UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"prompt", @"Prompt") message:NSLocalizedString(@"friend.notChatSelf", @"can't talk to yourself") delegate:nil cancelButtonTitle:NSLocalizedString(@"ok", @"OK") otherButtonTitles:nil, nil];
//                [alertView show];
                
                return;
            }
        }
        ChatViewController *chatController = [[ChatViewController alloc] initWithConversationChatter:model.buddy conversationType:EMConversationTypeChat];
        chatController.title = model.nickname.length > 0 ? model.nickname : model.buddy;
        [self.navigationController pushViewController:chatController animated:YES];
    }
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.
    if (indexPath.section == 0) {
        return NO;
    }
    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSString *loginUsername = [[EMClient sharedClient] currentUsername];
        EaseUserModel *model = [[self.dataArray objectAtIndex:(indexPath.section - 1)] objectAtIndex:indexPath.row];
        if ([model.buddy isEqualToString:loginUsername]) {
            
            UIAlertControllerActionBlock ok=^(UIAlertAction *acton){
                MOSLog(@"ok");
            };
            [UIAlertController showAlertTltileWith:NSLocalizedString(@"prompt", @"Prompt") andMessage:NSLocalizedString(@"friend.notDeleteSelf", @"can't delete self") andActions:@{NSLocalizedString(@"ok", @"OK"):ok} andShowVC:self andAlertStyle:UIAlertControllerStyleAlert];
            
//            UIAlertView *alertView = [[UIAlertView alloc] initWithTitle:NSLocalizedString(@"prompt", @"Prompt") message:NSLocalizedString(@"friend.notDeleteSelf", @"can't delete self") delegate:nil cancelButtonTitle:NSLocalizedString(@"ok", @"OK") otherButtonTitles:nil, nil];
//            [alertView show];
            
            return;
        }
        
        EMError *error = [[EMClient sharedClient].contactManager deleteContact:model.buddy];
        if (!error) {
            [[EMClient sharedClient].chatManager deleteConversation:model.buddy deleteMessages:YES];
            
            [tableView beginUpdates];
            [[self.dataArray objectAtIndex:(indexPath.section - 1)] removeObjectAtIndex:indexPath.row];
            [self.contactsSource removeObject:model.buddy];
            [tableView  deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            [tableView endUpdates];
        }
        else{
            [self showHint:[NSString stringWithFormat:NSLocalizedString(@"deleteFailed", @"Delete failed:%@"), error.errorDescription]];
            [tableView reloadData];
        }
    }
}

#pragma mark - UISearchBarDelegate

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    [searchBar setShowsCancelButton:YES animated:YES];
    
    return YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    __weak typeof(self) weakSelf = self;
    [[RealtimeSearchUtil currentUtil] realtimeSearchWithSource:self.contactsSource searchText:(NSString *)searchText collationStringSelector:@selector(showName) resultBlock:^(NSArray *results) {
        if (results) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.searchController.resultsSource removeAllObjects];
                [weakSelf.searchController.resultsSource addObjectsFromArray:results];
                [weakSelf.searchController.searchResultsTableView reloadData];
            });
        }
    }];
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar
{
    return YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    searchBar.text = @"";
    [[RealtimeSearchUtil currentUtil] realtimeSearchStop];
    [searchBar resignFirstResponder];
    [searchBar setShowsCancelButton:NO animated:YES];
}

#pragma mark - BaseTableCellDelegate

- (void)cellImageViewLongPressAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0 && indexPath.row >= 1) {
        // 群组，聊天室
        return;
    }
    NSString *loginUsername = [[EMClient sharedClient] currentUsername];
    EaseUserModel *model = [[self.dataArray objectAtIndex:(indexPath.section - 1)] objectAtIndex:indexPath.row];
    if ([model.buddy isEqualToString:loginUsername])
    {
        return;
    }
    
    _currentLongPressIndex = indexPath;
    __weak typeof(self) weakSelf = self;

    UIAlertControllerActionBlock cancel=^(UIAlertAction *action){
        MOSLog(@"cancel");
    };
    UIAlertControllerActionBlock joinBlack = ^(UIAlertAction *action){
        
        if (_currentLongPressIndex) {
            EaseUserModel *model = [[weakSelf.dataArray objectAtIndex:(_currentLongPressIndex.section - 1)] objectAtIndex:_currentLongPressIndex.row];
            [weakSelf showHudInView:weakSelf.view hint:NSLocalizedString(@"wait", @"Pleae wait...")];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                EMError *error = [[EMClient sharedClient].contactManager addUserToBlackList:model.buddy relationshipBoth:YES];
//                [weakSelf hideHud];
                
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (!error) {
                        //由于加入黑名单成功后会刷新黑名单，所以此处不需要再更改好友列表
                        [weakSelf.tableView beginUpdates];
                        [[weakSelf.dataArray objectAtIndex:(_currentLongPressIndex.section - 1)] removeObjectAtIndex:_currentLongPressIndex.row];
                        [weakSelf.contactsSource removeObject:model.buddy];
                        [weakSelf.tableView  deleteRowsAtIndexPaths:[NSArray arrayWithObject:_currentLongPressIndex] withRowAnimation:UITableViewRowAnimationFade];
                        [weakSelf.tableView endUpdates];
                        [weakSelf hideHud];
                        [weakSelf chechSectionSourceWith:_currentLongPressIndex];

                    }
                    else {
                        [weakSelf showHint:error.errorDescription];
                    }
                    _currentLongPressIndex = nil;

                });
                
            });
            
        }
        MOSLog(@"join");
    };
    [UIAlertController showAlertTltileWith:nil andMessage:nil andActions:@{NSLocalizedString(@"cancel", @"Cancel"):cancel,NSLocalizedString(@"friend.block", @"join the blacklist"):joinBlack} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet];
    
//    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"cancel", @"Cancel") destructiveButtonTitle:NSLocalizedString(@"friend.block", @"join the blacklist") otherButtonTitles:nil, nil];
//    [actionSheet showInView:[[UIApplication sharedApplication] keyWindow]];
}

#pragma mark - action

- (void)addContactAction
{
    AddFriendViewController *addController = [[AddFriendViewController alloc] initWithStyle:UITableViewStylePlain];
    [self.navigationController pushViewController:addController animated:YES];
}

#pragma mark - private data

- (void)_sortDataArray:(NSArray *)buddyList
{
    [self.dataArray removeAllObjects];
    [self.sectionTitles removeAllObjects];
    NSMutableArray *contactsSource = [NSMutableArray array];
    
    //从获取的数据中剔除黑名单中的好友
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        NSArray *blockList = [[EMClient sharedClient].contactManager getBlackListFromDB];
        
        for (NSString *buddy in buddyList) {
            if (![blockList containsObject:buddy]) {
                [contactsSource addObject:buddy];
            }
        }
        
        //建立索引的核心, 返回27，是a－z和＃
        UILocalizedIndexedCollation *indexCollation = [UILocalizedIndexedCollation currentCollation];
        [self.sectionTitles addObjectsFromArray:[indexCollation sectionTitles]];
        
        NSInteger highSection = [self.sectionTitles count];
        NSMutableArray *sortedArray = [NSMutableArray arrayWithCapacity:highSection];
        for (int i = 0; i < highSection; i++) {
            NSMutableArray *sectionArray = [NSMutableArray arrayWithCapacity:1];
            [sortedArray addObject:sectionArray];
        }
        
        //按首字母分组
        for (NSString *buddy in contactsSource) {
            EaseUserModel *model = [[EaseUserModel alloc] initWithBuddy:buddy];
            if (model) {
                model.avatarImage = [UIImage imageNamed:@"EaseUIResource.bundle/user"];
                model.nickname = [[UserProfileManager sharedInstance] getNickNameWithUsername:buddy];
                
                NSString *firstLetter = [EaseChineseToPinyin pinyinFromChineseString:[[UserProfileManager sharedInstance] getNickNameWithUsername:buddy]];
                NSInteger section = [indexCollation sectionForObject:[firstLetter substringToIndex:1] collationStringSelector:@selector(uppercaseString)];
                
                NSMutableArray *array = [sortedArray objectAtIndex:section];
                [array addObject:model];
            }
        }
        
        //每个section内的数组排序
        for (int i = 0; i < [sortedArray count]; i++) {
            NSArray *array = [[sortedArray objectAtIndex:i] sortedArrayUsingComparator:^NSComparisonResult(EaseUserModel *obj1, EaseUserModel *obj2) {
                NSString *firstLetter1 = [EaseChineseToPinyin pinyinFromChineseString:obj1.nickname];
                //                    firstLetter1 = [[firstLetter1 substringWithRange:NSMakeRange(1, 1)] uppercaseString];
                firstLetter1 = [[ self secondSubStringWith:firstLetter1] uppercaseString];
                NSString *firstLetter2 = [EaseChineseToPinyin pinyinFromChineseString:obj2.nickname];
                //                    firstLetter2 = [[firstLetter2 substringWithRange:NSMakeRange(1, 1)] uppercaseString];
                firstLetter2 = [[self secondSubStringWith:firstLetter2] uppercaseString];
                
                return [firstLetter1 caseInsensitiveCompare:firstLetter2];
            }];
            
            
            [sortedArray replaceObjectAtIndex:i withObject:[NSMutableArray arrayWithArray:array]];
        }
        
        //去掉空的section
        for (NSInteger i = [sortedArray count] - 1; i >= 0; i--) {
            NSArray *array = [sortedArray objectAtIndex:i];
            if ([array count] == 0) {
                [sortedArray removeObjectAtIndex:i];
                [self.sectionTitles removeObjectAtIndex:i];
            }
        }
        
        [self.dataArray addObjectsFromArray:sortedArray];

        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            [self.tableView reloadData];
            
        });
        
    });
    
}
//按第二个字母排序
-(NSString*)secondSubStringWith:(NSString*)str{
    if (str&&str.length>1) {
        return [str substringWithRange:NSMakeRange(1, 1)];
    }
    return @"a";
}
//没鸡毛用啊这个方法 在研究
-(void)chechSectionSourceWith:(NSIndexPath*)index{
//    NSArray *arr = [self.dataArray objectAtIndex:index.section-1];
//    //一个section刷新
//    if (!arr.count) {
//        NSIndexSet *indexSet=[[NSIndexSet alloc]initWithIndex:index.section-1 ];
//        
//        [self.tableView reloadSections:indexSet withRowAnimation:UITableViewRowAnimationAutomatic];
//    }
    
}

#pragma mark - EaseUserCellDelegate

- (void)cellLongPressAtIndexPath:(NSIndexPath *)indexPath
{
    if (indexPath.section == 0 && indexPath.row >= 1) {
        // 群组，聊天室
        return;
    }
    MOSLog(@"数组＝%@--%ld--%@",self.dataArray,self.dataArray.count,indexPath);
    NSString *loginUsername = [[EMClient sharedClient] currentUsername];
    EaseUserModel *model = [[self.dataArray objectAtIndex:(indexPath.section - 1)] objectAtIndex:indexPath.row];
    if ([model.buddy isEqualToString:loginUsername])
    {
        return;
    }
    
    _currentLongPressIndex = indexPath;
    __weak typeof(self) weakSelf = self;
    UIAlertControllerActionBlock cancel=^(UIAlertAction *action){
        MOSLog(@"cancel");
    };
    
    UIAlertControllerActionBlock joinBlack = ^(UIAlertAction *action){
        
        if (_currentLongPressIndex) {
            EaseUserModel *model = [[weakSelf.dataArray objectAtIndex:(_currentLongPressIndex.section - 1)] objectAtIndex:_currentLongPressIndex.row];
            [weakSelf showHudInView:weakSelf.view hint:NSLocalizedString(@"wait", @"Pleae wait...")];
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                EMError *error = [[EMClient sharedClient].contactManager addUserToBlackList:model.buddy relationshipBoth:YES];
               
                dispatch_async(dispatch_get_main_queue(), ^{
                    if (!error) {
                        //由于加入黑名单成功后会刷新黑名单，所以此处不需要再更改好友列表
                        [weakSelf.tableView beginUpdates];
                        [[weakSelf.dataArray objectAtIndex:(_currentLongPressIndex.section - 1)] removeObjectAtIndex:_currentLongPressIndex.row];
                        [weakSelf.contactsSource removeObject:model.buddy];
                        [weakSelf.tableView  deleteRowsAtIndexPaths:[NSArray arrayWithObject:_currentLongPressIndex] withRowAnimation:UITableViewRowAnimationFade];
                        [weakSelf.tableView endUpdates];
                        [weakSelf chechSectionSourceWith:_currentLongPressIndex];
                        [weakSelf hideHud];

                    }
                    else {
                        [weakSelf showHint:error.errorDescription];
                    }
                    _currentLongPressIndex = nil;

                });
                
            });
            
        }
        MOSLog(@"join");
    };
    [UIAlertController showAlertTltileWith:nil andMessage:nil andActions:@{NSLocalizedString(@"cancel", @"Cancel"):cancel,NSLocalizedString(@"friend.block", @"join the blacklist"):joinBlack} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet];
    
//    UIActionSheet *actionSheet = [[UIActionSheet alloc] initWithTitle:nil delegate:self cancelButtonTitle:NSLocalizedString(@"cancel", @"Cancel") destructiveButtonTitle:NSLocalizedString(@"friend.block", @"join the blacklist") otherButtonTitles:nil, nil];
//    [actionSheet showInView:[[UIApplication sharedApplication] keyWindow]];
}
/*
#pragma mark - UIActionSheetDelegate

- (void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex
{
    if (buttonIndex != actionSheet.cancelButtonIndex && _currentLongPressIndex) {
        EaseUserModel *model = [[self.dataArray objectAtIndex:(_currentLongPressIndex.section - 1)] objectAtIndex:_currentLongPressIndex.row];
        [self showHudInView:self.view hint:NSLocalizedString(@"wait", @"Pleae wait...")];
        
        EMError *error = [[EMClient sharedClient].contactManager addUserToBlackList:model.buddy relationshipBoth:YES];
        [self hideHud];
        if (!error) {
            //由于加入黑名单成功后会刷新黑名单，所以此处不需要再更改好友列表
            [self.tableView beginUpdates];
            [[self.dataArray objectAtIndex:(_currentLongPressIndex.section - 1)] removeObjectAtIndex:_currentLongPressIndex.row];
            [self.contactsSource removeObject:model.buddy];
            [self.tableView  deleteRowsAtIndexPaths:[NSArray arrayWithObject:_currentLongPressIndex] withRowAnimation:UITableViewRowAnimationFade];
            [self.tableView endUpdates];
        }
        else {
            [self showHint:error.errorDescription];
        }
    }
    _currentLongPressIndex = nil;
}//*/

#pragma mark - data

- (void)tableViewDidTriggerHeaderRefresh
{
//    [self showHudInView:self.view hint:NSLocalizedString(@"loadData", @"Load data...")];
    __weak typeof(self) weakself = self;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        EMError *error = nil;
        NSArray *buddyList = [[EMClient sharedClient].contactManager getContactsFromServerWithError:&error];
//        __weak __block EMError *weakError = error;
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!error) {
//                [[EMClient sharedClient].contactManager getBlackListFromServerWithError:&weakError];//暂时屏蔽 未发现此句话作用
                if (!error) {
                    [weakself.contactsSource removeAllObjects];
                    
                    for (NSInteger i = (buddyList.count - 1); i >= 0; i--) {
                        NSString *username = [buddyList objectAtIndex:i];
                        [weakself.contactsSource addObject:username];
                    }
                    
                    NSString *loginUsername = [[EMClient sharedClient] currentUsername];
                    if (loginUsername && loginUsername.length > 0) {
                        [weakself.contactsSource addObject:loginUsername];
                    }
                    dispatch_async(dispatch_get_main_queue(), ^{
                        [weakself _sortDataArray:self.contactsSource];
                    });
                }
            }
            if (error) {
                //            dispatch_async(dispatch_get_main_queue(), ^{
                [weakself showHint:NSLocalizedString(@"loadDataFailed", @"Load data failed.")];
                [weakself reloadDataSource];
                //            });
            }
            [weakself tableViewDidFinishTriggerHeader:YES reload:YES];
        });
        
    });
}

#pragma mark - public

- (void)reloadDataSource
{
    [self.dataArray removeAllObjects];
    [self.contactsSource removeAllObjects];
    
    NSArray *buddyList = [[EMClient sharedClient].contactManager getContactsFromDB];
    
    for (NSString *buddy in buddyList) {
        [self.contactsSource addObject:buddy];
    }
    
    NSString *loginUsername = [[EMClient sharedClient] currentUsername];
    if (loginUsername && loginUsername.length > 0) {
        [self.contactsSource addObject:loginUsername];
    }
    
    [self _sortDataArray:self.contactsSource];
    
    [self.tableView reloadData];
}

- (void)reloadApplyView
{
    NSInteger count = [[[ApplyViewController shareController] dataSource] count];
    self.unapplyCount = count;
    [self.tableView reloadData];
}

- (void)reloadGroupView
{
    [self reloadApplyView];
    
//    if (_groupController) {
//        [_groupController reloadDataSource];
//    }
}

- (void)addFriendAction
{
    AddFriendViewController *addController = [[AddFriendViewController alloc] initWithStyle:UITableViewStylePlain];
    [self.navigationController pushViewController:addController animated:YES];
}

@end
