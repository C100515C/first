//
//  InformationVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "InformationVC.h"
#import "SelectTableMenuView.h"
#import "BasicUITableView.h"
#import "NoticeTableCell.h"

#import "MJRefresh.h"

#import "NoticeCellResponse.h"
#import "NoticeCellRequest.h"
#import "SingletonServ.h"
#import "NoticeDeleteRequest.h"

#import "UIViewController+HUD.h"

#import "PostDetailVC.h"

#import "RootVC.h"
#import "AppDelegate.h"

static NSString * const NoticeCell_id = @"notice";
typedef void (^TableHeaderOrFooterRefFinish)(BOOL isfinish);
typedef void (^OptionFinish)(BOOL isfinish);

@interface InformationVC ()<SelectMenuprotocol>{
//    NSMutableArray *_noticeDataSource;
    int _page;
}

@property (nonatomic,strong) SelectTableMenuView *menuView;
@property (weak, nonatomic) IBOutlet BasicUITableView *noticeTable;
@property (weak, nonatomic) IBOutlet UIImageView *emptyTableTipsImage;
@property (weak, nonatomic) IBOutlet UILabel *emptyTableTipsTitle;
@property (weak, nonatomic) IBOutlet UIView *emptyTableTipsBackView;

//@property (nonatomic,assign) BOOL isShowNotice;

//@property (weak, nonatomic) IBOutlet NSLayoutConstraint *noticeTableCenter_x;

@property (nonatomic,strong)     NSMutableArray *noticeDataSource;
@property (nonatomic,assign) BOOL isNoticeShow;

@end

@implementation InformationVC

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.menuView = [[[NSBundle mainBundle] loadNibNamed:@"SelectTableMenuView" owner:nil options:nil]firstObject]; 
        [self.view addSubview:_menuView];
        
        CGRect frame = self.menuView.frame;
        frame.size.width = SCREEN_WIDTH;
        self.menuView.frame = frame;
        [self.menuView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.view.mas_left).with.offset(0);
            make.top.equalTo (@(0));
            make.right.equalTo(self.view.mas_right).with.offset(0);
            make.height.equalTo(@(frame.size.height));
        }];
        
        self.menuView.delegate = self;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.shouSearch = NO;
    
    self.title = @"消息";
    
    _noticeDataSource = [[NSMutableArray alloc]init];
    _page = 1;
//    self.isShowNotice = YES;
    
    [self moveMessageTablePosition];
    [self setEmptyTableTipsActionWith:YES];
    
    self.noticeTable.delegate = self;
    self.noticeTable.dataSource = self;
    self.tableView.hidden = YES;
    
    [self setNoticeTableRefresh];
    self.isNoticeShow = YES;
    __weak typeof(self) weakself = self;
    self.EaseRefreshFinishBlock = ^(BOOL isFinish){
        [weakself showEmptyTableTipsWith:weakself.isNoticeShow];
    };
    
    [self.noticeTable registerNib:[UINib nibWithNibName:@"NoticeTableCell" bundle:nil] forCellReuseIdentifier:NoticeCell_id];
    
    if ([[UserProfileManager sharedInstance] getLoginState]) {
        [self makeModelWith:_page with:nil andHeaderRef:YES];
    }

    // Do any additional setup after loading the view from its nib.
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    AppDelegate *app = [UIApplication sharedApplication].delegate;
    RootVC *root = (RootVC*)app.window.rootViewController;
    [root getNotRead];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - ui

-(void)setEmptyTableTipsActionWith:(BOOL)isNotice{
    if (isNotice) {
        self.emptyTableTipsImage.image = [UIImage imageNamed:@"meiyoutongzhi"];
        self.emptyTableTipsTitle.text = @"没有通知";
        self.emptyTableTipsBackView.hidden = self.noticeDataSource.count;
    }else{
        self.emptyTableTipsImage.image = [UIImage imageNamed:@"meiyousixin"];
        self.emptyTableTipsTitle.text = @"没有消息";
        self.emptyTableTipsBackView.hidden = self.dataArray.count;

    }
    
}

-(void)showEmptyTableTipsWith:(BOOL)isNotice{
    if (isNotice) {
        self.emptyTableTipsBackView.hidden = _noticeDataSource.count;
    }else {
        self.emptyTableTipsBackView.hidden = self.dataArray.count;

    }
}

/**
 *  根据顶部菜单移动继承的私信table位置 和大小
 */
-(void)moveMessageTablePosition{
    CGRect frame = self.tableView.frame;
    CGFloat width = self.view.frame.size.width;
    
    frame.origin.y = frame.origin.y+_menuView.frame.size.height;
    frame.origin.x = frame.origin.x+width;
    frame.size.height = frame.size.height-_menuView.frame.size.height;
    self.tableView.frame = frame;

}
/**
 *  根据顶部菜单移动消息通知table  位置  和大小
 */
-(void)moveNoticeTablePosition{
    CGRect frame = self.noticeTable.frame;
    
    frame.origin.y = frame.origin.y+_menuView.frame.size.height;
    frame.size.height = frame.size.height-_menuView.frame.size.height;
    self.noticeTable.frame = frame;
}
#pragma mark - data
-(void)makeModelWith:(int)page with:(TableHeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    NoticeCellRequest *req = [[NoticeCellRequest alloc] init];
    req.page = [NSString stringWithFormat:@"%d", page ];
    __weak typeof(self) weakself = self;
//    [self showHudInView:self.view hint:@"加载中..."];
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
       
        if (responeseError==nil) {
            NoticeCellItemsResponse *model = (NoticeCellItemsResponse*)responseDataModel;
            if (isHeaderRef) {
                [_noticeDataSource removeAllObjects];
            }
            [_noticeDataSource addObjectsFromArray:model.items];
            [weakself.noticeTable reloadData];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
        if (finishBlock) {
            finishBlock(YES);
        }
        weakself.emptyTableTipsBackView.hidden = weakself.noticeDataSource.count;
//        [weakself hideHud];
    }];
}

-(void)refreshTableWith:(BOOL)isIM{
    if (!self.isNoticeShow) {
        [self refreshUserInfor];
 
    }else{
        [self makeModelWith:_page with:nil andHeaderRef:YES];

    }
}

-(void)noticeDeleteWiht:(NSIndexPath*)indexpath and:(OptionFinish)block{
    NoticeCellResponse *model = [_noticeDataSource objectAtIndex:indexpath.row];
    NoticeDeleteRequest *req = [[NoticeDeleteRequest alloc] init];
    [req setNoticeIdWith:model.objectId];
    __weak typeof(self) weakself = self;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
       
        if (responeseError==nil) {
            MOSLog(@"%@",responseDataModel);
        }else {
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
        if (block) {
            block(YES);
        }
    }];
}

#pragma mark - mj
/**
 *  为通知table添加刷新
 */
-(void)setNoticeTableRefresh{
    __weak typeof(self) weakself = self;

    self.noticeTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [weakself.noticeTable.mj_header beginRefreshing];

        [weakself noticeTableHeaderRefresh];
    }];
    
    self.noticeTable.mj_footer = [MJRefreshBackNormalFooter footerWithRefreshingBlock:^{
        [weakself.noticeTable.mj_footer beginRefreshing];

        [weakself noticeTableFooterRefresh];
    }];
}

-(void)noticeTableHeaderRefresh{
    __weak typeof(self) weakself = self;
    _page = 1;
    [self makeModelWith:_page with:^(BOOL isfinish) {
        [weakself.noticeTable.mj_header endRefreshing];
        [weakself showEmptyTableTipsWith:weakself.isNoticeShow];
    } andHeaderRef:YES];
}

-(void)noticeTableFooterRefresh{
    __weak typeof(self) weakself = self;
    _page ++;
    [self makeModelWith:_page with:^(BOOL isfinish) {
        [weakself.noticeTable.mj_footer endRefreshing];
        weakself.noticeTable.mj_footer.alpha = 0.0f;
        [weakself showEmptyTableTipsWith:weakself.isNoticeShow];

    } andHeaderRef:NO];

}

#pragma mark - select menu
-(void)selectBtnClickedWith:(SelectMenuSelectBtn)btn{
    
    [self changeTableWith:btn];
}

-(void)changeTableWith:(SelectMenuSelectBtn)btn{

    CGRect noticeFrame = self.noticeTable.frame;
    CGRect messageFrame = self.tableView.frame;
//    CGPoint messageCenter = self.tableView.center;
    CGFloat width = SCREEN_WIDTH;
    
    if (btn==SelectMenuNoticBtn) {
        
        noticeFrame.origin.x = 0.0f;
        messageFrame.origin.x = width;
        
        self.isNoticeShow = YES;
        [self setEmptyTableTipsActionWith:YES];
        
        [UIView animateWithDuration:0.5f animations:^{
            self.tableView.frame = messageFrame;
//            self.noticeTable.frame = noticeFrame;
        } completion:^(BOOL finished) {
            self.noticeTable.hidden = NO;
            self.tableView.hidden = YES;
            [UIView animateWithDuration:0.2 animations:^{
//                self.tableView.frame = messageFrame;
                self.noticeTable.alpha = 1.0f;

            }];
        }];
        
    }else{
        noticeFrame.origin.x = -width;
        messageFrame.origin.x = 0.0f;
        
        self.isNoticeShow = NO;
        [self tableViewDidTriggerHeaderRefresh];
        [self setEmptyTableTipsActionWith:NO];
        
        [UIView animateWithDuration:0.2f animations:^{
//            self.tableView.frame = messageFrame;
//            self.noticeTable.frame = noticeFrame;
            self.noticeTable.alpha = 0.0f;

        } completion:^(BOOL finished) {
            self.tableView.hidden = NO;
            self.noticeTable.hidden = YES;
            [UIView animateWithDuration:0.5 animations:^{
                self.tableView.frame = messageFrame;
            }];

        }];
    }
}

#pragma mark - table
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView==_noticeTable) {
        return _noticeDataSource.count;

    }else{
       return [super tableView:tableView numberOfRowsInSection:section];
    }
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _noticeTable) {
        NoticeTableCell *cell = [tableView dequeueReusableCellWithIdentifier:NoticeCell_id];
        
        if (cell==nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"NoticeTableCell" owner:nil options:nil] firstObject];
        }
        NoticeCellResponse *model = [_noticeDataSource objectAtIndex:indexPath.row];
        [cell setCellWithModel:model];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    }else{
        EaseImageView.appearance.imageCornerRadius = 19.75;
        
        return [super tableView:tableView cellForRowAtIndexPath:indexPath];
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (tableView==_noticeTable) {
        NoticeCellResponse *model = [_noticeDataSource objectAtIndex:indexPath.row];
        return model.cellHeight;
    }else{
        return [super tableView: tableView heightForRowAtIndexPath:indexPath];
    }
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (tableView==_noticeTable) {
        MOSLog(@"通知cell点击");
        NoticeCellResponse *model = [_noticeDataSource objectAtIndex:indexPath.row];
        
        if ([model.system intValue]==1) {
            return;
        }
        PostDetailVC *vc = [[PostDetailVC alloc]init];
        vc.thread_id = model.thread_id;
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
        
    }else{
        [super tableView:tableView didSelectRowAtIndexPath:indexPath];
    }
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
    if (tableView==_noticeTable) {
        MOSLog(@"delete");
//        __weak typeof(self) weakself = self;
        [self noticeDeleteWiht:indexPath and:^(BOOL isfinish) {
            
            [tableView beginUpdates];
            [_noticeDataSource removeObjectAtIndex:indexPath.row];
            [tableView  deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            [tableView endUpdates];
            
//            [weakself showHint:[NSString stringWithFormat:NSLocalizedString(@"deleteFailed", @"Delete failed:%@"), @"成功"]];
        }];
        
    }else{
        [super tableView:tableView commitEditingStyle:editingStyle forRowAtIndexPath:indexPath];
    }
}

@end
