//
//  PostsCell.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostsCell.h"
#import "PostsResponse.h"
#import "UILabel+TapLabel.h"

@interface PostsCell ()<BasicUIImageTapProtocol,tapLabelDelegate>
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

@property (weak, nonatomic) IBOutlet BasicUIImageView *userIcon;
@property (weak, nonatomic) IBOutlet UILabel *userNickname;
@property (weak, nonatomic) IBOutlet UILabel *postsTitle;
@property (weak, nonatomic) IBOutlet BasicLabel *postsKind;
@property (weak, nonatomic) IBOutlet UILabel *userOption;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet BasicUIButton *praiseBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *toBackViewHeight;

@end

@implementation PostsCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [_userIcon setRaduis];
    [_postsKind setBorder];
    [_userIcon setTapUse];
    _userIcon.lyj_delegate = self;
    
    [_userNickname set_LabelTapGesWith:YES andDelegate:self];
    [_userOption set_LabelTapGesWith:YES andDelegate:self];
    [_timeLabel set_LabelTapGesWith:YES andDelegate:self];
    
    _userNickname.tag = PostsHeaderUserName;
    _userOption.tag = PostsHeaderOption;
    _timeLabel.tag = PostsHeaderTime;
}

#pragma mark - view  init

-(void)setCellWith:(PostsResponse *)model{

    self.contentLabel.text = model.postInfo.content;
    self.userNickname.text = model.userInfo.username;
    
    if ([[model.optionStr string] isEqualToString:@"推荐"]) {
        _userOption.userInteractionEnabled = NO;
    }else{
        _userOption.userInteractionEnabled = YES;

    }
    self.userOption.attributedText = model.optionStr;
    
    self.postsKind.text = model.thread.thread_type;
    self.postsKind.LYJ_textColor = [model getLabelColor];
    
    self.postsTitle.text = model.thread.title;
    [self.praiseBtn setTitle:model.thread.post_count forState:UIControlStateNormal];
    self.timeLabel.attributedText = model.timeCircleStr;
    [self.userIcon sd_setImageWithURL:[NSURL URLWithString:model.userInfo.avatar] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.toBackViewHeight.constant = model.topNewHeight;
}

-(void)setAllLayoutIfNeeded{
    [self.contentLabel layoutIfNeeded];
    [self.userNickname layoutIfNeeded];
    [self.userOption layoutIfNeeded];
    [self.postsKind layoutIfNeeded];
    [self.postsTitle layoutIfNeeded];
    [self.praiseBtn layoutIfNeeded];
    [self.timeLabel layoutIfNeeded];
}

#pragma mark - image
-(void)imageTapWith:(UITapGestureRecognizer *)sender{
    if (_headeTap) {
        _headeTap();
    }
}

#pragma mark - label
-(void)tapLabelAction:(UILabel *)currentLabel{
    if (_labelTap) {
        _labelTap((PostsHeaderTapLabelName)currentLabel.tag);
    }
}

@end
