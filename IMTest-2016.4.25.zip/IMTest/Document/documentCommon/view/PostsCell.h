//
//  PostsCell.h
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

@class PostsResponse;
@class BasicUIButton;
@class BasicUIImageView;
@class BasicLabel;
typedef enum {
    PostsHeaderUserName = 10,
    PostsHeaderOption,
    PostsHeaderTime
}PostsHeaderTapLabelName;
static NSString * const PostsCellIdentifier = @"posts";
typedef void (^PostsHeaderIconTapBlock)(void);
typedef void (^PostsHeaderLabelTapBlock)(PostsHeaderTapLabelName labelname);

@interface PostsCell : BasicTableViewCell

@property (nonatomic,copy) PostsHeaderIconTapBlock headeTap;
@property (nonatomic,copy) PostsHeaderLabelTapBlock labelTap;

-(void)setCellWith:(PostsResponse*)model;

@end
