//
//  ProvinceRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface ProvinceRequest : BaseRequest

- (id)init;
@end
