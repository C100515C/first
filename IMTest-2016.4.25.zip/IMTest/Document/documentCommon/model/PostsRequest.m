//
//  PostsRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/24.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostsRequest.h"

@implementation PostsRequest
-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"homes?access-token=%@",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        self.reqMethod = @"GET";
//        self.reqMethod = @"POST";
        self.reqClassName = @"PostsItemList";
    }
    return self;
}
@end
