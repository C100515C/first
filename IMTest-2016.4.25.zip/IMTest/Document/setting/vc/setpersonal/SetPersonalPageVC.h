//
//  SetPersonalPageVC.h
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@protocol SetPersonalProtocol <NSObject>

-(void)finishEditWit:(NSString*)imageurl;

@end

@interface SetPersonalPageVC : BasicVC

@property (nonatomic,assign) id<SetPersonalProtocol>lyj_delegate;

@end
