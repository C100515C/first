//
//  CaseClipDetailRecordCell.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipDetailRecordCell.h"
#import "CaseClipDetailResponse.h"

#import "LYJPicturesBrowse.h"

#import<objc/runtime.h>

static NSString *const DelModelKey = @"del";
static NSString *const EditModelKey = @"edit";

@interface CaseClipDetailRecordCell ()
@property (weak, nonatomic) IBOutlet BasicUIButton *delBtn;

@property (weak, nonatomic) IBOutlet BasicUIButton *editbtn;

@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UILabel *addres;

- (IBAction)deleteBtnClicked:(BasicUIButton *)sender;
- (IBAction)editBtnClicked:(BasicUIButton *)sender;
@property (weak, nonatomic) IBOutlet LYJPicturesBrowse *picsBrowse;

@end

@implementation CaseClipDetailRecordCell

-(void)awakeFromNib{
    
}

-(void)setCellWith:(CaseClipDetailResponse *)model{

    self.time.text = model.time;
    self.addres.text = model.showAddress;
    
    [self setBtnBindModel:model];
    
    UIImage *image = [UIImage imageNamed:@"callBg"];
    UIImage *image1 = [UIImage imageNamed:@"callBg"];
    UIImage *image2 = [UIImage imageNamed:@"chat_location_preview"];
    UIImage *image3 = [UIImage imageNamed:@"callBg"];
    UIImage *image4 = [UIImage imageNamed:@"callBg"];
    UIImage *image5 = [UIImage imageNamed:@"callBg"];

    self.picsBrowse.pics = @[image,image1,image2,image3,image4,image5];
}

-(void)setBtnBindModel:(CaseClipDetailResponse*)model{
    objc_setAssociatedObject(_delBtn, (__bridge const void *)(DelModelKey), model, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(_editbtn, (__bridge const void *)(EditModelKey), model, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

-(CaseClipDetailResponse*)getCellWith:(NSString*)key andObj:(BasicUIButton*)obj{
    CaseClipDetailResponse *model = (CaseClipDetailResponse*) objc_getAssociatedObject(obj, (__bridge const void *)(key));
    return model;
}

- (IBAction)deleteBtnClicked:(BasicUIButton *)sender {
//    MOSLog(@"xx");
    
    if (_delBtnClickedBlock) {
        _delBtnClickedBlock([self getCellWith:DelModelKey andObj:sender]);
    }
}

- (IBAction)editBtnClicked:(BasicUIButton *)sender {
//    MOSLog(@"xx");

    if (_editBtnClickedBlock) {
        _editBtnClickedBlock([self getCellWith:EditModelKey andObj:sender]);
    }
}

@end
