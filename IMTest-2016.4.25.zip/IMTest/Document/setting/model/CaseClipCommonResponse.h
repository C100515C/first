//
//  CaseClipCommonResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface CaseClipCommonResponse : BasicResponse

@property (nonatomic,copy) NSString *nameTitle;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,assign) BOOL isHideImage;


@end
