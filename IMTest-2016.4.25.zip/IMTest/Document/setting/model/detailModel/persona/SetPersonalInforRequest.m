//
//  SetPersonalInforRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SetPersonalInforRequest.h"
#import "SetPersonalPageResponse.h"
#import "JastorRuntimeHelper.h"
#import <objc/runtime.h>

@implementation SetPersonalInforRequest

- (id)init
{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"users?access-token=%@",token];
        
        //        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"SetPersonalPage";
    }
    return self;
}

-(void)setParamaWith:(NSArray *)parama withProAndCity:(NSString *)str{

    NSArray *dic = [JastorRuntimeHelper propertyNames:[self class]];
    for (SetPersonalPageResponse *model in parama) {
        NSString *key = model.key;
        NSString *content = model.content;
        if ([key isEqualToString:@"gender"]) {
            if ([content isEqualToString:@"男"]) {
                content = @"1";
            }else if([content isEqualToString:@"女"]){
                content = @"2";
            }else{
                content = @"0";
            }
        }
        
        if ([key isEqualToString:@"signature"]) {
            if (content.length==0) {
                content = @"这个人很懒，什么也没留下";
            }
        }
        
        for (NSString *dicKey in dic) {
            if ([key isEqualToString:dicKey]) {
                [self setValue:content forKey:dicKey];
            }
        }
    }
    
    NSArray *arr = [str componentsSeparatedByString:@"-"];
    
    [self setValue:[arr firstObject] forKey:@"province"];
    [self setValue:[arr lastObject] forKey:@"city"];

}

@end
