//
//  SetPersonalPageResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

typedef enum {

    SetPersonalPageResponseShowImage,
    SetPersonalPageResponseShowtitle,
    SetPersonalPageResponseShowDes
    
}SetPersonalPageResponseStyle;

@interface SetPersonalPageResponse : BasicResponse
/**
 *  获取数据属性
 */
@property (nonatomic,copy) NSString *key;
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,assign) SetPersonalPageResponseStyle style;

@property (nonatomic,copy) NSString *avatar;
/**
 *  上传 参数 属性
 */
//@property (nonatomic,copy) NSString *headerIcon;
//@property (nonatomic,copy) NSString *birthday;
//@property (nonatomic,copy) NSString *gender;
//@property (nonatomic,copy) NSString *address;
//@property (nonatomic,copy) NSString *signature;
//@property (nonatomic,copy) NSString *;


@end
