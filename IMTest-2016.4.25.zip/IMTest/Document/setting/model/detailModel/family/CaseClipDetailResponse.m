//
//  CaseClipDetailResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipDetailResponse.h"

static const CGFloat BasicHeight = 160.0f;

@implementation CaseClipDetailResponse


-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }
    
    _cellHeight = BasicHeight;
    
    return _cellHeight;
}

-(NSString*)showAddress{
    if (_showAddress) {
        return _showAddress;
    }else{
        _showAddress = [NSString stringWithFormat:@"%@/%@",self.address,self.type];
        return _showAddress;
    }
}

@end
