//
//  PostDetailHeaderResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface PostDetailHeaderResponse : BasicResponse

@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *updated_at;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *username;
@property (nonatomic,copy) NSString *board_id;
@property (nonatomic,copy) NSString *post_count;
@property (nonatomic,copy) NSString *edited_at;
@property (nonatomic,copy) NSString *status;
@property (nonatomic,copy) NSString *sources;
@property (nonatomic,copy) NSString *forum_id;
@property (nonatomic,copy) NSString *forum_name;
@property (nonatomic,copy) NSString *thread_status;
@property (nonatomic,copy) NSString *thread_type;
@property (nonatomic,copy) NSString *browse_count;
@property (nonatomic,copy) NSString *shares_count;
@property (nonatomic,copy) NSString *collect_count;
@property (nonatomic,copy) NSString *attention_count;
@property (nonatomic,copy) NSString *avatar;
@property (nonatomic,copy) NSString *attentionAction;
@property (nonatomic,copy) NSString *collectAction;
@property (nonatomic,copy) NSString *shareAction;

@property (nonatomic,assign) CGFloat topnewHeight;
@property (nonatomic,assign) CGFloat middleNewHeight;
@property (nonatomic,assign) CGFloat picHeight;

-(UIColor*)getLabelColor;
@end
