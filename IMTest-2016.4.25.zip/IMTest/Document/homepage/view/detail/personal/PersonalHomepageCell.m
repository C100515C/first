//
//  PersonalHomepageCell.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalHomepageCell.h"
#import "PersonalHomepageResponse.h"
#import "CC_LabelsOfView.h"

@interface PersonalHomepageCell ()<BasicUIImageTapProtocol>
@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;
@property (weak, nonatomic) IBOutlet UILabel *nickname;
@property (weak, nonatomic) IBOutlet UIImageView *gender;
@property (weak, nonatomic) IBOutlet UILabel *addressed;
@property (weak, nonatomic) IBOutlet UILabel *answerCount;
@property (weak, nonatomic) IBOutlet UILabel *publishedCount;

@property (weak, nonatomic) IBOutlet UILabel *illFriendsCount;

@property (weak, nonatomic) IBOutlet CC_LabelsOfView *focusLabelView;
@property (weak, nonatomic) IBOutlet UILabel *signature;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *focusLabelViewHeight;
@property (weak, nonatomic) IBOutlet UILabel *theAnswer;
@property (weak, nonatomic) IBOutlet UILabel *thePublic;
@property (weak, nonatomic) IBOutlet UILabel *theFriend;

@end

@implementation PersonalHomepageCell

-(void)setIsMySelf:(BOOL)isMySelf and:(BOOL)isman{
    if (isMySelf) {
        self.theAnswer.text = @"我的回答";
        self.theFriend.text = @"我的病友";
        self.thePublic.text = @"我的发表";
    }else{
        self.theAnswer.text = @"他的回答";
        self.theFriend.text = @"他的病友";
        self.thePublic.text = @"他的发表";
        if (!isman) {
            self.theAnswer.text = @"她的回答";
            self.theFriend.text = @"她的病友";
            self.thePublic.text = @"她的发表";
        }
    }
}

-(void)setCellWithModel:(PersonalHomepageResponse *)model{
    
    self.nickname.text = model.username;
    self.addressed.text = model.location;
    [self.focusLabelView set_MyLabelsCanChangeRowsWith:[model getForumLabelNames]];
    self.focusLabelViewHeight.constant = model.focusLabelHeight;
    self.signature.text = model.signature;
    self.answerCount.text = [NSString stringWithFormat:@"%@",model.post_count];
    self.publishedCount.text = [NSString stringWithFormat:@"%@",model.thread_count];
    self.illFriendsCount.text = [NSString stringWithFormat:@"%@",model.following_count];
    [self.headerIcon sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"sctx"]];
    if ([model.gender isEqualToString:@"1"]) {
        self.gender.image = [UIImage imageNamed:@"icon_sm"];
    }else if([model.gender isEqualToString:@"2"]){
        self.gender.image = [UIImage imageNamed:@"icon_sw"];
    }else {
        self.gender.image = [UIImage imageNamed:@""];
    }
    
    [self setIsMySelf:self.isMySelf and:2-[model.gender intValue]];
}

-(void)setCellWithUserModel:(UserProfileEntity *)model{
    self.nickname.text = model.username;
    self.addressed.text = model.location;
    [self.focusLabelView set_MyLabelsCanChangeRowsWith:[model getForumLabelNames]];
    
    self.focusLabelViewHeight.constant = model.focusLabelHeight;
    self.signature.text = model.signature;
    self.answerCount.text = [NSString stringWithFormat:@"%@",model.post_count];
    self.publishedCount.text = [NSString stringWithFormat:@"%@",model.thread_count];
    self.illFriendsCount.text = [NSString stringWithFormat:@"%@",model.following_count];
    [self.headerIcon sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"sctx"]];
    if ([model.gender isEqualToString:@"1"]) {
        self.gender.image = [UIImage imageNamed:@"icon_sm"];
    }else if([model.gender isEqualToString:@"2"]){
        self.gender.image = [UIImage imageNamed:@"icon_sw"];
    }else {
        self.gender.image = [UIImage imageNamed:@""];
    }
    [self setIsMySelf:self.isMySelf and:2-[model.gender intValue]];

}

-(void)awakeFromNib{
    [super awakeFromNib];

    [self.headerIcon setRaduis];
    [self.headerIcon setTapUse];
    self.headerIcon.lyj_delegate = self;
    
    _focusLabelView.isCanClicked = YES;
    [_focusLabelView setStart_x:0 andY:5.0f andInterval:5.0f andLabelHeight:20.0f andEndDistance:10.0f andLabelType:CCBlueFrameLabel];
    
    _focusLabelView.CC_LabelTapBlock = ^(NSInteger index){

        if (_PersonalHeaderLabelTapBlock) {
            _PersonalHeaderLabelTapBlock(index);
        }
    };
}


#pragma mark - image tap
-(void)imageTapWith:(UITapGestureRecognizer *)sender{
    if (_tapBlock) {
        _tapBlock();
    }
}

@end
