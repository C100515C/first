//
//  PostRepeatCell.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostRepeatCell.h"
#import "PostRepeatListResponse.h"
#import "UILabel+TapLabel.h"

@interface PostRepeatCell ()<tapLabelDelegate,BasicUIImageTapProtocol>
@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;
@property (weak, nonatomic) IBOutlet UILabel *nicknameLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet BasicUIButton *praiseBtn;
@property (weak, nonatomic) IBOutlet BasicUIButton *repeatCount;

@property (nonatomic,copy) NSString *userID;
@end

@implementation PostRepeatCell

-(void)awakeFromNib{
    [super awakeFromNib];

    self.userInteractionEnabled = YES;
    UILongPressGestureRecognizer *longpress = [[UILongPressGestureRecognizer alloc] initWithTarget:self action:@selector(cellLongPressAction:)];
    
    [self addGestureRecognizer:longpress];
    self.praiseBtn.imageFrame = CGRectMake(3, 1, 16, 16);
    [self.headerIcon setRaduis];
    
    [self.praiseBtn addTarget:self action:@selector(btnClickedAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.repeatCount addTarget:self action:@selector(btnClickedAction:) forControlEvents:UIControlEventTouchUpInside];
    self.praiseBtn.tag = PostRepeatCellPraiseBtn;
    self.repeatCount.tag = PostRepeatCellRepeatBtn;

    [self.headerIcon setTapUse];
    self.headerIcon.lyj_delegate = self;
    [self.nicknameLabel set_LabelTapGesWith:YES andDelegate:self];
}

-(void)setCellWith:(PostRepeatListResponse *)model{
    MOSLog(@"评论");
    self.contentLabel.text = model.content;
    self.nicknameLabel.text = model.userInfo.username;
    
    [self.praiseBtn setTitle:model.praise_count forState:UIControlStateNormal];
    if ([model.praiseAction intValue]==1) {
        [self.praiseBtn setImage:[UIImage imageNamed:@"icon_dianzhan1"] forState:UIControlStateNormal];

    }else{
        [self.praiseBtn setImage:[UIImage imageNamed:@"icon_dianzhan2"] forState:UIControlStateNormal];

    }
    
    [self.repeatCount setTitle:model.comment_count forState:UIControlStateNormal];

    self.timeLabel.text = model.created_at;
    [self.headerIcon sd_setImageWithURL:[NSURL URLWithString:model.userInfo.avatar] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.userID = model.user_id;
}

-(void)cellLongPressAction:(UILongPressGestureRecognizer*)sender{
    
    if (_longPressBlock) {
        _longPressBlock(sender);
    }
}

-(void)btnClickedAction:(UIButton*)sender{
    if (_btnBlock) {
        _btnBlock((int)sender.tag);
    }
}
#pragma mark - image tap 
-(void)imageTapWith:(UITapGestureRecognizer *)sender{
    if (_tapBlock) {
        _tapBlock(_userID);
    }
}


#pragma mark - label
-(void)tapLabelAction:(UILabel *)currentLabel{
    if (_tapBlock) {
        _tapBlock(_userID);
    }
}

@end
