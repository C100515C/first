//
//  HomePageVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "HomePageVC.h"

#import "PostsCell.h"
#import "BasicUITableView.h"

#import "PostDetailVC.h"
#import "PersonalHomepageVC.h"
#import "circleDetailVC.h"

#import "SingletonServ.h"
#import "PostsRequest.h"
#import "PostsResponse.h"

#import "UIViewController+HUD.h"

@interface HomePageVC (){
//    NSMutableArray *_dataSource;
    int _page;
}

@property (weak, nonatomic) IBOutlet BasicUITableView *myTable;
@property (strong,nonatomic) NSMutableArray *dataSource;
@end

@implementation HomePageVC


- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    [super viewDidLoad];
    
    self.title = @"优爱病友";
    
    __weak typeof(self) weakself = self;
    [self.emptyTableTipsView setAlertImageWith:@"meiyouguanzhu" andTitle:@"快去看看有没有新发现"];
    self.tableFinish = ^(BOOL finish){
        weakself.emptyTableTipsView.hidden = weakself.dataSource.count;
    };
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _page = 1;
    _dataSource = [[NSMutableArray alloc] init];
    [self.tableView registerNib:[UINib nibWithNibName:@"PostsCell" bundle:nil] forCellReuseIdentifier:PostsCellIdentifier];
    
    if ([[UserProfileManager sharedInstance] getLoginState]) {
        [self showHudInView:self.view hint:@"加载中..."];
        [self makeModelWith:_page with:nil andHeaderRef:YES];

    }
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    self.tabBarController.tabBar.hidden = NO;
}
#pragma mark - net work
-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    self.dataSearchSource = [NSMutableArray array];

    PostsRequest *req = [[PostsRequest alloc] init];
    req.page = [NSString stringWithFormat:@"%d",page];
    req.reqUrlPath = [NSString stringWithFormat:@"%@&",req.reqUrlPath];
    
    __weak typeof(self) weakself = self;

    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            PostsItemListResponse *model = (PostsItemListResponse*)responseDataModel;
//            MOSLog(@"%@",model.items);
            
            if (isHeaderRef) {
                [_dataSource removeAllObjects];
            }
            
            [_dataSource addObjectsFromArray:model.items];
            [_myTable reloadData];

        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
        if (finishBlock) {
            finishBlock(YES);
        }
        weakself.emptyTableTipsView.hidden = weakself.dataSource.count;
        [weakself hideHud];
    }];
}

-(void)refreshTable{
//    [self tableViewDidTriggerHeaderRefresh];
    _page = 1;
//    __weak typeof(self) weakself = self;
    
    [self makeModelWith:_page with:^(BOOL finish) {
        
    } andHeaderRef:YES];
}

- (void)tableViewDidTriggerHeaderRefresh{
    _page = 1;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];

    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:YES reload:NO];

    } andHeaderRef:YES];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    _page ++;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];

    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:NO reload:NO];
        
    } andHeaderRef:NO];

}//上拉加载事件

#pragma mark - table

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    PostsResponse *model = (PostsResponse*)[_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    PostsCell *cell = [tableView dequeueReusableCellWithIdentifier:PostsCellIdentifier];
    
    if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"PostsCell" owner:nil options:nil] firstObject];
    }
    PostsResponse *model = (PostsResponse*)[_dataSource objectAtIndex:indexPath.row];

    [cell setCellWith:model];
    
    __weak typeof(PostsResponse*) weakmodel = model;
    __weak typeof (self) weakself = self;
    cell.headeTap = ^{
        [weakself pushHeaderPersonalVCWith:weakmodel.userInfo.user_id];
    };
    cell.labelTap = ^(PostsHeaderTapLabelName labelname){
        if (labelname==PostsHeaderTime) {
            [weakself pushHeaderForumVCWith:weakmodel.thread.forum_id];
        }else if(labelname==PostsHeaderOption){
            [weakself pushHeaderPersonalVCWith:weakmodel.itemInfo.user_id];

        }else if(labelname==PostsHeaderUserName){
            [weakself pushHeaderPersonalVCWith:weakmodel.userInfo.user_id];

        }
    };
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;

    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    PostsResponse *model = (PostsResponse*)[_dataSource objectAtIndex:indexPath.row];
    
    PostDetailVC *vc = [[PostDetailVC alloc] init];
    vc.hidesBottomBarWhenPushed = YES;
    vc.thread_id = model.thread_id;
    vc.post_id = model.post_id;
    vc.title = [NSString stringWithFormat:@"%@详情",model.forum_name];
    [self.navigationController pushViewController:vc animated:YES];
    
}

-(void)pushHeaderPersonalVCWith:(NSString*)userid{
    PersonalHomepageVC *vc = [[PersonalHomepageVC alloc] init];
    vc.userid = userid;
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

-(void)pushHeaderForumVCWith:(NSString*)forum_id{
    circleDetailVC *vc = [[circleDetailVC alloc] init];
    vc.forum_id = forum_id;
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
