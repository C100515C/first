//
//  CCCollectionReusableView.m
//  test
//
//  Created by MS on 16-1-23.
//  Copyright (c) 2016年 MS. All rights reserved.
//

#import "CCCollectionReusableView.h"
#import "LYJBannerView.h"

@interface CCCollectionReusableView ()
@property (nonatomic,strong) LYJBannerView *bannerView;

@end

@implementation CCCollectionReusableView

- (void)awakeFromNib {
    // Initialization code
    self.bannerView = [[LYJBannerView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 100)];
    [self addSubview:_bannerView];
    [self.bannerView timerStart];
}

-(void)bannerStart{
    [self.bannerView timerStart];

}

-(void)bannerOver{
    [self.bannerView overTimer];

}

@end
