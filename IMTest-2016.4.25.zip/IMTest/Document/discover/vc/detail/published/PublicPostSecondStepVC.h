//
//  PublicPostSecondStepVC.h
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface PublicPostSecondStepVC : BasicVC

@property (nonatomic,copy) NSString *forum_id;
@property (nonatomic,copy) NSString *thread_type;
@property (nonatomic,copy) NSString *post_title;

@end
