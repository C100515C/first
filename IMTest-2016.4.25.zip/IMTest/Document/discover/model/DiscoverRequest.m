//
//  DiscoverRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "DiscoverRequest.h"

@implementation DiscoverRequest

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"finds?access-token=%@",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        self.reqMethod = @"GET";
//        self.reqMethod = @"POST";
        self.reqClassName = @"Discover";
    }
    return self;
}

@end
