//
//  CircleFriendsResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/15.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface CircleFriendsResponse : BasicResponse

@property (nonatomic,copy) NSString *username;
@property (nonatomic,copy) NSString *signature;
@property (nonatomic,copy) NSString *gender;
@property (nonatomic,copy) NSString *avatar;
@property (nonatomic,copy) NSString *recently_online;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSArray *forum_label;

@property (nonatomic,assign) CGFloat labelBackViewHeight;

-(NSArray*)getForumLabelNames;
+(Class)forum_label_class;
@end

@interface CircleFriends_metaResponse : BasicResponse
@property (nonatomic,copy) NSString *totalCount;
@property (nonatomic,copy) NSString *pageCount;
@property (nonatomic,copy) NSString *currentPage;
@property (nonatomic,copy) NSString *perPage;
@end

@interface CircleFriendsItemsResponse : BasicResponse

@property (nonatomic,strong) NSMutableArray *items;
@property (nonatomic,strong) CircleFriends_metaResponse *_meta;

+(Class)items_class;

@end
