//
//  CheckPhoneRegisterRequest.h
//  IMTest
//
//  Created by chenchen on 16/4/14.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"
#import "BasicResponse.h"

@interface CheckPhoneRegisterRequest : BaseRequest
@property (strong, nonatomic) NSString *phone;

- (id)init;
@end

@interface CheckPhoneRegisterResponse : BasicResponse

@end