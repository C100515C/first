//
//  BaseRequest.h
//  ufenqiDemo
//
//  Created by uchange on 14/12/3.
//  Copyright (c) 2014年 youthcode. All rights reserved.
//

#import "Jastor.h"
#import "NSString+UrlCode.h"

@interface BaseRequest : Jastor

@property (strong, nonatomic) NSString *reqUrlPath;   // 请求路径
@property (strong, nonatomic) NSString *reqMethod;    // 请求方法 // GET,POST,PUT,DELETE
@property (strong, nonatomic) NSString *reqClassName; // 例如: "Provinces"


@end
