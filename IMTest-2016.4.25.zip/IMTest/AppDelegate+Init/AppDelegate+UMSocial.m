
//
//  AppDelegate+UMSocial.m
//  IMTest
//
//  Created by chenchen on 16/3/9.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "AppDelegate+UMSocial.h"
#import "UMSocial.h"

#import "UMSocialWechatHandler.h"
#import "UMSocialQQHandler.h"
#import "UMSocialSinaSSOHandler.h"
#import "UMFeedback.h"

@implementation AppDelegate (UMSocial)

- (void)umSocialApplication:(UIApplication *)application
didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
                     appkey:(NSString *)appkey
               apnsCertName:(NSString *)apnsCertName
                otherConfig:(NSDictionary *)otherConfig{
    
    [UMSocialData setAppKey:appkey];
    [UMFeedback setAppkey:appkey];

//    [UMSocialSinaSSOHandler openNewSinaSSOWithRedirectURL:@"http://sns.whalecloud.com/sina2/callback"
    
    [UMSocialSinaSSOHandler openNewSinaSSOWithAppKey:@"3955444979"
                                              secret:@"cd23538ded978dd7651ee63799cfef19"
                                         RedirectURL:@"http://sns.whalecloud.com/sina2/callback"];
    //设置微信AppId，设置分享url，默认使用友盟的网址
    [UMSocialWechatHandler setWXAppId:@"wxd930ea5d5a258f4f" appSecret:@"db426a9829e4b49a0dcac7b4162da6b6" url:TBXL];//
    
    //设置分享到QQ空间的应用Id，和分享url 链接
    [UMSocialQQHandler setQQWithAppId:@"100424468" appKey:@"c7394704798a158208a74ab60104f0ba" url:TBXL];
    
}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    BOOL result = [UMSocialSnsService handleOpenURL:url];
    if (result == FALSE) {
        //调用其他SDK，例如支付宝SDK等
    }
    return result;
}

@end
