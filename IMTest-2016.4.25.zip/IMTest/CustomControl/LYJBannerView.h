//
//  LYJBannerView.h
//  IMTest
//
//  Created by chenchen on 16/3/10.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>


@interface LYJBannerView : UIView

-(void)reloadTableWithDataSource:(NSDictionary*)dic;

-(void)timerStart;
-(void)overTimer;

@end

