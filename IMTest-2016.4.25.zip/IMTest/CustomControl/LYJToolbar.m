//
//  LYJToolbar.m
//  IMTest
//
//  Created by chenchen on 16/2/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJToolbar.h"
static const CGFloat keyboard_height = 0.0f;
@interface LYJToolbar ()<UITextFieldDelegate>{

    UITextField *_textField;
    UIButton *_sendBtn;
    UIView *_backgroundView;
    CGRect _selfOriginalFrame;
}

@property (nonatomic,assign) BOOL keyboardAppear;

@end

@implementation LYJToolbar

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    
    if (self) {
        
        self.backgroundColor = [UIColor whiteColor];
        
        _selfOriginalFrame = frame;
        _backgroundView = [[UIView alloc] initWithFrame:frame];
        _backgroundView.backgroundColor = [UIColor clearColor];
        [self addSubview:_backgroundView];

        _textField = [[UITextField alloc] initWithFrame:CGRectZero];
        _textField.delegate = self;
        [_backgroundView addSubview:_textField];
        _textField.placeholder = @"请输入您回复的内容";
        
        _sendBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _sendBtn.frame = CGRectZero;
        [_backgroundView addSubview:_sendBtn];
        [_sendBtn addTarget:self action:@selector(sendBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        
        self.keyboardAppear = NO;
        self.isNotice = NO;
        
        [self interfaceLayout];
    }
    
    return self;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];

}

-(void)setTextPlaceholder:(NSString *)textPlaceholder{
    _textField.placeholder = textPlaceholder;

}

-(void)setIsNotice:(BOOL)isNotice{
    if (isNotice) {
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillAppear:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keboardWillDisappeat:) name:UIKeyboardWillHideNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidAppear:) name:UIKeyboardDidShowNotification object:nil];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keboardDidDisappeat:) name:UIKeyboardDidHideNotification object:nil];
                

    }
    _isNotice = isNotice;
}



-(void)drawRect:(CGRect)rect{
    [super drawRect:rect];
    
    CGContextRef ctx = UIGraphicsGetCurrentContext();
    
    //    [[UIColor yellowColor] set];
    
    CGContextSetLineWidth(ctx, 1.0);// 线条宽度设置为1
    CGContextSetStrokeColorWithColor(ctx, [UIColor grayColor].CGColor);
    
    CGPoint startPoint = CGPointMake(20, 5);
    CGPoint centerPointLeft = CGPointMake(20, 22);
    CGPoint thirdPoint = CGPointMake(SCREEN_WIDTH-20, 39);
    CGPoint centerPointRight = CGPointMake(SCREEN_WIDTH-20, 22);
    CGFloat radius = 17.0f;
    
    CGPoint anglePoint = CGPointMake(20-7, 35-5);
    CGPoint anglePoint1 = CGPointMake(23-7, 29-5);
    CGPoint anglePoint2 = CGPointMake(31-7, 22-5);
    CGPoint anglePoint3 = CGPointMake(35-7, 27-5);
    CGPoint anglePoint4 = CGPointMake(27-7, 34-5);
    
    CGContextMoveToPoint(ctx, startPoint.x, startPoint.y);
    
    CGContextAddArc(ctx, centerPointLeft.x, centerPointLeft.y, radius, -M_PI/2.0, M_PI/2.0, -1);
    
    
    CGContextAddLineToPoint(ctx, thirdPoint.x, thirdPoint.y);
    
    CGContextAddArc(ctx, centerPointRight.x, centerPointRight.y, radius, M_PI/2.0, -M_PI/2.0, -1);
    
    CGContextClosePath(ctx);
    CGContextStrokePath(ctx);
    
    CGContextMoveToPoint(ctx, anglePoint.x, anglePoint.y);
    CGContextAddLineToPoint(ctx, anglePoint1.x, anglePoint1.y);
    CGContextAddLineToPoint(ctx, anglePoint2.x, anglePoint2.y);
    CGContextAddLineToPoint(ctx, anglePoint3.x, anglePoint3.y);
    CGContextAddLineToPoint(ctx, anglePoint4.x, anglePoint4.y);
    
    CGContextClosePath(ctx);
    CGContextStrokePath(ctx);
    
    CGContextMoveToPoint(ctx, anglePoint1.x, anglePoint1.y);
    CGContextAddLineToPoint(ctx, anglePoint4.x, anglePoint4.y);
    CGContextStrokePath(ctx);
}

#pragma mark - 布局
-(void)interfaceLayout{
    
    [[self layer] setShadowOffset:CGSizeMake(0, -0.5)];
    [[self layer] setShadowColor:[UIColor lightGrayColor].CGColor];
    [[self layer] setShadowRadius:0.5];
    [[self layer] setShadowOpacity:1];
    
    CGFloat self_w = self.frame.size.width;
//    CGFloat self_h = self.frame.size.height;
    
    CGFloat spacing = 30.0f;
    CGFloat btn_w = 45.0f;
    CGFloat btn_h = 34.0f;
    CGFloat textField_w = self_w-2*spacing;
    
    _textField.frame = CGRectMake(spacing, spacing/5.0f, textField_w, btn_h);
    _sendBtn.frame = CGRectMake(spacing*2+textField_w, spacing/5.0f, btn_w, btn_w);
    
    _textField.borderStyle = UITextBorderStyleNone;
    _sendBtn.clipsToBounds = YES;
    _sendBtn.layer.cornerRadius  = 3.0f;
    _sendBtn.backgroundColor = [UIColor greenColor];
    [_sendBtn setTitle:@"发送" forState:UIControlStateNormal];
    
    [_backgroundView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self);
        make.width.equalTo(self);
        make.height.equalTo(self);
    }];
    
    [_textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_backgroundView.mas_left).with.offset(spacing);
        make.top.equalTo (_backgroundView.mas_top).with.offset(spacing/5.0f);
        make.right.equalTo(_backgroundView.mas_right).with.offset(-spacing);
        make.height.equalTo(@(btn_h));
    }];
    
    [_sendBtn mas_makeConstraints:^(MASConstraintMaker *make) {
       
        make.top.equalTo (@(spacing/5.0f));
        make.right.equalTo(_backgroundView.mas_right).with.offset(-spacing);
        make.width.equalTo(@(btn_w));
        make.height.equalTo(@(btn_h));
        
    }];
    
    _sendBtn.hidden = YES;

}

-(BOOL)keyboardCurrentAppearStyle{
    return _keyboardAppear;
}

#pragma mark -UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    return YES;
}

- (BOOL)textFieldShouldBeginEditing:(UITextField *)textField
{
    if (!self.isNotice) {
        if (self.sendDelegate && [self.sendDelegate respondsToSelector:@selector(keyboardAppearWith:)]) {
            [self.sendDelegate keyboardAppearWith:0];
        }
    }
    
    return self.isNotice;
}
//随键盘的移动界面移动
#pragma mark- 监听方法
-(void)keyboardWillAppear:(NSNotification*)notification{
    CGSize size = [[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
//    self.frame = CGRectMake(_selfOriginalFrame.origin.x,_selfOriginalFrame.origin.y-size.height-keyboard_height , _selfOriginalFrame.size.width, _selfOriginalFrame.size.height);

    if (self.sendDelegate && [self.sendDelegate respondsToSelector:@selector(keyboardAppearWith:)]) {
        [self.sendDelegate keyboardAppearWith:size.height+keyboard_height];
    }
    
    
}

-(void)keboardWillDisappeat:(NSNotification*)notification{
//    self.frame = _selfOriginalFrame;

    if (self.sendDelegate && [self.sendDelegate respondsToSelector:@selector(keyboardDisappearWith:)]) {
        [self.sendDelegate keyboardDisappearWith:0];
    }
    self.keyboardAppear = NO;
    
    
}

-(void)keyboardDidAppear:(NSNotification*)notification{
    self.keyboardAppear = YES;

}

-(void)keboardDidDisappeat:(NSNotification*)notification{
    self.keyboardAppear = NO;
    
}


#pragma mark - btn 
-(void)sendBtnAction:(UIButton*)sender{
    
    if (self.sendDelegate && [self.sendDelegate respondsToSelector:@selector(clickedSendBtn:)]) {
        [self.sendDelegate clickedSendBtn:_textField.text];
    }
    MOSLog(@"发送 ＝ %@",_textField.text);
    [_textField resignFirstResponder];
    _textField.text = @"";
}

#pragma mark- method
-(void)takeBackKeyboard{
    if (_keyboardAppear) {
        [_textField resignFirstResponder];
    }
}

-(void)keybaordAppear{
    if (!_keyboardAppear) {
        [_textField becomeFirstResponder];
    }
}

@end
