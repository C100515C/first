//
//  BasicModel.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"
#import <objc/runtime.h>

@interface BasicResponse ()

@end

@implementation BasicResponse

-(CGSize)getStringSizeWith:(NSString *)str fontSize:(CGFloat)font showSize:(CGSize)size{
    return [CC_NSStringHandle getSizeWithString:str andFont:font andSetStartSize:size];
}

-(void)setCellHeight:(CGFloat)cellHeight{
}

-(CGFloat)cellHeight{
    return 0;
}


-(NSAttributedString*)getNewAttributeStrWith:(NSString *)str andRangesAndColors:(NSArray *)arr{
    
    NSMutableAttributedString *att = [[NSMutableAttributedString alloc] initWithString:str];
    
    for (NSDictionary *dic in arr) {
        
        [att addAttribute:NSForegroundColorAttributeName value:[dic objectForKey:BaseTextColors] range:[BasicResponse getRangeWith:[dic objectForKey:BaseTextRanges]]];
        
    }
    
    
    return att;
}

+(NSDictionary *)rangeTransformToDicWith:(NSRange)range{
    return @{@"lonction":@(range.location),@"length":@(range.length)};
}

+(NSRange)getRangeWith:(NSDictionary *)rangeDic{
    if (rangeDic && rangeDic[@"lonction"] && rangeDic[@"length"]) {
        return NSMakeRange([rangeDic[@"lonction"] integerValue], [rangeDic[@"length"] integerValue]);
    }
    return NSMakeRange(0, 0);
}

/* 获取对象的所有属性 */
//- ( NSDictionary  *)properties_apsWith:(id)model
//
//{
//    
//    NSMutableDictionary  *props = [ NSMutableDictionary  dictionary ];

    //    unsigned   int  outCount, i;
    
    //    objc_property_t  *properties =  class_copyPropertyList ([ UserProfileEntity   class ], &outCount);
    //
    //    for  (i =  0 ; i<outCount; i++)
    //
    //    {
    //
    //        objc_property_t  property = properties[i];
    //
    //        const   char * char_f = property_getName (property);
    //
    //        NSString  *propertyName = [ NSString  stringWithUTF8String :char_f];
    //
    //        id  propertyValue = [ self  valueForKey :( NSString  *)propertyName];
    //
    //        if  (propertyValue) [props  setObject :propertyValue  forKey :propertyName];
    //
    //    }
    
//    unsigned int count;
//    objc_property_t *properties = class_copyPropertyList([UserProfileEntity class], &count);
//    for(int i = 0; i < count; i++)
//    {
//        objc_property_t property = properties[i];
//        
//                NSLog(@"name:%s",property_getName(property));
//                NSLog(@"attributes:%s",property_getAttributes(property));
//        NSString *keyname = [NSString stringWithUTF8String:property_getName(property)];
//        if (keyname==nil) {
//            continue;
//        }
//        id value = [self valueForKey:keyname];
//        if (value==nil) {
//            value = @"";
//        }
//        [props setObject:value forKey:keyname];
//    }
//    //    free(properties);
//    
//    free (properties);
//    
//    return  props;
//    
//}

-(NSDictionary*)getUserProfileDic{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    NSArray *keys = [JastorRuntimeHelper propertyNames:[self class]];
    
    for (NSString *key in keys) {
        id value = [self valueForKey:key];
        if (value==nil) {
            continue;
        }
        [dic setObject:value forKey:key];
    }
    return dic;
}

@end
