//
//  BasicModel.h
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <Foundation/Foundation.h>
#import "BaseResponse.h"
#import "CC_NSStringHandle.h"

static NSString *const BaseTextColors = @"colors";
static NSString *const BaseTextRanges = @"ranges";

@interface BasicResponse : BaseResponse

{
    CGFloat _cellHeight;
}

@property (nonatomic,strong) NSIndexPath *indexpath;

-(CGSize)getStringSizeWith:(NSString*)str fontSize:(CGFloat)font showSize:(CGSize)size;

-(void)setCellHeight:(CGFloat)cellHeight;
-(CGFloat)cellHeight;

-(NSAttributedString*)getNewAttributeStrWith:(NSString*)str andRangesAndColors:(NSArray*)arr;

+(NSDictionary*)rangeTransformToDicWith:(NSRange)range;
+(NSRange)getRangeWith:(NSDictionary*)rangeDic;

//- ( NSDictionary  *)properties_apsWith:(id)model;

-(NSDictionary*)getUserProfileDic;

@end
