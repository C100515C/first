//
//  BasicUIImageView.m
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicUIImageView.h"

@implementation BasicUIImageView
- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super init];
    if (self) {
        self.userInteractionEnabled = YES;

        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
        
        [self addGestureRecognizer:tap];
        
    }
    return self;
}

-(void)setRaduis{
    self.clipsToBounds = YES;
    self.layer.cornerRadius = self.frame.size.width/2.0f;
}

-(void)setTapUse{
    self.userInteractionEnabled = YES;
    
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
    
    [self addGestureRecognizer:tap];
}

-(void)tapAction:(UITapGestureRecognizer *)sender{
    
    if (self.lyj_delegate && [self.lyj_delegate respondsToSelector:@selector(imageTapWith:)]) {
        [self.lyj_delegate imageTapWith:sender];
    }
    
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
