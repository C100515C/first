/************************************************************
 *  * EaseMob CONFIDENTIAL
 * __________________
 * Copyright (C) 2013-2014 EaseMob Technologies. All rights reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of EaseMob Technologies.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from EaseMob Technologies.
 */

#import "UserProfileManager.h"
#import<objc/runtime.h>

#define kCURRENT_USERNAME [[EMClient sharedClient] currentUsername]

@implementation UIImage (UIImageExt)

- (UIImage*)imageByScalingAndCroppingForSize:(CGSize)targetSize
{
    UIImage *sourceImage = self;
    UIImage *newImage = nil;
    CGSize imageSize = sourceImage.size;
    CGFloat width = imageSize.width;
    CGFloat height = imageSize.height;
    CGFloat targetWidth = targetSize.width;
    CGFloat targetHeight = targetSize.height;
    CGFloat scaleFactor = 0.0;
    CGFloat scaledWidth = targetWidth;
    CGFloat scaledHeight = targetHeight;
    CGPoint thumbnailPoint = CGPointMake(0.0,0.0);
    if (CGSizeEqualToSize(imageSize, targetSize) == NO)
    {
        CGFloat widthFactor = targetWidth / width;
        CGFloat heightFactor = targetHeight / height;
        if (widthFactor > heightFactor)
            scaleFactor = widthFactor; // scale to fit height
        else
            scaleFactor = heightFactor; // scale to fit width
        scaledWidth= width * scaleFactor;
        scaledHeight = height * scaleFactor;
        // center the image
        if (widthFactor > heightFactor)
        {
            thumbnailPoint.y = (targetHeight - scaledHeight) * 0.5;
        }
        else if (widthFactor < heightFactor)
        {
            thumbnailPoint.x = (targetWidth - scaledWidth) * 0.5;
        }
    }
    UIGraphicsBeginImageContext(targetSize); // this will crop
    CGRect thumbnailRect = CGRectZero;
    thumbnailRect.origin = thumbnailPoint;
    thumbnailRect.size.width= scaledWidth;
    thumbnailRect.size.height = scaledHeight;
    [sourceImage drawInRect:thumbnailRect];
    newImage = UIGraphicsGetImageFromCurrentImageContext();
    if(newImage == nil)
        MOSLog(@"could not scale image");
    //pop the context to get back to the default
    UIGraphicsEndImageContext();
    return newImage;
}

@end
static NSString *const user_infor_key = @"user_infor";
static NSString *const user_file = @"/user";
static UserProfileManager *sharedInstance = nil;
@interface UserProfileManager ()
{
    NSString *_curusername;
}

@property (nonatomic, strong) NSMutableDictionary *users;
@property (nonatomic, strong) NSString *objectId;
@property (nonatomic, assign) BOOL lock;

@end

@implementation UserProfileManager

+ (instancetype)sharedInstance{
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        sharedInstance = [[self alloc] init];
        sharedInstance.lock = NO;
    });
    return sharedInstance;
}

- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

-(void)storeUserInfor:(NSDictionary *)dic{
    self.lock = YES;
    __weak typeof(self) weakself = self;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
       
        UserProfileEntity *model = [[UserProfileEntity alloc] initWith:dic];
        //归档
        NSMutableData *aD_data = [[NSMutableData alloc] init];
        NSKeyedArchiver *achiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:aD_data];
        [achiver encodeObject:model forKey:user_infor_key];
        [achiver finishEncoding];
        
        //存数据
        [aD_data writeToFile:[self filePathWith:user_file] atomically:YES];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            weakself.lock = NO;
        });
    });
}

//获取文件路径
-(NSString *)filePathWith:(NSString*)filename
{
    NSArray *paths = NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES);
    NSString *path = [paths objectAtIndex:0];
    
//    NSString *docPath = [NSSearchPathForDirectoriesInDomains(NSDocumentDirectory, NSUserDomainMask, YES)objectAtIndex:0];
    path = [path stringByAppendingPathComponent:filename];
    
    //  NSString *path = [NSHomeDirectory() stringByAppendingPathComponent:@"Library/Caches/texts"]; //两种方法都可以
    
    
    return path;
}

- (void)uploadUserHeadImageProfileInBackground:(UIImage*)image
                           completion:(void (^)(BOOL success, NSError *error))completion
{

}

- (void)updateUserProfileInBackground:(NSDictionary*)param
                           completion:(void (^)(BOOL success, NSError *error))completion
{

}

- (void)loadUserProfileInBackgroundWithBuddy:(NSArray*)buddyList
                                saveToLoacal:(BOOL)save
                                  completion:(void (^)(BOOL success, NSError *error))completion
{
    NSMutableArray *usernames = [NSMutableArray array];
    for (NSString *buddy in buddyList)
    {
        if ([buddy length])
        {
            if (![self getUserProfileByUsername:buddy]) {
                [usernames addObject:buddy];
            }
        }
    }
    if ([usernames count] == 0) {
        if (completion) {
            completion(YES,nil);
        }
        return;
    }
    [self loadUserProfileInBackground:usernames saveToLoacal:save completion:completion];
}

- (void)loadUserProfileInBackground:(NSArray*)usernames
                       saveToLoacal:(BOOL)save
                         completion:(void (^)(BOOL success, NSError *error))completion
{

}

- (UserProfileEntity*)getUserProfileByUsername:(NSString*)username
{
    return nil;
}

- (UserProfileEntity*)getCurUserProfile
{
    NSMutableData *data1 = [NSMutableData dataWithContentsOfFile:[self filePathWith:user_file]];
    NSKeyedUnarchiver *unarchiver = [[NSKeyedUnarchiver alloc]initForReadingWithData:data1];
    UserProfileEntity *model  = [unarchiver decodeObjectForKey:user_infor_key];
    
    if (model==nil) {
        return nil;
    }
    
    return model;
}

-(NSString*)getNickNameWithUsername:(NSString*)username{
    UserProfileEntity* entity = [self getUserProfileByUsername:username];
    if (entity.nickname && entity.nickname.length > 0) {
        return entity.nickname;
    } else {
        return username;
    }
}

-(NSString*)getToken{
    UserProfileEntity* entity = [self getCurUserProfile];
    if (entity.nickname && entity.nickname.length > 0) {
        return entity.nickname;
    } else {
        return @"";
    }
}

- (NSString*)getCurUsername
{
    UserProfileEntity* entity = [self getCurUserProfile];
    if (entity.nickname && entity.nickname.length > 0) {
        return entity.nickname;
    } else {
        return @"";
    }
}

-(BOOL)getLoginState{
//    __weak typeof(self) weakself = self;
//    __block BOOL loginState = NO;
    BOOL loginState = NO;
    if (!self.lock) {
//        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            UserProfileEntity* entity = [self getCurUserProfile];
            MOSLog(@"user = %d-%@-%@-%@-%@-%@",entity.isLogin,entity.nickname,entity.username,entity.imageUrl,entity.signature,entity.gender);
            
//            dispatch_async(dispatch_get_main_queue(), ^{
                loginState = entity.isLogin;
//            });
//        });
       
    }
    return loginState;
}

-(NSString*)getLoginToken{
    
    if (!self.lock) {
        UserProfileEntity* entity = [self getCurUserProfile];
        return entity.nickname;
    }
    return @"";
}

-(NSDictionary *)getModelProperties{
    
//    return [self properties_apsWith:[self getCurUserProfile]];
    return [[self getCurUserProfile] properties_apsWith:nil];
}

-(void)updateUserInforWith:(NSDictionary *)dic{
    
    self.lock = YES;
    __weak typeof(self) weakself = self;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
//        UserProfileEntity *model = [[UserProfileEntity alloc] initWith:dic];
        UserProfileEntity *model = [self getCurUserProfile];
        
        NSDictionary *modelKey = [model properties_apsWith:nil];
        NSArray *dicKey = [dic allKeys];
        for (NSString *key in dicKey) {
            
            for (NSString *mKey in modelKey) {
                if ([key isEqualToString:mKey]) {
                    [model setValue:dic[key] forKey:mKey];
                }
            }
        }

        //归档
        NSMutableData *aD_data = [[NSMutableData alloc] init];
        NSKeyedArchiver *achiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:aD_data];
        [achiver encodeObject:model forKey:user_infor_key];
        [achiver finishEncoding];
        
        //存数据
        [aD_data writeToFile:[self filePathWith:user_file] atomically:YES];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            weakself.lock = NO;
        });
    });
}

-(void)updateUserInforWith:(NSDictionary *)dic andFinished:(UpdateFinishedBlock)block{
    self.lock = YES;
    __weak typeof(self) weakself = self;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        
        //        UserProfileEntity *model = [[UserProfileEntity alloc] initWith:dic];
        UserProfileEntity *model = [self getCurUserProfile];
        
        NSDictionary *modelKey = [model properties_apsWith:nil];
        NSArray *dicKey = [dic allKeys];
        for (NSString *key in dicKey) {
            
            for (NSString *mKey in modelKey) {
                if ([key isEqualToString:mKey]) {
                    [model setValue:dic[key] forKey:mKey];
                }
            }
        }
        
        //归档
        NSMutableData *aD_data = [[NSMutableData alloc] init];
        NSKeyedArchiver *achiver = [[NSKeyedArchiver alloc] initForWritingWithMutableData:aD_data];
        [achiver encodeObject:model forKey:user_infor_key];
        [achiver finishEncoding];
        
        //存数据
        [aD_data writeToFile:[self filePathWith:user_file] atomically:YES];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            weakself.lock = NO;
            if (block) {
                block(weakself.lock);
            }
        });
    });
}

-(NSString*)getUserId{
    return [[self getCurUserProfile] objectId];
}


@end

static const CGFloat BasicHeight = 82.0f;
@implementation UserProfileEntity


-(id)initWith:(NSDictionary*)dic{
    self = [super init];
    
    if (self) {
        NSArray *keys = [dic allKeys];
        for (NSString *key in keys) {
            id value = dic[key];
            
            if (value==nil) {
        
                value = @"";
                
                if ([key isEqualToString:@"forumLabel"] ) {
                    value = @[@{@"forum_name":@"无",@"key":@"0"}];
                }
                if ([key isEqualToString:@"labels"]) {
                    value = @[@"无"];
                }
            }
            
            if ([key isEqualToString:@"answerCount"] || [key isEqualToString:@"publicCount"] || [key isEqualToString:@"friendCount"]) {
                
                [self setValue:value forKey:key];
            }else{
                [self setValue:value forKey:key];

            }
        }
        /*
        self.objectId = dic[@"objectId"];
        self.username = dic[@"username"];
        self.nickname = dic[@"nickname"];
        self.imageUrl = dic[@"imageUrl"];
        self.signature = dic[@"signature"];
        self.gender = dic[@"gender"];
        self.address = dic[@"address"];

        self.isLogin = [dic[@"isLogin"] boolValue];
        self.answerCount = [dic[@"answerCount"] boolValue];
        self.publicCount = [dic[@"publicCount"] boolValue];
        self.friendCount = [dic[@"friendCount"] boolValue];
        self.birthdate = dic[@"birthdate"];
        self.labels = dic[@"labels"];
        self.addres_id = dic[@"addres_id"];*/
    }
    return self;
}

-(id)initWithCoder:(NSCoder *)aDecoder{
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];

    NSDictionary *propertDic = [self properties_apsWith:nil];
    NSArray *keys = [propertDic allKeys];
//    NSArray *values = [propertDic allValues];
    
    for (NSString *key in keys) {
        id value;

        if ([key isEqualToString:@"answerCount"] || [key isEqualToString:@"friendCount"]||[key isEqualToString:@"publicCount"]) {
           value = [NSString stringWithFormat:@"%d",[aDecoder decodeIntForKey:key]];
        }else{
           value = [aDecoder decodeObjectForKey:key];
        }
        if (value==nil) {
            value = @"";
            if ([key isEqualToString:@"forumLabel"] ) {
                value = @[@{@"forum_name":@"无",@"key":@"0"}];
            }
            if ([key isEqualToString:@"labels"]) {
                value = @[@"无"];
            }
        }
        [dic setObject:value forKey:key];

    }
    /*
    NSArray *keys = @[@"objectId",@"username",@"imageUrl",@"nickname",@"signature",@"gender",@"isLogin",@"address",@"answerCount",@"publicCount",@"friendCount",@"labels",@"birthdate",@"addres_id"];
    NSString *objectId = [aDecoder decodeObjectForKey:@"objectId"];
    NSString *username = [aDecoder decodeObjectForKey: @"username"];
    NSString *imageUrl = [aDecoder decodeObjectForKey: @"imageUrl"];
    NSString *nickname = [aDecoder decodeObjectForKey: @"nickname"];
    NSString *signature = [aDecoder decodeObjectForKey: @"signature"];
    NSString *gender = [aDecoder decodeObjectForKey: @"gender"];
    BOOL isLogin = [aDecoder decodeIntForKey: @"isLogin"] ;
    
    NSString *address = [aDecoder decodeObjectForKey: @"address"];
    int answerCount = [aDecoder decodeIntForKey: @"answerCount"] ;
    int publicCount = [aDecoder decodeIntForKey: @"publicCount"] ;
    int friendCount = [aDecoder decodeIntForKey: @"friendCount"] ;
    NSString *birthdate = [aDecoder decodeObjectForKey:@"birthdate"];
    
    NSArray *labels = [aDecoder decodeObjectForKey: @"labels"];
    NSString *addres_id = [aDecoder decodeObjectForKey:@"addres_id"];
    
    NSArray *values = @[objectId,username,imageUrl,nickname,signature,gender,@(isLogin),address,@(answerCount),@(publicCount),@(friendCount),labels,birthdate,addres_id];
    
    NSMutableDictionary *dic = [[NSMutableDictionary alloc]init];
    
    for (int i=0; i<keys.count; i++) {
        [dic setObject:values[i] forKey:keys[i]];
    }*/
    
    self = [self initWith:dic];
    
    return self;
}

-(void)encodeWithCoder:(NSCoder *)aCoder{
    
    NSDictionary *dic = [self properties_apsWith:nil];
    
    NSArray *arr = [dic allKeys];
    
    for (NSString *key in arr) {
        id value = [self valueForKey:key];
        if (value==nil) {
            value = @"";
            if ([key isEqualToString:@"forumLabel"] ) {
                value = @[@{@"forum_name":@"无",@"key":@"0"}];
            }
            if ([key isEqualToString:@"labels"]) {
                value = @[@"无"];
            }
        }
        if ([key isEqualToString:@"answerCount"] || [key isEqualToString:@"friendCount"]||[key isEqualToString:@"publicCount"]) {
            [aCoder encodeInteger:[value intValue] forKey:key];

        }else{
            [aCoder encodeObject:value forKey:key];

        }
    }
    
    /*
    [aCoder encodeObject:self.objectId forKey:@"objectId"];
    [aCoder encodeObject:self.username forKey:@"username"];
    [aCoder encodeObject:self.imageUrl forKey:@"imageUrl"];
    [aCoder encodeObject:self.nickname forKey:@"nickname"];

    [aCoder encodeObject:self.signature forKey:@"signature"];

    [aCoder encodeObject:self.gender forKey:@"gender"];
    
    [aCoder encodeInteger:self.isLogin forKey:@"isLogin"];
    
    [aCoder encodeObject:self.address forKey:@"address"];

    [aCoder encodeInteger:self.answerCount forKey:@"answerCount"];
    [aCoder encodeInteger:self.publicCount forKey:@"publicCount"];
    [aCoder encodeInteger:self.friendCount forKey:@"friendCount"];
    
    [aCoder encodeObject:self.labels forKey:@"labels"];
    [aCoder encodeObject:self.birthdate forKey:@"birthdate"];
    [aCoder encodeObject:self.addres_id forKey:@"addres_id"];*/
}
-(CGFloat)focusLabelHeight{
    
    if (self.forumLabel.count!=0) {
        CGFloat x=0,dis_x=5.0f,enddis=10.0f;
        CGFloat height = 15.0f,dis_y = 5.0f;
        
        CGFloat tmpWidth = x;
        CGFloat row = 1;
        
        for (NSString *str in [self getForumLabelNames]) {
            CGSize size = [self getStringSizeWith:str fontSize:10.0f showSize:CGSizeMake(100, 2000)];
            tmpWidth = tmpWidth +size.width+dis_x;
            if (tmpWidth>SCREEN_WIDTH-enddis) {//需要减去后面的要留出的宽度
                row ++;
                tmpWidth = tmpWidth-SCREEN_WIDTH+enddis;
            }
        }
        
        return (row*height+(row-1)*dis_y);
    }
    return 30.0f;
}

-(CGSize)getStringSizeWith:(NSString *)str fontSize:(CGFloat)font showSize:(CGSize)size{
      CGSize newsize = [str boundingRectWithSize:size options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:font]} context:nil].size;
    return newsize;
}

-(CGFloat)newHeight{
    
    if (_newHeight) {
        return _newHeight;
    }else{
        
        CGSize size = [self getStringSizeWith:_signature fontSize:15.0f showSize:CGSizeMake(SCREEN_WIDTH-16, 2000)];
        _newHeight = size.height+BasicHeight+self.focusLabelHeight;
        
        return _newHeight;
    }
}

/* 获取对象的所有属性 */
- ( NSDictionary  *)properties_apsWith:(id)model

{
    
    NSMutableDictionary  *props = [ NSMutableDictionary  dictionary ];
    
//    unsigned   int  outCount, i;
    
//    objc_property_t  *properties =  class_copyPropertyList ([ UserProfileEntity   class ], &outCount);
//    
//    for  (i =  0 ; i<outCount; i++)
//        
//    {
//        
//        objc_property_t  property = properties[i];
//        
//        const   char * char_f = property_getName (property);
//        
//        NSString  *propertyName = [ NSString  stringWithUTF8String :char_f];
//        
//        id  propertyValue = [ self  valueForKey :( NSString  *)propertyName];
//        
//        if  (propertyValue) [props  setObject :propertyValue  forKey :propertyName];
//        
//    }
    
    unsigned int count;
    objc_property_t *properties = class_copyPropertyList([UserProfileEntity class], &count);
    for(int i = 0; i < count; i++)
    {
        objc_property_t property = properties[i];
        
//        NSLog(@"name:%s",property_getName(property));
//        NSLog(@"attributes:%s",property_getAttributes(property));
        NSString *keyname = [NSString stringWithUTF8String:property_getName(property)];
        id value = [self valueForKey:keyname];
        if (value==nil) {
            value = @"";
            if ([keyname isEqualToString:@"forumLabel"] ) {
                value = @[@{@"forum_name":@"无",@"key":@"0"}];
            }
            if ([keyname isEqualToString:@"labels"]) {
                value = @[@"无"];
            }
        }
        [props setObject:value forKey:keyname];
    }
//    free(properties);
    
    free (properties);
    
    return  props;
    
}

-(NSArray*)getForumLabelNames{
    NSMutableArray *arr = [NSMutableArray array];
    
    if (self.forumLabel && self.forumLabel.count!=0) {
        
        for (NSDictionary *dic in self.forumLabel) {
            [arr addObject:dic[@"forum_name"]];
        }
    }else{
        return @[@"无"];
    }
    
    return arr;
}

@end
