/************************************************************
 *  * EaseMob CONFIDENTIAL
 * __________________
 * Copyright (C) 2013-2014 EaseMob Technologies. All rights reserved.
 *
 * NOTICE: All information contained herein is, and remains
 * the property of EaseMob Technologies.
 * Dissemination of this information or reproduction of this material
 * is strictly forbidden unless prior written permission is obtained
 * from EaseMob Technologies.
 */

//  用来处理UIDemo上Parse相关逻辑

#import <Foundation/Foundation.h>

#define kPARSE_HXUSER @"hxuser"
#define kPARSE_HXUSER_USERNAME @"username"
#define kPARSE_HXUSER_NICKNAME @"nickname"
#define kPARSE_HXUSER_AVATAR @"avatar"

@class MessageModel;
@class PFObject;
@class UserProfileEntity;
typedef void(^UpdateFinishedBlock)(BOOL finish);
@interface UserProfileManager : NSObject

+ (instancetype)sharedInstance;

/**
 *  存储用户信息
 *
 *  @param dic 获得的用户信息字典了
 */
-(void)storeUserInfor:(NSDictionary *)dic;

/*
 *  上传个人头像
 */
- (void)uploadUserHeadImageProfileInBackground:(UIImage*)image
                                    completion:(void (^)(BOOL success, NSError *error))completion;

/*
 *  上传个人信息
 */
- (void)updateUserProfileInBackground:(NSDictionary*)param
                                    completion:(void (^)(BOOL success, NSError *error))completion;

/*
 *  获取用户信息 by username
 */
- (void)loadUserProfileInBackground:(NSArray*)usernames
                       saveToLoacal:(BOOL)save
                         completion:(void (^)(BOOL success, NSError *error))completion;

/*
 *  获取用户信息 by buddy
 */
- (void)loadUserProfileInBackgroundWithBuddy:(NSArray*)buddyList
                                saveToLoacal:(BOOL)save
                                  completion:(void (^)(BOOL success, NSError *error))completion;

/*
 *  获取本地用户信息
 */
- (UserProfileEntity*)getUserProfileByUsername:(NSString*)username;

/*
 *  获取当前用户信息
 */
- (UserProfileEntity*)getCurUserProfile;

/*
 *  根据username获取当前用户昵称
 */
- (NSString*)getCurUsername;
/**
 *  根据用户名获得昵称
 *
 *  @param username 用户名字
 *
 *  @return 用户昵称
 */
-(NSString *)getNickNameWithUsername:(NSString*)username;
/**
 *  判断是否登陆了
 *
 *  @return 是否登陆
 */
-(BOOL)getLoginState;

/**
 *  获取登陆token
 *
 *  @return token  
 */
-(NSString*)getLoginToken;
/**
 *  获取本地存储数据模型 的属性
 *
 *  @return 属性字典
 */
-(NSDictionary*)getModelProperties;
/**
 *  获取认证 token
 *
 *  @return token
 */
-(NSString *)getToken;

-(NSString *)getUserId;

/**
 *  更新信息
 *
 *  @param dic 需要更新的数据
 */
-(void)updateUserInforWith:(NSDictionary*)dic;
-(void)updateUserInforWith:(NSDictionary *)dic andFinished:(UpdateFinishedBlock)block;

@end


@interface UserProfileEntity : NSObject<NSCoding>

-(id)initWith:(NSDictionary*)dic;


@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *avatar;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *province;
@property (nonatomic,copy) NSString *city;
@property (nonatomic,copy) NSString *location;
@property (nonatomic,copy) NSString *post_count;
@property (nonatomic,copy) NSString *feed_count;
@property (nonatomic,copy) NSString *following_count;
@property (nonatomic,copy) NSString *follower_count;
@property (nonatomic,copy) NSString *unread_notice_count;
@property (nonatomic,copy) NSString *unread_message_count;
@property (nonatomic,copy) NSString *thread_count;
@property (nonatomic,copy) NSString *comment_count;
@property (nonatomic,copy) NSMutableArray *forumLabel;
/**
 *  用户id
 */
@property (nonatomic,copy) NSString *objectId;
/**
 *  用户名字
 */
@property (nonatomic,copy) NSString *username;
/**
 *  用户 token
 */
@property (nonatomic,copy) NSString *nickname;
/**
 *  用户头像
 */
@property (nonatomic,copy) NSString *imageUrl;
/**
 *  用户签名
 */
@property (nonatomic,copy) NSString *signature;
/**
 *  用户性别
 */
@property (nonatomic,copy) NSString *gender;
/**
 *  用户登陆状态
 */
@property (nonatomic,assign) BOOL isLogin;
/**
 *  用户关注的所有模块
 */
@property (nonatomic,copy) NSArray *labels;
/**
 *  用户 位置
 */
@property (nonatomic,copy) NSString *address;
@property (nonatomic,copy)  NSString *addres_id;

@property (nonatomic,copy) NSString *birthdate;

/**
 *  用户的回答 关注 病友数量
 */
@property (nonatomic,assign) int answerCount;
@property (nonatomic,assign) int publicCount;
@property (nonatomic,assign) int friendCount;
/**
 *  标签背景新高度  和  用户信息cell 高度
 */
@property (nonatomic,assign) CGFloat focusLabelHeight;
@property (nonatomic,assign) CGFloat newHeight;

- ( NSDictionary  *)properties_apsWith:(id)model;

- (NSArray*)getForumLabelNames;

@end
