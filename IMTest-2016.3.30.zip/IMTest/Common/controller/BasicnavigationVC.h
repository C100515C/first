//
//  BasicnavigationVC.h
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface BasicnavigationVC : UINavigationController

-(void)setNavBarBtnItemImageWith:(NSString*)imageName andRightItem:(BOOL)isRight andAction:(SEL)action andTarget:(id)target andVCIndex:(NSInteger)index;

-(void)setNavBarBtnItemTitleWith:(NSString*)title andRightItem:(BOOL)isRight andAction:(SEL)action andTarget:(id)target andVCIndex:(NSInteger)index andTitleColor:(UIColor *)color;

-(void)setBackBtnWith:(NSString*)image withCurrentVC:(UIViewController*)vc andBackAction:(SEL)action;

- (void)CustomPushviewWith:(UIViewController*)vc; //自定义切换动画效果

@end
