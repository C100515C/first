//
//  BasicVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"
#import "BasicSearchBar.h"
#import "BasicSearchDisplayController.h"
#import "BasicTableViewCell.h"
#import "RealtimeSearchUtil.h"
#import "BasicnavigationVC.h"


static NSString * const CellIdentifier = @"basic";
@interface BasicVC ()<UISearchBarDelegate, UISearchDisplayDelegate>
//@property (strong, nonatomic) UISearchBar *searchBar;

@property (strong, nonatomic) BasicSearchBar *searchBar;
@property (strong, nonatomic) BasicSearchDisplayController *searchController;
@property (nonatomic, copy) NSString *searchStr;
@end

@implementation NSString (search)

//进行搜索对比字符串
- (NSString*)showNameWith:(id)obj
{
    if ([obj isKindOfClass:[BasicVC class]]) {
        BasicVC *currentVC = (BasicVC*)obj;
        return currentVC.searchStr;

    }
    return @"";
}

@end

@implementation BasicVC

-(id)initBottomBarHide{
    self = [super init];
    if (self) {
        self.hidesBottomBarWhenPushed = YES;
    }
    return self;
}
- (instancetype)init
{
    self = [super init];
    if (self) {
        
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    

    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setNav{
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    [nav setBackBtnWith:@"topicon_back" withCurrentVC:self andBackAction:@selector(back:)];
}

-(void)back:(UIButton*)sender{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)setShowSearchBar:(BOOL)showSearchBar{
    
    
    if (showSearchBar) {
        [self searchController];

        self.searchBar.frame = CGRectMake(0, 0, self.view.frame.size.width, 44);
        [self.view addSubview:self.searchBar];
        
        self.tableView.frame = CGRectMake(0, self.searchBar.frame.size.height, self.view.frame.size.width, self.view.frame.size.height - self.searchBar.frame.size.height);
    }
    
    _showSearchBar = showSearchBar;
    
}

-(void)setDataSearchSource:(NSMutableArray *)dataSearchSource{
    
    if (_dataSearchSource.count!=0 && _dataSearchSource!=nil) {
        [_dataSearchSource removeAllObjects];
    }else{
        _dataSearchSource = nil;
        _dataSearchSource = dataSearchSource;
    }
}

- (UISearchBar *)searchBar
{
    if (_searchBar == nil) {
        _searchBar = [[BasicSearchBar alloc] init];
        _searchBar.delegate = self;
        _searchBar.placeholder = NSLocalizedString(@"search", @"Search");
        _searchBar.backgroundColor = [UIColor colorWithRed:0.747 green:0.756 blue:0.751 alpha:1.000];
    }
    
    return _searchBar;
}

- (BasicSearchDisplayController *)searchController
{
    if (_searchController == nil) {
        _searchController = [[BasicSearchDisplayController alloc] initWithSearchBar:self.searchBar contentsController:self];
        _searchController.delegate = self;
        _searchController.searchResultsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        __weak BasicVC *weakSelf = self;
        [_searchController setCellForRowAtIndexPathCompletion:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
            
            UITableViewCell* cell = [weakSelf setSearchTableCellWith:tableView and:indexPath];
            
            return cell;
        }];
        
        [_searchController setHeightForRowAtIndexPathCompletion:^CGFloat(UITableView *tableView, NSIndexPath *indexPath) {
            return [weakSelf setSearchCellHeightWith:tableView and:indexPath];
        }];
        
        [_searchController setDidSelectRowAtIndexPathCompletion:^(UITableView *tableView, NSIndexPath *indexPath) {
            
            [weakSelf setSearchSelectedCellActionWith:tableView and:indexPath];
        }];
    }
    
    return _searchController;
}

-(UITableViewCell*)setSearchTableCellWith:(UITableView *)tableView and:( NSIndexPath *)indexPath{
    ///*
     BasicTableViewCell *cell = (BasicTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
     
     // Configure the cell...
     if (cell == nil) {
     cell = [[BasicTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
     }
     
     NSString *buddy = [self.searchController.resultsSource objectAtIndex:indexPath.row];//*/
    cell.textLabel.text = buddy;
    
    return cell;
}
-(CGFloat)setSearchCellHeightWith:(UITableView *)tableView and:( NSIndexPath *)indexPath{
    return 50.0f;
}
-(void)setSearchSelectedCellActionWith:(UITableView *)tableView and:( NSIndexPath *)indexPath{
//    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
//    NSString *buddy = [self.searchController.resultsSource objectAtIndex:indexPath.row];
    
    [self.searchController.searchBar endEditing:YES];
}


#pragma mark - UISearchBarDelegate

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    [searchBar setShowsCancelButton:YES animated:YES];
    
    return YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    __weak typeof(self) weakSelf = self;
    [[RealtimeSearchUtil currentUtil] realtimeSearchWithSource:self.dataSearchSource searchText:(NSString *)searchText collationStringSelector:nil andSelectorObj:nil resultBlock:^(NSArray *results) {
        if (results) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.searchController.resultsSource removeAllObjects];
                [weakSelf.searchController.resultsSource addObjectsFromArray:results];
                [weakSelf.searchController.searchResultsTableView reloadData];
            });
        }
    }];
    self.searchStr = searchText;
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar
{
    return YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    searchBar.text = @"";
    [[RealtimeSearchUtil currentUtil] realtimeSearchStop];
    [searchBar resignFirstResponder];
    [searchBar setShowsCancelButton:NO animated:YES];
}


@end

