 
//  SingletonServ.m
//  ufenqiDemo
//
//  Created by uchange on 14/12/4.
//  Copyright (c) 2014年 youthcode. All rights reserved.
//
#import "SingletonServ.h"
#import "AFNetworking.h"
//#import "UserProfileManager.h"

static SingletonServ * shareIns = nil;
@interface SingletonServ()

@end

@implementation SingletonServ

#pragma mark - 单例初始化

+ (SingletonServ *)sharedInstance
{
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        shareIns = [[self alloc] init];
        NSURL *homeUrl = [NSURL URLWithString:UIHURL_TEST_SERVER];
        shareIns.netWorkManager = [[AFHTTPRequestOperationManager manager] initWithBaseURL:homeUrl];
        
        shareIns.netWorkManager.requestSerializer.timeoutInterval = 20;
        [self networkOBserverMonitor];
    });
    return shareIns;
}

#pragma mark - 网络请求

- (AFHTTPRequestOperation *)processDataWithReqModel:(BaseRequest *)requestModel
                  completeBlock:(ProcessCompleteBlockType)completeBlock {
    
//    self.netWorkManager.requestSerializer = [AFHTTPRequestSerializer serializer];
//    self.netWorkManager.responseSerializer = [AFHTTPResponseSerializer serializer];// 响应
    [self.netWorkManager.requestSerializer setValue:@"ios" forHTTPHeaderField:@"os_type"];
    
//    // app build版本
    NSString *app_build = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    [self.netWorkManager.requestSerializer setValue:app_build forHTTPHeaderField:@"version"];
    
    if ([requestModel.reqMethod isEqualToString:@"GET"]) {
        MOSLog(@"Process GET method");
        return [self reqGetWithModel:requestModel completeBlock:completeBlock];
    } else if ([requestModel.reqMethod isEqualToString:@"POST"]) {
        MOSLog(@"Process POST method");
        return [self reqPostWithModel:requestModel completeBlock:completeBlock];
    } else if ([requestModel.reqMethod isEqualToString:@"PUT"]) {
        MOSLog(@"Process PUT method");
        return nil;
    } else if ([requestModel.reqMethod isEqualToString:@"DELETE"]) {
        MOSLog(@"Process DELETE method");
        return nil;
    } else {
        MOSLog(@"Wrong network method");
        return nil;
    }

}

#pragma mark 网络请求GET方法

- (AFHTTPRequestOperation *)reqGetWithModel:(BaseRequest *)requestModel
          completeBlock:(ProcessCompleteBlockType)completeBlock {
    
    NSMutableDictionary *parameReqDic = [[requestModel toDictionary] mutableCopy];
    
    [parameReqDic removeObjectsForKeys:@[@"reqClassName", @"reqMethod", @"reqUrlPath"]];
    
//    NSString *reqUrlStr = [@"/v4" stringByAppendingString:[requestModel.reqUrlPath stringByAppendingString:@"?"]];
    NSString *reqUrlStr = requestModel.reqUrlPath;
    for (NSString *parKey in parameReqDic) {
        NSString *parValue = [parameReqDic objectForKey:parKey];
        reqUrlStr = [reqUrlStr stringByAppendingString:
                     [[NSString alloc] initWithFormat:@"%@=%@&", parKey, parValue]];
    }
//    reqUrlStr = [reqUrlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

//    MOSLog(@"GET data from net %@",reqUrlStr);

    return [self.netWorkManager GET:reqUrlStr
                  parameters:nil
                     success:^(AFHTTPRequestOperation *operation, id responseObject) {
                         MOSLog(@"Get data success");
                         
                         NSDictionary *opDic = responseObject;
                         
                         NSString *statusstr = [opDic objectForKey:@"msg"];
                         NSNumber *resCodeNum = [opDic objectForKey:@"code"];
                         if ([resCodeNum intValue] == 200) {
                             MOSLog(@"网络访问成功");
                             
                             NSDictionary *dataDic;
                             
                             id dataRes = [opDic objectForKey:@"data"];
                             
                             if ([dataRes isKindOfClass:[NSArray class]]) {
                                 MOSLog(@"GET 返回数组");
                                 dataDic = [[NSDictionary alloc] initWithObjectsAndKeys:dataRes, @"itemList", nil];
                             } else if([dataRes isKindOfClass:[NSDictionary class]]) {
                                 MOSLog(@"GET 返回字典");
                                 dataDic = dataRes;
                             }
                             
                             NSString *className = requestModel.reqClassName;
                             NSString *holeClassName = [[NSString alloc] initWithFormat:@"%@Response", className];
                             
                             id obj = [[NSClassFromString(holeClassName) alloc] init];
                             
                             Jastor * jFromObj =(Jastor*)obj;
                             
                             Jastor *resmodel = [jFromObj initWithDictionary:dataDic];
                             
                             MOSLog(@"finished");
                             
                             completeBlock(resmodel, nil);
                             
                         }else {
                             MOSLog(@"网络访问失败");
                             if ([[NSNull null] isEqual:statusstr]) {
                                 statusstr = @"网络访问失败";
                             }
                             
                             ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                             if ( [statusstr isKindOfClass:[NSDictionary class]]) {
                                 NSDictionary *state = (NSDictionary *)statusstr;
                                 errorRes.msg = state[@"phone"];
                                 errorRes.msgDic = state;
                                 
                             }else if([statusstr isKindOfClass:[NSString class]]){
                                 NSString *state = (NSString *)statusstr;
                                 errorRes.msg = state;
                             }
                             errorRes.code = resCodeNum;
                             completeBlock(nil, errorRes);
                         }
                         MOSLog(@"Download data");
                     }
                     failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                         MOSLog(@"Get data fail");
                         ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                         errorRes.msg = @"网络连接失败";
                         completeBlock(nil, errorRes);
                     }];
}

#pragma mark 网络请求POST方法
- (AFHTTPRequestOperation *)reqPostWithModel:(BaseRequest *)requestModel
           completeBlock:(ProcessCompleteBlockType)completeBlock {
    
    NSMutableDictionary *parameDic = [requestModel toDictionary];
    
    [parameDic removeObjectsForKeys:@[@"reqClassName", @"reqMethod", @"reqUrlPath"]];

//    NSString *reqUrlStr = [@"/v4" stringByAppendingString:requestModel.reqUrlPath];
    NSString *reqUrlStr = requestModel.reqUrlPath;

//    reqUrlStr = [reqUrlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

    
    // 返回请求operation
    return [self.netWorkManager POST:reqUrlStr
                   parameters:parameDic
                      success:^(AFHTTPRequestOperation *operation, id responseObject) {
                          MOSLog(@"Post data success");
                          NSDictionary *opDic = responseObject;
                          
                          NSString *statusStr = [opDic objectForKey:@"msg"];
                          NSNumber *resCodeNum = [opDic objectForKey:@"code"];
                          
                          if ([resCodeNum intValue] == 200) {
                              MOSLog(@"网络访问成功");
                              
                              NSDictionary *dataDic;
                              
                              id dataRes = [opDic objectForKey:@"data"];
                              
                              if ([dataRes isKindOfClass:[NSArray class]]) {
                                  MOSLog(@"POST 返回数组");
                                  dataDic = [[NSDictionary alloc] initWithObjectsAndKeys:dataRes, @"itemList", nil];
                              } else if([dataRes isKindOfClass:[NSDictionary class]]) {
                                  MOSLog(@"POST 返回字典");
                                  dataDic = dataRes;
                              }
                              
                              NSString *className = requestModel.reqClassName;
                              NSString *holeClassName = [[NSString alloc] initWithFormat:@"%@Response", className];
                              
                              id obj = [[NSClassFromString(holeClassName) alloc] init];
                              
                              Jastor * jFromObj =(Jastor*)obj;
                              
                              Jastor *resmodel = [jFromObj initWithDictionary:dataDic];
                              
                              
                              completeBlock(resmodel, nil);
                              
                          } else {
                              MOSLog(@"网络访问失败");
                              
                              if ([[NSNull null] isEqual:statusStr]) {
                                  statusStr = @"网络访问失败";
                              }
                              
                              ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                              
                              if ( [statusStr isKindOfClass:[NSDictionary class]]) {
                                  NSDictionary *state = (NSDictionary *)statusStr;
                                  errorRes.msg = state[@"username"];
                                  errorRes.msgDic = state;
                                  
                              }else if([statusStr isKindOfClass:[NSString class]]){
                                  NSString *state = (NSString *)statusStr;
                                  errorRes.msg = state;
                              }
                              errorRes.code = resCodeNum;
                              completeBlock(nil, errorRes);
                          }
                          MOSLog(@"Download data");
                      }
                      failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                          MOSLog(@"Get data fail");
                          ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                          errorRes.msg = @"网络连接失败";
                          completeBlock(nil, errorRes);
                      }];
}

// 重新登录
- (void)loginWithRequestModel:(BaseRequest *)requestModel
             andCompleteBlock:(ProcessCompleteBlockType)completeBlock
{
    
}

#pragma mark - post 上传图片
- (AFHTTPRequestOperation *)reqPostWithModel:(BaseRequest *)requestModel
                               completeBlock:(ProcessCompleteBlockType)completeBlock constructingBodyWithBlock:(void (^)(id <AFMultipartFormData> formData))block{
    
    NSMutableDictionary *parameDic = [requestModel toDictionary];
    
    [parameDic removeObjectsForKeys:@[@"reqClassName", @"reqMethod", @"reqUrlPath"]];
    
    //    NSString *reqUrlStr = [@"/v4" stringByAppendingString:requestModel.reqUrlPath];
    NSString *reqUrlStr = requestModel.reqUrlPath;
    
//    reqUrlStr = [reqUrlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    
    // 返回请求operation
    return [self.netWorkManager POST:reqUrlStr
                                parameters:parameDic
                                constructingBodyWithBlock:block
                        success:^(AFHTTPRequestOperation *operation, id responseObject) {
                          MOSLog(@"Post data success");
                          
                          NSDictionary *opDic = responseObject;
                          
                          id statusstr = [opDic objectForKey:@"msg"];
                          NSNumber *resCodeNum = [opDic objectForKey:@"code"];
                            
                          if ([resCodeNum intValue] == 200) {
                              MOSLog(@"网络访问成功");
                              
                              NSDictionary *dataDic;
                              
                              id dataRes = [opDic objectForKey:@"data"];
                              
                              if ([dataRes isKindOfClass:[NSArray class]]) {
                                  MOSLog(@"POST 返回数组");
                                  dataDic = [[NSDictionary alloc] initWithObjectsAndKeys:dataRes, @"itemList", nil];
                              } else if([dataRes isKindOfClass:[NSDictionary class]]) {
                                  MOSLog(@"POST 返回字典");
                                  dataDic = dataRes;
                              }
                              
                              NSString *className = requestModel.reqClassName;
                              NSString *holeClassName = [[NSString alloc] initWithFormat:@"%@Response", className];
                              
                              id obj = [[NSClassFromString(holeClassName) alloc] init];
                              
                              Jastor * jFromObj =(Jastor*)obj;
                              
                              Jastor *resmodel = [jFromObj initWithDictionary:dataDic];
                              
                              completeBlock(resmodel, nil);
                              
                          }else {
                              MOSLog(@"网络访问失败");
                              if ([[NSNull null] isEqual:statusstr]) {
                                  statusstr = @"网络访问失败";
                              }
                              
                              ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                              if ( [statusstr isKindOfClass:[NSDictionary class]]) {
                                  NSDictionary *state = (NSDictionary *)statusstr;
                                  errorRes.msg = state[@"phone"];
                                  errorRes.msgDic = state;
                                  
                              }else if([statusstr isKindOfClass:[NSString class]]){
                                  NSString *state = (NSString *)statusstr;
                                  errorRes.msg = state;
                              }
                              errorRes.code = resCodeNum;
                              completeBlock(nil, errorRes);
                          }
                          MOSLog(@"Download data");
                      }
                      failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                          MOSLog(@"Get data fail");
                          ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                          errorRes.msg = @"网络连接失败";//error.description;
                          completeBlock(nil, errorRes);
                      }];
}

#pragma mark - 监测网络状态

+(void)networkOBserverMonitor
{
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status){
        
        if (status == AFNetworkReachabilityStatusNotReachable) {
        } else {
        }
    }];
}

@end

