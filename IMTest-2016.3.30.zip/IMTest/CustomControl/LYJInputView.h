//
//  LYJInputView.h
//  IMTest
//
//  Created by chenchen on 16/3/15.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LYJInputViewDelegate <NSObject>
@optional
-(void)sendBtnAction:(UIButton*)sender andText:(NSString*)text;
-(void)cancleBtnAction:(UIButton*)sender andText:(NSString*)text;

@end


@interface LYJInputView : UIView

@property (weak, nonatomic) IBOutlet UILabel *inputTitle;
@property (weak, nonatomic) IBOutlet UIButton *sendBtn;
@property (nonatomic,assign) id<LYJInputViewDelegate>lyj_delegate;

-(void)keyboardAppear;
-(void)keyboardDisappear;

-(void)updateInputConstraintsWith:(CGFloat)newHeight;

-(void)customAnimation;

@end
