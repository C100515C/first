//
//  CC_CanDeleteImageView.h
//  CC_Managers
//
//  Created by mac on 15/7/23.
//  Copyright (c) 2015年 CC. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CC_CanDeleteImageView;
@protocol CC_CanDeleteImage <NSObject>

@optional
-(void)deletePictureWith:(CC_CanDeleteImageView*)currentPicture;
-(void)pictureSelectedWith:(CC_CanDeleteImageView*)selectedPicture;

@end

@interface CC_CanDeleteImageView : UIImageView
@property (nonatomic,assign) int number;//图片产生的序号
@property (nonatomic,assign) BOOL isUpload;//记录是否上传
@property (nonatomic,copy) NSString *fileName;//上传后的文件名字
@property (nonatomic,assign) BOOL isSelected;//在相册中选择时判断是否已经选择过
@property (nonatomic,assign) id<CC_CanDeleteImage>delegate;
/**
 *  重设删除按钮位置
 */
-(void)set_NewDeleteBtnFrame;


-(id)initWithFrame:(CGRect)frame andSelected:(BOOL)isselected;

-(void)hidenRightMark;

@end
