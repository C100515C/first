//
//  LYJPicturesBrowse.m
//  IMTest
//
//  Created by chenchen on 16/3/18.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJPicturesBrowse.h"
#import "AppDelegate.h"

@interface LYJPicturesBrowse ()

@property (nonatomic,strong) UIScrollView *backContentView;
@property (nonatomic,strong) UIScrollView *bigScreenPicContent;

@property (nonatomic,assign) NSInteger currentIndex;
@property (nonatomic,assign) BOOL isNewPics;

@end

@implementation LYJPicturesBrowse

-(void)awakeFromNib{
    self.backContentView = [[UIScrollView alloc] initWithFrame:self.bounds];
    [self addSubview:_backContentView];
    _backContentView.backgroundColor = [UIColor whiteColor];
    _backContentView.pagingEnabled = YES;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backContentView = [[UIScrollView alloc] initWithFrame:self.bounds];
        [self addSubview:_backContentView];
        _backContentView.backgroundColor = [UIColor whiteColor];
        _backContentView.pagingEnabled = YES;
    }
    return self;
}

#pragma mark - Property method

-(void)setPics:(NSArray *)pics{
    
     [_backContentView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [_bigScreenPicContent.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    if (pics==nil) {
        _pics = pics;

    }else{
        if (![pics isEqualToArray:_pics]) {
            _pics = nil;
            _pics = pics;

        }
    }
    [self createImageviewWith:_pics];
}

-(UIScrollView*)bigScreenPicContent{
    
    if (_bigScreenPicContent==nil) {
        _bigScreenPicContent = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        _bigScreenPicContent.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:1.0f];
        _bigScreenPicContent.pagingEnabled = YES;
        _bigScreenPicContent.contentSize = CGSizeMake(SCREEN_WIDTH*_pics.count, SCREEN_HEIGHT);

        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(smallTap:)];
        tap.numberOfTapsRequired = 1;
        [_bigScreenPicContent addGestureRecognizer:tap];
    }
    
    _bigScreenPicContent.hidden = NO;

    return _bigScreenPicContent;
}

-(void)createBigBrowseWith:(BOOL)isstore{
    if (isstore) {
        for (int i=0; i<_pics.count; i++) {
            UIImage *image = _pics[i];
            CGFloat height = image.size.height;
            CGFloat width = image.size.width;
            CGFloat scale = width/height;
            if (height>=SCREEN_HEIGHT) {
                height = (height-80);
                width = height*scale;
            }
            
            if (width>=SCREEN_WIDTH) {
                width = width-60;
                height = width/scale;
            }
            
            UIImageView *pic = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, width, height)];
            pic.contentMode = UIViewContentModeScaleToFill;
            pic.image = image;
            pic.center = CGPointMake(SCREEN_WIDTH/2.0+(i*SCREEN_WIDTH), SCREEN_HEIGHT/2.0);
            pic.userInteractionEnabled = YES;
            [_bigScreenPicContent addSubview:pic];
            
            pic.tag = i;
            
        }
    }
}

#pragma mark - ui
-(void)createImageviewWith:(NSArray*)Pics{
    CGFloat height = _backContentView.frame.size.height;
//    CGFloat width = _backContentView.frame.size.width;
    CGFloat space = 8.0f;

//    CGFloat picWidth = (width-(space*(Pics.count+1)))/Pics.count;
    CGFloat picHeight = height-2*space;
    
    CGFloat sizeWidth = Pics.count*picHeight+(Pics.count+1)*space;
    
    _backContentView.contentSize = CGSizeMake(sizeWidth, height);
    
    for (int i=0; i<Pics.count; i++) {
        
        UIImageView *pic = [[UIImageView alloc] initWithFrame:CGRectMake(space+i*(space+picHeight), space, picHeight, picHeight)];
        pic.contentMode = UIViewContentModeScaleAspectFit;
        pic.image = Pics[i];
        pic.userInteractionEnabled = YES;
        [_backContentView addSubview:pic];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(bigTap:)];
        [pic addGestureRecognizer:tap];
        pic.tag = i;
    
    }
    
}

#pragma mark - tap
-(void)bigTap:(UITapGestureRecognizer*)tap{
    self.currentIndex = tap.view.tag;
    [self showBigPicsWith:tap.view.tag];
}

-(void)smallTap:(UITapGestureRecognizer*)tap{
    _bigScreenPicContent.hidden = YES;
}

#pragma mark - big pic browse

-(void)showBigPicsWith:(NSInteger)index{
    
    AppDelegate *appdel = [UIApplication sharedApplication].delegate;
    [appdel.window addSubview:self.bigScreenPicContent];
    [self createBigBrowseWith:YES];
    [_bigScreenPicContent setContentOffset:CGPointMake(_currentIndex*SCREEN_WIDTH, 0) animated:YES];

}

@end
