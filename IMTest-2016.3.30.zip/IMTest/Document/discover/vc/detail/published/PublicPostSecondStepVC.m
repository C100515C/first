//
//  PublicPostSecondStepVC.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PublicPostSecondStepVC.h"
#import "BasicUIButton.h"
#import "UIAlertController+LYJAlertView.h"
#import "UIViewController+HUD.h"
#import "CC_CanDeleteImageView.h"

static const NSInteger ImageViewBaseTag = 30;
@interface PublicPostSecondStepVC ()<UITextViewDelegate,UINavigationControllerDelegate, UIImagePickerControllerDelegate,CC_CanDeleteImage>

@property (weak, nonatomic) IBOutlet BasicUIButton *upPicBtn;

@property (weak, nonatomic) IBOutlet UITextView *desTextView;
@property (weak, nonatomic) IBOutlet UILabel *titleLableOfTextView;
@property (strong, nonatomic) UIImagePickerController *imagePickerController;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *picBtnX;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *picBtnY;

@property (nonatomic,strong) NSMutableArray *selectedPics;

@property (nonatomic,copy) NSString *content;
@property (nonatomic,strong) NSData *upfile;

@end

@implementation PublicPostSecondStepVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setNav];
    
    self.tableView.hidden = YES;
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    self.desTextView.delegate = self;
    
    [self initBtn];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(NSMutableArray*)selectedPics{
    if (_selectedPics==nil) {
        _selectedPics = [NSMutableArray array];
    }
    return _selectedPics;
}

#pragma mark - nav
-(void)setNav{
    [super setNav];

    self.title = @"发新帖";

    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
//    [nav setNavBarBtnItemImageWith:@"faceDelete.png" andRightItem:YES andAction:@selector(nextClickdAction:) andTarget:self andVCIndex:3];
    [nav setNavBarBtnItemTitleWith:@"发布" andRightItem:YES andAction:@selector(nextClickdAction:) andTarget:self andVCIndex:3 andTitleColor:G_COLOR_GREEN];
}

-(void)nextClickdAction:(UIButton*)sender{
    
    MOSLog(@"发布");
}

#pragma mark - btn

-(void)initBtn{
    
    [self.upPicBtn setImage:[UIImage imageNamed:@"account"] forState:UIControlStateNormal];
   
    
    self.upPicBtn.titleLabelFrame = CGRectMake(0, 56, 76, 18);
    self.upPicBtn.imageFrame = CGRectMake(15, 8, 40, 40);
    
    [self.upPicBtn addTarget:self action:@selector(upPicAction:) forControlEvents:UIControlEventTouchUpInside];
    
}

-(void)upPicAction:(UIButton*)sender{
 
    [self cellAvatarPress];
    
}

#pragma mark - 头像模块
- (void)cellAvatarPress
{
    MOSLog(@"Cell avatar press.");
    __weak typeof (self) weakSelf = self;
    UIAlertControllerActionBlock takephoto = ^(UIAlertAction *action){
        MOSLog(@"拍照");
        
        if ([LYJSystemCallsJudgeManager isCanUseCamera_CCWith:^{
            [self showHint:@"请去系统设置允许应用访问相机" yOffset:-300];
        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            weakSelf.imagePickerController.editing = YES;
            weakSelf.imagePickerController.allowsEditing = YES;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                     //
                                 }];
        }
        
        
    };
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"取消");
    };
    UIAlertControllerActionBlock pics = ^(UIAlertAction *action){
        MOSLog(@"从手机相册选择");
        if ([LYJSystemCallsJudgeManager iscanPictureAblumWith:^{
            [self showHint:@"请去系统设置允许应用访问相册" yOffset:-300];

        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                     
                                     //                             [[UIApplication sharedApplication] setStatusBarHidden:NO];
                                     //                             [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
                                     
                                     [self prefersStatusBarHidden ];
                                     [self preferredStatusBarStyle];
                                 }];
        
        }
       };
    [UIAlertController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"拍照":takephoto,@"从手机相册选择":pics} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet];
    
    
}



#pragma mark - Property method

- (UIImagePickerController *)imagePickerController
{
    if (_imagePickerController == nil) {
        _imagePickerController = [[UIImagePickerController alloc] init];
        _imagePickerController.navigationBar.barTintColor = G_COLOR_NAVGATION_BACK;
        _imagePickerController.navigationBar.tintColor = [UIColor whiteColor];
        _imagePickerController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:G_COLOR_NAVGATION_TITLE,
                                                                     NSFontAttributeName:G_FONT_NAVGATION_TITLE};
        //        [[UIApplication sharedApplication] setStatusBarHidden:NO];
        //        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
        [self prefersStatusBarHidden ];
        [self preferredStatusBarStyle];
        
        _imagePickerController.delegate = self;
    }
    return _imagePickerController;
}

-(BOOL)prefersStatusBarHidden{
    return NO;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *picImage;
    //    = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
        picImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    } else {
        picImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    }
    
    __weak typeof(self) weakSelf = self;
    
    [self.imagePickerController dismissViewControllerAnimated:YES completion:^{
        MOSLog(@"dismiss self");
        NSData *data = UIImageJPEGRepresentation(picImage , 0.1);
        
        CC_CanDeleteImageView *pic = [weakSelf createSelectPicWith:picImage andBaseFrame:weakSelf.upPicBtn.frame];
        [weakSelf.view addSubview:pic];
        [weakSelf.selectedPics addObject:pic];
    }];
    
    
    
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self preferredStatusBarStyle];
    //    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [picker dismissViewControllerAnimated:YES completion:^{
        //        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
        [self preferredStatusBarStyle];
    }];
    
}

-(CC_CanDeleteImageView*)createSelectPicWith:(UIImage*)image andBaseFrame:(CGRect)baseFrame{
    CC_CanDeleteImageView *pic = nil;
    
    pic  = [[CC_CanDeleteImageView alloc] initWithFrame:baseFrame];
    pic.image = image;
    
    CGFloat space = 10.0f;
    CGFloat n_x =  baseFrame.origin.x+baseFrame.size.width+space;
    CGFloat n_y = baseFrame.origin.y-self.desTextView.frame.origin.y-self.desTextView.frame.size.height;
    
    if ((n_x+baseFrame.size.width+space)>self.view.frame.size.width) {
        n_x = space;
        n_y = n_y+space+baseFrame.size.height;
    }
    
    pic.delegate = self;
    self.picBtnX.constant = n_x;
    self.picBtnY.constant = n_y;
    pic.number = (int)(n_x/baseFrame.size.width)+(int)(n_y/baseFrame.size.height)*(int)(self.view.frame.size.width/(baseFrame.size.width+space));
    pic.tag = ImageViewBaseTag+pic.number;
    [self.upPicBtn layoutIfNeeded];
    
    return pic;
}

-(NSArray*)getPics{
    
    NSMutableArray *arr = [NSMutableArray array ];
    
    NSArray *subs = [self.view subviews];
    
    for (CC_CanDeleteImageView *pic in subs) {
        if ([pic isKindOfClass:[CC_CanDeleteImageView class]]) {
            [arr addObject:pic];
        }
    }
    return arr;
}

#pragma mark - CC_CanDeleteImage
-(void)deletePictureWith:(CC_CanDeleteImageView*)currentPicture{
    
    [self resetFrameWith:currentPicture];
    
    [currentPicture removeFromSuperview];
}

-(void)resetFrameWith:(CC_CanDeleteImageView*)currentPic{
    
    CGRect tmp = currentPic.frame;
    CGRect current = currentPic.frame;
     CC_CanDeleteImageView *last = [self.selectedPics lastObject];
    CGRect lastRect = last.frame;

    for (int i=0; i<self.selectedPics.count; i++ ) {
        CC_CanDeleteImageView *pic = self.selectedPics[i];
        if (currentPic.number < pic.number) {
            tmp = pic.frame;
            pic.frame = current;
            pic.number -= 1;
            pic.tag = ImageViewBaseTag+pic.number;
            current = tmp;
        }
    }
    
    [self.selectedPics removeObject:currentPic];

    self.picBtnX.constant = lastRect.origin.x;
    self.picBtnY.constant = lastRect.origin.y-self.desTextView.frame.origin.y-self.desTextView.frame.size.height;
    
}

@end
