//
//  PublicPostFirstStepVC.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PublicPostFirstStepVC.h"
#import "PublicPostSecondStepVC.h"
#import "UIViewController+HUD.h"
#import "BasicUIButton.h"

#import "LYJDBManager.h"

typedef enum {
    Roast = 20,
    Recommend,
    Ask
}SelectBtns;

@interface PublicPostFirstStepVC ()<UITextViewDelegate>

@property (weak, nonatomic) IBOutlet BasicUIButton *ask;
@property (weak, nonatomic) IBOutlet BasicUIButton *recommend;
@property (weak, nonatomic) IBOutlet BasicUIButton *roast;

@property (nonatomic,weak) UIButton *tmpBtn;

@property (weak, nonatomic) IBOutlet UITextView *desTextField;
@property (weak, nonatomic) IBOutlet UILabel *titleTextField;

/*test db*/
- (IBAction)btnaction:(UIButton *)sender;

- (IBAction)show:(UIButton *)sender;
- (IBAction)save:(UIButton *)sender;

- (IBAction)del:(UIButton *)sender;

@property (nonatomic,copy) NSString *thread_type;
@property (nonatomic,copy) NSString *post_title;

@end

@implementation PublicPostFirstStepVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setNav];
    
    self.tableView.hidden = YES;
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    self.desTextField.delegate = self;
    
    [self initBtn];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    
    [self.desTextField resignFirstResponder];
}

-(void)setNav{
    [super setNav];

    self.title = @"发新帖";
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
//    [nav setNavBarBtnItemImageWith:@"faceDelete.png" andRightItem:YES andAction:@selector(nextClickdAction:) andTarget:self andVCIndex:2];
    [nav setNavBarBtnItemTitleWith:@"下一步" andRightItem:YES andAction:@selector(nextClickdAction:) andTarget:self andVCIndex:2 andTitleColor:G_COLOR_GREEN];
}

-(void)nextClickdAction:(UIButton*)sender{
    
    if (self.desTextField.text.length==0) {
        [self showHint:@"标题不能为空" yOffset:-200];
        return;
    }
    PublicPostSecondStepVC *vc = [[PublicPostSecondStepVC alloc] init];
    vc.hidesBottomBarWhenPushed = YES;
    vc.thread_type = [NSString stringWithFormat:@"%d",22-(int)self.tmpBtn.tag];
    vc.post_title = self.desTextField.text;
    vc.forum_id = self.forum_id;
    [self.navigationController pushViewController:vc animated:YES];
    
}

-(void)initBtn{
    
    [self.ask setImage:[UIImage imageNamed:@"button_xz2"] forState:UIControlStateNormal];
    [self.recommend setImage:[UIImage imageNamed:@"button_xz1"] forState:UIControlStateNormal];
    [self.roast setImage:[UIImage imageNamed:@"button_xz1"] forState:UIControlStateNormal];

    self.ask.titleLabelFrame = CGRectMake(25, 3, 40, 16);
    self.ask.imageFrame = CGRectMake(5, 3, 16, 16);
    
    self.recommend.titleLabelFrame = CGRectMake(25, 3, 40, 16);
    self.recommend.imageFrame = CGRectMake(5, 3, 16, 16);
    
    self.roast.titleLabelFrame = CGRectMake(25, 3, 40, 16);
    self.roast.imageFrame = CGRectMake(5, 3, 16, 16);
    
    self.ask.tag = Ask;
    self.recommend.tag = Recommend;
    self.roast.tag = Roast;
    
    [self.ask addTarget:self action:@selector(typeSelectBtnsAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.recommend addTarget:self action:@selector(typeSelectBtnsAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.roast addTarget:self action:@selector(typeSelectBtnsAction:) forControlEvents:UIControlEventTouchUpInside];
    self.tmpBtn = self.ask;
}

#pragma mark - btn
-(void)typeSelectBtnsAction:(UIButton*)sender{
    
    [self.tmpBtn setImage:[UIImage imageNamed:@"button_xz1"] forState:UIControlStateNormal];
    
    [sender setImage:[UIImage imageNamed:@"button_xz2"] forState:UIControlStateNormal];
    
    self.tmpBtn = sender;
    
}

#pragma mark - text view
-(void)textViewDidChange:(UITextView *)textView {
//    MOSLog(@"%@",textView.text);
    
    if (textView.text.length) {
        self.titleTextField.hidden = YES;
    }else{
        self.titleTextField.hidden = NO;
    }
    
    if (textView.text.length>5) {
        textView.text = [textView.text substringWithRange:NSMakeRange(0, 5)];
        [self showHint:@"最多输入25个字" yOffset:-300];
    }
    
}

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    return YES;
}

/***** db test****/
- (IBAction)btnaction:(UIButton *)sender {
    
}

- (IBAction)show:(UIButton *)sender {
    
}

- (IBAction)save:(UIButton *)sender {

}

- (IBAction)del:(UIButton *)sender {

}

@end
