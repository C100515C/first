//
//  circleDetailVC.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "circleDetailVC.h"
#import "BasicUITableView.h"
#import "CircleDetailCell.h"
#import "CircleDetailHotCell.h"
#import "CircleDetailHeaderView.h"

#import "PublicPostFirstStepVC.h"
#import "CircleFriendsVC.h"

#import "CircleDetailResponse.h"
#import "CircleDetailRequest.h"
#import "SingletonServ.h"

#import "UIViewController+HUD.h"

@interface circleDetailVC (){
    NSMutableArray *_dataSource;
    int _page;
}

@property (weak, nonatomic) IBOutlet BasicUITableView *myTableView;
@property (nonatomic,strong) CircleDetailHeaderView *tableHeaderView;
@property (nonatomic,strong) CircleDetailHeaderResponse *headerModel;

@end

@implementation circleDetailVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTableView;
    
    [super viewDidLoad];
    
    [self setNav];
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _page = 1;
    _dataSource = [[NSMutableArray alloc] init];
    [self.tableView registerNib:[UINib nibWithNibName:@"CircleDetailCell" bundle:nil] forCellReuseIdentifier:circleDetailCell_id];
    [self.tableView registerNib:[UINib nibWithNibName:@"CircleDetailHotCell" bundle:nil] forCellReuseIdentifier:CircleDetailHotCell_id];

    CircleDetailHeaderView *headerview = [[[NSBundle mainBundle] loadNibNamed:@"CircleDetailHeaderView" owner:nil options:nil] firstObject];
    self.tableHeaderView = headerview;
    self.tableView.tableHeaderView = _tableHeaderView;
    
    __weak typeof(self) weakself = self;
    self.tableHeaderView.imageTapBlock = ^(UITapGestureRecognizer *sender){
        CircleFriendsVC *vc = [[CircleFriendsVC alloc] init];
        [weakself.navigationController pushViewController:vc animated:YES];
    };
    
    [self makeModelWith:_page with:nil andHeaderRef:YES];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setNav{
    [super setNav];

    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
    [nav setNavBarBtnItemImageWith:@"topicon_add" andRightItem:YES andAction:@selector(editClickdAction:) andTarget:self andVCIndex:1];
    
}

-(void)editClickdAction:(UIButton*)sender{
    
    PublicPostFirstStepVC *vc = [[PublicPostFirstStepVC alloc] init];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - data
-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    
    CircleDetailRequest *req = [[CircleDetailRequest alloc] init];
    req.forum_id = self.forum_id;
    __weak typeof(self) weakself = self;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            
            CircleDetailItemListOfFindResponse *model = (CircleDetailItemListOfFindResponse*)responseDataModel;
            [_dataSource addObject:model.recommend];
            [_dataSource addObject:model.items];
            [weakself.tableView reloadData];
            
            weakself.headerModel = model.forum;
            [weakself.tableHeaderView setHeaerViewWith:weakself.headerModel];
            weakself.tableView.tableHeaderView = weakself.tableHeaderView;
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
    }];

}

- (void)tableViewDidTriggerHeaderRefresh{
    
    [self tableViewDidFinishTriggerHeader:YES reload:NO];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    [self tableViewDidFinishTriggerHeader:NO reload:NO];
    
}//上拉加载事件

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _dataSource.count;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==0) {
        NSArray *arr = [_dataSource firstObject];
        CircleDetailHotResponse *model = (CircleDetailHotResponse*)[arr objectAtIndex:indexPath.row];
        return model.cellHeight;

    }else{
        
        NSArray *arr = [_dataSource lastObject];
        CircleDetailResponse *model = (CircleDetailResponse*)[arr objectAtIndex:indexPath.row];
        return model.cellHeight;
    }
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==0) {
        NSArray *arr = [_dataSource firstObject];
        
        return [arr count];
    }else{
        NSArray *arr = [_dataSource lastObject];

        return arr.count;
    }
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if (indexPath.section==0) {
        
        CircleDetailHotCell *cell = [tableView dequeueReusableCellWithIdentifier:CircleDetailHotCell_id];
        
        if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"CircleDetailHotCell" owner:nil options:nil] firstObject];
        }
        NSArray *arr = [_dataSource firstObject];
        
        CircleDetailHotResponse *model = (CircleDetailHotResponse*)[arr objectAtIndex:indexPath.row];
        
        [cell setCellWith:model];
        
        return cell;
        
    }else{
        CircleDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:circleDetailCell_id];
        
        if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"CircleDetailCell" owner:nil options:nil] firstObject];
        }
        NSArray *arr = [_dataSource lastObject];

        CircleDetailResponse *model = (CircleDetailResponse*)[arr objectAtIndex:indexPath.row];
        
        [cell setCellWith:model andFormName:_headerModel.forum_name];
        
        return cell;
    }
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==0) {
        NSArray *arr = [_dataSource firstObject];
        CircleDetailHotResponse *model = (CircleDetailHotResponse*)[arr objectAtIndex:indexPath.row];
        
    }else{
        NSArray *arr = [_dataSource lastObject];
        CircleDetailResponse *model = (CircleDetailResponse*)[arr objectAtIndex:indexPath.row];
    }
    
    
}

@end
