//
//  CircleFriendsCell.h
//  IMTest
//
//  Created by chenchen on 16/3/15.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString *const CircleFriendsCell_id = @"circlefriends";
@class CircleFriendsResponse;
@interface CircleFriendsCell : BasicTableViewCell

-(void)setCellWith:(CircleFriendsResponse*)model;

@end
