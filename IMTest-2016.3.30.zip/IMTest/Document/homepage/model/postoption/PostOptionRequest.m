//
//  PostOptionRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostOptionRequest.h"

@implementation PostOptionRequest

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"praises?access-token=%@",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
//        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"PostOption";
    }
    return self;
}

@end

@implementation PostOptionAttentionRequest

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"attentions?access-token=%@",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        //        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"PostOption";
    }
    return self;
}

@end

@implementation PostOptionCollectionRequest

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"collects?access-token=%@",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        //        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"PostOption";
    }
    return self;
}

@end