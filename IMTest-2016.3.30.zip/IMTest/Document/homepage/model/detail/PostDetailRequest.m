//
//  PostDetailRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/28.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostDetailRequest.h"

@interface PostDetailRequest (){
    NSString *_thread_id;
}

@end

@implementation PostDetailRequest

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"threads/thread_id?access-token=%@",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        self.reqMethod = @"GET";
//        self.reqMethod = @"POST";
        self.reqClassName = @"PostDetail";
    }
    return self;
}

-(void)setMyPost_id:(NSString *)thread_id{
 
    if (thread_id) {
        if (_thread_id) {
            _thread_id = nil;
        }
        _thread_id = [thread_id copy];
    }
    
    NSMutableString *tmp = [[NSMutableString alloc] initWithString:self.reqUrlPath];
    NSRange range = [tmp rangeOfString:@"thread_id"];
    if (_thread_id==nil) {
        _thread_id = @"";
    }
    [tmp replaceCharactersInRange:range withString:_thread_id];
    self.reqUrlPath = tmp;
}

-(void)setPageCount:(NSString *)pageCount{
    if (pageCount) {
        if (_pageCount) {
            _pageCount = nil;
        }
        _pageCount = [pageCount copy];
    }
    
    self.reqUrlPath = [NSString stringWithFormat:@"%@&",self.reqUrlPath];
}

@end
