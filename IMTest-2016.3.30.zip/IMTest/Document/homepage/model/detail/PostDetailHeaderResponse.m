//
//  PostDetailHeaderResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostDetailHeaderResponse.h"

static const CGFloat BasicHeight = 55.0f;

@implementation PostDetailHeaderResponse

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size_content = [self getStringSizeWith:_content fontSize:14.0f showSize:CGSizeMake(SCREEN_WIDTH-16, 2000)];
        CGSize size_title = [self getStringSizeWith:_title fontSize:14.0f showSize:CGSizeMake(SCREEN_WIDTH-90, 2000)];
        _picHeight = 151.0f;
        
        _topnewHeight = size_title.height+38.0;
        _middleNewHeight = size_content.height+_picHeight;
        _cellHeight = _topnewHeight+_middleNewHeight+BasicHeight;
        return _cellHeight;
    }
}

-(NSString*)thread_type{
    
    if ([_thread_type integerValue]==1) {
        return @"吐槽";
        
    }else if ([_thread_type integerValue]==2){
        return @"提问" ;
        
    }else{
        return @"推荐";
    }
}

-(UIColor*)getLabelColor{
    if ([_thread_type isEqualToString:@"1"]) {
        return [UIColor redColor];
    }else if ([_thread_type isEqualToString:@"2"]){
        return [UIColor orangeColor];
    }else{
        
        return RGB(57, 189,104, 1);
    }
}

-(NSString*)collect_count{
    if (_collect_count) {
        return [NSString stringWithFormat:@"收藏 %@",_collect_count];
    }
    return _collect_count;
}
-(NSString*)shares_count{
    if (_shares_count) {
        return [NSString stringWithFormat:@"分享 %@",_shares_count];
    }
    return _shares_count;
}
-(NSString*)attention_count{
    if (_attention_count) {
        return [NSString stringWithFormat:@"关注 %@",_attention_count];
    }
    return _attention_count;
}
@end
