//
//  PostDetailResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/28.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostDetailResponse.h"

@implementation PostDetailResponse

-(NSMutableArray*)post{
    if (_post==nil) {
        _post = [[NSMutableArray alloc]init];
    }
    return _post;
}

+(Class)post_class{
    return [PostRepeatListResponse class];
}

@end
