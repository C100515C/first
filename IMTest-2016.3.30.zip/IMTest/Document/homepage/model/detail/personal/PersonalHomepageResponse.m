
//
//  PersonalHomepageResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalHomepageResponse.h"

static const CGFloat BasicHeight = 82.0f;
static const CGFloat font = 10.0f;
static const CGFloat focusHeight = 30.0f;

@implementation PersonalHomepageResponse

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size = [self getStringSizeWith:self.signature fontSize:15.0f showSize:CGSizeMake(SCREEN_WIDTH-16, 2000)];
        _cellHeight = size.height+BasicHeight+self.focusLabelHeight;
        
        return _cellHeight;
    }
}

-(CGFloat)focusLabelHeight{

    if (self.forumLabel.count!=0) {
        CGFloat x=0,dis_x=5.0f,enddis=10.0f;
        CGFloat height = 15.0f,dis_y = 5.0f;
        
        CGFloat tmpWidth = x;
        CGFloat row = 1;
        
        for (NSString *str in self.forumLabel) {
             CGSize size = [self getStringSizeWith:str fontSize:font showSize:CGSizeMake(100, 2000)];
            tmpWidth = tmpWidth +size.width+dis_x;
            if (tmpWidth>SCREEN_WIDTH-enddis) {//需要减去后面的要留出的宽度
                row ++;
                tmpWidth = tmpWidth-SCREEN_WIDTH+enddis;
            }
        }
        
        return (row*height+(row-1)*dis_y);
    }
    return focusHeight;
}

@end
