//
//  PostDetailHeaderView.h
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PostDetailHeaderResponse;

typedef enum {
    PostDetailHeaderShareBtn = 40,
    PostDetailHeaderCollectBtn,
    PostDetailHeaderAttentionBtn
}PostDetailHeaderBtn;

typedef void (^HeaderIconTapActionBlock)(UITapGestureRecognizer *sender);
typedef void (^PostDetailHeaderBtnActionBlick)(PostDetailHeaderBtn btnname);
@interface PostDetailHeaderView : UIView

@property (nonatomic,copy) HeaderIconTapActionBlock tapBlock;
@property (nonatomic,copy) PostDetailHeaderBtnActionBlick btnBlock;

-(void)setHeaderViewWith:(PostDetailHeaderResponse*)model;

-(void)updateBtnCountWith:(PostDetailHeaderBtn)btnname andNewCount:(PostDetailHeaderResponse*)newmodel;
@end
