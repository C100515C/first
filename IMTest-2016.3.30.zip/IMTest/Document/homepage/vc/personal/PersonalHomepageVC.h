//
//  PersonalHomepageVC.h
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface PersonalHomepageVC : BasicVC
@property (nonatomic,copy) NSString *userid;
@end
