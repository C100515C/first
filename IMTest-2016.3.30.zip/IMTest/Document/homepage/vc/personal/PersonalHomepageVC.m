//
//  PersonalHomepageVC.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalHomepageVC.h"
#import "MyFocusVC.h"
#import "MyCollectionVC.h"

#import "PersonalHomepageCell.h"
#import "SetMenuCell.h"

#import "PersonalHomepageResponse.h"
#import "SingletonServ.h"
#import "PersonalHomepageRequest.h"

#import "UIViewController+HUD.h"

@interface PersonalHomepageVC (){
    NSMutableArray *_dataSource;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;
- (IBAction)focusAction:(UIButton *)sender;
- (IBAction)sendMessageAction:(UIButton *)sender;

@end

@implementation PersonalHomepageVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;

    [super viewDidLoad];
    
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    _dataSource = [[NSMutableArray alloc] init];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"PersonalHomepageCell" bundle:nil] forCellReuseIdentifier:PersonalHomepageCell_id];
    [self.tableView registerNib:[UINib nibWithNibName:@"SetMenuCell" bundle:nil] forCellReuseIdentifier:setMenuCell_id];
    
    [self makeDataSource];
    
    [self setNav];

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setNav{
    [super setNav];
    self.title = @"他的主页";
}

- (IBAction)focusAction:(UIButton *)sender {
}

- (IBAction)sendMessageAction:(UIButton *)sender {
}

#pragma mark - data
-(void)makeDataSource{
    //第一个cell   头部 数据 模型
    PersonalHomepageRequest *req = [[PersonalHomepageRequest alloc] init];
    __weak typeof(self) weakself = self;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            PersonalHomepageResponse *model = (PersonalHomepageResponse*)responseDataModel;
            MOSLog(@"%@",model);
            
            [_dataSource addObject:model];
            [weakself setUIData];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
    }];
    
    
}

-(void)setUIData{
    //收藏 关注 cell
    NSArray *menu_name = @[@"ta的收藏",@"ta的关注"];
    NSArray *menu_img = @[@"icon_shoucan2",@"icon_guanzhu2"];
    
    for (int i=0;i<menu_img.count ; i++) {
        
        NSDictionary *dic = @{@"name":menu_name[i],@"img":menu_img[i]};
        [_dataSource addObject:dic];
        
    }
    [_myTable reloadData];
}

#pragma mark - table
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        PersonalHomepageResponse *model = [_dataSource firstObject];

        return model.cellHeight;
    }
    return 40.0f;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row==0 ) {
        PersonalHomepageCell *cell = [tableView dequeueReusableCellWithIdentifier:PersonalHomepageCell_id];
        
        if (cell==nil) {
            cell  = [[[NSBundle mainBundle] loadNibNamed:@"PersonalHomepageCell" owner:nil options:nil] firstObject];
        }
        
        PersonalHomepageResponse *model = [_dataSource firstObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell setCellWithModel:model];
        
        return cell;
    }else{
        SetMenuCell *cell = [tableView dequeueReusableCellWithIdentifier:setMenuCell_id];
        
        if (cell==nil) {
            cell  = [[[NSBundle mainBundle] loadNibNamed:@"SetMenuCell" owner:nil options:nil] firstObject];
        }
        
        NSDictionary *dic = [_dataSource objectAtIndex:indexPath.row];
        
        cell.icon.image = [UIImage imageNamed:dic[@"img"]];
        cell.name.text = dic[@"name"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

        return cell;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row==1) {
        MyCollectionVC *vc = [[MyCollectionVC alloc] init];
        vc.hidesBottomBarWhenPushed = YES;
        vc.userid = self.userid;
        [self.navigationController pushViewController:vc animated:YES];
        
    }else if(indexPath.row==2){
    
        MyFocusVC *vc = [[MyFocusVC alloc] init];
        vc.hidesBottomBarWhenPushed = YES;
        vc.userid = self.userid;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
