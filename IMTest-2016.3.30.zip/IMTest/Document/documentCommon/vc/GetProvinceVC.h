//
//  GetProvinceVC.h
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@protocol GetProvinceProtocol <NSObject>

-(void)getProvinceWith:(NSString*)province andCityWith:(NSString*)city andProvince_id:(NSString*)pro_id andCity_id:(NSString*)city_id;

@end

@interface GetProvinceVC : BasicVC

@property (nonatomic,copy) NSMutableArray *cityList;
@property (nonatomic,assign) BOOL isCituList;
@property (nonatomic,copy) NSString *provinceName;
@property (nonatomic,assign) id<GetProvinceProtocol>lyj_delegate;

@end
