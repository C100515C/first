//
//  ProvinceResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface ProvinceResponse : BasicResponse

@property (nonatomic,copy) NSMutableArray *provinces;
@property (nonatomic,copy) NSMutableArray *cityList;

+ (Class)cityList_class;
+ (Class)provinces_class;

@end
