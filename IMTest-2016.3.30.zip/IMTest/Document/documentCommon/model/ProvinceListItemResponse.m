//
//  ProvinceListItemResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "ProvinceListItemResponse.h"

@implementation ProvinceListItemResponse

-(NSMutableArray*)cityList{
    if (_cityList==nil) {
        _cityList = [[NSMutableArray alloc]init];
    }
    return _cityList;
}

+ (Class)cityList_class{
    return [CityItemResponse class];
}

@end

@implementation CityItemResponse


@end