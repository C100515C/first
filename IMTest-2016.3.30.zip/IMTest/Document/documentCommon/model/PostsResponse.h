//
//  PostsModel.h
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface PostsItemListPageResponse : BasicResponse

@property (nonatomic,copy) NSString *totalCount;
@property (nonatomic,copy) NSString *pageCount;
@property (nonatomic,copy) NSString *currentPage;
@property (nonatomic,copy) NSString *perPage;


@end

@interface PostsUserInforResponse : BasicResponse
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *username;
@property (nonatomic,copy) NSString *avatar;

@end

@interface PostsPostInforResponse : BasicResponse
@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *thread_id;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *comment_count;
@property (nonatomic,copy) NSString *status;
@property (nonatomic,copy) NSString *sources;
@property (nonatomic,copy) NSString *praise_count;
@property (nonatomic,copy) NSString *username;
@property (nonatomic,copy) NSString *avatar;

@end

@interface PostsThreadResponse : BasicResponse

@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *updated_at;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *board_id;
@property (nonatomic,copy) NSString *post_count;
@property (nonatomic,copy) NSString *edited_at;
@property (nonatomic,copy) NSString *status;
@property (nonatomic,copy) NSString *sources;
@property (nonatomic,copy) NSString *forum_id;
@property (nonatomic,copy) NSString *thread_status;
@property (nonatomic,copy) NSString *thread_type;
@property (nonatomic,copy) NSString *browse_count;
@property (nonatomic,copy) NSString *shares_count;
@property (nonatomic,copy) NSString *collect_count;
@property (nonatomic,copy) NSString *attention_count;

@end

@interface PostsResponse : BasicResponse

@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *thread_id;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *type;
@property (nonatomic,copy) NSString *post_id;
@property (nonatomic,copy) NSString *updated_at;
@property (nonatomic,copy) NSString *forum_name;
@property (nonatomic,copy) NSString *content;

@property (nonatomic,strong) PostsUserInforResponse *userInfo;
@property (nonatomic,strong) PostsPostInforResponse *postInfo;
@property (nonatomic,strong) PostsThreadResponse *thread;

/**
 *  处理后 需要的数据
 */
@property (nonatomic,copy) NSAttributedString *optionStr;
@property (nonatomic,copy) NSAttributedString *timeCircleStr;

//@property (nonatomic,copy) UIColor *labelColor;

//+(Class)userInfo_class;
//+(Class)postInfo_class;
-(UIColor*)getLabelColor;
@end

@interface PostsItemListResponse : BasicResponse
@property (nonatomic,copy) NSMutableArray *items;
@property (nonatomic,strong) PostsItemListPageResponse *_meta;

+(Class)items_class;

@end
