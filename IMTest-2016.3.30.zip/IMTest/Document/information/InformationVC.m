//
//  InformationVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "InformationVC.h"
#import "SelectTableMenuView.h"
#import "BasicUITableView.h"
#import "MJRefresh.h"
#import "NoticeTableCell.h"
#import "NoticeCellResponse.h"

static NSString * const NoticeCell_id = @"notice";

@interface InformationVC ()<SelectMenuprotocol>{
    NSMutableArray *_noticeDataSource;
}

@property (nonatomic,strong) SelectTableMenuView *menuView;
@property (weak, nonatomic) IBOutlet BasicUITableView *noticeTable;

@end

@implementation InformationVC

- (instancetype)init
{
    self = [super init];
    if (self) {
        self.menuView = [[[NSBundle mainBundle] loadNibNamed:@"SelectTableMenuView" owner:nil options:nil]firstObject]; 
        [self.view addSubview:_menuView];
        
        CGRect frame = self.menuView.frame;
        frame.size.width = SCREEN_WIDTH;
        self.menuView.frame = frame;
        [self.menuView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.left.equalTo(self.view.mas_left).with.offset(0);
            make.top.equalTo (@(0));
            make.right.equalTo(self.view.mas_right).with.offset(0);
            make.height.equalTo(@(frame.size.height));
        }];
        
        self.menuView.delegate = self;
    }
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.shouSearch = NO;
    
    self.title = @"消息";
    
    _noticeDataSource = [[NSMutableArray alloc]init];
    
    [self moveMessageTablePosition];
//    [self moveNoticeTablePosition];
    
    self.noticeTable.delegate = self;
    self.noticeTable.dataSource = self;
    self.tableView.hidden = YES;
    
    [self setNoticeTableRefresh];
    
    [self.noticeTable registerNib:[UINib nibWithNibName:@"NoticeTableCell" bundle:nil] forCellReuseIdentifier:NoticeCell_id];
    [self MakeData];
    // Do any additional setup after loading the view from its nib.
}



- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
/**
 *  根据顶部菜单移动继承的私信table位置 和大小
 */
-(void)moveMessageTablePosition{
    CGRect frame = self.tableView.frame;
    CGFloat width = self.view.frame.size.width;
    
    frame.origin.y = frame.origin.y+_menuView.frame.size.height;
    frame.origin.x = frame.origin.x+width;
    frame.size.height = frame.size.height-_menuView.frame.size.height;
    self.tableView.frame = frame;

}
/**
 *  根据顶部菜单移动消息通知table  位置  和大小
 */
-(void)moveNoticeTablePosition{
    CGRect frame = self.noticeTable.frame;
    
    frame.origin.y = frame.origin.y+_menuView.frame.size.height;
    frame.size.height = frame.size.height-_menuView.frame.size.height;
    self.noticeTable.frame = frame;
}

-(void)MakeData{
    
    for (int i=0; i<5; i++) {
        NoticeCellResponse *model = [[NoticeCellResponse alloc] init];
        model.nickname = @"cc";
        model.option = @"回复了你的问题";
        model.time = @"34567";
        model.content = @"我就是在测试想一下";
        [_noticeDataSource addObject:model];
    }
    [self.noticeTable reloadData];
    
}

#pragma mark - mj
/**
 *  为通知table添加刷新
 */
-(void)setNoticeTableRefresh{

    self.noticeTable.mj_header = [MJRefreshNormalHeader headerWithRefreshingBlock:^{
        [self noticeTableHeaderRefresh];
    }];
    
    self.noticeTable.mj_footer = [MJRefreshAutoNormalFooter footerWithRefreshingBlock:^{
        [self noticeTableFooterRefresh];
    }];
    self.noticeTable.mj_footer.alpha = 0.0f;
}

-(void)noticeTableHeaderRefresh{
    [self.noticeTable.mj_header endRefreshing];
}

-(void)noticeTableFooterRefresh{
    [self.noticeTable.mj_footer endRefreshing];
    self.noticeTable.mj_footer.alpha = 0.0f;

}

#pragma mark - select menu
-(void)selectBtnClickedWith:(SelectMenuSelectBtn)btn{
    
    [self changeTableWith:btn];
}

-(void)changeTableWith:(SelectMenuSelectBtn)btn{

    CGRect noticeFrame = self.noticeTable.frame;
    CGRect messageFrame = self.tableView.frame;
    CGFloat width = SCREEN_WIDTH;
    
    if (btn==SelectMenuNoticBtn) {
        
        noticeFrame.origin.x = 0.0f;
        messageFrame.origin.x = width;
        [UIView animateWithDuration:0.5f animations:^{
            self.tableView.frame = messageFrame;
            self.noticeTable.frame = noticeFrame;
        } completion:^(BOOL finished) {
            self.tableView.hidden = YES;
        }];
        
    }else{
        noticeFrame.origin.x = -width;
        messageFrame.origin.x = 0.0f;
        self.tableView.hidden = NO;

        [UIView animateWithDuration:0.5f animations:^{
            self.tableView.frame = messageFrame;
            self.noticeTable.frame = noticeFrame;
        }];
    }
}

#pragma mark - table
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (tableView==_noticeTable) {
        return _noticeDataSource.count;

    }else{
       return [super tableView:tableView numberOfRowsInSection:section];
    }
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (tableView == _noticeTable) {
        NoticeTableCell *cell = [tableView dequeueReusableCellWithIdentifier:NoticeCell_id];
        
        if (cell==nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"NoticeTableCell" owner:nil options:nil] firstObject];
        }
        NoticeCellResponse *model = [_noticeDataSource objectAtIndex:indexPath.row];
        [cell setCellWithModel:model];

        return cell;
    }else{
        return [super tableView:tableView cellForRowAtIndexPath:indexPath];
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (tableView==_noticeTable) {
        NoticeCellResponse *model = [_noticeDataSource objectAtIndex:indexPath.row];
        return model.cellHeight;
    }else{
        return [super tableView: tableView heightForRowAtIndexPath:indexPath];
    }
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (tableView==_noticeTable) {
        MOSLog(@"通知cell点击");
        
    }else{
        [super tableView:tableView didSelectRowAtIndexPath:indexPath];
    }
}

@end
