//
//  NoticeCellResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "NoticeCellResponse.h"

static const CGFloat BasicHeight = 27.0f;

@implementation NoticeCellResponse

@synthesize nicknameAndOp = _nicknameAndOp;
@synthesize time = _time;

-(void)setNicknameAndOp:(NSString *)nicknameAndOp{
    _nicknameAndOp = nicknameAndOp;
}

-(NSString*)nicknameAndOp{
    if (_nicknameAndOp) {
        return _nicknameAndOp;
    }else{
        return [NSString stringWithFormat:@"%@ %@",self.nickname,self.option];
    }
}

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size = [self getStringSizeWith:_content fontSize:15.0f showSize:CGSizeMake(SCREEN_WIDTH, 2000)];
        _cellHeight = size.height+BasicHeight;
        return _cellHeight;
    }
}

-(void)setTime:(NSString *)time{
    
     _time = [CC_NSStringHandle formatTime:[time integerValue]];
    
}

@end
