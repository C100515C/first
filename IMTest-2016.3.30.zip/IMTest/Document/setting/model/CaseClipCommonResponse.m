//
//  CaseClipCommonResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipCommonResponse.h"

static const CGFloat BasicHeight = 50.0f;

@implementation CaseClipCommonResponse

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }
    
    _cellHeight = BasicHeight;
    
    return _cellHeight;
}

@end
