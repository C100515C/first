//
//  MineSetUserInforResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/24.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MineSetUserInforResponse.h"

@implementation MineSetUserInforResponse

-(NSMutableArray*)forumLabel{
    
    if (_forumLabel==nil) {
        _forumLabel = [NSMutableArray array];
    }
    return _forumLabel;
}

+(Class)forumLabel_class{
    return [NSDictionary class];
}

-(NSArray*)getForumLabelNames{
    NSMutableArray *arr = [NSMutableArray array];
    
    if (self.forumLabel && self.forumLabel.count!=0) {
        
        for (NSDictionary *dic in self.forumLabel) {
            [arr addObject:dic[@"forum_name"]];
        }
    }else{
        return @[@"无"];
    }
    
    return arr;
}

@end
