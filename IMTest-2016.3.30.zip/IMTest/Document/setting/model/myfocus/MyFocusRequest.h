//
//  MyFocusRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/30.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface MyFocusRequest : BaseRequest

@property (nonatomic,copy) NSString *user_id;
-(id)init;
@end
