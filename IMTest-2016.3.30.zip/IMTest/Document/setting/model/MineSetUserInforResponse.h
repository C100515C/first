//
//  MineSetUserInforResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/24.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface MineSetUserInforResponse : BasicResponse

@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *username;
@property (nonatomic,copy) NSString *avatar;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *gender;
@property (nonatomic,copy) NSString *birthdate;
@property (nonatomic,copy) NSString *signature;
@property (nonatomic,copy) NSString *address;
//@property (nonatomic,copy) NSString *description;
@property (nonatomic,copy) NSString *province;
@property (nonatomic,copy) NSString *city;
@property (nonatomic,copy) NSString *location;
@property (nonatomic,copy) NSString *post_count;
@property (nonatomic,copy) NSString *feed_count;
@property (nonatomic,copy) NSString *following_count;
@property (nonatomic,copy) NSString *follower_count;
@property (nonatomic,copy) NSString *unread_notice_count;
@property (nonatomic,copy) NSString *unread_message_count;
@property (nonatomic,copy) NSString *thread_count;
@property (nonatomic,copy) NSString *comment_count;
@property (nonatomic,copy) NSMutableArray *forumLabel;

+(Class)forumLabel_class;
-(NSArray*)getForumLabelNames;
@end
