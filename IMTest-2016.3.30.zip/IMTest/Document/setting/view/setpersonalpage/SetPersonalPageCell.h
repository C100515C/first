//
//  SetPersonalPageCell.h
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

@class SetPersonalPageResponse;
static NSString *const SetPersonalPage_id = @"SetPersonalPage";

@interface SetPersonalPageCell : BasicTableViewCell

@property (weak, nonatomic) IBOutlet BasicUIImageView *icon;
@property (weak, nonatomic) IBOutlet UILabel *content;
@property (weak, nonatomic) IBOutlet UILabel *des;

-(void)setCellWith:(SetPersonalPageResponse*)model;

@end
