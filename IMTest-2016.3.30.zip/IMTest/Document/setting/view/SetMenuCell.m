//
//  SetMenuCell.m
//  IMTest
//
//  Created by chenchen on 16/3/3.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SetMenuCell.h"

@implementation SetMenuCell

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
