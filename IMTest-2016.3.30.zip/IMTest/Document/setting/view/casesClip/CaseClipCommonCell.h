//
//  CaseClipCommonCell.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString *const CaseClipCommon_id = @"CaseClipCommon";

@class CaseClipCommonResponse;
@interface CaseClipCommonCell : BasicTableViewCell

@property (weak, nonatomic) IBOutlet UILabel *nametitle;

@property (weak, nonatomic) IBOutlet UILabel *content;
@property (weak, nonatomic) IBOutlet UIImageView *arrowImage;

-(void)setCellWith:(CaseClipCommonResponse*)model;

@end
