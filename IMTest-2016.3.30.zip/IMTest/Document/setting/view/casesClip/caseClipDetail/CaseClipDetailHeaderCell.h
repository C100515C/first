//
//  CaseClipDetailHeaderCell.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString *const CaseClipDetailHeader_id = @"CaseClipDetailHeader";
@class FamilyCasesClipResponse;
@interface CaseClipDetailHeaderCell : BasicTableViewCell

@property (nonatomic,strong) void (^addCaseClipRecordBlock)(void);

-(void)setCellWith:(FamilyCasesClipResponse*)model;

@end
