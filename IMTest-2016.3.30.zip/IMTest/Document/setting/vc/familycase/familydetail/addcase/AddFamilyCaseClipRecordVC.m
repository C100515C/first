//
//  AddFamilyCaseClipRecordVC.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "AddFamilyCaseClipRecordVC.h"
#import "CaseClipCommonCell.h"
#import "CaseClipCommonResponse.h"

#import "UIAlertController+LYJAlertView.h"
#import "UIViewController+HUD.h"

#import "LYJInputView.h"

@interface AddFamilyCaseClipRecordVC ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate,LYJInputViewDelegate>
{
    NSMutableArray *_dataSource;
    NSString *_dateString;

}
@property (weak, nonatomic) IBOutlet UITableView *myTable;

@property (nonatomic,strong) NSIndexPath *currentIndexPath;
@property (nonatomic,strong) UIDatePicker *datePicker;
@property (nonatomic,strong) UIView *dataBackView;
@property (nonatomic,strong) LYJInputView *inputView;

@property (strong, nonatomic) UIImagePickerController *imagePickerController;

@end

@implementation AddFamilyCaseClipRecordVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self setNav];
    
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    _dataSource = [[NSMutableArray alloc] init];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"CaseClipCommonCell" bundle:nil] forCellReuseIdentifier:CaseClipCommon_id];
    
    [self datePickerSelect];
    
    [self setInputView];
    
    [self makeModel];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Nav
-(void)setNav{
    [super setNav];
    self.title = @"添加门诊记录";
    
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    [nav setNavBarBtnItemTitleWith:@"完成" andRightItem:YES andAction:@selector(finishClickdAction:) andTarget:self andVCIndex:3 andTitleColor:nil];
}

-(void)finishClickdAction:(UIButton*)sender{
    
    MOSLog(@"完成");
}

#pragma mark - data

-(void)makeModel{
    
    [_dataSource addObjectsFromArray:[self getSecondSection]];
    
    [_myTable reloadData];
}


-(NSArray *)getSecondSection{
    NSMutableArray *sectionArr = [NSMutableArray array];
    NSArray *names = @[@"就诊时间：",@"就诊医院：",@"疾病分类：",@"检查报告："];
    NSArray *title = @[@"请选择就诊时间",@"请输入就诊医院",@"请选疾病分类",@"拍照上传就诊的处方、报告等"];

    for (int i=0 ; i<4; i++) {
        CaseClipCommonResponse *model = [[CaseClipCommonResponse alloc] init];
        model.content = title[i];
        
        model.isHideImage = NO;
        
        model.nameTitle = names[i];
        [sectionArr addObject:model];
    }
    return sectionArr;
}

-(void)resetDatasourceWith:(NSIndexPath*)indexpath andChangeValue:(NSString*)change{
    
    CaseClipCommonResponse *model = [_dataSource objectAtIndex:indexpath.row];
    model.content = change;
    
    
}

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CaseClipCommonResponse *model = (CaseClipCommonResponse*)[_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CaseClipCommonCell *cell = [tableView dequeueReusableCellWithIdentifier:CaseClipCommon_id];
    
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"CaseClipCommonCell" owner:nil options:nil] firstObject];
    }
    
    CaseClipCommonResponse *model = (CaseClipCommonResponse*)[_dataSource objectAtIndex:indexPath.row];
    
    [cell setCellWith:model];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;

    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.currentIndexPath = indexPath;

    switch (indexPath.row) {
        case 0:
        {
            //时间
            [self showDateView];

        }
            break;
        case 1:
        {
            //医院
            self.inputView.hidden = NO;
            [self.inputView keyboardAppear];
        }
            break;
        case 2:
        {
            //病类
            self.inputView.hidden = NO;
            [self.inputView keyboardAppear];
        }
            break;
        case 3:
        {
            //照片
            [self cellAvatarPress];
        }
            break;
        default:
            break;
    }
}

#pragma mark - 头像模块
- (void)cellAvatarPress
{
    MOSLog(@"Cell avatar press.");
    __weak typeof (self) weakSelf = self;
    UIAlertControllerActionBlock takephoto = ^(UIAlertAction *action){
        MOSLog(@"拍照");
        if ([LYJSystemCallsJudgeManager isCanUseCamera_CCWith:^{
            [self showHint:@"请去系统设置允许应用访问相机" yOffset:-300];
        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            weakSelf.imagePickerController.editing = YES;
            weakSelf.imagePickerController.allowsEditing = YES;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                     //
                                 }];
        }
    };
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"取消");
    };
    UIAlertControllerActionBlock pics = ^(UIAlertAction *action){
        MOSLog(@"从手机相册选择");
        if ([LYJSystemCallsJudgeManager iscanPictureAblumWith:^{
            [self showHint:@"请去系统设置允许应用访问相册" yOffset:-300];
            
        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                     
                                     [self prefersStatusBarHidden ];
                                     [self preferredStatusBarStyle];
                                 }];
            
        }
    };
    [UIAlertController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"拍照":takephoto,@"从手机相册选择":pics} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet];
    
    
}

#pragma mark - Property method

- (UIImagePickerController *)imagePickerController
{
    if (_imagePickerController == nil) {
        _imagePickerController = [[UIImagePickerController alloc] init];
        _imagePickerController.navigationBar.barTintColor = G_COLOR_NAVGATION_BACK;
        _imagePickerController.navigationBar.tintColor = [UIColor whiteColor];
        _imagePickerController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:G_COLOR_NAVGATION_TITLE,
                                                                     NSFontAttributeName:G_FONT_NAVGATION_TITLE};
        
        [self prefersStatusBarHidden ];
        [self preferredStatusBarStyle];
        
        _imagePickerController.delegate = self;
    }
    return _imagePickerController;
}

-(BOOL)prefersStatusBarHidden{
    return NO;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *picImage;
    //    = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
        picImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    } else {
        picImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    }
    
    __weak typeof(self) weakSelf = self;
    
    [self.imagePickerController dismissViewControllerAnimated:YES completion:^{
        MOSLog(@"dismiss self");
        NSData *data = UIImageJPEGRepresentation(picImage , 0.1);
        
    }];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self preferredStatusBarStyle];
    [picker dismissViewControllerAnimated:YES completion:^{
        [self preferredStatusBarStyle];
    }];
    
}

#pragma mark - gender select
-(void)selectGender{
    
    CaseClipCommonCell *cell = [_myTable cellForRowAtIndexPath:self.currentIndexPath];
    
    __weak typeof(self) weakself = self;
    UIAlertControllerActionBlock man = ^(UIAlertAction *action){
        cell.content.text = @"男";
        [weakself resetDatasourceWith:_currentIndexPath andChangeValue:cell.content.text];
        
    };
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"取消");
    };
    UIAlertControllerActionBlock woman = ^(UIAlertAction *action){
        cell.content.text = @"女";
        [weakself resetDatasourceWith:_currentIndexPath andChangeValue:cell.content.text];
        
    };
    [UIAlertController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"男":man,@"女":woman} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet];
}

#pragma mark - date select
-(void)datePickerSelect{
    self.dataBackView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 246)];
    _dataBackView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.dataBackView];
    
    self.datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 30, SCREEN_WIDTH, 216)];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    _datePicker.locale = locale;
    _datePicker.datePickerMode = UIDatePickerModeDate;
    
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM-dd"];
    
    //    NSString *  currentDate = [format stringFromDate:[NSDate date]];
    NSDate *minDate = [format dateFromString:@"1900-01-01"];
    NSDate *maxDate = [format dateFromString:@"2099-01-01"];
    
    _datePicker.minimumDate = minDate;
    _datePicker.maximumDate = maxDate;
    
    [self.datePicker setDate:[NSDate date]];
    [self.datePicker addTarget:self action:@selector(dateChangeAction:) forControlEvents:UIControlEventValueChanged];
    
    [self.dataBackView addSubview:_datePicker];
    
    UIButton *cancale = [UIButton buttonWithType:UIButtonTypeCustom];
    cancale.frame = CGRectMake(0, 0, 45, 30);
    [cancale addTarget:self action:@selector(cancelDateSelect:) forControlEvents:UIControlEventTouchUpInside];
    [cancale setTitle:@"取消" forState:UIControlStateNormal];
    [cancale setTitleColor:[UIColor darkTextColor] forState:UIControlStateNormal];
    [_dataBackView addSubview:cancale];
    
    UIButton *finish = [UIButton buttonWithType:UIButtonTypeCustom];
    finish.frame = CGRectMake( _dataBackView.frame.size.width-45,0, 45, 30);
    [finish addTarget:self action:@selector(finishDateSelect:) forControlEvents:UIControlEventTouchUpInside];
    [finish setTitle:@"完成" forState:UIControlStateNormal];
    [finish setTitleColor:[UIColor darkTextColor] forState:UIControlStateNormal];
    [_dataBackView addSubview:finish];
    
}

-(void)dateChangeAction:(id)sender{
    UIDatePicker* control = (UIDatePicker*)sender;
    NSDate* date = control.date;
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM-dd"];
    NSString *datestr = [format stringFromDate:date];
    //    MOSLog(@"%@",datestr);
    _dateString = datestr;
    
}

-(void)cancelDateSelect:(UIButton*)sender{
    [self takeBackDateView];
}

-(void)finishDateSelect:(UIButton*)sender{
    CaseClipCommonCell *cell = [_myTable cellForRowAtIndexPath:self.currentIndexPath];
    cell.content.text = _dateString;
    [self takeBackDateView];
    [self resetDatasourceWith:_currentIndexPath andChangeValue:_dateString];
    
}

-(void)takeBackDateView{
    CGRect frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 246);
    
    [UIView animateWithDuration:0.5 animations:^{
        self.dataBackView.frame = frame;
    }];
}
-(void)showDateView{
    CGRect frame = CGRectMake(0, SCREEN_HEIGHT-246, SCREEN_WIDTH, 246);
    [UIView animateWithDuration:0.5 animations:^{
        self.dataBackView.frame = frame;
    }];
}

#pragma mark - input view
-(void)setInputView{
    
    self.inputView = [[[NSBundle mainBundle] loadNibNamed:@"LYJInputView" owner:nil options:nil] firstObject];
    self.inputView.lyj_delegate = self;
    [self.view addSubview: self.inputView];
    
    self.inputView.hidden = YES;
    self.inputView.inputTitle.text = @"";
    [self.inputView.sendBtn setTitle:@"完成" forState:UIControlStateNormal];
    
}



#pragma mark - input delegate
-(void)sendBtnAction:(UIButton *)sender andText:(NSString *)text{
    if (text.length) {
        CaseClipCommonCell *cell = [_myTable cellForRowAtIndexPath:self.currentIndexPath];
        [self resetDatasourceWith:_currentIndexPath andChangeValue:text];
        cell.content.text = text;
    }
    
}

@end
