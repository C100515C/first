//
//  MyCollectionVC.m
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MyCollectionVC.h"

#import "CircleDetailCell.h"

#import "CircleDetailResponse.h"
#import "MyCollectionRequest.h"
#import "SingletonServ.h"

#import "UIViewController+HUD.h"

@interface MyCollectionVC ()
{
    NSMutableArray *_dataSource;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;

@end

@implementation MyCollectionVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self setNav];
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _dataSource = [[NSMutableArray alloc] init];
    [self.tableView registerNib:[UINib nibWithNibName:@"CircleDetailCell" bundle:nil] forCellReuseIdentifier:circleDetailCell_id];
    
    [self makeModelWith:1 with:nil andHeaderRef:YES];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Nav
-(void)setNav{
    [super setNav];

    self.title = @"我的收藏";

//    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
}

#pragma mark - data

-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{

    __weak typeof(self) weakself = self;
    NSString *userid;
    if (self.userid) {
        userid = self.userid;
    }else{
        userid = [[UserProfileManager sharedInstance] getUserId];
    }
    
    MyCollectionRequest *req = [[MyCollectionRequest alloc] init];
    req.user_id = userid;
    [[SingletonServ sharedInstance ] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            CircleDetailItemListResponse *model = (CircleDetailItemListResponse*)responseDataModel;
//            MOSLog(@"%@",model.itemList);
            [_dataSource addObjectsFromArray:model.itemList];
            [weakself.tableView reloadData];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
    }];
    
}

- (void)tableViewDidTriggerHeaderRefresh{
    
    [self tableViewDidFinishTriggerHeader:YES reload:NO];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    [self tableViewDidFinishTriggerHeader:NO reload:NO];
    
}//上拉加载事件

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CircleDetailResponse *model = (CircleDetailResponse*)[_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CircleDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:circleDetailCell_id];
    
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"CircleDetailCell" owner:nil options:nil] firstObject];
    }
    
    CircleDetailResponse *model = (CircleDetailResponse*)[_dataSource objectAtIndex:indexPath.row];
    
    [cell setCellWith:model andFormName:nil];
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CircleDetailResponse *model = (CircleDetailResponse*)[_dataSource objectAtIndex:indexPath.row];
    
}


@end
