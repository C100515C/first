//
//  RegisterUserInforVC.m
//  IMTest
//
//  Created by chenchen on 16/3/8.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "RegisterUserInforVC.h"
#import "BasicUIImageView.h"
#import "UIAlertController+LYJAlertView.h"
#import "UIViewController+HUD.h"

#import "RegisterRequest.h"
#import "RegisterResponse.h"
#import "SingletonServ.h"

@interface RegisterUserInforVC ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate,BasicUIImageTapProtocol,UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;
@property (weak, nonatomic) IBOutlet UIView *mideBackView;
@property (weak, nonatomic) IBOutlet UITextField *nickNameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UIButton *agreeAction;

@property (nonatomic,strong) NSData *iconData;
@property (nonatomic,strong) NSString *iconDataFormat;

- (IBAction)agreeBtnAction:(UIButton *)sender;

@property (strong, nonatomic) UIImagePickerController *imagePickerController;

@end

@implementation RegisterUserInforVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = YES;
    self.nickNameField.delegate = self;
    self.passwordField.delegate = self;
    
    [self setNav];
    [self.headerIcon setRaduis];
    [self.headerIcon setTapUse];
    self.headerIcon.lyj_delegate = self;
    

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    [self.nickNameField resignFirstResponder];
    [self.passwordField resignFirstResponder];
}

#pragma mark - net work
-(void)registerUser{
 
    RegisterRequest *req = [[RegisterRequest alloc] init];
    req.username = self.nickNameField.text;
    req.password = self.passwordField.text;
    req.authCode = self.userVerCode;
    req.phone = self.userPhone;
//    req.userAvatar = @"icon";
    
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"注册中..."];
    
    [[SingletonServ sharedInstance] reqPostWithModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            RegisterResponse *model = (RegisterResponse*)responseDataModel;
            
            MOSLog(@"%@-%@-%@-%@",model.uid,model.phone,model.token,model.avatar);
            [weakself.navigationController popToRootViewControllerAnimated:YES];
        
        }else{
            [weakself showHint:responeseError.msg yOffset:-100];
        }
        [weakself hideHud];
    } constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        if (weakself.iconData) {
            [formData appendPartWithFileData:weakself.iconData name:@"userAvatar" fileName:[NSString stringWithFormat:@"userAvatar.%@",weakself.iconDataFormat] mimeType:@"image/jpeg"];
        }
    }];
}

#pragma mark - judge str

-(BOOL)judgePhoneWith:(NSString*)num{
    if (self.nickNameField.text.length>=5 && self.nickNameField.text.length<=16) {
        return YES;
    }else{
        return NO;
    }
}

-(BOOL)judgeVerificationCodeWith:(NSString*)num{
    
    if (self.passwordField.text.length>=6 && self.passwordField.text.length<=16) {
        return YES;
        
    }else{
        return NO;
    }
}

#pragma mark- nav
-(void)setNav{
    
    [super setNav];

    // 设置navigationBar的背景颜色，根据需要自己设置
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    //     设置navigationController的title的字体颜色
    NSDictionary * dict=[NSDictionary dictionaryWithObject:[UIColor darkGrayColor] forKey:NSForegroundColorAttributeName];
    self.navigationController.navigationBar.titleTextAttributes = dict;
    self.title = @"注册";
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
//    [nav setNavBarBtnItemImageWith:@"topicon_back" andRightItem:NO andAction:@selector(popVC:) andTarget:self andVCIndex:2];
    [nav setBackBtnWith:@"topicon_back" withCurrentVC:self andBackAction:@selector(popVC:)];

    [nav setNavBarBtnItemTitleWith:@"提交注册" andRightItem:YES andAction:@selector(pushVC:) andTarget:self andVCIndex:2 andTitleColor:RGB(81, 196, 127, 1)];
}

-(void)popVC:(UIButton*)btn{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)pushVC:(UIButton*)btn{
    MOSLog(@"注册");
    
    if ([self judgeVerificationCodeWith:self.nickNameField.text] && [self judgePhoneWith:self.passwordField.text]) {
        
        [self registerUser];

    }else{
        [self showHint:@"昵称和密码不能为空" yOffset:-300];
    }
}

#pragma mark- btn
- (IBAction)agreeBtnAction:(UIButton *)sender {
    
}

#pragma mark - image tap 
-(void)imageTapWith:(UITapGestureRecognizer*)sender{
    [self cellAvatarPress];
}

#pragma mark - 头像模块
- (void)cellAvatarPress
{
    MOSLog(@"Cell avatar press.");
    __weak typeof (self) weakSelf = self;
    UIAlertControllerActionBlock takephoto = ^(UIAlertAction *action){
        MOSLog(@"拍照");
        if ([LYJSystemCallsJudgeManager isCanUseCamera_CCWith:^{
            [self showHint:@"请去系统设置允许应用访问相机" yOffset:-300];
        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            weakSelf.imagePickerController.editing = YES;
            weakSelf.imagePickerController.allowsEditing = YES;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                     //
                                 }];
        }
    };
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"取消");
    };
    UIAlertControllerActionBlock pics = ^(UIAlertAction *action){
        MOSLog(@"从手机相册选择");
        if ([LYJSystemCallsJudgeManager iscanPictureAblumWith:^{
            [self showHint:@"请去系统设置允许应用访问相册" yOffset:-300];
            
        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                    
                                     
                                     [self prefersStatusBarHidden ];
                                     [self preferredStatusBarStyle];
                                 }];
            
        }
    };
    [UIAlertController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"拍照":takephoto,@"从手机相册选择":pics} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet];
    
    
}



#pragma mark - Property method

- (UIImagePickerController *)imagePickerController
{
    if (_imagePickerController == nil) {
        _imagePickerController = [[UIImagePickerController alloc] init];
        _imagePickerController.navigationBar.barTintColor = G_COLOR_NAVGATION_BACK;
        _imagePickerController.navigationBar.tintColor = [UIColor whiteColor];
        _imagePickerController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:G_COLOR_NAVGATION_TITLE,
                                                                     NSFontAttributeName:G_FONT_NAVGATION_TITLE};

        [self prefersStatusBarHidden ];
        [self preferredStatusBarStyle];
        
        _imagePickerController.delegate = self;
    }
    return _imagePickerController;
}

-(BOOL)prefersStatusBarHidden{
    return NO;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *picImage;
    //    = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
        picImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    } else {
        picImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    }
    NSURL *imagePath = [info objectForKey:@"UIImagePickerControllerReferenceURL"];
    NSString *imagePathStr = [NSString stringWithFormat:@"%@",imagePath];
    NSArray *imagePaths = [imagePathStr componentsSeparatedByString:@"="];
    self.iconDataFormat = [imagePaths lastObject];
    __weak typeof(self) weakSelf = self;

    [self.imagePickerController dismissViewControllerAnimated:YES completion:^{
        MOSLog(@"dismiss self");
        NSData *data = UIImageJPEGRepresentation(picImage , 0.1);
        weakSelf.headerIcon.image = picImage;
        weakSelf.iconData = data;
    }];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self preferredStatusBarStyle];
    [picker dismissViewControllerAnimated:YES completion:^{
        [self preferredStatusBarStyle];
    }];
    
}
#pragma mark - text field
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSInteger lenth = textField.text.length+string.length;
    if (textField == self.nickNameField) {
        if (!(lenth<=16)) {
            [self showHint:@"昵称为5～16个字符" yOffset:-400];
            
            return NO;
        }
    }else{
        if (!(lenth<=16)) {
            [self showHint:@"密码为6～16个字符" yOffset:-400];
            
            return NO;
        }
    }   
    return YES;
}

@end
