//
//  CC_SsoModel.m
//  StoryBoardTest
//
//  Created by mac on 15/7/14.
//  Copyright (c) 2015年 CC. All rights reserved.
//

#import "CC_SsoModel.h"

@implementation CC_SsoModel

-(void)set_myModelWith:(NSDictionary *)inforDic andPlatform:(PlatformName_cc)name{
    
    switch (name) {
        case QQ:{
            self.name = [inforDic objectForKey:@"screen_name"];
            self.user_id = [inforDic objectForKey:@"uid"] ;
            self.gender = [inforDic objectForKey:@"gender"];
            self.access_token = [inforDic objectForKey:@"access_token"];
            self.user_icon_url = [inforDic objectForKey:@"profile_image_url"];
        }
            break;
            
        case Sina:{
            self.name = [inforDic objectForKey:@"screen_name"];
            self.user_id = [[inforDic objectForKey:@"uid"] stringValue];
            self.gender = [[inforDic objectForKey:@"gender"] intValue]==1?@"男":@"女";
            self.access_token = [inforDic objectForKey:@"access_token"];
            self.user_icon_url = [inforDic objectForKey:@"profile_image_url"];
        }
            break;
            
        case WeiChat:{
            self.name = [inforDic objectForKey:@"screen_name"];
            self.user_id = [inforDic objectForKey:@"openid"];
            self.gender = [[inforDic objectForKey:@"gender"] intValue]==1?@"男":@"女";
            self.access_token = [inforDic objectForKey:@"access_token"];
            self.user_icon_url = [inforDic objectForKey:@"profile_image_url"];
        }
            break;
            
        default:
            break;
    }
    
}

@end
