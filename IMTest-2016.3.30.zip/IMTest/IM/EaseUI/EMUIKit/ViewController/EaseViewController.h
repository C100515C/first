//
//  EaseViewController.h
//  ChatDemo-UI3.0
//
//  Created by dhc on 15/6/24.
//  Copyright (c) 2015年 easemob.com. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface EaseViewController : UIViewController

@property (strong, nonatomic) NSArray *rightItems;

//default YES;
@property (nonatomic) BOOL endEditingWhenTap;

@end
