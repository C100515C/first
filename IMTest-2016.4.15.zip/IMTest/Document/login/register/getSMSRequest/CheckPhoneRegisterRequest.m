//
//  CheckPhoneRegisterRequest.m
//  IMTest
//
//  Created by chenchen on 16/4/14.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CheckPhoneRegisterRequest.h"

@implementation CheckPhoneRegisterRequest
- (id)init
{
    self = [super init];
    if (self) {
        self.reqUrlPath = @"registers?";
        
        self.reqMethod = @"GET";
//        self.reqMethod = @"POST";
        self.reqClassName = @"CheckPhoneRegister";
    }
    return self;
}

@end
