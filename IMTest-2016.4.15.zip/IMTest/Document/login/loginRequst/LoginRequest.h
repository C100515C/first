//
//  LoginRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/21.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface LoginRequest : BaseRequest

@property (strong, nonatomic) NSString *username;
@property (strong, nonatomic) NSString *password;
//@property (strong, nonatomic) NSString *phone;

- (id)init;

@end
