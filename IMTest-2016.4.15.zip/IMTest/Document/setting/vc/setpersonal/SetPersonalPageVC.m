//
//  SetPersonalPageVC.m
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SetPersonalPageVC.h"

#import "SetPersonalPageCell.h"
#import "SetPersonalPageResponse.h"
#import "SetPersonalInforRequest.h"
#import "SingletonServ.h"

#import "UIViewController+LYJAlertView.h"
#import "UIViewController+HUD.h"
#import "LYJInputView.h"

#import "GetProvinceVC.h"


@interface SetPersonalPageVC ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate,LYJInputViewDelegate,GetProvinceProtocol>{

    NSMutableArray *_dataSource;
    NSString *_dateString;
}

@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (strong, nonatomic) UIImagePickerController *imagePickerController;
@property (nonatomic,strong) NSIndexPath *currentIndexPath;
@property (nonatomic,strong) UIDatePicker *datePicker;
@property (nonatomic,strong) UIView *dataBackView;
@property (nonatomic,strong) LYJInputView *inputView;

@property (nonatomic,copy) NSString *getProAndCity_id;
@property (nonatomic,strong) NSData *imageData;
@property (nonatomic,strong) NSString *iconDataFormat;

@end

@implementation SetPersonalPageVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    _dataSource = [[NSMutableArray alloc] init];
    [self.tableView registerNib:[UINib nibWithNibName:@"SetPersonalPageCell" bundle:nil] forCellReuseIdentifier:SetPersonalPage_id];
    
    [self datePickerSelect];
    
    [self setInputView];
    
    [self setNav];
    
    [self makeModel];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - make data
-(void)makeModel{
    
    UserProfileEntity *infor = [[UserProfileManager sharedInstance] getCurUserProfile];
    
    NSArray *arr = @[@{@"imageUrl":infor.avatar},@{@"username":infor.username},@{@"gender":infor.genderStr},@{@"birthdate":infor.birthdate},@{@"address":infor.location},@{@"signature":infor.signature}];
    
    self.getProAndCity_id = infor.addres_id;
    
    for (NSDictionary *dic in arr) {
        SetPersonalPageResponse *model = [[SetPersonalPageResponse alloc] init];
        model.name = [[dic allKeys] firstObject];
        model.content = [[dic allValues] firstObject];
        model.key = [[dic allKeys] firstObject];
        [_dataSource addObject:model];
    }
 
    [_myTable reloadData];
}

-(void)resetDatasourceWith:(NSIndexPath*)indexpath andChangeValue:(NSString*)change{
    
    if (indexpath.section==0) {
        SetPersonalPageResponse *model = [_dataSource objectAtIndex:indexpath.row];
        model.content = change;
    }else{
        SetPersonalPageResponse *model = [_dataSource objectAtIndex:indexpath.row+1];
        model.content = change;
    }
    
}

-(void)finishStoreNewInfor{
    
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"修改中..."];
    SetPersonalInforRequest *req = [[SetPersonalInforRequest alloc] init];
    [req setParamaWith:_dataSource withProAndCity:_getProAndCity_id];
    
    [[SingletonServ sharedInstance ] reqPostWithModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            
            SetPersonalPageResponse *model = (SetPersonalPageResponse*)responseDataModel;
            
            [[UserProfileManager sharedInstance] updateUserInforWith:@{@"imageUrl":model.avatar,@"avatar":model.avatar}];
            
            dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
                NSDictionary *dic = [[UserProfileManager sharedInstance] getModelProperties];
                
                NSMutableDictionary *newInforDic = [[NSMutableDictionary alloc]initWithDictionary:dic];
                
                for (SetPersonalPageResponse *model in _dataSource) {
                    NSString *modelKey = model.key;
                    NSString *content = model.content;
                    
                    if ([model.key isEqualToString:@"gender"]) {
                        if ([content isEqualToString:@"男"]) {
                            content = @"1";
                        }else if([content isEqualToString:@"女"]){
                            content = @"2";
                        }else{
                            content = @"0";
                        }
                    }
                    
                    if ([model.key isEqualToString:@"address"]) {
                        [newInforDic setObject:content forKey:@"location"];
                    }
                    
                    [newInforDic setValue:content forKey:modelKey];
                }
                
                [newInforDic setValue:_getProAndCity_id forKey:@"addres_id"];
                dispatch_async(dispatch_get_main_queue(), ^{
                    [[UserProfileManager sharedInstance] updateUserInforWith:newInforDic andFinished:^(BOOL finish) {
                        if (weakself.lyj_delegate && [weakself.lyj_delegate respondsToSelector:@selector(finishEditWit:)]) {
                            [weakself.lyj_delegate finishEditWit:model.avatar];
                        }
                    }];
                    
                });
            });
            [weakself.navigationController popViewControllerAnimated:YES];

        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
        [weakself hideHud];
        
    } constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        if (weakself.imageData) {
            [formData appendPartWithFileData:weakself.imageData name:@"userAvatar" fileName:[NSString stringWithFormat:@"userAvatar.%@",weakself.iconDataFormat] mimeType:@"image/jpeg"];
        }
        
    }];
    
}

#pragma mark - nav 
-(void)setNav{
    [super setNav];

    self.title = @"个人主页";
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
    [nav setNavBarBtnItemTitleWith:@"完成" andRightItem:YES andAction:@selector(finishClickdAction:) andTarget:self andVCIndex:1 andTitleColor:G_COLOR_GREEN];
}

-(void)finishClickdAction:(UIButton*)sender{

    if ([self isCanAmend]) {
        [self finishStoreNewInfor];

    }else{
        [self showHint:@"请将信息填写完整" yOffset:-200];
    }
    
}

-(BOOL)isCanAmend{
    
    for (SetPersonalPageResponse *model in _dataSource) {
        NSString *name = model.content;
        if (name.length==0) {
            return NO;
        }
    }
    return YES;
}

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 2;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==0) {
       
        SetPersonalPageResponse *model = (SetPersonalPageResponse*) [_dataSource firstObject];
        return model.cellHeight;
        
    }else{
        
        SetPersonalPageResponse *model = (SetPersonalPageResponse*)[_dataSource objectAtIndex:indexPath.row+1];
        return model.cellHeight;
    }
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==0) {
        
        return 1;
    }else{
      
        return _dataSource.count-1;
    }
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    if (indexPath.section==0) {
        
        SetPersonalPageCell *cell = [tableView dequeueReusableCellWithIdentifier:SetPersonalPage_id];
        
        if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"SetPersonalPageCell" owner:nil options:nil] firstObject];
        }
        
        SetPersonalPageResponse *model = (SetPersonalPageResponse*)[_dataSource firstObject];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        if (self.imageData) {
            cell.icon.image = [UIImage imageWithData:self.imageData];
        }else{
            [cell setCellWith:model];

        }
        
        return cell;
        
    }else{
        SetPersonalPageCell *cell = [tableView dequeueReusableCellWithIdentifier:SetPersonalPage_id];
        
        if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"SetPersonalPageCell" owner:nil options:nil] firstObject];
        }
        
        SetPersonalPageResponse *model = (SetPersonalPageResponse*)[_dataSource objectAtIndex:indexPath.row+1];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

        [cell setCellWith:model];
        
        return cell;
    }
    
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section==0) {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 15)];
        view.backgroundColor = RGB(247, 249, 249, 1);
        return view;
        
    }else{
        return [[UIView alloc] init];
    }
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 15.0f;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    self.currentIndexPath = indexPath;
    
    if (indexPath.section==0) {
        
        switch (indexPath.row) {
            case 0:
            {
                [self cellAvatarPress];
            }
                break;
                
            default:
                break;
        }
        
    }else{
        
        switch (indexPath.row) {
            case 0:
            {
                self.inputView.hidden = NO;
                [self.inputView keyboardAppear];

            }
                break;
            case 1:
            {
                [self selectGender];
            }
                break;
            case 2:
            {
                [self showDateView];
            }
                break;
            case 3:
            {
//                self.inputView.hidden = NO;
//                [self.inputView keyboardAppear];

                GetProvinceVC *vc = [[GetProvinceVC alloc] init];
                vc.title = @"省份";
                vc.lyj_delegate = self;
                [self.navigationController pushViewController:vc animated:YES];
            }
                break;
            case 4:
            {
                self.inputView.hidden = NO;
                [self.inputView keyboardAppear];


            }
                break;
                
            default:
                break;
        }
    }
    
    
}

#pragma mark - 头像模块
- (void)cellAvatarPress
{
    MOSLog(@"Cell avatar press.");
    __weak typeof (self) weakSelf = self;
    UIAlertControllerActionBlock takephoto = ^(UIAlertAction *action){
        MOSLog(@"拍照");
        if ([LYJSystemCallsJudgeManager isCanUseCamera_CCWith:^{
            [self showHint:@"请去系统设置允许应用访问相机" yOffset:-300];
        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            weakSelf.imagePickerController.editing = YES;
            weakSelf.imagePickerController.allowsEditing = YES;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                     //
                                 }];
        }
    };
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"取消");
    };
    UIAlertControllerActionBlock pics = ^(UIAlertAction *action){
        MOSLog(@"从手机相册选择");
        if ([LYJSystemCallsJudgeManager iscanPictureAblumWith:^{
            [self showHint:@"请去系统设置允许应用访问相册" yOffset:-300];
            
        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                     
                                     [self prefersStatusBarHidden ];
                                     [self preferredStatusBarStyle];
                                 }];
            
        }
    };
    [UIViewController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"拍照":takephoto,@"从手机相册选择":pics} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet andalertTag:700];
    
    
}

#pragma mark - Property method

- (UIImagePickerController *)imagePickerController
{
    if (_imagePickerController == nil) {
        _imagePickerController = [[UIImagePickerController alloc] init];
        _imagePickerController.navigationBar.barTintColor = RGB(75, 186, 251, 1);//G_COLOR_NAVGATION_BACK;

        _imagePickerController.navigationBar.tintColor = [UIColor whiteColor];
        _imagePickerController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:G_COLOR_NAVGATION_TITLE,
                                                                     NSFontAttributeName:G_FONT_NAVGATION_TITLE};
    
        [self prefersStatusBarHidden ];
        [self preferredStatusBarStyle];
        
        _imagePickerController.delegate = self;
    }
    return _imagePickerController;
}

-(BOOL)prefersStatusBarHidden{
    return NO;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *picImage;
    //    = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
        picImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    } else {
        picImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    }
    
    NSURL *imagePath = [info objectForKey:@"UIImagePickerControllerReferenceURL"];
    NSString *imagePathStr = [NSString stringWithFormat:@"%@",imagePath];
    NSArray *imagePaths = [imagePathStr componentsSeparatedByString:@"="];
    self.iconDataFormat = [imagePaths lastObject];
    
    __weak typeof(self) weakSelf = self;
    
    [self.imagePickerController dismissViewControllerAnimated:YES completion:^{
        MOSLog(@"dismiss self");
        NSData *data = UIImageJPEGRepresentation(picImage , 0.1);
        
        SetPersonalPageCell *cell = [_myTable cellForRowAtIndexPath:weakSelf.currentIndexPath];
        cell.icon.image = picImage;
        weakSelf.imageData = data;
    }];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self preferredStatusBarStyle];
    [picker dismissViewControllerAnimated:YES completion:^{
        [self preferredStatusBarStyle];
    }];
    
}

#pragma mark - gender select
-(void)selectGender{

    
    SetPersonalPageCell *cell = [_myTable cellForRowAtIndexPath:self.currentIndexPath];
    
    __weak typeof(self) weakself = self;
    UIAlertControllerActionBlock man = ^(UIAlertAction *action){
        cell.content.text = @"男";
        [weakself resetDatasourceWith:_currentIndexPath andChangeValue:cell.content.text];

    };
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"取消");
    };
    UIAlertControllerActionBlock woman = ^(UIAlertAction *action){
        cell.content.text = @"女";
        [weakself resetDatasourceWith:_currentIndexPath andChangeValue:cell.content.text];

    };
    [UIViewController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"男":man,@"女":woman} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet andalertTag:701];
}

#pragma mark - date select
-(void)datePickerSelect{
    
    self.dataBackView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 246)];
    _dataBackView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.dataBackView];
    
    self.datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 30, SCREEN_WIDTH, 216)];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    _datePicker.locale = locale;
    _datePicker.datePickerMode = UIDatePickerModeDate;
    
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM-dd"];
    
    NSDate *minDate = [format dateFromString:@"1900-01-01"];
    NSDate *maxDate = [format dateFromString:@"2099-01-01"];
    
    _datePicker.minimumDate = minDate;
    _datePicker.maximumDate = maxDate;
    
    [self.datePicker setDate:[NSDate date]];
    [self.datePicker addTarget:self action:@selector(dateChangeAction:) forControlEvents:UIControlEventValueChanged];
    
    [self.dataBackView addSubview:_datePicker];

    UIButton *cancale = [UIButton buttonWithType:UIButtonTypeCustom];
    cancale.frame = CGRectMake(0, 0, 45, 30);
    [cancale addTarget:self action:@selector(cancelDateSelect:) forControlEvents:UIControlEventTouchUpInside];
    [cancale setTitle:@"取消" forState:UIControlStateNormal];
    [cancale setTitleColor:[UIColor darkTextColor] forState:UIControlStateNormal];
    [_dataBackView addSubview:cancale];
    
    UIButton *finish = [UIButton buttonWithType:UIButtonTypeCustom];
    finish.frame = CGRectMake( _dataBackView.frame.size.width-45,0, 45, 30);
    [finish addTarget:self action:@selector(finishDateSelect:) forControlEvents:UIControlEventTouchUpInside];
    [finish setTitle:@"完成" forState:UIControlStateNormal];
    [finish setTitleColor:[UIColor darkTextColor] forState:UIControlStateNormal];
    [_dataBackView addSubview:finish];
    
   
    NSDate* date = self.datePicker.date;
    [format setDateFormat:@"yyyy-MM-dd"];
    NSString *datestr = [format stringFromDate:date];
    _dateString = datestr;
}

-(void)dateChangeAction:(id)sender{
    UIDatePicker* control = (UIDatePicker*)sender;
    NSDate* date = control.date;
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM-dd"];
    NSString *datestr = [format stringFromDate:date];
    _dateString = datestr;
    
}

-(void)cancelDateSelect:(UIButton*)sender{
    [self takeBackDateView];
}

-(void)finishDateSelect:(UIButton*)sender{
    SetPersonalPageCell *cell = [_myTable cellForRowAtIndexPath:self.currentIndexPath];
    cell.content.text = _dateString;
    [self takeBackDateView];
    [self resetDatasourceWith:_currentIndexPath andChangeValue:_dateString];

}

-(void)takeBackDateView{
    CGRect frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 246);
    
    [UIView animateWithDuration:0.5 animations:^{
        self.dataBackView.frame = frame;
    }];
}
-(void)showDateView{
    CGRect frame = CGRectMake(0, SCREEN_HEIGHT-246, SCREEN_WIDTH, 246);
    [UIView animateWithDuration:0.5 animations:^{
        self.dataBackView.frame = frame;
    }];
}

#pragma mark - input view
-(void)setInputView{

    self.inputView = [[[NSBundle mainBundle] loadNibNamed:@"LYJInputView" owner:nil options:nil] firstObject];
    self.inputView.lyj_delegate = self;
    [self.view addSubview: self.inputView];
    
    self.inputView.hidden = YES;
    self.inputView.inputTitle.text = @"";
    [self.inputView.sendBtn setTitle:@"完成" forState:UIControlStateNormal];
    
}



#pragma mark - input delegate
-(void)sendBtnAction:(UIButton *)sender andText:(NSString *)text{
    if (text.length) {
        SetPersonalPageCell *cell = [_myTable cellForRowAtIndexPath:self.currentIndexPath];
        [self resetDatasourceWith:_currentIndexPath andChangeValue:text];

        if (_currentIndexPath.row==4) {
            cell.des.text = text;
            [_myTable reloadData];
        }
        cell.content.text = text;
    }
    
}

#pragma mark - get province
-(void)getProvinceWith:(NSString *)province andCityWith:(NSString *)city andProvince_id:(NSString *)pro_id andCity_id:(NSString *)city_id{
    SetPersonalPageCell *cell = [_myTable cellForRowAtIndexPath:self.currentIndexPath];
    NSString *text = [NSString stringWithFormat:@"%@-%@",province,city];
    cell.content.text = text;
    [self resetDatasourceWith:_currentIndexPath andChangeValue:text];
    self.getProAndCity_id = [NSString stringWithFormat:@"%@-%@",pro_id,city_id];
}

#pragma mark - sheet
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (actionSheet.tag==700) {
        NSString *str = [actionSheet buttonTitleAtIndex:buttonIndex];
        if ([str isEqualToString:@"拍照"]) {
            if ([LYJSystemCallsJudgeManager isCanUseCamera_CCWith:^{
                [self showHint:@"请去系统设置允许应用访问相机" yOffset:-300];
            }]) {
                self.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
                self.imagePickerController.editing = YES;
                self.imagePickerController.allowsEditing = YES;
                [self presentViewController:self.imagePickerController
                                   animated:YES
                                 completion:^{
                                     //
                                 }];
            }
        }else if ([str isEqualToString:@"从手机相册选择"]){
            if ([LYJSystemCallsJudgeManager iscanPictureAblumWith:^{
                [self showHint:@"请去系统设置允许应用访问相册" yOffset:-300];
                
            }]) {
                self.imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:self.imagePickerController
                                   animated:YES
                                 completion:^{
                                     
                                     [self prefersStatusBarHidden ];
                                     [self preferredStatusBarStyle];
                                 }];
                
            }
        }
        
    }else if(actionSheet.tag==701){
        NSString *str = [actionSheet buttonTitleAtIndex:buttonIndex];
        
        SetPersonalPageCell *cell = (SetPersonalPageCell*)[self.myTable cellForRowAtIndexPath:_currentIndexPath ];
        
        if ([str isEqualToString:@"男"]) {
            cell.content.text = @"男";
            [self resetDatasourceWith:_currentIndexPath andChangeValue:cell.content.text];
        }else if([str isEqualToString:@"女"]){
            cell.content.text = @"女";
            [self resetDatasourceWith:_currentIndexPath andChangeValue:cell.content.text];
        }
    }
}


@end
