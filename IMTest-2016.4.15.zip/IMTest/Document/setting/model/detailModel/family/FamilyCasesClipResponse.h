//
//  FamilyCasesClipResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface FamilyCasesClipResponse : BasicResponse

@property (nonatomic,copy) NSString *nickname;
@property (nonatomic,copy) NSString *gender;
@property (nonatomic,copy) NSString *age;
@property (nonatomic,copy) NSString *caseCount;

@property (nonatomic,assign) BOOL needHighHeight;

@end
