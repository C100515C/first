//
//  CaseClipDetailRecordCell.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString *const CaseClipDetailRecord_id = @"CaseClipDetailRecord";
@class CaseClipDetailResponse;
@interface CaseClipDetailRecordCell : BasicTableViewCell

@property (nonatomic,strong) void (^delBtnClickedBlock)(__weak CaseClipDetailResponse *model);
@property (nonatomic,strong) void (^editBtnClickedBlock)(__weak CaseClipDetailResponse *model);

-(void)setCellWith:(CaseClipDetailResponse*)model;

@end
