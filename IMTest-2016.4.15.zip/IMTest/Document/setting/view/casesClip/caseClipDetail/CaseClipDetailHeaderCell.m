//
//  CaseClipDetailHeaderCell.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipDetailHeaderCell.h"
#import "FamilyCasesClipResponse.h"

@interface CaseClipDetailHeaderCell ()

@property (weak, nonatomic) IBOutlet UILabel *callName;

@property (weak, nonatomic) IBOutlet UILabel *gender;
@property (weak, nonatomic) IBOutlet UILabel *age;
@property (weak, nonatomic) IBOutlet UILabel *caseCount;
- (IBAction)addClicked:(UIButton *)sender;

@end

@implementation CaseClipDetailHeaderCell

-(void)setCellWith:(FamilyCasesClipResponse *)model{

    
    self.callName.text = model.nickname;
    
    self.gender.text = model.gender;
    
    self.age.text = model.age;
    
    self.caseCount.text = model.caseCount;
}

- (IBAction)addClicked:(UIButton *)sender {
    
    if (_addCaseClipRecordBlock) {
        _addCaseClipRecordBlock();
    }
}
@end
