//
//  MineSettingVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MineSettingVC.h"
#import "UserInforCell.h"
#import "SetMenuCell.h"
//#import "UserProfileManager.h"

#import "PersonalHomepageCell.h"

#import "SetPersonalPageVC.h"
#import "MyCollectionVC.h"
#import "MyFocusVC.h"
#import "MySettingVC.h"
#import "MyFamilyCasesClipVC.h"
#import "UMFeedback.h"
#import "AboutUsVC.h"
#import "circleDetailVC.h"

#import "UIViewController+HUD.h"

#import "SingletonServ.h"
#import "MineSetUserInforRequest.h"
#import "MineSetUserInforResponse.h"

#import "NotificationManager.h"

@interface MineSettingVC ()<SetPersonalProtocol>{
    NSMutableArray *_source;
    
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;

@end

@implementation MineSettingVC


- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;

    [super viewDidLoad];
    
    self.title = @"我的";
    
    self.myTable.delegate = self;
    self.myTable.dataSource = self;
//    self.myTable.tableFooterView = [[UIView alloc] init];
//    self.myTable.tableHeaderView = [[UIView alloc] init];
    
    [self.myTable registerNib:[UINib nibWithNibName:@"PersonalHomepageCell" bundle:nil] forCellReuseIdentifier:PersonalHomepageCell_id];
    [self.myTable registerNib:[UINib nibWithNibName:@"SetMenuCell" bundle:nil] forCellReuseIdentifier:setMenuCell_id];
    if ([[UserProfileManager sharedInstance] getLoginState]) {
        [self getMineInfor];
    }
    
    [NotificationManager changeMessagePushStateWith:[NotificationManager isAllowedNotification]];
    [NotificationManager changeAppPushStateWith:[NotificationManager isAllowedNotification]];

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self makeDataSource];
}

-(void)refreshTable{
    [self getMineInfor];

}

#pragma mark - net work
-(void)getMineInfor{
    
    MineSetUserInforRequest *req = [[MineSetUserInforRequest alloc] init];
    __weak typeof(self) weakself = self;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
       
        if (responeseError==nil) {
            MineSetUserInforResponse *model = (MineSetUserInforResponse*)responseDataModel;
            
            [[UserProfileManager sharedInstance] updateUserInforWith:[model getUserProfileDic] andFinished:^(BOOL finish) {
                [weakself makeDataSource];
            }];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
    }];
    
}

#pragma mark - data
-(void)makeDataSource{
    _source = [NSMutableArray array];
    
    UserProfileEntity *user_model = [[UserProfileManager sharedInstance] getCurUserProfile];
    
    if (!user_model.isLogin) {
        [self showHint:@"请先去登陆"];
        return;
    }
    NSArray *firstSection = @[user_model];
    
    [_source addObject:firstSection];
    
    NSArray *menu_name = @[@"家庭病历夹",@"我收藏的",@"我关注的",@"问题反馈",@"关于我们",@"设置"];
    NSArray *menu_img = @[@"meicon_blj.png",@"icon_shoucan2.png",@"icon_guanzhu2.png",@"meicon_wtfk.png",@"meicon_关于我们.png",@"meicon_sz.png"];
    
    NSMutableArray *second = [NSMutableArray array];

    for (int i=0;i<menu_img.count ; i++) {
        
        NSDictionary *dic = @{@"name":menu_name[i],@"img":menu_img[i]};
        [second addObject:dic];
        
        if (i==0 || i==2 || i==5) {
            NSMutableArray *tmp = [[NSMutableArray alloc] initWithArray:second];
            [_source addObject:tmp];
            [second removeAllObjects];
        }

    }
    [_myTable reloadData];
}

#pragma mark - table
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _source.count;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    NSArray *arr = _source[section];
    return arr.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        NSArray *arr = _source[indexPath.section];
        UserProfileEntity *user_model = arr[indexPath.row];
        return user_model.newHeight;
    }else{
        
        if (indexPath.section==1 && indexPath.row==0) {
            return 0.0f;//隐藏家庭病例cell
        }
        return 48.0f;
    }
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    if (indexPath.section==0 ) {
       PersonalHomepageCell *cell = [tableView dequeueReusableCellWithIdentifier:PersonalHomepageCell_id];
        
        if (cell==nil) {
            cell  = [[[NSBundle mainBundle] loadNibNamed:@"PersonalHomepageCell" owner:nil options:nil] firstObject];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        UserProfileEntity *model = [[_source objectAtIndex:indexPath.row] objectAtIndex:indexPath.row];
        [cell setCellWithUserModel:model];
        __weak typeof(self) weakself = self;
        cell.isMySelf = YES;
        cell.tapBlock = ^{
            SetPersonalPageVC *vc = [[SetPersonalPageVC alloc] init];
            vc.hidesBottomBarWhenPushed = YES;
            vc.lyj_delegate = weakself;
            [weakself.navigationController pushViewController:vc animated:YES];
        };
        
        cell.PersonalHeaderLabelTapBlock = ^(NSInteger index){
            NSDictionary *dic = model.forumLabel[index];
            circleDetailVC *vc = [[circleDetailVC alloc] init];
            vc.forum_id = [NSString stringWithFormat:@"%@",dic[@"key"]];
            vc.hidesBottomBarWhenPushed = YES;
            [weakself.navigationController pushViewController:vc animated:YES];
        };
        
        return cell;
    }else {
        SetMenuCell *cell = [tableView dequeueReusableCellWithIdentifier:setMenuCell_id];
        
        if (cell==nil) {
            cell  = [[[NSBundle mainBundle] loadNibNamed:@"SetMenuCell" owner:nil options:nil] firstObject];
        }
        
        NSDictionary *dic = [[_source objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
        
        cell.icon.image = [UIImage imageNamed:dic[@"img"]];
        cell.name.text = dic[@"name"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

        return cell;
    }
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section==3 || section==1) {
        return [[UIView alloc] init];
    }else{
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 15)];
        view.backgroundColor = RGB(247, 249, 249, 1);
        return view;
    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    if (section==3|| section==1) {
        return 0.1f;
    }else{
        
        return 15.0f;
    }
}
-(CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section{
    return 0.1f;
}

-(UIView*)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section{
    return [[UIView alloc] init];
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.section) {
        case 0:
            switch (indexPath.row) {
                case 0:
                    //个人主页
                {
//                    SetPersonalPageVC *vc = [[SetPersonalPageVC alloc] init];
//                    vc.hidesBottomBarWhenPushed = YES;
//                    vc.lyj_delegate = self;
//                    [self.navigationController pushViewController:vc animated:YES];
                }
                    break;
                    
                default:
                    break;
            }
            break;
        case 1:
            
            switch (indexPath.row) {
                case 0:
                    //家庭病例
                {
                    MyFamilyCasesClipVC *vc = [[MyFamilyCasesClipVC alloc] init];
                    vc.hidesBottomBarWhenPushed = YES;
                    [self.navigationController pushViewController:vc animated:YES];
                }
                    break;
                    
                default:
                    break;
            }
            break;
        case 2:
            
            switch (indexPath.row) {
                case 0:
                    //我的收藏
                {
                    MyCollectionVC *vc = [[MyCollectionVC alloc] init];
                    vc.hidesBottomBarWhenPushed = YES;
                    [self.navigationController pushViewController:vc animated:YES];
                }
                    break;
                case 1:
                    //我的关注
                {
                    MyFocusVC *vc = [[MyFocusVC alloc] init];
                    vc.hidesBottomBarWhenPushed = YES;
                    [self.navigationController pushViewController:vc animated:YES];
                }
                    break;
                default:
                    break;
            }
            break;
        case 3:
            
            switch (indexPath.row) {
                case 0:
                    //问题反馈
                {
                    UIViewController *umFeedBackVC = [UMFeedback feedbackViewController];
                    umFeedBackVC.hidesBottomBarWhenPushed = YES;
#if 0
                    UINavigationController *nav = [[UINavigationController alloc] initWithRootViewController:umFeedBackVC];
                    [self presentViewController:nav animated:YES completion:^{
                    }];
                    
#else
                    [self.navigationController pushViewController:umFeedBackVC animated:YES];//友盟的反馈
#endif
                }
                    break;
                case 1:
                    //关于我们
                {
                    AboutUsVC *vc = [[AboutUsVC alloc] init];
                    vc.hidesBottomBarWhenPushed = YES;
                    [self.navigationController pushViewController:vc animated:YES];
                }
                    break;
                case 2:
                    //设置
                {
                    MySettingVC *vc = [[MySettingVC alloc] init];
                    vc.hidesBottomBarWhenPushed = YES;
                    [self.navigationController pushViewController:vc animated:YES];
                }
                    break;
                default:
                    break;
            }
            break;
        
        default:
            break;
    }
    
}

#pragma  mark - setpersonal
-(void)finishEditWit:(NSString *)imageurl{
    [self makeDataSource];
}

@end
