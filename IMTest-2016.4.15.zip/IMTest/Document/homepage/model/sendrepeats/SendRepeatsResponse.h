//
//  SendRepeatsResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface SendRepeatsResponse : BasicResponse

@end
