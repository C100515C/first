//
//  PostRepeatsCell.h
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

@class PostRepeatsResponse;
static NSString * const PostRepeatsCell_id = @"postrepeats";

@interface PostRepeatsCell : BasicTableViewCell

-(void)setCellWithModel:(PostRepeatsResponse*)model;

@end
