//
//  CircleFriendsRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/31.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleFriendsRequest.h"

@implementation CircleFriendsRequest

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"forums/forum_id?access-token=%@&",[[[UserProfileManager sharedInstance] getLoginToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        self.reqMethod = @"GET";
        //        self.reqMethod = @"POST";
        self.reqClassName = @"CircleFriendsItems";
    }
    return self;
}

-(void)mySetForum_id:(NSString *)forum_id{
    if (forum_id==nil) {
        return;
    }
    NSMutableString *str = [[NSMutableString alloc] initWithString:self.reqUrlPath];
    NSRange range = [str rangeOfString:@"forum_id"];
    [str replaceCharactersInRange:range withString:forum_id];
//    NSString *newstr = [NSString  stringWithFormat:@"%@",str];
    self.reqUrlPath = str;
}

@end
