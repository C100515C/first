//
//  DiscoverResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "DiscoverResponse.h"

@implementation DiscoverResponse

-(NSMutableArray*)itemList{
    if (_itemList==nil) {
        _itemList = [NSMutableArray array ];
    }
    return _itemList;
}

+(Class)itemList_class{
    return [DiscoverItemResponse class];
}
@end

@implementation DiscoverItemResponse

@end