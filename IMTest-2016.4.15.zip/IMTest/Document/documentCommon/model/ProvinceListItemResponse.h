//
//  ProvinceListItemResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface ProvinceListItemResponse : BasicResponse

@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *parent_id;
@property (nonatomic,copy) NSString *province_id;
@property (nonatomic,copy) NSMutableArray *cityList;

+ (Class)cityList_class;

@end


@interface CityItemResponse : BasicResponse

@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *parent_id;
@property (nonatomic,copy) NSString *city_id;

@end