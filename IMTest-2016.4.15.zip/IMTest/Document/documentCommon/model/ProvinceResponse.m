//
//  ProvinceResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "ProvinceResponse.h"
#import "ProvinceListItemResponse.h"
@implementation ProvinceResponse

-(NSMutableArray *)provinces{
    if (_provinces == nil) {
        _provinces = [NSMutableArray array];
    }
    return _provinces;
}

-(NSMutableArray *)cityList{

    if (_cityList==nil) {
        _cityList = [NSMutableArray array];
    }
    return _cityList;
}

+ (Class)provinces_class{
    return [ProvinceListItemResponse class];
}

+(Class)cityList_class{
    return [CityItemResponse class];
}

@end
