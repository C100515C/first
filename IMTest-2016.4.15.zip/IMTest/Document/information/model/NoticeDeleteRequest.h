//
//  NoticeDeleteRequest.h
//  IMTest
//
//  Created by chenchen on 16/4/14.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"
#import "BasicResponse.h"

@interface NoticeDeleteRequest : BaseRequest
//@property (nonatomic,copy) NSString *page;
-(id)init;
-(void)setNoticeIdWith:(NSString*)n_id;

@end

@interface NoticeDeleteResponse : BasicResponse

@end