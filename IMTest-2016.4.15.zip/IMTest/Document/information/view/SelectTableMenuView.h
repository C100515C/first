//
//  SelectTableMenuView.h
//  IMTest
//
//  Created by chenchen on 16/3/3.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BasicTableViewCell.h"

typedef enum {
    SelectMenuNoticBtn,
    SelectMenuMessageBtn
}SelectMenuSelectBtn;

@protocol SelectMenuprotocol <NSObject>
/**
 *  点击菜单按钮执行回调
 *
 *  @param btn 点击按钮名字   
 */
-(void)selectBtnClickedWith:(SelectMenuSelectBtn)btn ;

@end

@interface SelectTableMenuView : BasicTableViewCell

@property (nonatomic,assign) id<SelectMenuprotocol>delegate;

@end
