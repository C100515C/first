

//
//  BasicLabel.m
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicLabel.h"

@implementation BasicLabel

-(void)awakeFromNib{
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

-(void)setBorder{
    self.clipsToBounds = YES;
    self.layer.cornerRadius = 3.0f;
    
   
    self.layer.borderColor = [[UIColor redColor]CGColor];
    self.textColor = [UIColor redColor];

    
    self.layer.borderWidth = 1.0f;
    self.textAlignment = NSTextAlignmentCenter;
}

-(void)setLYJ_textColor:(UIColor *)LYJ_textColor{
    
    if (LYJ_textColor) {
        _LYJ_textColor = nil;
        _LYJ_textColor = LYJ_textColor;
        self.layer.borderColor = [_LYJ_textColor CGColor];
        self.textColor = _LYJ_textColor;
    }else{
        _LYJ_textColor = nil;
        _LYJ_textColor = [UIColor redColor];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
