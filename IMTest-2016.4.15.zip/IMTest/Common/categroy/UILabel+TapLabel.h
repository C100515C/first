//
//  UILabel+TapLabel.h
//  MoscoperV3
//
//  Created by mac on 15/10/29.
//  Copyright © 2015年 moscoper. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol tapLabelDelegate;
@interface UILabel (TapLabel)
@property (nonatomic,assign) id <tapLabelDelegate>delegate;

-(void)set_LabelTapGesWith:(BOOL)isCanTap andDelegate:(id<tapLabelDelegate>)delegate;

@end
@protocol tapLabelDelegate <NSObject>

-(void)tapLabelAction:(UILabel*)currentLabel;

@end