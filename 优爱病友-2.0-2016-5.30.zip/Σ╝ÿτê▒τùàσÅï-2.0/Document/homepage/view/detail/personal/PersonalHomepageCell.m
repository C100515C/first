//
//  PersonalHomepageCell.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalHomepageCell.h"
#import "PersonalHomepageResponse.h"
#import "CC_LabelsOfView.h"

#import "UILabel+TapLabel.h"

@interface PersonalHomepageCell ()<BasicUIImageTapProtocol,tapLabelDelegate>
@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;
@property (weak, nonatomic) IBOutlet BasicLabel *nickname;
@property (weak, nonatomic) IBOutlet UIImageView *gender;
@property (weak, nonatomic) IBOutlet BasicLabel *addressed;
@property (weak, nonatomic) IBOutlet BasicLabel *answerCount;
@property (weak, nonatomic) IBOutlet BasicLabel *publishedCount;
@property (weak, nonatomic) IBOutlet BasicLabel *illFriendsCount;

@property (weak, nonatomic) IBOutlet CC_LabelsOfView *focusLabelView;
@property (weak, nonatomic) IBOutlet BasicLabel *signature;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *focusLabelViewHeight;
@property (weak, nonatomic) IBOutlet BasicLabel *theAnswer;
@property (weak, nonatomic) IBOutlet BasicLabel *thePublic;
@property (weak, nonatomic) IBOutlet BasicLabel *theFriend;

@property (nonatomic,copy) PersonalLabelTapBlock labelTap;
@end

@implementation PersonalHomepageCell

-(void)setAnswerPublicAndFriendTapWith:(PersonalLabelTapBlock)block{

    [self.answerCount set_LabelTapGesWith:YES andDelegate:self];
    [self.theAnswer set_LabelTapGesWith:YES andDelegate:self];
    [self.theFriend set_LabelTapGesWith:YES andDelegate:self];
    [self.illFriendsCount set_LabelTapGesWith:YES andDelegate:self];
    [self.thePublic set_LabelTapGesWith:YES andDelegate:self];
    [self.publishedCount set_LabelTapGesWith:YES andDelegate:self];
    
    self.answerCount.tag = PersonalAnswer;
    self.theAnswer.tag = PersonalAnswer;
    
    self.illFriendsCount.tag = PersonalFriend;
    self.theFriend.tag = PersonalFriend;

    self.thePublic.tag = PersonalPublic;
    self.publishedCount.tag = PersonalPublic;
    
    if (block) {
        self.labelTap = block;
    }
}

-(void)setIsMySelf:(BOOL)isMySelf and:(BOOL)isman{
    if (isMySelf) {
        self.theAnswer.text = @"我的评论";
        self.theFriend.text = @"我的病友";
        self.thePublic.text = @"我的帖子";
    }else{
        self.theAnswer.text = @"他的评论";
        self.theFriend.text = @"他的病友";
        self.thePublic.text = @"他的帖子";
        if (!isman) {
            self.theAnswer.text = @"她的评论";
            self.theFriend.text = @"她的病友";
            self.thePublic.text = @"她的帖子";
        }
    }
}

-(void)setCellWithModel:(PersonalHomepageResponse *)model{
    
    self.nickname.text = model.username;
    self.addressed.text = model.location;
    [self.focusLabelView set_MyLabelsCanChangeRowsWith:[model getForumLabelNames]];
    self.focusLabelViewHeight.constant = model.focusLabelHeight;
    self.signature.text = model.signature;
    self.answerCount.text = [NSString stringWithFormat:@"%@",model.post_count];
    self.publishedCount.text = [NSString stringWithFormat:@"%@",model.thread_count];
    self.illFriendsCount.text = [NSString stringWithFormat:@"%@",model.following_count];
    [self.headerIcon sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"sctx"]];
    if ([model.gender isEqualToString:@"1"]) {
        self.gender.image = [UIImage imageNamed:@"icon_sm"];
    }else if([model.gender isEqualToString:@"2"]){
        self.gender.image = [UIImage imageNamed:@"icon_sw"];
    }else {
        self.gender.image = [UIImage imageNamed:@""];
    }
    
    [self setIsMySelf:self.isMySelf and:2-[model.gender intValue]];
}

-(void)setCellWithUserModel:(UserProfileEntity *)model{
    self.nickname.text = model.username;
    self.addressed.text = model.location;
    [self.focusLabelView set_MyLabelsCanChangeRowsWith:[model getForumLabelNames]];
    
    self.focusLabelViewHeight.constant = model.focusLabelHeight;
    self.signature.text = model.signature;
    self.answerCount.text = [NSString stringWithFormat:@"%@",model.post_count];
    self.publishedCount.text = [NSString stringWithFormat:@"%@",model.thread_count];
    self.illFriendsCount.text = [NSString stringWithFormat:@"%@",model.following_count];
    [self.headerIcon sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"sctx"]];
    if ([model.gender isEqualToString:@"1"]) {
        self.gender.image = [UIImage imageNamed:@"icon_sm"];
    }else if([model.gender isEqualToString:@"2"]){
        self.gender.image = [UIImage imageNamed:@"icon_sw"];
    }else {
        self.gender.image = [UIImage imageNamed:@""];
    }
    [self setIsMySelf:self.isMySelf and:2-[model.gender intValue]];

}

-(void)awakeFromNib{
    [super awakeFromNib];

    [self.headerIcon setRaduis];
    [self.headerIcon setTapUse];
    self.headerIcon.lyj_delegate = self;
    
    _focusLabelView.isCanClicked = YES;
    [_focusLabelView setStart_x:0 andY:5.0f andInterval:5.0f andLabelHeight:20.0f andEndDistance:10.0f andLabelType:CCBlueFrameLabel];
    
    _focusLabelView.CC_LabelTapBlock = ^(NSInteger index){

        if (_PersonalHeaderLabelTapBlock) {
            _PersonalHeaderLabelTapBlock(index);
        }
    };
    
    self.nickname.type = LabelFont_17;
    self.answerCount.type = LabelFont_17;
    self.publishedCount.type = LabelFont_17;
    self.illFriendsCount.type = LabelFont_17;
    self.theAnswer.type = LabelFont_12;
    self.theFriend.type = LabelFont_12;
    self.thePublic.type = LabelFont_12;
    self.signature.type = LabelFont_15;
}


#pragma mark - image tap
-(void)imageTapWith:(UITapGestureRecognizer *)sender{
    if (_tapBlock) {
        _tapBlock();
    }
}

#pragma mark - label tap
-(void)tapLabelAction:(UILabel *)currentLabel{
    
    if (_labelTap) {
        _labelTap((PersonalLabelName)currentLabel.tag);
    }
}

@end
