//
//  PostDetailHeaderView.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostDetailHeaderView.h"
#import "BasicUIImageView.h"
#import "BasicLabel.h"
#import "BasicUIButton.h"
#import "PostDetailHeaderResponse.h"
//#import "UserProfileManager.h"
#import "NSString+UrlCode.h"

@interface PostDetailHeaderView ()<BasicUIImageTapProtocol,UIWebViewDelegate>

@property (weak, nonatomic) IBOutlet BasicUIImageView *icon;

@property (weak, nonatomic) IBOutlet BasicLabel *nickname;
@property (weak, nonatomic) IBOutlet BasicLabel *postType;
@property (weak, nonatomic) IBOutlet BasicLabel *title;
@property (weak, nonatomic) IBOutlet BasicLabel *content;
@property (weak, nonatomic) IBOutlet BasicLabel *timeLabel;

@property (weak, nonatomic) IBOutlet UIImageView *desImage;
@property (weak, nonatomic) IBOutlet BasicUIButton *collectBtn;
@property (weak, nonatomic) IBOutlet BasicUIButton *shareBtn;
@property (weak, nonatomic) IBOutlet BasicUIButton *focusBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topViewHeight;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *middleViewHeight;
@property (weak, nonatomic) IBOutlet UIView *topBackView;
@property (weak, nonatomic) IBOutlet UIView *middleBackView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *picHeight;
@property (weak, nonatomic) IBOutlet UIWebView *desWebView;

@property (nonatomic,weak) PostDetailHeaderResponse *model;
@property (nonatomic,copy) DetailFinishLoadBlock finish;

@end

@implementation PostDetailHeaderView
-(void)awakeFromNib{
    [self.icon setRaduis];
    [self.postType setBorder];
    [self.icon setTapUse];
    self.icon.lyj_delegate = self;
    
    [self.shareBtn addTarget:self action:@selector(headerBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.collectBtn addTarget:self action:@selector(headerBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    [self.focusBtn addTarget:self action:@selector(headerBtnAction:) forControlEvents:UIControlEventTouchUpInside];
    self.shareBtn.tag = PostDetailHeaderShareBtn;
    self.collectBtn.tag = PostDetailHeaderCollectBtn;
    self.focusBtn.tag = PostDetailHeaderAttentionBtn;
    self.desWebView.delegate = self;
    
    self.content.hidden = YES;
    self.desImage.hidden = YES;
//    self.desWebView.hidden = YES;
    
    self.nickname.type = LabelFont_17;
    self.postType.type = LabelFont_12;
    self.title.type = LabelFont_16;
    self.content.type = LabelFont_15;
    self.timeLabel.type = LabelFont_12;

}

-(UIImage*)getPicImage{
    return self.desImage.image;
}
-(void)setWebUrl:(NSString *)webUrl{
    if (_desWebView && webUrl) {
        _webUrl = webUrl;
        
        NSURL *url = [[NSURL alloc] initWithString:webUrl];
        [_desWebView loadRequest:[NSURLRequest requestWithURL:url]];
        [_desWebView setScalesPageToFit:NO];     //yes:根据webview自适应，NO：根据内容自适应

    }
}

-(void)setHeaderViewWith:(PostDetailHeaderResponse *)model andThread_id:(NSString*)thread_id andFinish:(DetailFinishLoadBlock)finish{

    self.model = model;
    self.title.text = model.title;
    self.content.text = model.content;
    self.postType.text = model.thread_type;
    self.postType.LYJ_textColor  = [model getLabelColor];
    self.nickname.text = model.username;
    
    [self.icon sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    
    if ([model.collectAction intValue]==1) {
        [self.collectBtn setImage:[UIImage imageNamed:@"icon_shoucan2"] forState:UIControlStateNormal];
    }else{
        [self.collectBtn setImage:[UIImage imageNamed:@"icon_shoucan1"] forState:UIControlStateNormal];

    }
    
    if ([model.shareAction intValue]==1) {
        [self.shareBtn setImage:[UIImage imageNamed:@"icon_fenxiang2"] forState:UIControlStateNormal];
    }else{
        [self.shareBtn setImage:[UIImage imageNamed:@"icon_fenxiang1"] forState:UIControlStateNormal];
        
    }
    if ([model.attentionAction intValue]==1) {
        [self.focusBtn setImage:[UIImage imageNamed:@"icon_guanzhu2"] forState:UIControlStateNormal];
    }else{
        [self.focusBtn setImage:[UIImage imageNamed:@"icon_guanzhu1"] forState:UIControlStateNormal];
        
    }
    [self.collectBtn setTitle:model.collect_count forState:UIControlStateNormal];
    [self.shareBtn setTitle:model.shares_count forState:UIControlStateNormal];
    [self.focusBtn setTitle:model.attention_count forState:UIControlStateNormal];
    
    self.timeLabel.text = [NSString stringWithFormat:@"%@ 来自%@",model.created_at,model.forum_name];
    
    [self makeHtmlDesWebWith:thread_id];
    
    if (finish) {
        self.finish = finish;
    }

}
-(void)makeHtmlDesWebWith:(NSString*)thread_id{
    NSString *urlStr = [NSString stringWithFormat:@"%@v1/infos/%@?access-token=%@",UIHURL_TEST_SERVER,thread_id,[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
    self.webUrl = urlStr;
}
#pragma mark - image tap
-(void)imageTapWith:(UITapGestureRecognizer *)sender{

    if (_tapBlock) {
        _tapBlock(sender);
    }
}

-(void)headerBtnAction:(UIButton*)sender{
    
    if (_btnBlock) {
        _btnBlock((int)sender.tag);
    }
}


-(void)updateBtnCountWith:(PostDetailHeaderBtn)btnname andNewCount:(PostDetailHeaderResponse*)newmodel{
    
    if (btnname==PostDetailHeaderAttentionBtn) {
        [self.focusBtn setTitle:newmodel.attention_count forState:UIControlStateNormal];
//        [self.focusBtn setImage:[UIImage imageNamed:@"icon_guanzhu1"] forState:UIControlStateNormal];
        if ([newmodel.attentionAction intValue]==1) {
            [self.focusBtn setImage:[UIImage imageNamed:@"icon_guanzhu2"] forState:UIControlStateNormal];
        }else{
            [self.focusBtn setImage:[UIImage imageNamed:@"icon_guanzhu1"] forState:UIControlStateNormal];
            
        }
    }else if (btnname==PostDetailHeaderCollectBtn){
        [self.collectBtn setTitle:newmodel.collect_count forState:UIControlStateNormal];
//        [self.collectBtn setImage:[UIImage imageNamed:@"icon_shoucan1"] forState:UIControlStateNormal];
        if ([newmodel.collectAction intValue]==1) {
            [self.collectBtn setImage:[UIImage imageNamed:@"icon_shoucan2"] forState:UIControlStateNormal];
        }else{
            [self.collectBtn setImage:[UIImage imageNamed:@"icon_shoucan1"] forState:UIControlStateNormal];
            
        }
    }else{
        [self.shareBtn setTitle:newmodel.shares_count forState:UIControlStateNormal];
//        [self.shareBtn setImage:[UIImage imageNamed:@"icon_fenxiang1"] forState:UIControlStateNormal];
       
    }
}

#pragma mark - web 
//webview委托   高度自适应
-(void)webViewDidFinishLoad:(UIWebView *)webView
{
    CGSize actualSize = [webView sizeThatFits:CGSizeZero];
    CGRect newFrame = webView.frame;
    newFrame.size.height = actualSize.height;
    webView.frame = newFrame;
    
    CGSize newsize=CGSizeMake(SCREEN_WIDTH, webView.frame.size.height);
    webView.scrollView.contentSize=newsize;

    CGRect frame = self.frame;
    frame.size.height = _model.cellHeight-_model.middleNewHeight+newsize.height;
    
    self.frame = frame;
    
    self.topViewHeight.constant = _model.topnewHeight;
    self.middleViewHeight.constant = newsize.height;
//    self.picHeight.constant = _model.picHeight;
    if (_finish) {
        _finish(YES);
    }
}
@end
