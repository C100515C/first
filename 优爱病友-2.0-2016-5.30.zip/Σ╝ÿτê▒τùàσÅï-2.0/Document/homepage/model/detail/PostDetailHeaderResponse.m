//
//  PostDetailHeaderResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostDetailHeaderResponse.h"

static const CGFloat BasicHeight = 55.0f;
static const CGFloat TopViewHight = 58.0f;
@implementation PostDetailHeaderResponse

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size_content = [self getStringSizeWith:_content fontSize:FontSize_15 showSize:CGSizeMake(SCREEN_WIDTH-16, 2000)];
        _picHeight = 151.0f;
        
        _middleNewHeight = size_content.height+_picHeight;
        _cellHeight = self.topnewHeight+_middleNewHeight+BasicHeight;
        return _cellHeight;
    }
}

-(CGFloat)topnewHeight{
    if (_topnewHeight) {
        return _topnewHeight;
    }else{
        CGSize size_title = [self getStringSizeWith:_title fontSize:FontSize_16 showSize:CGSizeMake(SCREEN_WIDTH-83, 2000)];
        _topnewHeight = size_title.height+TopViewHight;
        return _topnewHeight;
    }
}

-(NSString*)thread_type{
    
    if ([_thread_type integerValue]==2) {
        return @"吐槽";
        
    }else if ([_thread_type integerValue]==1){
        return @"提问" ;
        
    }else{
        return @"推荐";
    }
}

-(UIColor*)getLabelColor{
    if ([_thread_type isEqualToString:@"2"]) {
        return [UIColor redColor];
    }else if ([_thread_type isEqualToString:@"1"]){
        return [UIColor orangeColor];
    }else{
        
        return RGB(57, 189,104, 1);
    }
}

-(NSString*)collect_count{
    if (_collect_count) {
        if ([self.collectAction intValue]==0) {
            return [NSString stringWithFormat:@"收藏 %@",_collect_count];
        }
        else{
            return [NSString stringWithFormat:@"收藏 %@",_collect_count];
        }
        
    }
    return _collect_count;
}
-(NSString*)shares_count{
    return @"分享";
    if (_shares_count) {
        return [NSString stringWithFormat:@"分享 %@",_shares_count];
    }
    
    return _shares_count;
}
-(NSString*)attention_count{
    if (_attention_count) {
        if ([self.attentionAction intValue] == 0) {
            return [NSString stringWithFormat:@"关注 %@",_attention_count];
        }
        else{
            return [NSString stringWithFormat:@"关注 %@",_attention_count];

        }
    }
    return _attention_count;
}
@end
