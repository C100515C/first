//
//  PostDetailRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/28.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface PostDetailRequest : BaseRequest
//@property (nonatomic,copy) NSString *post_id;
@property (nonatomic,copy) NSString *page;

-(id)init;

-(void)setMyPost_id:(NSString *)thread_id;

@end
