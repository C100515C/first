//
//  PostRepeatListResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostRepeatListResponse.h"

static const CGFloat BasicHeight = 65.0f;

@implementation PostRepeatListResponse

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
//        CGSize size = [self getStringSizeWith:_content fontSize:13.0f showSize:CGSizeMake(SCREEN_WIDTH-16, 2000)];
        CGSize size = [self baseStrHeightWith:FontSize_15];
        NSInteger numLines = [self LinesOfString:self.content andMaxLines:10 andStringFontSize:FontSize_15 andLineMaxWidth:SCREEN_WIDTH-16];
        _cellHeight = size.height*numLines+BasicHeight;
        
        return _cellHeight;
    }
}

//-(NSString*)created_at{
//    if (_created_at) {
//       return [CC_NSStringHandle formatTime:[_created_at integerValue]];
//    }
//    return _created_at;
//}

@end

@implementation PostRepeatListUserInforResponse


@end
