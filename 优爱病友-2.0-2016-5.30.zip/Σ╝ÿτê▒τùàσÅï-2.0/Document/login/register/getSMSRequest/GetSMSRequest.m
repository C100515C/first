//
//  GetSMSRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/21.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "GetSMSRequest.h"
static  NSString *const KEY = @"tVBIZFCqv96srhrmdvnkDCnwnImCJeoK";
@implementation GetSMSRequest

- (id)init
{
    self = [super init];
    if (self) {
        self.reqUrlPath = @"messages";
        
        //        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"GetSMS";
    }
    return self;
}

-(NSString*)time{
    NSDate *date = [NSDate date];
    NSTimeInterval interval = [date timeIntervalSince1970] * 1000;
    NSString *dateStr = [NSString stringWithFormat:@"%f",interval];
    _time = dateStr;
    return _time;
}

-(NSString*)sign{
    NSDictionary *parameReqDic = @{@"phone":self.phone,@"time":self.time};

     NSString *sign = [self getSign:parameReqDic];
    
    _sign = sign;
    return _sign;
}

- (NSArray *)sortKeyWithAscendingOrder:(NSArray *)array {
    NSSortDescriptor *descriptor = [NSSortDescriptor sortDescriptorWithKey:nil ascending:YES];
    NSArray *descriptors = [NSArray arrayWithObject:descriptor];
    NSArray *resultArray = [array sortedArrayUsingDescriptors:descriptors];
    return resultArray;
}

- (NSString *)getSign:(NSDictionary *)dic {
    NSArray *sortArray = [self sortKeyWithAscendingOrder:[dic allKeys]];
    NSMutableArray *array = [NSMutableArray array];
    for (NSString *str in sortArray) {
        [array addObject:[NSString stringWithFormat:@"%@=%@", str, [dic objectForKey:str]]];
    }
    NSString *joinStr = [array componentsJoinedByString:@"&"];
    return [NSString md5:[NSString stringWithFormat:@"%@&%@", joinStr, KEY]];
}

@end
