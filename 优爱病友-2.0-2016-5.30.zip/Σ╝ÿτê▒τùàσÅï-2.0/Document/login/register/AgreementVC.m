//
//  AgreementVC.m
//  IMTest
//
//  Created by chenchen on 16/4/15.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "AgreementVC.h"

@interface AgreementVC ()
@property (weak, nonatomic) IBOutlet UIWebView *agreementWeb;

@end

@implementation AgreementVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = YES;
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    self.showSearchBar = NO;

    self.title = @"用户协议";
    [self setNav];
    NSString *webUrl = [NSString stringWithFormat:@"%@agreements",UIHURL_TEST_SERVER];
    NSURL *url = [[NSURL alloc] initWithString:webUrl];
    [_agreementWeb loadRequest:[NSURLRequest requestWithURL:url]];
    
    [_agreementWeb setScalesPageToFit:NO];     //yes:根据webview自适应，NO：根据内容自适应
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

/*
#pragma mark - Navigation

// In a storyboard-based application, you will often want to do a little preparation before navigation
- (void)prepareForSegue:(UIStoryboardSegue *)segue sender:(id)sender {
    // Get the new view controller using [segue destinationViewController].
    // Pass the selected object to the new view controller.
}
*/

@end
