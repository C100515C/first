//
//  ForgetAndFindPasswordVC.m
//  IMTest
//
//  Created by chenchen on 16/4/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "ForgetAndFindPasswordVC.h"
#import "UIViewController+HUD.h"

#import "FindPasswordRequest.h"
#import "SingletonServ.h"

@interface ForgetAndFindPasswordVC ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UIScrollView *backScrollView;
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UITextField *myNewPasswordField;
@property (weak, nonatomic) IBOutlet UITextField *myConfirmPasswordField;
@property (weak, nonatomic) IBOutlet UIButton *myFinishBtn;


@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentViewHeight;

- (IBAction)myFinishBtnClicked:(UIButton *)sender;
@end

@implementation ForgetAndFindPasswordVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.myConfirmPasswordField.delegate = self;
    self.myNewPasswordField.delegate = self;
    self.myNewPasswordField.secureTextEntry = YES;
    self.myConfirmPasswordField.secureTextEntry = YES;
    
    
    self.tableView.hidden = YES;
    [self setNav];
    [self setScrollSize];
    
    self.myFinishBtn.clipsToBounds = YES;
    self.myFinishBtn.layer.cornerRadius  = 3.0f;
    
    [self.myNewPasswordField becomeFirstResponder];
    self.title = @"设置新密码";
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setScrollSize{
    self.backScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 2.0*SCREEN_WIDTH);
    self.contentViewHeight.constant = 2.0*SCREEN_WIDTH;
    self.backScrollView.scrollEnabled = YES;
    self.backScrollView.delegate = self;
}

-(BOOL)judgePassword{
    BOOL isok = NO;
    
    if ([self.myNewPasswordField.text isEqualToString: self.myConfirmPasswordField.text]) {
        isok = YES;
    }
    
    return isok;
}

#pragma mark - scroll
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self.myNewPasswordField resignFirstResponder];
    [self.myConfirmPasswordField resignFirstResponder];
}

#pragma mark - text field
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    if (textField ==self.myNewPasswordField) {
        NSInteger len = self.myNewPasswordField.text.length;
        
        if (len>12) {
            [self showHint:@"密码最长12位" yOffset:-200];
            return NO;
            
        }
    }
    
    if (textField==self.myConfirmPasswordField) {
        NSInteger len = self.myConfirmPasswordField.text.length;
        
        if (len>12) {
            [self showHint:@"密码最长12位" yOffset:-200];
            return NO;
            
        }
    }
    
    return YES;
}

-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    if (textField ==self.myNewPasswordField) {
        NSInteger len = textField.text.length;
        
        if (len<6) {
            [self showHint:@"密码至少6位" yOffset:-200];
            return NO;
        }
        
        if (len>12) {
            [self showHint:@"密码最长12位" yOffset:-200];
            return NO;
            
        }
    }
    
//    if (textField==self.myConfirmPasswordField) {
//        BOOL isok = [self judgePassword];
//        if (!isok) {
//            [self showHint:@"密码不一致" yOffset:-200];
//            return NO;
//        }
//    }
    return YES;
}

#pragma mark - btn

- (IBAction)myFinishBtnClicked:(UIButton *)sender {
    
    if (![self judgePassword]) {
        [self showHint:@"两次密码不输入一致" yOffset:-200];
        return;
    }
    
    FindPasswordRequest *req = [[FindPasswordRequest alloc]init];
    req.password = self.myNewPasswordField.text;
    req.phone = self.userPhone;
    req.authCode = self.userVerCode;
    
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"修改中..."];
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
       
        if (responeseError==nil) {
            [weakself.navigationController popToRootViewControllerAnimated:YES];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
        [weakself hideHud];
        
    }];
}

@end
