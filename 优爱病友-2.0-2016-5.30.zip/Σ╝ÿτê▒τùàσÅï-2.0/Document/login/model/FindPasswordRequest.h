//
//  FindPasswordRequest.h
//  IMTest
//
//  Created by chenchen on 16/4/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"
#import "BasicResponse.h"

@interface FindPasswordRequest : BaseRequest

@property (strong, nonatomic) NSString *authCode;
@property (strong, nonatomic) NSString *password;
@property (strong, nonatomic) NSString *phone;

- (id)init;
@end

@interface FindPasswordResponse : BasicResponse

@end