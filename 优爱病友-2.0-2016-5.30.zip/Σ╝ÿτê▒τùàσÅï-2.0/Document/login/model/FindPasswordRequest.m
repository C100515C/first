//
//  FindPasswordRequest.m
//  IMTest
//
//  Created by chenchen on 16/4/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "FindPasswordRequest.h"

@implementation FindPasswordRequest
- (id)init
{
    self = [super init];
    if (self) {
        
//        NSString *urlStr = [NSString stringWithFormat:@"update-passwords?access-token=%@",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
//        self.reqUrlPath = urlStr;
        self.reqUrlPath = @"update-passwords";
        //        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"FindPassword";
    }
    return self;
}
@end

@implementation FindPasswordResponse

@end