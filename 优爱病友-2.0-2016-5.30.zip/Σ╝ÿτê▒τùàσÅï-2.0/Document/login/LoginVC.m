//
//  LoginVC.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LoginVC.h"

#import "UMSocial.h"
#import "CC_SsoModel.h"

#import "SingletonServ.h"
#import "LoginRequest.h"
#import "LoginResponse.h"

#import "UIViewController+HUD.h"

#import "NewLoginVC.h"
#import "NewRegisterVC.h"

#import "AppDelegate.h"
#import "RootVC.h"

typedef void(^Register_IMLoginFinish)(BOOL isfinish);

@interface LoginVC ()<UITextFieldDelegate,UMSocialUIDelegate,UIAlertViewDelegate,EMClientDelegate,RegisterFinishProtocol>//,UMSocialDataDelegate

@property (weak, nonatomic) IBOutlet UIScrollView *backScrollView;
@property (weak, nonatomic) IBOutlet UIView *scrollContentView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *scrollContentViewHeight;

@property (weak, nonatomic) IBOutlet UIImageView *backImageview;

@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UIButton *registerBtn;


@property (nonatomic,assign) PlatformName_cc currentPlatformName;

- (IBAction)weiboLoginAction:(UIButton *)sender;
- (IBAction)weichatLoginAction:(UIButton *)sender;
- (IBAction)QQLoginAction:(UIButton *)sender;

- (IBAction)loginOrRegisterBtnClickd:(UIButton *)sender;

@end

@implementation LoginVC

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBarHidden = YES;
    [MobClick beginLogPageView:@"login1"];//("login1"为页面名称，可自定义)

}
-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    self.navigationController.navigationBarHidden = NO;
    [MobClick endLogPageView:@"login1"];

}
- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = YES;
    
    [self setScrollSize];
    
    [self setNav];
    
    [self setMyLoginBtn];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UI
-(void)setMyLoginBtn{
    
    self.loginBtn.clipsToBounds = YES;
    self.loginBtn.layer.cornerRadius = 20.0f;
    self.loginBtn.layer.borderWidth = 1.0f;
    self.loginBtn.layer.borderColor = [UIColor whiteColor].CGColor;
    
    self.registerBtn.clipsToBounds = YES;
    self.registerBtn.layer.cornerRadius = 20.0f;
    self.registerBtn.layer.borderWidth = 1.0f;
    self.registerBtn.layer.borderColor = [UIColor whiteColor].CGColor;
    
    self.loginBtn.alpha = 0.0f;
    self.registerBtn.alpha = 0.0f;
//    self.backImageview.alpha = 0.0f;
    
    [UIView animateWithDuration:1.5 animations:^{
        self.loginBtn.alpha = 1.0f;
        self.registerBtn.alpha = 1.0f;
//        self.backImageview.alpha = 1.0f;

    }];
}


-(void)setScrollSize{
    self.backScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, SCREEN_HEIGHT);
    self.scrollContentViewHeight.constant = SCREEN_HEIGHT;
    self.backScrollView.scrollEnabled = YES;
    self.backScrollView.delegate = self;
}

#pragma mark - register
-(void)registerFinishWith:(NSString *)phone and:(NSString *)password{
    [self loginRequestWith:phone and:password];
}

-(void)loginRequestWith:(NSString*)phone and:(NSString*)password{
    
    LoginRequest *req = [[LoginRequest alloc] init];
    req.password = password;
    req.username = phone;//self.phoneNumber.text;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"登录中..."];
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            LoginResponse *model = (LoginResponse*)responseDataModel;

            NSDictionary *dic = @{@"imageUrl":model.avatar,@"signature":@" ",@"gender":@"0",@"isLogin":@(1),@"objectId":model.user_id,@"username":model.phone,@"nickname":model.token,@"address":@" ",@"answerCount":@"0",@"publicCount":@"0",@"friendCount":@"0",@"labels":@[@" ",@" ",@" ",@" "],@"birthdate":@" ",@"addres_id":@" ",@"avatar":model.avatar};
            
            [[UserProfileManager sharedInstance] storeUserInfor:dic andFinish:^(BOOL finish) {
                [weakself dismissVC];
//                [weakself hideHud];
                
            }];
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-100];
            [weakself hideHud];
        }
        
    }];
}

-(void)dismissVC{
    __weak typeof(self) weakself = self;
    AppDelegate *delegate = [UIApplication sharedApplication].delegate;
    if (delegate.isLoginRoot) {
        [weakself loginIMWith:^(BOOL isfinish) {
            [weakself hideHud];

            if (isfinish) {
                [delegate goToMain];
            }else{
                [weakself showHint:@"登录失败" yOffset:-200];
            }
        }];
        
    }else{
        [self dismissViewControllerAnimated:YES completion:^{
            
            [weakself loginIMWith:^(BOOL isfinish) {
                [weakself hideHud];

                if (isfinish) {
                    AppDelegate *app = [UIApplication sharedApplication].delegate;
                    RootVC *root = (RootVC*)app.window.rootViewController;
                    
                    [root refreshVCWith:0 andNeedHint:YES];
                }
                
            }];
            
           
        }];
    }
}

-(void)loginIMWith:(Register_IMLoginFinish)finish{
    //*
    BOOL isAutoLogin = [EMClient sharedClient].options.isAutoLogin;

    if (!isAutoLogin) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSString *userid = [NSString stringWithFormat:@"%@",[[UserProfileManager sharedInstance] getUserId]];
            
            EMError *error = [[EMClient sharedClient] loginWithUsername:userid password:@"123456"];
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!error) {
                    MOSLog(@"登陆成功");
                    //设置成自动登陆
                    [[EMClient sharedClient].options setIsAutoLogin:YES];
                    NSString *name = [[UserProfileManager sharedInstance] getCurUsername];
                    [[EMClient sharedClient] setApnsNickname:name];
                    
                    if (finish) {
                        finish(YES);
                    }
                    
                }else{
//                    MOSLog(@"登陆失败=%@",error.errorDescription);
                    if (finish) {
                        finish(NO);
                    }
                }
            });
            
        });
    }
    //*/
}

#pragma mark - action
- (IBAction)loginOrRegisterBtnClickd:(UIButton *)sender {
    if (sender==self.loginBtn) {
        NewLoginVC *vc = [[NewLoginVC alloc] init];
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        NewRegisterVC *vc = [[NewRegisterVC alloc] init];
        vc.lyj_delegate = self;
        [self.navigationController pushViewController:vc
                                             animated:YES];
    }
}

- (IBAction)weichatLoginAction:(UIButton *)sender {
    self.currentPlatformName = WeiChat;
    [self showHint:@"功能尚未开通" yOffset:-200];
    return;
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToWechatSession]) {
    
        MOSLog(@"未授权");
        [self get_SsoWith:UMSocialSnsTypeWechatSession];

        return;
    }
    [self get_SsoInforWith:UMShareToWechatSession];

}

- (IBAction)QQLoginAction:(UIButton *)sender {
    self.currentPlatformName = QQ;
    [self showHint:@"功能尚未开通" yOffset:-200];
    return;
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToQQ]) {
        MOSLog(@"未授权");
        [self get_SsoWith:UMSocialSnsTypeMobileQQ];
        
        return;
    }
    [self get_SsoInforWith:UMShareToQQ];

}

- (IBAction)weiboLoginAction:(UIButton *)sender {
    self.currentPlatformName = Sina;
    
    [self showHint:@"功能尚未开通" yOffset:-200];
    return;
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToSina]) {
        
        
        MOSLog(@"未授权");
        [self get_SsoWith:UMSocialSnsTypeSina];
        
        return;
    }
    [self get_SsoInforWith:UMShareToSina];
}

#pragma mark - UM

/**
 *  根据不同的type 获取不同的平台授权
 *
 *  @param tag 平台标识
 */
-(void)get_SsoWith:(UMSocialSnsType)type{
    
    NSString *platformName = [UMSocialSnsPlatformManager getSnsPlatformString:type];
    
    [UMSocialControllerService defaultControllerService].socialUIDelegate = self;
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:platformName];
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        //          获取用户名、uid、token等
        MOSLog(@"获取授权=%@",response);
        if (response.responseCode == UMSResponseCodeSuccess) {
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:platformName];
            MOSLog(@"username is %@, uid is %@, token is %@ iconUrl is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
            [self get_SsoInforWith:platformName];
            
        }
    });
}
/**
 *  获取授权平台 信息
 *
 *  @param platformName 平台名字
 */
-(void)get_SsoInforWith:(NSString*)platformName{
    
    [[UMSocialDataService defaultDataService] requestSnsInformation:platformName  completion:^(UMSocialResponseEntity *response){
        MOSLog(@"SnsInformation is %@",response.data);
        CC_SsoModel *model = [[CC_SsoModel alloc] init];
        [model set_myModelWith:response.data andPlatform:self.currentPlatformName];
        [self finishSsoPushCheckViewWith:model];
    }];
}
/**
 *  取消授权
 *
 *  @param platformName 平台名字
 */
-(void)cancel_SsoWith:(NSString*)platformName{
    
    [[UMSocialDataService defaultDataService] requestUnOauthWithType:platformName  completion:^(UMSocialResponseEntity *response){
        MOSLog(@"response is %@",response);
    }];
}
/**
 *  判断是否能跳转应用
 *
 *  @param urlStr 应用跳转url
 *
 *  @return 能否跳转
 */
-(BOOL)isCanJumpTarget:(NSString*)urlStr{
    NSString *url = [NSString stringWithFormat:@"%@://",urlStr];
    NSURL * myURL_APP = [NSURL URLWithString:url];
    BOOL iscan = NO;
    if ([[UIApplication sharedApplication] canOpenURL:myURL_APP]) {
        iscan = YES;
        //        [[UIApplication sharedApplication] openURL:myURL_APP];
        
    }
    
    return iscan;
}

/**
 *  取消授权
 *
 *  @param sender
 */
- (IBAction)cancelSso:(id)sender {
    //取消授权
    [self cancel_SsoWith:UMShareToSina];
    [self cancel_SsoWith:UMShareToQQ];
    [self cancel_SsoWith:UMShareToWechatSession];
    
}

/**
 *  新浪授权按钮点击
 *
 *  @param sender 按钮
 */
- (IBAction)sina_sso:(id)sender {
    self.currentPlatformName = Sina;
    
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToSina]) {
        
    
        return;
    }
    
        NSString *platformName = [UMSocialSnsPlatformManager getSnsPlatformString:UMSocialSnsTypeSina];
        [self get_SsoInforWith:platformName];
        [self get_SsoWith:UMSocialSnsTypeSina];
        

    
}
/**
 *  qq 授权按钮点击
 *
 *  @param sender 按钮
 */
- (IBAction)QQ_Sso:(id)sender {
    self.currentPlatformName = QQ;
    
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToQQ]) {
        
        return;
    }
    
        NSString *platformName = [UMSocialSnsPlatformManager getSnsPlatformString:UMSocialSnsTypeMobileQQ];
        [self get_SsoInforWith:platformName];

    
}
/**
 *  微信授权点击按钮
 *
 *  @param sender按钮
 */
- (IBAction)weichat_Sso:(id)sender {
    self.currentPlatformName = WeiChat;
    
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToWechatSession]) {
        
        return;
    }
    

        NSString *platformName = [UMSocialSnsPlatformManager getSnsPlatformString:UMSocialSnsTypeWechatSession];
        [self get_SsoInforWith:platformName];
    
}
/**
 *  完成授权 切换验证界面
 *  信息字典传到下级界面
 */
-(void)finishSsoPushCheckViewWith:(CC_SsoModel*)inforModel{
    MOSLog(@"拿到授权信息");
}


@end
