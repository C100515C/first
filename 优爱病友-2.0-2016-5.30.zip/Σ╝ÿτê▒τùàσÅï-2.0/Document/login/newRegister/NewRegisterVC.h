//
//  NewRegisterVC.h
//  IMTest
//
//  Created by chenchen on 16/4/25.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@protocol RegisterFinishProtocol <NSObject>

-(void)registerFinishWith:(NSString*)phone and:(NSString*)password;

@end
@interface NewRegisterVC : BasicVC

@property (nonatomic,copy) void (^RegisterSuccessFinish)(NSString *phone,NSString *password);
@property (nonatomic,assign) id<RegisterFinishProtocol>lyj_delegate;

@end
