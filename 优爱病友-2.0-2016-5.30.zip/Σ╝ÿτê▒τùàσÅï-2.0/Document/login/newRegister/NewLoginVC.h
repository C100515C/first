//
//  NewLoginVC.h
//  IMTest
//
//  Created by chenchen on 16/4/25.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface NewLoginVC : BasicVC

@end
