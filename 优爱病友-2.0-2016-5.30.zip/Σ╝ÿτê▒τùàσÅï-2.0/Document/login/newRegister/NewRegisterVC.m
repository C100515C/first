//
//  NewRegisterVC.m
//  IMTest
//
//  Created by chenchen on 16/4/25.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "NewRegisterVC.h"
#import "AgreementVC.h"

#import "SingletonServ.h"
#import "GetSMSRequest.h"
#import "GetSMSResponse.h"
#import "CheckPhoneRegisterRequest.h"
#import "RegisterRequest.h"
#import "RegisterResponse.h"

#import "UIViewController+HUD.h"
#import "UIViewController+LYJAlertView.h"

@interface NewRegisterVC ()<UITextFieldDelegate>
@property (weak, nonatomic) IBOutlet UITextField *phoneNumber;
@property (weak, nonatomic) IBOutlet UITextField *verificationCode;
@property (weak, nonatomic) IBOutlet UIButton *getVerificationCodeBtn;

@property (weak, nonatomic) IBOutlet UITextField *nickNameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UIButton *agreeAction;
@property (weak, nonatomic) IBOutlet UIButton *myChangePasswordStateBtn;
@property (weak, nonatomic) IBOutlet UIButton *submitBtn;


- (IBAction)getVerificationCodeAction:(UIButton *)sender;

- (IBAction)agreeBtnAction:(UIButton *)sender;
- (IBAction)myChangePasswordClicked:(UIButton *)sender;
- (IBAction)submitBtnClicked:(UIButton *)sender;


@property (strong, nonatomic) NSTimer *countTimer;
@property (nonatomic) int timeRemain;
@property (assign,nonatomic) BOOL isStart;


@property (assign,nonatomic) BOOL showPassword;
@property (nonatomic,copy) NSString *loginUserName;

@property (nonatomic,copy) NSString *userPhone;
@property (nonatomic,copy) NSString *userVerCode;

@end

@implementation NewRegisterVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = YES;
    
    self.title = @"注册";

    self.verificationCode.delegate = self;
    self.phoneNumber.delegate = self;
    self.nickNameField.delegate = self;
    self.passwordField.delegate = self;
    self.showPassword = NO;
    self.passwordField.secureTextEntry = YES;
    
    self.timeRemain = 60;
    
    [self.getVerificationCodeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
    
    [self setNav];
    
    [self setUIInit];
    
//    [self setNav];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.barTintColor = G_COLOR_NAVGATION_BACK;
    [MobClick beginLogPageView:@"register"];
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"register"];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];

}

#pragma mark - set UI
-(void)setUIInit{
    self.phoneNumber.keyboardType = UIKeyboardTypeNumberPad;
    self.verificationCode.keyboardType = UIKeyboardTypeNumberPad;
    self.submitBtn.clipsToBounds = YES;
    self.submitBtn.layer.cornerRadius = 5.0f;
    
}
#pragma mark - net work
-(void)getSMSWith:(NSString*)phoneNum{
    
    GetSMSRequest *req = [[GetSMSRequest alloc] init];
    req.phone =  [self getPhoneNumberWith:self.phoneNumber.text andSeparateStr:@"-"];//self.phoneNumber.text;
    
    [[SingletonServ sharedInstance ] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError == nil) {
            
            MOSLog(@"获取短信请求成功");
        }else{
            [self showHint:responeseError.msg yOffset:-200];
            
        }
        
    }];
}

-(void)submitWith:(UIButton*)btn{
    
    if (![self judgePhoneWith:self.phoneNumber.text]) {
        [self showHint:@"填写正确电话号码" yOffset:-300];

        return;
    }
    
    if (![self judgeVerificationCodeWith:self.verificationCode.text]) {
        [self showHint:@"填写正确验证码" yOffset:-300];

        return;
    }
    
    if (self.nickNameField.text.length==0) {
        [self showHint:@"昵称不能为空" yOffset:-300];
        
        return;
    }
    
    if (![self judgePhoneWith:self.nickNameField.text]) {
        [self showHint:@"昵称最多为16位" yOffset:-300];
        return;
    }
    
    if (![self judgeVerificationCodeWith:self.passwordField.text]) {
        [self showHint:@"密码为6~16位" yOffset:-300];
        return;
    }
    
    
    [self registerUser];
    
}

-(void)registerUser{
    
    self.loginUserName = self.nickNameField.text;
    
    RegisterRequest *req = [[RegisterRequest alloc] init];
    req.username = self.loginUserName;//self.nickNameField.text;
    req.password = self.passwordField.text;
    req.authCode = self.userVerCode;
    req.phone = self.userPhone;
    
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"注册中..."];
    
    [[SingletonServ sharedInstance] reqPostWithModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            RegisterResponse *model = (RegisterResponse*)responseDataModel;
            
            MOSLog(@"%@-%@-%@-%@",model.uid,model.phone,model.token,model.avatar);
            
            if (self.lyj_delegate && [self.lyj_delegate respondsToSelector:@selector(registerFinishWith:and:)]) {
                [self.lyj_delegate registerFinishWith:self.userPhone and:self.passwordField.text];
            }
            
            [weakself.navigationController popToRootViewControllerAnimated:YES];
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-100];
        }
        [weakself hideHud];
    } constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        //  不传图片
    }];
}


#pragma mark - nav
-(void)setNav{
    [super setNav];
//    // 设置navigationBar的背景颜色，根据需要自己设置
//    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
//    //     设置navigationController的title的字体颜色
//    NSDictionary * dict=[NSDictionary dictionaryWithObject:G_COLOR_NAVGATION_TITLE forKey:NSForegroundColorAttributeName];
//    self.navigationController.navigationBar.titleTextAttributes = dict;
    self.title = @"注册";
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
    [nav setBackBtnWith:NavBackBtnImage withCurrentVC:self andBackAction:@selector(popVC:)];
}

-(void)popVC:(UIButton*)btn{
    
    __weak typeof(self) weakself = self;
    UIAlertControllerActionBlock sure = ^(UIAlertAction *action){
        [weakself.navigationController popViewControllerAnimated:YES];
    };
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"继续注册");
    };
    [UIViewController showAlertTltileWith:@"提示" andMessage:@"确定放弃注册" andActions:@{@"放弃":sure,@"取消":cancle} andShowVC:self andAlertStyle:UIAlertControllerStyleAlert andalertTag:600];
}

-(void)checkPhoneWith:(NSString*)phone andFinish:(HeaderOrFooterRefFinish)finish{
    CheckPhoneRegisterRequest *req = [[CheckPhoneRegisterRequest alloc] init];
    req.phone = phone;
    __weak typeof(self) weakself = self;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
            if (responeseError==nil) {
                if (finish) {
                    finish(YES);
                }
            }else{
                [weakself showHint:@"该号码已经注册" yOffset:-200];
                weakself.getVerificationCodeBtn.userInteractionEnabled = YES;
            }
        
    }];
}

#pragma mark - timer
-(NSTimer*)countTimer{
    
    if (!_countTimer) {
        _countTimer = [NSTimer scheduledTimerWithTimeInterval:1
                                                       target:self
                                                     selector:@selector(oneSecondFlip)
                                                     userInfo:nil
                                                      repeats:YES];
    }
    
    return _countTimer;
}

-(UIButton*)getVerificationCodeBtn{
    
    if (_getVerificationCodeBtn) {
        _getVerificationCodeBtn.clipsToBounds = YES;
        _getVerificationCodeBtn.layer.cornerRadius = 5.0f;
    }
    
    return _getVerificationCodeBtn;
}

#pragma mark - judge str

-(BOOL)judgePhoneWith:(NSString*)num{
    if (self.phoneNumber.text.length==13) {
        return YES;
    }else{
        return NO;
    }
}

-(BOOL)judgeVerificationCodeWith:(NSString*)num{
    
    if (self.verificationCode.text.length==6) {
        return YES;
        
    }else{
        return NO;
    }
}

-(BOOL)judgeNicknameWith:(NSString*)nickname{
    if (self.nickNameField.text.length>0 && self.nickNameField.text.length<=16) {
        return YES;
    }else{
        return NO;
    }
}

-(BOOL)judgePasswordWith:(NSString*)password{
    
    if (self.passwordField.text.length>=6 && self.passwordField.text.length<=16) {
        return YES;
        
    }else{
        return NO;
    }
}

#pragma mark - text field
-(BOOL)textFieldShouldEndEditing:(UITextField *)textField{
    if (textField==self.phoneNumber) {
        
    }
    return YES;
}

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    if (textField==self.phoneNumber || textField==self.verificationCode) {
        if (![self judeTextNumWith:textField.text andNextChar:string]) {
            
            [self showHint:@"非法字符" yOffset:-400];
            
            return NO;
        }
    }
    
    
    if (textField==self.phoneNumber) {
        if (self.isStart) {
            [self.countTimer invalidate];
            self.countTimer = nil;
            [self.getVerificationCodeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
            self.isStart = NO;
            self.getVerificationCodeBtn.userInteractionEnabled = YES;
        }
    }
    
    NSInteger lenth = textField.text.length+string.length;
    if (textField == self.phoneNumber) {
        if (lenth>13) {
            [self showHint:@"电话号码为11位" yOffset:-400];
            
            return NO;
        }
        
        if (range.location==3||range.location==8) {
            if (textField.text.length==3||textField.text.length==8) {
                NSString *s=[textField.text stringByAppendingString:@"-"];
                textField.text=s;
            }
        }
        
        return YES;
        
    }else if(textField==self.verificationCode){
        if (lenth>6) {
            [self showHint:@"验证码为6位" yOffset:-400];
            
            return NO;
        }
        return YES;
        
    }else{
        return YES;
    }
    
}

-(BOOL)judeTextNumWith:(NSString*)text andNextChar:(NSString*)str{
    NSArray *arr = @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@""];
    for (int i=0; i<arr.count; i++ ) {
        if ([arr[i] isEqualToString:str]) {
            return YES;
        }
    }
    return NO;
}

-(NSString*)getPhoneNumberWith:(NSString*)phoneNumberText andSeparateStr:(NSString*)str{
    
    return [[phoneNumberText componentsSeparatedByString:str] componentsJoinedByString:@""];
}

#pragma mark 倒计时功能
- (void)timeCountStart
{
    self.isStart = YES;
    [self.getVerificationCodeBtn setTitle:@"60秒后重新发验证码" forState:UIControlStateNormal];
    [self.countTimer fire];
}

- (void)oneSecondFlip
{
    self.timeRemain = self.timeRemain - 1;
    if (self.timeRemain == 0) {
        
        [self.countTimer invalidate];
        self.countTimer = nil;
        self.timeRemain = 60;
        self.getVerificationCodeBtn.userInteractionEnabled = YES;
        [self.getVerificationCodeBtn setTitle:@"重新发送" forState:UIControlStateNormal];
        self.isStart = NO;
        return;
    }
    MOSLog(@"1 second flip");
    
    NSString *countTitle = [[NSString alloc] initWithFormat:@"%d秒后重新发验证码", self.timeRemain];//, self.timeRemain];
    
    [self.getVerificationCodeBtn setTitle:countTitle
                                 forState:UIControlStateNormal];
    
}

#pragma mark - btn action
- (IBAction)getVerificationCodeAction:(UIButton *)sender {
    if (![self judgePhoneWith:self.phoneNumber.text]) {
        [self showHint:@"请输入正确电话号码" yOffset:-200];
        return;
    }
    
    NSString *userPhone = [self getPhoneNumberWith:self.phoneNumber.text andSeparateStr:@"-"];
    
    BOOL isPhone = [CC_NSStringHandle phoneNumberJudgeWith:userPhone];
    
    if (!isPhone) {
        [self showHint:@"请输入正确电话号码" yOffset:-200];
        return;
    }
    
    __weak typeof(self) weakself = self;
    sender.userInteractionEnabled = NO;
    [self checkPhoneWith:[CC_NSStringHandle filteringTheBlankSpaceWith:userPhone] andFinish:^(BOOL finish) {
        sender.userInteractionEnabled = NO;
        [weakself timeCountStart];
        [weakself getSMSWith:nil];
    }];
    
    
}

#pragma mark - sheet
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag==600){
        NSString *str = [alertView buttonTitleAtIndex:buttonIndex];
        
        if ([str isEqualToString:@"放弃"]) {
            [self.navigationController popToRootViewControllerAnimated:YES];
        }
    }
}

#pragma mark - property
-(void)setLoginUserName:(NSString *)loginUserName{
    if (loginUserName) {
        _loginUserName = [CC_NSStringHandle filteringTheBlankSpaceWith:loginUserName];
    }
}

-(NSString*)userPhone{
    if (_userPhone) {
        _userPhone = nil;
    }
    _userPhone = [self getPhoneNumberWith:self.phoneNumber.text andSeparateStr:@"-"];
    return _userPhone;
}

-(NSString*)userVerCode{
    if (_userVerCode) {
        _userVerCode = nil;
    }
    _userVerCode = self.verificationCode.text;
    return _userVerCode;
}


#pragma mark- btn
- (IBAction)agreeBtnAction:(UIButton *)sender {
    MOSLog(@"同意协议");
    AgreementVC *vc = [[AgreementVC alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)myChangePasswordClicked:(UIButton *)sender {
    
    [self changePasswordStateWith:self.showPassword];
    
    self.showPassword = !self.showPassword;
}

- (IBAction)submitBtnClicked:(UIButton *)sender {
    
    [self submitWith:sender];
}

-(void)changePasswordStateWith:(BOOL)showPassword{
    
    if (showPassword) {
        [self.myChangePasswordStateBtn setBackgroundImage:[UIImage imageNamed:@"dlicon_ck2"] forState:UIControlStateNormal];
        
    }else{
        [self.myChangePasswordStateBtn setBackgroundImage:[UIImage imageNamed:@"dlicon_ck1"] forState:UIControlStateNormal];
        
    }
    self.passwordField.secureTextEntry = showPassword;
    
}


@end
