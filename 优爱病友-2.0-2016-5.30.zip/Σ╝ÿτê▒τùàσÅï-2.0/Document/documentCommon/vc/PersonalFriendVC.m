//
//  PersonalFriendVC.m
//  IMTest
//
//  Created by chenchen on 16/4/26.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalFriendVC.h"

#import "PersonalHomepageVC.h"

#import "SingletonServ.h"
#import "PersonalFriendsRequest.h"
#import "PersonalAddAttentionRequest.h"

#import "UIViewController+HUD.h"

#import "PersonalFriendsCell.h"

typedef void (^OptionFinishBlock)(BOOL isFinish);

@interface PersonalFriendVC (){
    int _page;
}

@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (nonatomic,strong) NSMutableArray *myDataSource;

@end

@implementation PersonalFriendVC

- (void)viewDidLoad {
    self.tableView = self.myTable;
    
    [super viewDidLoad];
    
    self.myDataSource = [[NSMutableArray alloc] init];
    
    self.myTable.delegate = self;
    self.myTable.dataSource = self;
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _page = 1;
    
    [self.myTable registerNib:[UINib nibWithNibName:@"PersonalFriendsCell" bundle:nil] forCellReuseIdentifier:PersonalFriends_id];
    
    __weak typeof(self) weakself = self;
    [self.emptyTableTipsView setAlertImageWith:@"meiyouguanzhu" andTitle:@"还没有关注任何人"];
    self.tableFinish = ^(BOOL finish){
        weakself.emptyTableTipsView.hidden = weakself.myDataSource.count;
    };
    
    [self setNav];
    [self showHudInView:self.view hint:@"加载中..."];
//    [self makeModelWith:_page with:nil andHeaderRef:YES];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [self makeModelWith:1 with:nil andHeaderRef:YES];
}

#pragma mark - property

#pragma mark - net work
-(void)myAddAttentionBtnClickedWith:(NSIndexPath*)index andFinish:(OptionFinishBlock)finish{
    PersonalFriends_items *model = [self.myDataSource objectAtIndex:index.row];
    
    PersonalAddAttentionRequest *req = [[PersonalAddAttentionRequest alloc] init];
    req.people_id = model.userInfo.user_id;
    __weak typeof(self) weakself = self;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            model.status = [NSString stringWithFormat:@"%d",1-[model.status intValue]];
            if ([model.status intValue]==1) {
                [weakself showHint:@"关注成功" yOffset:-200];
            }else{
                [weakself showHint:@"取消关注" yOffset:-200];
            }
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
        if (finish) {
            finish([model.status boolValue]);
        }
    }];
}

-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    
    PersonalFriendsRequest *req = [[PersonalFriendsRequest alloc] init];
    req.user_id = self.userid;
    req.page = [NSString stringWithFormat:@"%d",page];
    
    __weak typeof(self) weakself = self;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            
            if (isHeaderRef) {
                [weakself.myDataSource removeAllObjects];
            }
            
            PersonalFriendsResponse *model = (PersonalFriendsResponse*)responseDataModel;
            [weakself.myDataSource addObjectsFromArray:model.items];
            
            [weakself.myTable reloadData];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        [weakself hideHud];
        weakself.emptyTableTipsView.hidden = weakself.myDataSource.count;

        if (finishBlock) {
            finishBlock(YES);
        }
    }];
    
}
#pragma mark - refresh
- (void)tableViewDidTriggerHeaderRefresh{
    _page = 1;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:YES reload:NO];
        
    } andHeaderRef:YES];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    _page ++;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:NO reload:NO];
        
    } andHeaderRef:NO];
    
}//上拉加载事件
#pragma mark - table
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.myDataSource.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    PersonalFriends_items *model = [self.myDataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    PersonalFriendsCell *cell = [tableView dequeueReusableCellWithIdentifier:PersonalFriends_id];
    
    if (cell==nil) {
        cell  = [[[NSBundle mainBundle] loadNibNamed:@"PersonalFriendsCell" owner:nil options:nil] firstObject];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    PersonalFriends_items *model = [self.myDataSource objectAtIndex:indexPath.row];
    [cell setMyCellWith:model];
    
//    __weak typeof (self) weakself = self;
//    __weak typeof(PersonalFriendsCell *) weakcell = cell;
    if (self.isMyself) {
        [cell hidenAttendBtnWith:YES];
    }
//    else{
//        cell.AttentionBtnClickedBlock = ^(NSInteger isAttented){
//            [weakself myAddAttentionBtnClickedWith:indexPath andFinish:^(BOOL isFinish) {
//                [weakcell changeAttendBtnStateWith:[NSString stringWithFormat:@"%d",isFinish]];
//            }];
//        };
        
//    }
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    PersonalFriends_items *model = (PersonalFriends_items*)[_myDataSource objectAtIndex:indexPath.row];
    PersonalHomepageVC *vc = [[PersonalHomepageVC alloc] init];
    vc.userid = model.userInfo.user_id;
//    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
