//
//  PersonalAnswersVC.h
//  IMTest
//
//  Created by chenchen on 16/4/26.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface PersonalAnswersVC : BasicVC
@property (nonatomic,copy) NSString* userid;

@end
