//
//  GetProvinceVC.m
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "GetProvinceVC.h"

#import "UIViewController+HUD.h"

#import "SingletonServ.h"
#import "ProvinceRequest.h"
#import "ProvinceResponse.h"
#import "ProvinceListItemResponse.h"

static NSString *const Cell_id = @"province";
@interface GetProvinceVC (){
     NSMutableArray *_source;

}
@property (weak, nonatomic) IBOutlet UITableView *myTable;

@end

@implementation GetProvinceVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;

    [super viewDidLoad];
    
//    self.title = @"选择地区";
    
    _source = [[NSMutableArray alloc] init];
    
    self.myTable.delegate = self;
    self.myTable.dataSource = self;
    
    [self netWorkRequest];
    
    [self setNav];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    
}

#pragma  mark - property
-(void)setCityList:(NSMutableArray *)cityList{
    if (_cityList==nil) {
        _cityList = [NSMutableArray array];
    }
    
    [_cityList removeAllObjects];
    [_cityList addObjectsFromArray:cityList];
    
}

#pragma mark - make data
-(void)netWorkRequest{

    ProvinceRequest *req = [[ProvinceRequest alloc] init];
    
    __weak typeof (self) weakself = self;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            
            ProvinceResponse * modelList = (ProvinceResponse*)responseDataModel;
            [_source addObjectsFromArray: modelList.provinces];
            [weakself.myTable reloadData];
        }else{
            [self showHint:responeseError.msg yOffset:-200];
        }
        
    }];
}



#pragma mark - table
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    if (self.isCituList) {
        return _cityList.count;
    }
    return _source.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return 40.0f;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
   
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:Cell_id];
        
    if (cell==nil) {
        cell  = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:Cell_id];
    }
    
    if (self.isCituList) {
        CityItemResponse *model = [_cityList objectAtIndex:indexPath.row];
        cell.textLabel.text = model.name;
    }else{
        ProvinceListItemResponse *model = [_source objectAtIndex:indexPath.row];
        cell.textLabel.text = model.name;
    }
    
    return cell;
  
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
 
    if (self.isCituList) {
        CityItemResponse *model = [_cityList objectAtIndex:indexPath.row];

        MOSLog(@"%@",model.city_id);
        
        if (self.lyj_delegate && [self.lyj_delegate respondsToSelector:@selector(getProvinceWith:andCityWith:andProvince_id:andCity_id:)]) {
            [self.lyj_delegate getProvinceWith:self.provinceName andCityWith:model.name andProvince_id:model.parent_id andCity_id:model.city_id];
        }
        
        NSArray *arr = self.navigationController.viewControllers;
        [self.navigationController popToViewController:arr[arr.count-3] animated:YES];
    }else{
        ProvinceListItemResponse *model = [_source objectAtIndex:indexPath.row];
        GetProvinceVC *vc = [[GetProvinceVC alloc] init];
        vc.isCituList = YES;
        vc.cityList = model.cityList;
        vc.provinceName = model.name;
        vc.title = @"城市";
        vc.lyj_delegate = self.lyj_delegate;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
