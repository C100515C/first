//
//  PersonalAnswersCell.h
//  IMTest
//
//  Created by chenchen on 16/4/26.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString * const PersonalAnswers_id = @"PersonalAnswers";
@class PersonalAnswers_items;
@interface PersonalAnswersCell : BasicTableViewCell

-(void)setMyCellWith:(PersonalAnswers_items*)model;

@end
