//
//  PersonalAnswersRequest.h
//  IMTest
//
//  Created by chenchen on 16/4/26.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"
#import "BasicResponse.h"

@interface PersonalAnswersRequest : BaseRequest

@property (nonatomic,copy) NSString *page;
@property (nonatomic,copy) NSString *user_id;

-(id)init;

@end

@interface PersonalAnswers_meta : BasicResponse
@property (nonatomic,copy) NSString *currentPage;
@property (nonatomic,copy) NSString *pageCount;
@property (nonatomic,copy) NSString *perPage;
@property (nonatomic,copy) NSString *totalCount;

@end
@interface PersonalAnswers_userInfo : BasicResponse
@property (nonatomic,copy) NSString *avatar;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *username;

@end

@interface PersonalAnswers_items : BasicResponse
@property (nonatomic,copy) NSString *comment_count;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *forum_id;
@property (nonatomic,copy) NSString *forum_name;
@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *praise_count;
@property (nonatomic,copy) NSString *sources;
@property (nonatomic,copy) NSString *status;
@property (nonatomic,copy) NSString *thread_id;
@property (nonatomic,copy) NSString *thread_title;
@property (nonatomic,copy) NSString *thread_type;
@property (nonatomic,strong) PersonalAnswers_userInfo *userInfo;
@property (nonatomic,copy) NSString *user_id;

@property (nonatomic,assign) CGFloat topNewHeight;

-(UIColor*)getLabelColor;

@end

@interface PersonalAnswersResponse : BasicResponse

@property (nonatomic,strong) NSMutableArray *items;
@property (nonatomic,strong) PersonalAnswers_meta *_meta;

+(Class)items_class;

@end