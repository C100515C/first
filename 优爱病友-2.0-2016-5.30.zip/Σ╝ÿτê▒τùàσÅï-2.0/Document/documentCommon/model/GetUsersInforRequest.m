//
//  GetUsersInforRequest.m
//  IMTest
//
//  Created by chenchen on 16/4/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "GetUsersInforRequest.h"

@implementation GetUsersInforRequest

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"users/%@?access-token=%@&",[[UserProfileManager sharedInstance] getUserId],[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        self.reqMethod = @"GET";
//        self.reqMethod = @"POST";
        self.reqClassName = @"GetUsersInforItem";
    }
    return self;
}

@end

@implementation GetUsersInforItemResponse

-(NSMutableArray*)itemList{
    if (_itemList==nil) {
        _itemList = [NSMutableArray array];
    }
    return _itemList;
}

+(Class)itemList_class{
    return [GetUsersInforResponse class];
}

@end

@implementation GetUsersInforResponse

@end