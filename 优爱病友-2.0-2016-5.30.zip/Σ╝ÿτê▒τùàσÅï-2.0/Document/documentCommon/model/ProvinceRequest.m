//
//  ProvinceRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "ProvinceRequest.h"

@implementation ProvinceRequest
- (id)init
{
    self = [super init];
    if (self) {
        self.reqUrlPath = @"configs";
        self.reqMethod = @"GET";
//        self.reqMethod = @"POST";
        self.reqClassName = @"Province";
    }
    return self;
}
@end
