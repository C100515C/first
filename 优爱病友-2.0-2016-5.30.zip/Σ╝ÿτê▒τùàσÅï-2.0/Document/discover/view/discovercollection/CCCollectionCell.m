//
//  CCCollectionCell.m
//  test
//
//  Created by MS on 16-1-21.
//  Copyright (c) 2016年 MS. All rights reserved.
//

#import "CCCollectionCell.h"
#import "DiscoverResponse.h"

@interface CCCollectionCell ()

@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UIImageView *pic;


@end

@implementation CCCollectionCell

-(void)awakeFromNib{
    self.clipsToBounds = YES;
    self.layer.borderColor = [[UIColor lightGrayColor]CGColor];
    self.layer.borderWidth = 0.5f;
    self.title.adjustsFontSizeToFitWidth = YES;

}

-(void)setCellWith:(DiscoverItemResponse *)model{
    self.title.text = model.forum_name;
    [self.pic sd_setImageWithURL:[NSURL URLWithString:model.forum_icon] placeholderImage:[UIImage imageNamed:@"dlicon"]];

}

@end
