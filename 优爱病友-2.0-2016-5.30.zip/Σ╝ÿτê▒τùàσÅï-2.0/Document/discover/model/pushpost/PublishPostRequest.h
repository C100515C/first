//
//  PublishPostRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/30.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface PublishPostRequest : BaseRequest
@property (nonatomic,copy) NSString *forum_id;
@property (nonatomic,copy) NSString *thread_type;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *content;

-(id)init;
@end
