//
//  PublishPostRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/30.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PublishPostRequest.h"

@implementation PublishPostRequest

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"threads?access-token=%@",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
//        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"PublishPost";
    }
    return self;
}
@end
