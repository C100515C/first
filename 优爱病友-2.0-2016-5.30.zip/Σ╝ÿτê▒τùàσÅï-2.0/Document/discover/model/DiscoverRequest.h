//
//  DiscoverRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface DiscoverRequest : BaseRequest

-(id)init;

@end
