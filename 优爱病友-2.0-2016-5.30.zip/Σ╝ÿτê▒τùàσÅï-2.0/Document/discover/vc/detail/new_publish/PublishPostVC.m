//
//  PublishPostVC.m
//  IMTest
//
//  Created by chenchen on 16/5/18.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PublishPostVC.h"
#import "BasicUIButton.h"
#import "CC_CanDeleteImageView.h"

#import "UIViewController+LYJAlertView.h"
#import "UIViewController+HUD.h"

#import "SingletonServ.h"
#import "PublishPostRequest.h"
#import "PublishPostResponse.h"

static const NSInteger ImageViewBaseTag = 30;

@interface PublishPostVC ()<UITextViewDelegate,UINavigationControllerDelegate, UIImagePickerControllerDelegate,CC_CanDeleteImage>

@property (weak, nonatomic) IBOutlet BasicUIButton *upPicBtn;
@property (weak, nonatomic) IBOutlet UITextView *titleTextView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabelOfTitleTextView;
@property (weak, nonatomic) IBOutlet UITextView *desTextView;
@property (weak, nonatomic) IBOutlet UILabel *titleLableOfTextView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *picBtnX;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *picBtnY;

@property (strong, nonatomic) UIImagePickerController *imagePickerController;

@property (nonatomic,strong) NSMutableArray *selectedPics;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,strong) NSData *upfile;
@property (nonatomic,strong) NSString *upfileName;

@property (nonatomic,copy) NSString *thread_type;
@property (nonatomic,copy) NSString *post_title;

@end

@implementation PublishPostVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setNav];
    
    self.tableView.hidden = YES;
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    self.desTextView.delegate = self;
    self.titleTextView.delegate = self;
    [self initBtn];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (void)viewWillDisappear:(BOOL)animated {
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"findDetail_public2"];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"findDetail_public2"];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    [self.desTextView resignFirstResponder];
    [self.titleTextView resignFirstResponder];
}

#pragma mark - property
-(NSString*)post_title{
    if (_post_title) {
        _post_title = nil;
    }
    NSString *str = [CC_NSStringHandle filteringTheBlankSpaceWith:self.titleTextView.text];
    _post_title = str;
    return _post_title;
}

-(NSString*)thread_type{
    return @"1";
}

-(NSString*)content{
    if (_content) {
        _content = nil;
    }
    _content = [CC_NSStringHandle filteringTheBlankSpaceWith:self.desTextView.text];
    if (_content.length==0) {
        _content = @"";
    }
    return _content;
}

-(NSMutableArray*)selectedPics{
    if (_selectedPics==nil) {
        _selectedPics = [NSMutableArray array];
    }
    
    return _selectedPics;
}

#pragma mark - nav
-(void)setNav{
    [super setNav];
    self.title = @"发新帖";
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
    [nav setNavBarBtnItemTitleWith:@"发布" andRightItem:YES andAction:@selector(nextClickdAction:) andTarget:self andVCIndex:3 andTitleColor:G_COLOR_WHITE];
}

-(void)nextClickdAction:(UIButton*)sender{
    
    [self.desTextView resignFirstResponder];
    [self.titleTextView resignFirstResponder];
    
    [self publishPost];
}

-(NSString*)stringChangeHtmlWith:(NSString*)str{
    NSString *a = @"\n";
    NSString *b = @"'\'";
    NSString *c = @" ";
    NSArray *arr = @[a,b,c];
    NSArray *htm = @[@"<br>",@"&nbsp;&nbsp;",@"&nbsp;"];
    
    NSString *ret = str;
    for (int i=0;i<arr.count;i++) {
        NSArray *tmpArr = [ret componentsSeparatedByString:arr[i]];
        if (tmpArr.count<=1) {
            continue;
        }else{
            ret = [tmpArr componentsJoinedByString:htm[i]];
        }
    }
    
    return [NSString stringWithFormat:@"<p>%@</p>",ret];
}

-(void)publishPost{
    
    PublishPostRequest *req = [[PublishPostRequest alloc] init];
    req.forum_id = self.forum_id;
    req.thread_type = self.thread_type;
    req.title = self.post_title;
    req.content = [self stringChangeHtmlWith:self.content];//self.content;
    
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"发布中..."];
    
    [[SingletonServ sharedInstance] reqPostWithModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            
            [weakself.navigationController popToViewController:weakself.navigationController.viewControllers[1] animated:YES];
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-100];
        }
        
        [weakself hideHud];
        
    } constructingBodyWithBlock:^(id<AFMultipartFormData> formData) {
        if (weakself.selectedPics.count) {
            CC_CanDeleteImageView *pic = [weakself.selectedPics firstObject];
            
            NSData *data = UIImageJPEGRepresentation(pic.image , 0.1);
            [formData appendPartWithFileData:data name:@"upfile" fileName:[NSString stringWithFormat:@"upfile.%@",pic.fileName] mimeType:@"image/jpeg"];
        }
    }];
}

-(void)back:(UIButton*)btn{
    [self.navigationController popViewControllerAnimated:YES];
    
    /*
     __weak typeof(self) weakself = self;
     UIAlertControllerActionBlock sure = ^(UIAlertAction *action){
     
     [weakself.navigationController popToViewController:[weakself.navigationController.viewControllers objectAtIndex:1] animated:YES];
     [weakself.navigationController popViewControllerAnimated:YES];
     
     };
     UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
     MOSLog(@"继续注册");
     };
     [UIViewController showAlertTltileWith:@"提示" andMessage:@"确定放弃本次发帖" andActions:@{@"放弃":sure,@"取消":cancle} andShowVC:self andAlertStyle:UIAlertControllerStyleAlert andalertTag:900];*/
}

#pragma mark - text view
-(void)textViewDidChange:(UITextView *)textView {
    if (textView==self.titleTextView) {
        if (textView.text.length) {
            self.titleLabelOfTitleTextView.hidden = YES;
        }else{
            self.titleLabelOfTitleTextView.hidden = NO;
        }
    }
    
    if (textView==self.desTextView) {
        if (textView.text.length) {
            self.titleLableOfTextView.hidden = YES;
        }else{
            self.titleLableOfTextView.hidden = NO;
        }
    }
}

-(BOOL)textView:(UITextView *)textView shouldChangeTextInRange:(NSRange)range replacementText:(NSString *)text{
    if (textView==self.titleTextView) {
        if (textView.text.length+text.length>25) {
            //        textView.text = [textView.text substringWithRange:NSMakeRange(0, 200)];
            [self showHint:@"最多输入25个字" yOffset:-300];
            return NO;
        }
    }
    
    if (textView==self.desTextView) {
        if (textView.text.length+text.length>400) {
            //        textView.text = [textView.text substringWithRange:NSMakeRange(0, 200)];
            [self showHint:@"最多输入200个字" yOffset:-300];
            return NO;
        }
    }
    
    return YES;
}

#pragma mark - btn

-(void)initBtn{
    
    [self.upPicBtn setImage:[UIImage imageNamed:@"tianjiatupian"] forState:UIControlStateNormal];
    
    self.upPicBtn.titleLabelFrame = CGRectMake(5, 56, 76, 18);
    self.upPicBtn.imageFrame = CGRectMake(19, 8, 40, 40);
    
    [self.upPicBtn addTarget:self action:@selector(upPicAction:) forControlEvents:UIControlEventTouchUpInside];
    self.upPicBtn.clipsToBounds = YES;
    self.upPicBtn.layer.borderWidth = 0.5f;
    self.upPicBtn.layer.borderColor = [RGB(166, 173, 175, 1)CGColor];
    
}

-(void)upPicAction:(UIButton*)sender{
    if (self.selectedPics.count>0) {
        [self showHint:@"只能选择一张图片" yOffset:-200];
        return ;
    }
    [self cellAvatarPress];
    
}

#pragma mark - 头像模块
- (void)cellAvatarPress
{
    __weak typeof (self) weakSelf = self;
    UIAlertControllerActionBlock takephoto = ^(UIAlertAction *action){
        MOSLog(@"拍照");
        
        if ([LYJSystemCallsJudgeManager isCanUseCamera_CCWith:^{
            [self showHint:@"请去系统设置允许应用访问相机" yOffset:-300];
        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            weakSelf.imagePickerController.editing = YES;
            weakSelf.imagePickerController.allowsEditing = YES;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                     
                                 }];
        }
        
        
    };
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"取消");
    };
    UIAlertControllerActionBlock pics = ^(UIAlertAction *action){
        MOSLog(@"从手机相册选择");
        if ([LYJSystemCallsJudgeManager iscanPictureAblumWith:^{
            [self showHint:@"请去系统设置允许应用访问相册" yOffset:-300];
            
        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                     
                                     [self prefersStatusBarHidden ];
                                     [self preferredStatusBarStyle];
                                 }];
            
        }
    };
    [UIViewController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"拍照":takephoto,@"从手机相册选择":pics} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet andalertTag:901];
}



#pragma mark - Property method

- (UIImagePickerController *)imagePickerController
{
    if (_imagePickerController == nil) {
        _imagePickerController = [[UIImagePickerController alloc] init];
        _imagePickerController.navigationBar.barTintColor = RGB(41, 187, 98, 1);//G_COLOR_NAVGATION_BACK;
        
        _imagePickerController.navigationBar.tintColor = [UIColor whiteColor];
        _imagePickerController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:G_COLOR_NAVGATION_TITLE,
                                                                     NSFontAttributeName:G_FONT_NAVGATION_TITLE};
        
        [self prefersStatusBarHidden ];
        [self preferredStatusBarStyle];
        
        _imagePickerController.delegate = self;
    }
    return _imagePickerController;
}

-(BOOL)prefersStatusBarHidden{
    return NO;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *picImage;
    //    = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    
    //    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
    //        picImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    //    } else {
    //        picImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    //    }
    //    NSURL *imagePath = [info objectForKey:@"UIImagePickerControllerReferenceURL"];
    //    NSString *imagePathStr = [NSString stringWithFormat:@"%@",imagePath];
    //    NSArray *imagePaths = [imagePathStr componentsSeparatedByString:@"="];
    //    NSString *iconDataFormat = [imagePaths lastObject];
    
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
        picImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
        self.upfileName = @"png";
        
    } else {
        picImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
        NSURL *imagePath = [info objectForKey:@"UIImagePickerControllerReferenceURL"];
        NSString *imagePathStr = [NSString stringWithFormat:@"%@",imagePath];
        NSArray *imagePaths = [imagePathStr componentsSeparatedByString:@"="];
        self.upfileName = [imagePaths lastObject];
        
    }
    
    __weak typeof(self) weakSelf = self;
    
    [self.imagePickerController dismissViewControllerAnimated:YES completion:^{
        //        NSData *data = UIImageJPEGRepresentation(picImage , 0.1);
        
        CC_CanDeleteImageView *pic = [weakSelf createSelectPicWith:picImage andBaseFrame:weakSelf.upPicBtn.frame];
        pic.fileName = weakSelf.upfileName;
        [weakSelf.view addSubview:pic];
        [weakSelf.selectedPics addObject:pic];
        weakSelf.upPicBtn.hidden = weakSelf.selectedPics.count;
        
    }];
    
    
    
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self preferredStatusBarStyle];
    [picker dismissViewControllerAnimated:YES completion:^{
        [self preferredStatusBarStyle];
    }];
    
}

-(CC_CanDeleteImageView*)createSelectPicWith:(UIImage*)image andBaseFrame:(CGRect)baseFrame{
    CC_CanDeleteImageView *pic = nil;
    
    pic  = [[CC_CanDeleteImageView alloc] initWithFrame:baseFrame];
    pic.image = image;
    
    CGFloat space = 10.0f;
    CGFloat n_x =  baseFrame.origin.x+baseFrame.size.width+space;
    CGFloat n_y = baseFrame.origin.y-self.desTextView.frame.origin.y-self.desTextView.frame.size.height;
    
    if ((n_x+baseFrame.size.width+space)>self.view.frame.size.width) {
        n_x = space;
        n_y = n_y+space+baseFrame.size.height;
    }
    
    pic.delegate = self;
    self.picBtnX.constant = n_x;
    self.picBtnY.constant = n_y;
    pic.number = (int)(n_x/baseFrame.size.width)+(int)(n_y/baseFrame.size.height)*(int)(self.view.frame.size.width/(baseFrame.size.width+space));
    pic.tag = ImageViewBaseTag+pic.number;
    [self.upPicBtn layoutIfNeeded];
    
    return pic;
}

-(NSArray*)getPics{
    
    NSMutableArray *arr = [NSMutableArray array ];
    
    NSArray *subs = [self.view subviews];
    
    for (CC_CanDeleteImageView *pic in subs) {
        if ([pic isKindOfClass:[CC_CanDeleteImageView class]]) {
            [arr addObject:pic];
        }
    }
    return arr;
}

#pragma mark - CC_CanDeleteImage
-(void)deletePictureWith:(CC_CanDeleteImageView*)currentPicture{
    
    [self resetFrameWith:currentPicture];
    
    [currentPicture removeFromSuperview];
}

-(void)resetFrameWith:(CC_CanDeleteImageView*)currentPic{
    
    CGRect tmp = currentPic.frame;
    CGRect current = currentPic.frame;
    CC_CanDeleteImageView *last = [self.selectedPics lastObject];
    CGRect lastRect = last.frame;
    
    for (int i=0; i<self.selectedPics.count; i++ ) {
        CC_CanDeleteImageView *pic = self.selectedPics[i];
        if (currentPic.number < pic.number) {
            tmp = pic.frame;
            pic.frame = current;
            pic.number -= 1;
            pic.tag = ImageViewBaseTag+pic.number;
            current = tmp;
        }
    }
    
    [self.selectedPics removeObject:currentPic];
    self.upPicBtn.hidden = self.selectedPics.count;
    
    self.picBtnX.constant = lastRect.origin.x;
    self.picBtnY.constant = lastRect.origin.y-self.desTextView.frame.origin.y-self.desTextView.frame.size.height;
    
}

#pragma mark - sheet
-(void)alertView:(UIAlertView *)alertView clickedButtonAtIndex:(NSInteger)buttonIndex{
    if(alertView.tag==900){
        NSString *str = [alertView buttonTitleAtIndex:buttonIndex];
        
        if ([str isEqualToString:@"放弃"]) {
            [self.navigationController popViewControllerAnimated:YES];
        }
    }
}
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
    
    if (actionSheet.tag==901) {
        
        NSString *str = [actionSheet buttonTitleAtIndex:buttonIndex];
        if ([str isEqualToString:@"拍照"]) {
            if ([LYJSystemCallsJudgeManager isCanUseCamera_CCWith:^{
                [self showHint:@"请去系统设置允许应用访问相机" yOffset:-300];
            }]) {
                self.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
                self.imagePickerController.editing = YES;
                self.imagePickerController.allowsEditing = YES;
                [self presentViewController:self.imagePickerController
                                   animated:YES
                                 completion:^{
                                     //
                                 }];
            }
        }else if ([str isEqualToString:@"从手机相册选择"]){
            if ([LYJSystemCallsJudgeManager iscanPictureAblumWith:^{
                [self showHint:@"请去系统设置允许应用访问相册" yOffset:-300];
                
            }]) {
                self.imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
                [self presentViewController:self.imagePickerController
                                   animated:YES
                                 completion:^{
                                     
                                     [self prefersStatusBarHidden ];
                                     [self preferredStatusBarStyle];
                                 }];
                
            }
        }
        
    }
}


@end
