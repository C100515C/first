//
//  Discover_newVC.h
//  IMTest
//
//  Created by chenchen on 16/5/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface Discover_newVC : BasicVC

@end
