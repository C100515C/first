//
//  NoticeCellRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/31.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "NoticeCellRequest.h"

@implementation NoticeCellRequest

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"notices?access-token=%@&",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        self.reqMethod = @"GET";
//        self.reqMethod = @"POST";
        self.reqClassName = @"NoticeCellItems";
    }
    return self;
}

@end
