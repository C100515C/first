//
//  NoticeTableCell.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "NoticeTableCell.h"
#import "NoticeCellResponse.h"

@implementation NoticeTableCell
-(void)awakeFromNib{
    [super awakeFromNib];
    
    self.nicknameLabel.type = LabelFont_17;
    self.timeLabel.type = LabelFont_12;
    self.desContentLabel.type = LabelFont_15;
}
-(void)setCellWithModel:(NoticeCellResponse *)model{
    self.nicknameLabel.text = model.nicknameAndOp;
    self.desContentLabel.text = model.content;
    self.timeLabel.text = model.created_at;
}

@end
