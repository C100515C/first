//
//  AddFamilyCaseClipRecordVC.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"
@class  CaseClipDetailResponse;
@interface AddFamilyCaseClipRecordVC : BasicVC
@property (nonatomic,copy) NSString *dossierId;
@property (nonatomic,assign) BOOL isHidenDelete;
@property (nonatomic,strong) CaseClipDetailResponse *oldModel;

@end
