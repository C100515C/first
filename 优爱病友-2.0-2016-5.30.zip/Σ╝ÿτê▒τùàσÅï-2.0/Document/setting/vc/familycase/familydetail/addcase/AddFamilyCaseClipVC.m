//
//  AddFamilyCaseClipVC.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "AddFamilyCaseClipVC.h"
#import "AddFamilyCaseClipRecordVC.h"

#import "CaseClipCommonCell.h"
#import "CaseClipCommonHeaderView.h"

#import "CaseClipCommonResponse.h"
#import "FamilyCasesClipResponse.h"
#import "SingletonServ.h"

#import "LYJInputView.h"
#import "UIViewController+LYJAlertView.h"
#import "UIViewController+HUD.h"

@interface AddFamilyCaseClipVC ()<LYJInputViewDelegate,UINavigationControllerDelegate, UIImagePickerControllerDelegate>
{
    NSString *_dateString;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;

@property (nonatomic,strong) NSMutableArray *dataSource;
@property (nonatomic,strong) NSIndexPath *currentIndexPath;
@property (nonatomic,strong) UIDatePicker *datePicker;
@property (nonatomic,strong) UIView *dataBackView;
@property (nonatomic,strong) LYJInputView *inputView;

@property (nonatomic,weak) IBOutlet CaseClipCommonHeaderView *tableHeaderView;
@property (nonatomic,strong) UIButton *addCaseClip;

@property (strong, nonatomic) UIImagePickerController *imagePickerController;
@property (nonatomic,assign) BOOL isFinished;
@property (strong,nonatomic) NSString *case_id;
@end

@implementation AddFamilyCaseClipVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self setNav];
    
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    _dataSource = [[NSMutableArray alloc] init];
    
    [self datePickerSelect];
    
    [self setInputView];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"CaseClipCommonCell" bundle:nil] forCellReuseIdentifier:CaseClipCommon_id];
    __weak typeof(self) weakself = self;
//    self.tableView.tableHeaderView = self.tableHeaderView;
    self.tableHeaderView.tapImageBlock = ^(UIImageView *imageview){
        [weakself cellAvatarPress];
    };
    
    [self createUI];
    
    [self makeModel];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}
#pragma mark - ui
-(void)createUI{
    UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_HEIGHT, 40)];
    view.backgroundColor = RGB(247, 249, 249, 1);
    self.tableView.tableFooterView = view;
    self.addCaseClip = [UIButton buttonWithType:UIButtonTypeCustom];
    self.addCaseClip.frame = CGRectMake(0, 5, 150, 30);
    self.addCaseClip.center = CGPointMake(view.frame.size.width/2.0, 20);
    self.addCaseClip.backgroundColor = [UIColor clearColor];
    [self.addCaseClip setTitle:@"添加就诊记录" forState:UIControlStateNormal];
    [self.addCaseClip setTitleColor:RGB(41, 187, 98, 1) forState:UIControlStateNormal];
    [self.addCaseClip addTarget:self action:@selector(addCaseClicked:) forControlEvents:UIControlEventTouchUpInside];
    [view addSubview:self.addCaseClip];
}

#pragma mark - btn
-(void)addCaseClicked:(UIButton*)sender{
    if (self.isFinished) {
        AddFamilyCaseClipRecordVC *vc = [[AddFamilyCaseClipRecordVC alloc] init];
        vc.dossierId = self.case_id;
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        [self showHint:@"请先保存病例信息" yOffset:-200];
    }
    
}

#pragma mark - Nav
-(void)setNav{
    
    [super setNav];

    self.title = @"添加病例夹";
    
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    [nav setNavBarBtnItemTitleWith:@"保存" andRightItem:YES andAction:@selector(finishClickdAction:) andTarget:self andVCIndex:2 andTitleColor:nil];

}

-(void)finishClickdAction:(UIButton*)sender{
    
    MOSLog(@"完成");
    [self showHudInView:self.view hint:@"保存中..."];
    [self makeModelWith:0 with:nil andHeaderRef:YES];
}

#pragma mark - data
-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    __weak typeof(self) weakself = self;
    
    CaseClipCommonRequest *req = [[CaseClipCommonRequest alloc] init];
    NSArray *arr = [self getParam];
    if (arr.count==0) {
        [self hideHud];
        return;
    }
    req.name = arr[0];
    req.gender = arr[1];
    req.birthday = arr[2];
    
    if (self.oldEditModel) {
        [req setEditUrl:self.oldEditModel.objectId];
    }
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        if (responeseError==nil) {
            CaseClipCommonResponse *model = (CaseClipCommonResponse*)responseDataModel;
            weakself.case_id = model.objectId;
            weakself.isFinished = YES;
            [weakself showHint:@"添加成功" yOffset:-200];
            
            if (weakself.oldEditModel) {
                [weakself.navigationController popViewControllerAnimated:YES];
            }
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        [weakself hideHud];
//        weakself.emptyTableTipsView.hidden = weakself.dataSource.count;
        
        if (finishBlock) {
            finishBlock(YES);
        }
    }];
}

-(NSArray*)getParam{
    NSMutableArray *arr = [NSMutableArray array ];
    for (int i=0; i<_dataSource.count; i++) {
        CaseClipCommonResponse *model = _dataSource[i];
        if ([model.parma isEqualToString:@"请输入您对该家庭成员的称呼"] || [model.parma isEqualToString:@"选择该成员的出生日期"] || model.parma.length==0) {
            [self showHint:@"请填写正确的信息" yOffset:-200];
            [arr removeAllObjects];
            return arr;
        }
        [arr addObject:model.parma];
    }
    return arr;
}

-(void)makeModel{
    
    [_dataSource addObjectsFromArray:[self getSecondSection]];
    
    [_myTable reloadData];
}


-(NSArray *)getSecondSection{
    NSMutableArray *sectionArr = [NSMutableArray array];
    NSArray *names = @[@"称       呼",@"性       别",@"出生日期"];
    NSArray *title = @[@"请输入您对该家庭成员的称呼",@"女",@"选择该成员的出生日期"];
    if (self.oldEditModel) {
        title = @[self.oldEditModel.name,self.oldEditModel.gender,self.oldEditModel.birthday];
    }
    for (int i=0 ; i<3; i++) {
        CaseClipCommonResponse *model = [[CaseClipCommonResponse alloc] init];
        model.content = title[i];
        if (i==0) {
            model.isHideImage = YES;

        }else{
            model.isHideImage = NO;

        }
        model.nameTitle = names[i];
        [sectionArr addObject:model];
    }
    return sectionArr;
}

-(void)resetDatasourceWith:(NSIndexPath*)indexpath andChangeValue:(NSString*)change{
    
    CaseClipCommonResponse *model = [_dataSource objectAtIndex:indexpath.row];
    model.content = change;
}

#pragma mark - table
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CaseClipCommonResponse *model = (CaseClipCommonResponse*)[_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
 
        CaseClipCommonCell *cell = [tableView dequeueReusableCellWithIdentifier:CaseClipCommon_id];
        
        if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"CaseClipCommonCell" owner:nil options:nil] firstObject];
        }
        
        CaseClipCommonResponse *model = (CaseClipCommonResponse*)[_dataSource objectAtIndex:indexPath.row];
        
        [cell setCellWith:model];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    self.currentIndexPath = indexPath;

    switch (indexPath.row) {
        case 0:
        {
            //称呼
            self.inputView.hidden = NO;
            [self.inputView keyboardAppear];
        }
            break;
        case 1:
        {
            //性别
            [self selectGender];

        }
            break;
        case 2:
        {
            //生日
            [self showDateView];

        }
            break;
            
        default:
            break;
    }
    
}

#pragma mark - gender select
-(void)selectGender{
    
    CaseClipCommonCell *cell = [_myTable cellForRowAtIndexPath:self.currentIndexPath];
    
    __weak typeof(self) weakself = self;
    UIAlertControllerActionBlock man = ^(UIAlertAction *action){
        cell.content.text = @"男";
        [weakself resetDatasourceWith:_currentIndexPath andChangeValue:cell.content.text];
        
    };
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"取消");
    };
    UIAlertControllerActionBlock woman = ^(UIAlertAction *action){
        cell.content.text = @"女";
        [weakself resetDatasourceWith:_currentIndexPath andChangeValue:cell.content.text];
        
    };
    [UIViewController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"男":man,@"女":woman} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet andalertTag:400];
}

#pragma mark - date select
-(void)datePickerSelect{
    self.dataBackView = [[UIView alloc] initWithFrame:CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 246)];
    _dataBackView.backgroundColor = [UIColor whiteColor];
    [self.view addSubview:self.dataBackView];
    
    self.datePicker = [[UIDatePicker alloc] initWithFrame:CGRectMake(0, 30, SCREEN_WIDTH, 216)];
    NSLocale *locale = [[NSLocale alloc] initWithLocaleIdentifier:@"zh_CN"];
    _datePicker.locale = locale;
    _datePicker.datePickerMode = UIDatePickerModeDate;
    
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM-dd"];
    
    //    NSString *  currentDate = [format stringFromDate:[NSDate date]];
    NSDate *minDate = [format dateFromString:@"1900-01-01"];
    NSDate *maxDate = [format dateFromString:@"2099-01-01"];
    
    _datePicker.minimumDate = minDate;
    _datePicker.maximumDate = maxDate;
    
    [self.datePicker setDate:[NSDate date]];
    [self.datePicker addTarget:self action:@selector(dateChangeAction:) forControlEvents:UIControlEventValueChanged];
    
    [self.dataBackView addSubview:_datePicker];
    
    UIButton *cancale = [UIButton buttonWithType:UIButtonTypeCustom];
    cancale.frame = CGRectMake(0, 0, 45, 30);
    [cancale addTarget:self action:@selector(cancelDateSelect:) forControlEvents:UIControlEventTouchUpInside];
    [cancale setTitle:@"取消" forState:UIControlStateNormal];
    [cancale setTitleColor:[UIColor darkTextColor] forState:UIControlStateNormal];
    [_dataBackView addSubview:cancale];
    
    UIButton *finish = [UIButton buttonWithType:UIButtonTypeCustom];
    finish.frame = CGRectMake( _dataBackView.frame.size.width-45,0, 45, 30);
    [finish addTarget:self action:@selector(finishDateSelect:) forControlEvents:UIControlEventTouchUpInside];
    [finish setTitle:@"完成" forState:UIControlStateNormal];
    [finish setTitleColor:[UIColor darkTextColor] forState:UIControlStateNormal];
    [_dataBackView addSubview:finish];
    
}

-(void)dateChangeAction:(id)sender{
    UIDatePicker* control = (UIDatePicker*)sender;
    NSDate* date = control.date;
    NSDateFormatter *format = [[NSDateFormatter alloc] init];
    [format setDateFormat:@"yyyy-MM-dd"];
    NSString *datestr = [format stringFromDate:date];
    //    MOSLog(@"%@",datestr);
    _dateString = datestr;
    
}

-(void)cancelDateSelect:(UIButton*)sender{
    [self takeBackDateView];
}

-(void)finishDateSelect:(UIButton*)sender{
    CaseClipCommonCell *cell = [_myTable cellForRowAtIndexPath:self.currentIndexPath];
    cell.content.text = _dateString;
    [self takeBackDateView];
    [self resetDatasourceWith:_currentIndexPath andChangeValue:_dateString];
    
}

-(void)takeBackDateView{
    CGRect frame = CGRectMake(0, SCREEN_HEIGHT, SCREEN_WIDTH, 246);
    
    [UIView animateWithDuration:0.5 animations:^{
        self.dataBackView.frame = frame;
    }];
}
-(void)showDateView{
    CGRect frame = CGRectMake(0, SCREEN_HEIGHT-246, SCREEN_WIDTH, 246);
    [UIView animateWithDuration:0.5 animations:^{
        self.dataBackView.frame = frame;
    }];
}

#pragma mark - input view
-(void)setInputView{
    
    self.inputView = [[[NSBundle mainBundle] loadNibNamed:@"LYJInputView" owner:nil options:nil] firstObject];
    self.inputView.lyj_delegate = self;
    [self.view addSubview: self.inputView];
    
    self.inputView.hidden = YES;
    self.inputView.inputTitle.text = @"";
    [self.inputView.sendBtn setTitle:@"完成" forState:UIControlStateNormal];
    
}



#pragma mark - input delegate
-(void)sendBtnAction:(UIButton *)sender andText:(NSString *)text{
    if (text.length) {
        CaseClipCommonCell *cell = [_myTable cellForRowAtIndexPath:self.currentIndexPath];
        [self resetDatasourceWith:_currentIndexPath andChangeValue:text];
        cell.content.text = text;
    }
    
}

#pragma mark - sheet
-(void)actionSheet:(UIActionSheet *)actionSheet clickedButtonAtIndex:(NSInteger)buttonIndex{
//    __weak typeof (self) weakSelf = self;
    
    if (actionSheet.tag==400) {
        NSString *str = [actionSheet buttonTitleAtIndex:buttonIndex];
        CaseClipCommonCell *cell = (CaseClipCommonCell*)[self.myTable cellForRowAtIndexPath:_currentIndexPath ];
        
        if ([str isEqualToString:@"男"]) {
            cell.content.text = @"男";
            [self resetDatasourceWith:_currentIndexPath andChangeValue:cell.content.text];
        }else if([str isEqualToString:@"女"]){
            cell.content.text = @"女";
            [self resetDatasourceWith:_currentIndexPath andChangeValue:cell.content.text];
        }
        
    }
}

#pragma mark - camera
#pragma mark - 头像模块
- (void)cellAvatarPress
{
    MOSLog(@"Cell avatar press.");
    __weak typeof (self) weakSelf = self;
    UIAlertControllerActionBlock takephoto = ^(UIAlertAction *action){
        MOSLog(@"拍照");
        if ([LYJSystemCallsJudgeManager isCanUseCamera_CCWith:^{
            [self showHint:@"请去系统设置允许应用访问相机" yOffset:-300];
        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
            weakSelf.imagePickerController.editing = YES;
            weakSelf.imagePickerController.allowsEditing = YES;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                     //
                                 }];
        }
    };
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"取消");
    };
    UIAlertControllerActionBlock pics = ^(UIAlertAction *action){
        MOSLog(@"从手机相册选择");
        if ([LYJSystemCallsJudgeManager iscanPictureAblumWith:^{
            [self showHint:@"请去系统设置允许应用访问相册" yOffset:-300];
            
        }]) {
            weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
            [weakSelf presentViewController:weakSelf.imagePickerController
                                   animated:YES
                                 completion:^{
                                     
                                     [self prefersStatusBarHidden ];
                                     [self preferredStatusBarStyle];
                                 }];
            
        }
    };
    [UIViewController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"拍照":takephoto,@"从手机相册选择":pics} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet andalertTag:300];
    
    
}

#pragma mark - Property method

- (UIImagePickerController *)imagePickerController
{
    if (_imagePickerController == nil) {
        _imagePickerController = [[UIImagePickerController alloc] init];
        _imagePickerController.navigationBar.barTintColor = RGB(41, 187, 98, 1);//G_COLOR_NAVGATION_BACK;
        
        _imagePickerController.navigationBar.tintColor = [UIColor whiteColor];
        _imagePickerController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:G_COLOR_NAVGATION_TITLE,
                                                                     NSFontAttributeName:G_FONT_NAVGATION_TITLE};
        
        [self prefersStatusBarHidden ];
        [self preferredStatusBarStyle];
        
        _imagePickerController.delegate = self;
    }
    return _imagePickerController;
}

-(BOOL)prefersStatusBarHidden{
    return NO;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *picImage;
    //    = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
        picImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    } else {
        picImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    }
    
    __weak typeof(self) weakSelf = self;
    
    [self.imagePickerController dismissViewControllerAnimated:YES completion:^{
        MOSLog(@"dismiss self");
        NSData *data = UIImageJPEGRepresentation(picImage , 0.1);
        
    }];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self preferredStatusBarStyle];
    [picker dismissViewControllerAnimated:YES completion:^{
        [self preferredStatusBarStyle];
    }];
    
}
@end
