//
//  FamilyCaseClipDetailVC.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"
@class FamilyCasesClipResponse;
@interface FamilyCaseClipDetailVC : BasicVC

@property (nonatomic,copy) NSString *caseId;
@property (nonatomic,strong) FamilyCasesClipResponse *headerInfor;

@property (nonnull,copy) void (^ClearCaseFinish)(BOOL isFinish);
@end
