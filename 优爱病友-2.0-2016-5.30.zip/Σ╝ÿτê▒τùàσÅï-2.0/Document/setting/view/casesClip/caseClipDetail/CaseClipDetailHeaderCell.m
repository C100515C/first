//
//  CaseClipDetailHeaderCell.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipDetailHeaderCell.h"
#import "FamilyCasesClipResponse.h"

@interface CaseClipDetailHeaderCell ()

@property (weak, nonatomic) IBOutlet BasicLabel *callName;

@property (weak, nonatomic) IBOutlet BasicLabel *gender;
@property (weak, nonatomic) IBOutlet BasicLabel *time;
@property (weak, nonatomic) IBOutlet BasicUIImageView *userIcon;

- (IBAction)addClicked:(UIButton *)sender;

@end

@implementation CaseClipDetailHeaderCell
-(void)awakeFromNib{
//    [super awakeFromNib];
    [self.userIcon setRaduis];
    self.callName.type = LabelFont_17;
    self.gender.type =LabelFont_15;
    self.time.type = LabelFont_12;
}

-(void)setCellWith:(FamilyCasesClipResponse *)model{

    [self.userIcon sd_setImageWithURL:[NSURL URLWithString:model.icon] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.callName.text = model.name;
    
    self.gender.text = model.gender;
    
    self.time.text = model.count;
}

- (IBAction)addClicked:(UIButton *)sender {
    
    if (_addCaseClipRecordBlock) {
        _addCaseClipRecordBlock();
    }
}

@end
