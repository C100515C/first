//
//  CaseClipCommonPicCell.m
//  IMTest
//
//  Created by chenchen on 16/5/19.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipCommonPicCell.h"
#import "LYJPicturesBrowse.h"
#import "CaseClipCommonResponse.h"

#import "CC_CanDeleteImageView.h"

@interface CaseClipCommonPicCell ()<LYJPictureBrowser>
@property (weak, nonatomic) IBOutlet LYJPicturesBrowse *picShow;

@property (weak, nonatomic) IBOutlet BasicLabel *alertLabel;
@property (weak, nonatomic) IBOutlet UIButton *addPicBtnAction;
- (IBAction)addPicClicked:(UIButton *)sender;

@end

@implementation CaseClipCommonPicCell

-(void)awakeFromNib{
    [super awakeFromNib];
    self.alertLabel.type = LabelFont_15;
    self.picShow.lyj_delegate = self;
}

-(void)setCellWith:(CaseClipCommonResponse*)model{
    self.picShow.isHidenDelete = self.ishideDel;

    self.picShow.pics = [model.pics mutableCopy];
    BOOL isHide = NO;
    if (model.pics.count==0) {
        isHide = YES;
    }
    self.picShow.hidden = isHide;
}

- (IBAction)addPicClicked:(UIButton *)sender {
    
    if (_AddPicBtnClickedBlock) {
        _AddPicBtnClickedBlock(sender);
    }
}
#pragma mark -delete
-(void)deleteImage:(CC_CanDeleteImageView *)image{
    if (_DelPicBtnClickedBlock) {
        _DelPicBtnClickedBlock(image);
    }
}
@end
