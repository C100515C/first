//
//  CaseClipCommonPicCell.h
//  IMTest
//
//  Created by chenchen on 16/5/19.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString *const CaseClipCommonPic_id = @"CaseClipCommonPic";
@class CC_CanDeleteImageView;
@class CaseClipCommonResponse;
@interface CaseClipCommonPicCell : BasicTableViewCell
@property (nonatomic,copy) void (^AddPicBtnClickedBlock)(UIButton *btn);
@property (nonatomic,copy) void (^DelPicBtnClickedBlock)(CC_CanDeleteImageView *image);
@property (nonatomic,assign) BOOL ishideDel;
-(void)setCellWith:(CaseClipCommonResponse*)model;

@end
