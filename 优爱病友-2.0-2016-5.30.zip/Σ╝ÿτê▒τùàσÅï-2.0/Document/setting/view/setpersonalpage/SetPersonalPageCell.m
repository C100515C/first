//
//  SetPersonalPageCell.m
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SetPersonalPageCell.h"
#import "SetPersonalPageResponse.h"

@interface SetPersonalPageCell ()
@property (weak, nonatomic) IBOutlet BasicLabel *name;

@end

@implementation SetPersonalPageCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self.icon setRaduis];
    
    self.name.type = LabelFont_17;
    self.content.type = LabelFont_15;
    self.des.type = LabelFont_15;
}

-(void)setCellWith:(SetPersonalPageResponse *)model{

    self.name.text = model.name;
    self.content.text = model.content;
    self.des.text = model.content;
    [self.icon sd_setImageWithURL:[NSURL URLWithString:model.content] placeholderImage:[UIImage imageNamed:@"account"]];
    
    
    if (model.style == SetPersonalPageResponseShowImage) {
        self.content.hidden = YES;
        self.des.hidden = YES;
        self.icon.hidden = NO;
        
    }else if (model.style == SetPersonalPageResponseShowDes){
        self.content.hidden = YES;
        self.des.hidden = NO;
        self.icon.hidden = YES;
        
    }
    else{
        self.content.hidden = NO;
        self.des.hidden = YES;
        self.icon.hidden = YES;
        
    }
}

@end
