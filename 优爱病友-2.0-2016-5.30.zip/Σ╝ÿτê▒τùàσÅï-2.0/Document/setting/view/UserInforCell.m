//
//  UserInforCell.m
//  IMTest
//
//  Created by chenchen on 16/3/3.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "UserInforCell.h"
//#import "UserProfileManager.h"

@implementation UserInforCell

-(void)awakeFromNib{
    [super awakeFromNib];
    [_header setRaduis];
}

-(void)setCellWithModel:(UserProfileEntity *)model{

}

@end
