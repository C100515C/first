//
//  MyFocusRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/30.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MyFocusRequest.h"

@implementation MyFocusRequest

- (id)init
{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"attentions?access-token=%@&",token];
        
        self.reqMethod = @"GET";
//        self.reqMethod = @"POST";
        self.reqClassName = @"CircleDetailItemList";
    }
    return self;
}
//[[UserProfileManager sharedInstance] getUserId]

-(void)setType:(NSString *)type{
    if ([type isEqualToString:@"thread"]) {
        self.reqClassName = @"CircleDetailItemList";
    }else{
        self.reqClassName = @"Discover";
    }
    
    if (_type) {
        _type = nil;
    }
    _type = type;
}

@end
