//
//  FamilyCasesClipResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"
#import "BaseRequest.h"

@interface  FamilyCasesClipRequest: BaseRequest
@property (nonatomic,copy) NSString *page;
@property (nonatomic,copy) NSString *dossier_id;
-(id)init;
@end

@interface FamilyCaseListRequest : BaseRequest
-(id)init;

@end

@interface FamilyCaseListItemResponse : BasicResponse
@property (nonatomic,strong) NSMutableArray *itemList;

+(Class)itemList_class;

@end

@interface FamilyCasesClipResponse : BasicResponse

@property (nonatomic,copy) NSString *gender;
@property (nonatomic,copy) NSString *icon;
@property (nonatomic,strong) NSMutableArray *pics;
@property (nonatomic,copy) NSString *birthday;
@property (nonatomic,copy) NSString *count;
@property (nonatomic,copy) NSString *create_time;
@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *user_id;

@property (nonatomic,assign) BOOL needHighHeight;

@end
