//
//  CaseClipDetailResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"
#import "BaseRequest.h"

@interface  CaseClipDetailRequest: BaseRequest
@property (nonatomic,copy) NSString *page;
@property (nonatomic,copy) NSString *dossier_id;
-(id)init;
@end

@interface CaseClipDetailItmesResponse : BasicResponse
@property (nonatomic,copy) NSMutableArray *itemList;

+(Class)itemList_class;
@end

@interface CaseClipDetailResponse : BasicResponse

@property (nonatomic,copy) NSString *dossier_id;
@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *user_id;

@property (nonatomic,copy) NSString *visit_time;
@property (nonatomic,copy) NSString *hospital;
@property (nonatomic,copy) NSString *illness_category;//圈子类型
@property (nonatomic,copy) NSString *picture;

@property (nonatomic,copy) NSArray *photos;
@property (nonatomic,copy) NSString *showAddress;//合成的地址圈子
//@property (nonatomic,strong) NSIndexPath *caseIndexpath;

+(Class)photos_class;
-(NSArray*)getNeedPhotos;
@end
