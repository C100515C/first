
//
//  FamilyCasesClipResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "FamilyCasesClipResponse.h"

@implementation FamilyCasesClipRequest

- (id)init
{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"dossier-details?user_id=%@&access-token=%@&",[[UserProfileManager sharedInstance] getUserId],token];
        
        self.reqMethod = @"GET";
        //        self.reqMethod = @"POST";
        self.reqClassName = @"FamilyCasesClip";
    }
    return self;
}

@end

@implementation FamilyCaseListRequest

-(id)init{
    
    self = [super init];
    
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token = [token  urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"dossiers?user_id=%@&access-token=%@",[[UserProfileManager sharedInstance] getUserId],token];
        self.reqMethod = @"GET";
        self.reqClassName = @"FamilyCaseListItem";

    }
    return self;
}
@end

@implementation FamilyCaseListItemResponse

-(NSMutableArray *)itemList{
 
    if (_itemList==nil) {
        _itemList = [NSMutableArray array];
        
    }
    return _itemList;
}
+(Class)itemList_class{
    return [FamilyCasesClipResponse class];
}

@end

static const CGFloat BasicHeight = 148.0f;
static const CGFloat AnotherHeight = 110.0;

@implementation FamilyCasesClipResponse

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }
   
    if (self.needHighHeight) {
        _cellHeight = AnotherHeight;
    }else{
        _cellHeight = BasicHeight;

    }
    
    return _cellHeight;
}

-(void)setNeedHighHeight:(BOOL)needHighHeight{
    if (_needHighHeight !=needHighHeight) {
        _cellHeight = 0;
    }
    _needHighHeight = needHighHeight;
}

-(NSMutableArray*)pics{
    if (_pics==nil) {
        _pics = [NSMutableArray array];
    }
    return _pics;
}

-(NSString *)count
{
    if (_count) {
        return [NSString stringWithFormat:@"%@次",_count];
    }
    return _count;
}

-(NSString*)gender{
    if ([_gender isEqualToString:@"M"]) {
        return @"男";
    }else if ([_gender isEqualToString:@"W"]){
        return @"女";

    }else{
        return _gender;
    }
}

@end
