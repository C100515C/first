//
//  RootVC.h
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicBarController.h"

typedef enum : NSUInteger {
    TabIndexHome,
    TabIndexDiscover,
    TabIndexInformation,
    TabIndexSetting
} TabIndexType;

@interface RootVC : BasicBarController

// 在其他设备登录
- (void)loginElseWhere;

//减少未读消息
-(void)reduceNoReadNumWith:(NSInteger)IsReadedNum and:(TabIndexType)tabindex;

-(void)prensentLoginVC;
-(void)refreshVCWith:(NSInteger)index andNeedHint:(BOOL)isNeed;
-(void)getNotRead;

@end
