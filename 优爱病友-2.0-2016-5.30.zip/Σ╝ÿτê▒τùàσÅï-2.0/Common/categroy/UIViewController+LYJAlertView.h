//
//  UIAlertController+LYJAlertView.h
//  IMTest
//
//  Created by chenchen on 16/2/25.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef void (^UIAlertControllerActionBlock)(UIAlertAction *action);

@interface UIViewController (LYJAlertView)

+(void)showAlertTltileWith:(NSString*)title andMessage:(NSString*)message andActions:(NSDictionary*)actions andShowVC:(id)showVC andAlertStyle:(UIAlertControllerStyle)style andalertTag:(NSInteger)tag;

@end
