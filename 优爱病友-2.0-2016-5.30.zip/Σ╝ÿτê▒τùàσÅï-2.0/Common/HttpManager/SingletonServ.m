 
//  SingletonServ.m
//  ufenqiDemo
//
//  Created by uchange on 14/12/4.
//  Copyright (c) 2014年 youthcode. All rights reserved.
//
#import "SingletonServ.h"
#import "AFNetworking.h"

#import "AppDelegate.h"
#import "RootVC.h"

static SingletonServ * shareIns = nil;
@interface SingletonServ()

@end

@implementation SingletonServ

#pragma mark - 单例初始化

+ (SingletonServ *)sharedInstance
{
    static dispatch_once_t predicate;
    dispatch_once(&predicate, ^{
        shareIns = [[self alloc] init];
        NSURL *homeUrl = [NSURL URLWithString:UIHURL_TEST_SERVER];
        shareIns.netWorkManager = [[AFHTTPRequestOperationManager manager] initWithBaseURL:homeUrl];
        
        shareIns.netWorkManager.requestSerializer.timeoutInterval = 20;
        [self networkOBserverMonitor];
    });
    return shareIns;
}

#pragma mark - 网络请求

- (AFHTTPRequestOperation *)processDataWithReqModel:(BaseRequest *)requestModel
                  completeBlock:(ProcessCompleteBlockType)completeBlock {
    
//    self.netWorkManager.requestSerializer = [AFHTTPRequestSerializer serializer];
//    self.netWorkManager.responseSerializer = [AFHTTPResponseSerializer serializer];// 响应
    [self.netWorkManager.requestSerializer setValue:@"ios" forHTTPHeaderField:@"os_type"];
    
//    // app build版本
    NSString *app_build = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    [self.netWorkManager.requestSerializer setValue:app_build forHTTPHeaderField:@"version"];
    
    if ([requestModel.reqMethod isEqualToString:@"GET"]) {
        return [self reqGetWithModel:requestModel completeBlock:completeBlock];
    } else if ([requestModel.reqMethod isEqualToString:@"POST"]) {
        return [self reqPostWithModel:requestModel completeBlock:completeBlock];
    } else if ([requestModel.reqMethod isEqualToString:@"PUT"]) {
        MOSLog(@"Process PUT method");
        return [self reqPUTWithModel:requestModel completeBlock:completeBlock];
    } else if ([requestModel.reqMethod isEqualToString:@"DELETE"]) {
        MOSLog(@"Process DELETE method");
        return [self reqDELETEWithModel:requestModel completeBlock:completeBlock];;
    } else {
        MOSLog(@"Wrong network method");
        return nil;
    }

}

- (AFHTTPRequestOperation *)processDataUploadPicWithReqModel:(BaseRequest *)requestModel
                                      completeBlock:(ProcessCompleteBlockType)completeBlock
                                    constructingBodyWithBlock:(void (^)(id <AFMultipartFormData> formData))block{
    //    self.netWorkManager.requestSerializer = [AFHTTPRequestSerializer serializer];
    //    self.netWorkManager.responseSerializer = [AFHTTPResponseSerializer serializer];// 响应
    [self.netWorkManager.requestSerializer setValue:@"ios" forHTTPHeaderField:@"os_type"];
    
    //    // app build版本
    NSString *app_build = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    [self.netWorkManager.requestSerializer setValue:app_build forHTTPHeaderField:@"version"];
    
    if ([requestModel.reqMethod isEqualToString:@"GET"]) {
        MOSLog(@"Process PUT method");
        return nil;
    } else if ([requestModel.reqMethod isEqualToString:@"POST"]) {
        return [self reqPostWithModel:requestModel completeBlock:completeBlock constructingBodyWithBlock:block];
    } else if ([requestModel.reqMethod isEqualToString:@"PUT"]) {
        MOSLog(@"Process PUT method");
        return nil;
    } else if ([requestModel.reqMethod isEqualToString:@"DELETE"]) {
        MOSLog(@"Process DELETE method");
        return nil;
    } else {
        MOSLog(@"Wrong network method");
        return nil;
    }
}
#pragma mark - DELETE
-(AFHTTPRequestOperation *)reqDELETEWithModel:(BaseRequest *)requestModel completeBlock:(ProcessCompleteBlockType)completeBlock{
    NSMutableDictionary *parameReqDic = [[requestModel toDictionary] mutableCopy];
    [parameReqDic removeObjectsForKeys:@[@"reqClassName", @"reqMethod", @"reqUrlPath"]];
//    NSString *reqUrlStr = [@"v1/" stringByAppendingString:requestModel.reqUrlPath];

    NSString *reqUrlStr = requestModel.reqUrlPath;
    __weak typeof(self) weakself = self;
    
    return [self.netWorkManager DELETE:reqUrlStr parameters:parameReqDic success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSDictionary *opDic = responseObject;
        
        NSString *statusstr = [opDic objectForKey:@"msg"];
        NSNumber *resCodeNum = [opDic objectForKey:@"code"];
        if ([resCodeNum intValue] == 200) {
            MOSLog(@"网络访问成功");
            
            NSDictionary *dataDic;
            
            id dataRes = [opDic objectForKey:@"data"];
            
            if ([dataRes isKindOfClass:[NSArray class]]) {
                dataDic = [[NSDictionary alloc] initWithObjectsAndKeys:dataRes, @"itemList", nil];
            } else if([dataRes isKindOfClass:[NSDictionary class]]) {
                dataDic = dataRes;
            }
            
            NSString *className = requestModel.reqClassName;
            NSString *holeClassName = [[NSString alloc] initWithFormat:@"%@Response", className];
            
            id obj = [[NSClassFromString(holeClassName) alloc] init];
            
            Jastor * jFromObj =(Jastor*)obj;
            
            Jastor *resmodel = [jFromObj initWithDictionary:dataDic];
            
            
            completeBlock(resmodel, nil);
            
        }else {
            MOSLog(@"网络访问失败");
            if ([[NSNull null] isEqual:statusstr]) {
                statusstr = @"网络访问失败";
            }
            
            ErrorResponse *errorRes = [[ErrorResponse alloc] init];
            if ( [statusstr isKindOfClass:[NSDictionary class]]) {
                NSDictionary *state = (NSDictionary *)statusstr;
                errorRes.msg = @"网络访问失败";
                errorRes.msgDic = state;
                
            }else if([statusstr isKindOfClass:[NSString class]]){
                NSString *state = (NSString *)statusstr;
                errorRes.msg = state;
            }
            errorRes.code = resCodeNum;
            
            if ([errorRes.code intValue]==401) {
                errorRes.msg = @"登录过期，请重新登录";
                errorRes.code = @(401);
                [weakself resetLogin];
                
            }
            
            completeBlock(nil, errorRes);
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        ErrorResponse *errorRes = [[ErrorResponse alloc] init];
        
        if ([weakself isLogInFailureWith:error]) {
            errorRes.msg = @"登录过期，请重新登录";
            errorRes.code = @(401);
            [weakself resetLogin];
            
        }else{
            errorRes.msg = @"网络连接失败";
        }
        completeBlock(nil, errorRes);
        
    }];
}
#pragma mark PUT请求
- (AFHTTPRequestOperation *)reqPUTWithModel:(BaseRequest *)requestModel
                              completeBlock:(ProcessCompleteBlockType)completeBlock {
    
    NSMutableDictionary *parameReqDic = [[requestModel toDictionary] mutableCopy];
    [parameReqDic removeObjectsForKeys:@[@"reqClassName", @"reqMethod", @"reqUrlPath"]];
//    NSString *reqUrlStr = [@"v1/" stringByAppendingString:requestModel.reqUrlPath];

    NSString *reqUrlStr = requestModel.reqUrlPath;
    __weak typeof(self) weakself = self;

    return [self.netWorkManager PUT:reqUrlStr parameters:parameReqDic success:^(AFHTTPRequestOperation *operation, id responseObject) {
        
        NSDictionary *opDic = responseObject;
        
        NSString *statusstr = [opDic objectForKey:@"msg"];
        NSNumber *resCodeNum = [opDic objectForKey:@"code"];
        if ([resCodeNum intValue] == 200) {
            MOSLog(@"网络访问成功");
            
            NSDictionary *dataDic;
            
            id dataRes = [opDic objectForKey:@"data"];
            
            if ([dataRes isKindOfClass:[NSArray class]]) {
                dataDic = [[NSDictionary alloc] initWithObjectsAndKeys:dataRes, @"itemList", nil];
            } else if([dataRes isKindOfClass:[NSDictionary class]]) {
                dataDic = dataRes;
            }
            
            NSString *className = requestModel.reqClassName;
            NSString *holeClassName = [[NSString alloc] initWithFormat:@"%@Response", className];
            
            id obj = [[NSClassFromString(holeClassName) alloc] init];
            
            Jastor * jFromObj =(Jastor*)obj;
            
            Jastor *resmodel = [jFromObj initWithDictionary:dataDic];
            
            
            completeBlock(resmodel, nil);
            
        }else {
            MOSLog(@"网络访问失败");
            if ([[NSNull null] isEqual:statusstr]) {
                statusstr = @"网络访问失败";
            }
            
            ErrorResponse *errorRes = [[ErrorResponse alloc] init];
            if ( [statusstr isKindOfClass:[NSDictionary class]]) {
                NSDictionary *state = (NSDictionary *)statusstr;
                errorRes.msg = @"网络访问失败";
                errorRes.msgDic = state;
                
            }else if([statusstr isKindOfClass:[NSString class]]){
                NSString *state = (NSString *)statusstr;
                errorRes.msg = state;
            }
            errorRes.code = resCodeNum;
            
            if ([errorRes.code intValue]==401) {
                errorRes.msg = @"登录过期，请重新登录";
                errorRes.code = @(401);
                [weakself resetLogin];
                
            }
            
            completeBlock(nil, errorRes);
        }
        
        
    } failure:^(AFHTTPRequestOperation *operation, NSError *error) {
        
        ErrorResponse *errorRes = [[ErrorResponse alloc] init];
        
        if ([weakself isLogInFailureWith:error]) {
            errorRes.msg = @"登录过期，请重新登录";
            errorRes.code = @(401);
            [weakself resetLogin];
            
        }else{
            errorRes.msg = @"网络连接失败";
        }
        completeBlock(nil, errorRes);
        
    }];
}

#pragma mark 网络请求GET方法

- (AFHTTPRequestOperation *)reqGetWithModel:(BaseRequest *)requestModel
          completeBlock:(ProcessCompleteBlockType)completeBlock {
    
    NSMutableDictionary *parameReqDic = [[requestModel toDictionary] mutableCopy];
    
    [parameReqDic removeObjectsForKeys:@[@"reqClassName", @"reqMethod", @"reqUrlPath"]];
    
//    NSString *reqUrlStr = [@"v1/" stringByAppendingString:requestModel.reqUrlPath];
    NSString *reqUrlStr = requestModel.reqUrlPath;
    for (NSString *parKey in parameReqDic) {
        NSString *parValue = [parameReqDic objectForKey:parKey];
        reqUrlStr = [reqUrlStr stringByAppendingString:
                     [[NSString alloc] initWithFormat:@"%@=%@&", parKey, parValue]];
    }
//    reqUrlStr = [reqUrlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

    __weak typeof(self) weakself = self;

    return [self.netWorkManager GET:reqUrlStr
                  parameters:nil
                     success:^(AFHTTPRequestOperation *operation, id responseObject) {
                         
                         NSDictionary *opDic = responseObject;
                         
                         NSString *statusstr = [opDic objectForKey:@"msg"];
                         NSNumber *resCodeNum = [opDic objectForKey:@"code"];
                         if ([resCodeNum intValue] == 200) {
                             MOSLog(@"网络访问成功");
                             
                             NSDictionary *dataDic;
                             
                             id dataRes = [opDic objectForKey:@"data"];
                             
                             if ([dataRes isKindOfClass:[NSArray class]]) {
                                 dataDic = [[NSDictionary alloc] initWithObjectsAndKeys:dataRes, @"itemList", nil];
                             } else if([dataRes isKindOfClass:[NSDictionary class]]) {
                                 dataDic = dataRes;
                             }
                             
                             NSString *className = requestModel.reqClassName;
                             NSString *holeClassName = [[NSString alloc] initWithFormat:@"%@Response", className];
                             
                             id obj = [[NSClassFromString(holeClassName) alloc] init];
                             
                             Jastor * jFromObj =(Jastor*)obj;
                             
                             Jastor *resmodel = [jFromObj initWithDictionary:dataDic];
                             
                             
                             completeBlock(resmodel, nil);
                             
                         }else {
                             MOSLog(@"网络访问失败");
                             if ([[NSNull null] isEqual:statusstr]) {
                                 statusstr = @"网络访问失败";
                             }
                             
                             ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                             if ( [statusstr isKindOfClass:[NSDictionary class]]) {
                                 NSDictionary *state = (NSDictionary *)statusstr;
                                 errorRes.msg = @"网络访问失败";
                                 errorRes.msgDic = state;
                                 
                             }else if([statusstr isKindOfClass:[NSString class]]){
                                 NSString *state = (NSString *)statusstr;
                                 errorRes.msg = state;
                             }
                             errorRes.code = resCodeNum;
                             
                             
                             if ([errorRes.code intValue]==401) {
                                 errorRes.msg = @"登录过期，请重新登录";
                                 errorRes.code = @(401);
                                 [weakself resetLogin];
                                 
                             }
                             
                             completeBlock(nil, errorRes);
                         }
                     }
                     failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                         ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                         
                         if ([weakself isLogInFailureWith:error]) {
                             errorRes.msg = @"登录过期，请重新登录";
                             errorRes.code = @(401);
                             [weakself resetLogin];

                         }else{
                             errorRes.msg = @"网络连接失败";
                         }
                         completeBlock(nil, errorRes);
                     }];
}

#pragma mark 网络请求POST方法
- (AFHTTPRequestOperation *)reqPostWithModel:(BaseRequest *)requestModel
           completeBlock:(ProcessCompleteBlockType)completeBlock {
    
    NSMutableDictionary *parameDic = [requestModel toDictionary];
    
    [parameDic removeObjectsForKeys:@[@"reqClassName", @"reqMethod", @"reqUrlPath"]];
//    NSString *reqUrlStr;
    
//    reqUrlStr = [@"v1/" stringByAppendingString:requestModel.reqUrlPath];
    
    NSString *reqUrlStr = requestModel.reqUrlPath;
//    reqUrlStr = [reqUrlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];

    __weak typeof(self) weakself = self;
    // 返回请求operation
    return [self.netWorkManager POST:reqUrlStr
                   parameters:parameDic
                      success:^(AFHTTPRequestOperation *operation, id responseObject) {
                          NSDictionary *opDic = responseObject;
                          
                          NSString *statusStr = [opDic objectForKey:@"msg"];
                          NSNumber *resCodeNum = [opDic objectForKey:@"code"];
                          
                          if ([resCodeNum intValue] == 200) {
                              MOSLog(@"网络访问成功");
                              
                              NSDictionary *dataDic;
                              
                              id dataRes = [opDic objectForKey:@"data"];
                              
                              if ([dataRes isKindOfClass:[NSArray class]]) {
                                  dataDic = [[NSDictionary alloc] initWithObjectsAndKeys:dataRes, @"itemList", nil];
                              } else if([dataRes isKindOfClass:[NSDictionary class]]) {
                                  dataDic = dataRes;
                              }
                              
                              NSString *className = requestModel.reqClassName;
                              NSString *holeClassName = [[NSString alloc] initWithFormat:@"%@Response", className];
                              
                              id obj = [[NSClassFromString(holeClassName) alloc] init];
                              
                              Jastor * jFromObj =(Jastor*)obj;
                              
                              Jastor *resmodel = [jFromObj initWithDictionary:dataDic];
                              
                              
                              completeBlock(resmodel, nil);
                              
                          } else {
                              MOSLog(@"网络访问失败");
                              
                              if ([[NSNull null] isEqual:statusStr]) {
                                  statusStr = @"网络访问失败";
                              }
                              
                              ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                              
                              if ( [statusStr isKindOfClass:[NSDictionary class]]) {
                                  NSDictionary *state = (NSDictionary *)statusStr;
                                  errorRes.msg = @"网络访问失败";
                                  errorRes.msgDic = state;
                                  
                              }else if([statusStr isKindOfClass:[NSString class]]){
                                  NSString *state = (NSString *)statusStr;
                                  errorRes.msg = state;
                              }
                              errorRes.code = resCodeNum;
                              
                              if ([errorRes.code intValue]==401) {
                                  errorRes.msg = @"登录过期，请重新登录";
                                  errorRes.code = @(401);
                                  [weakself resetLogin];
                                  
                              }
                              
                              completeBlock(nil, errorRes);
                          }
                      }
                      failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                          ErrorResponse *errorRes = [[ErrorResponse alloc] init];
//                          MOSLog(@"%@",error.description);
                          if ([weakself isLogInFailureWith:error]) {
                              errorRes.msg = @"登录过期，请重新登录";
                              errorRes.code = @(401);
                              [weakself resetLogin];

                          }else{
                              errorRes.msg = @"网络连接失败";
                          }
                          
                          completeBlock(nil, errorRes);
                      }];
}

#pragma mark - post 上传图片
- (AFHTTPRequestOperation *)reqPostWithModel:(BaseRequest *)requestModel
                               completeBlock:(ProcessCompleteBlockType)completeBlock constructingBodyWithBlock:(void (^)(id <AFMultipartFormData> formData))block{
    
    NSMutableDictionary *parameDic = [requestModel toDictionary];
    
    [parameDic removeObjectsForKeys:@[@"reqClassName", @"reqMethod", @"reqUrlPath"]];
    
//    NSString *reqUrlStr = [@"v1/" stringByAppendingString:requestModel.reqUrlPath];
    NSString *reqUrlStr = requestModel.reqUrlPath;
    
//    reqUrlStr = [reqUrlStr stringByAddingPercentEscapesUsingEncoding:NSUTF8StringEncoding];
    __weak typeof(self) weakself = self;

    // 返回请求operation
    return [self.netWorkManager POST:reqUrlStr
                                parameters:parameDic
                                constructingBodyWithBlock:block
                        success:^(AFHTTPRequestOperation *operation, id responseObject) {
                          
                          NSDictionary *opDic = responseObject;
                          
                          id statusstr = [opDic objectForKey:@"msg"];
                          NSNumber *resCodeNum = [opDic objectForKey:@"code"];
                            
                          if ([resCodeNum intValue] == 200) {
                              MOSLog(@"网络访问成功");
                              
                              NSDictionary *dataDic;
                              
                              id dataRes = [opDic objectForKey:@"data"];
                              
                              if ([dataRes isKindOfClass:[NSArray class]]) {
                                  dataDic = [[NSDictionary alloc] initWithObjectsAndKeys:dataRes, @"itemList", nil];
                              } else if([dataRes isKindOfClass:[NSDictionary class]]) {
                                  dataDic = dataRes;
                              }
                              
                              NSString *className = requestModel.reqClassName;
                              NSString *holeClassName = [[NSString alloc] initWithFormat:@"%@Response", className];
                              
                              id obj = [[NSClassFromString(holeClassName) alloc] init];
                              
                              Jastor * jFromObj =(Jastor*)obj;
                              
                              Jastor *resmodel = [jFromObj initWithDictionary:dataDic];
                              
                              completeBlock(resmodel, nil);
                              
                          }else {
                              MOSLog(@"网络访问失败");
                              if ([[NSNull null] isEqual:statusstr]) {
                                  statusstr = @"网络访问失败";
                              }
                              
                              ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                              if ( [statusstr isKindOfClass:[NSDictionary class]]) {
                                  NSDictionary *state = (NSDictionary *)statusstr;
                                  errorRes.msg = @"网络访问失败";
                                  errorRes.msgDic = state;
                                  
                              }else if([statusstr isKindOfClass:[NSString class]]){
                                  NSString *state = (NSString *)statusstr;
                                  errorRes.msg = state;
                              }
                              errorRes.code = resCodeNum;
                              
                              if ([errorRes.code intValue]==401) {
                                  errorRes.msg = @"登录过期，请重新登录";
                                  errorRes.code = @(401);
                                  [weakself resetLogin];
                                  
                              }
                              
                              completeBlock(nil, errorRes);
                          }
                      }
                      failure:^(AFHTTPRequestOperation *operation, NSError *error) {
                          ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                        
                          if ([weakself isLogInFailureWith:error]) {
                              errorRes.msg = @"登录过期，请重新登录";
                              errorRes.code = @(401);
                              [weakself resetLogin];
                          }else{
                              errorRes.msg = @"网络连接失败";
                          }
                          completeBlock(nil, errorRes);
                          
                      }];
}

//登陆失效判断
-(BOOL)isLogInFailureWith:(NSError*)error{
    
    NSError *nSLocalizedError = [error.userInfo objectForKey:@"NSUnderlyingError"];
    MOSLog(@"网络错误原因＝%@",[nSLocalizedError.userInfo objectForKey:@"NSLocalizedDescription"]);
    NSString *errorReason = [nSLocalizedError.userInfo objectForKey:@"NSLocalizedDescription"];
    NSRange range = [errorReason rangeOfString:@"(401)"];
    if (range.location!= NSNotFound) {
        return YES;
    }
    return NO;
}

-(void)resetLogin{
    [[UserProfileManager sharedInstance] logoutDelInforWith:^(BOOL finish) {
        AppDelegate *app = [UIApplication sharedApplication].delegate;
        RootVC *root = (RootVC *) app.window.rootViewController;
        [root prensentLoginVC];
    }];
}

#pragma mark - put updata
/*
- (void)upLoadData:(NSData *)dataToUpload andReqModel:(BaseRequest*)req completeBlock:(ProcessCompleteBlockType)completeBlock
{
    
    
    NSMutableDictionary *parameDic = [req toDictionary];
    
    [parameDic removeObjectsForKeys:@[@"reqClassName", @"reqMethod", @"reqUrlPath"]];
    
    NSString *reqUrlStr = [@"v1/" stringByAppendingString:req.reqUrlPath];
    ErrorResponse *err = [[ErrorResponse alloc] init];
    
    NSMutableURLRequest * request = [NSMutableURLRequest requestWithURL:[NSURL URLWithString:[NSString stringWithFormat:@"%@%@", UIHURL_TEST_SERVER,reqUrlStr]]
                                                            cachePolicy:NSURLRequestReloadIgnoringLocalCacheData
                                                        timeoutInterval:10];
    if (dataToUpload == nil) {
        err.msg = @"失败";
        completeBlock(nil, err);
        return;
    }
    
    [request setValue:[NSString stringWithFormat:@"%d", (int)[dataToUpload length]]
   forHTTPHeaderField:@"Content-Length"];
    
    [request setHTTPBody:dataToUpload];
    [request setHTTPMethod:@"PUT"];
    
    NSOperationQueue *operationQue = [NSOperationQueue currentQueue];
    
    [NSURLConnection sendAsynchronousRequest:request
                                       queue:operationQue
                           completionHandler:^(NSURLResponse *response, NSData *data, NSError *connectionError) {
                               ErrorResponse *error = [[ErrorResponse alloc] init];

                               if (data == nil) {
                                   error.msg = @"失败";
                                   completeBlock(nil, err);
                                   return;
                               }
                               NSString *resStr = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
                               MOSLog(@"rec data %@", resStr);
                               
                               NSError *err;
                               NSDictionary *dic = [NSJSONSerialization JSONObjectWithData:data
                                                                                   options:NSJSONReadingMutableContainers
                                                                                     error:&err];
                               if (err) {
                                   MOSLog(@"fail");
                                   error.msg = @"失败";

                                   completeBlock(nil, error);
                               } else {
                                   MOSLog(@"success");
                                   
                                   NSDictionary *opDic = dic;
                                   
                                   id statusstr = [opDic objectForKey:@"msg"];
                                   NSNumber *resCodeNum = [opDic objectForKey:@"code"];
                                   
                                   if ([resCodeNum intValue] == 200) {
                                       MOSLog(@"网络访问成功");
                                       
                                       NSDictionary *dataDic;
                                       
                                       id dataRes = [opDic objectForKey:@"data"];
                                       
                                       if ([dataRes isKindOfClass:[NSArray class]]) {
                                           dataDic = [[NSDictionary alloc] initWithObjectsAndKeys:dataRes, @"itemList", nil];
                                       } else if([dataRes isKindOfClass:[NSDictionary class]]) {
                                           dataDic = dataRes;
                                       }
                                       
                                       NSString *className = req.reqClassName;
                                       NSString *holeClassName = [[NSString alloc] initWithFormat:@"%@Response", className];
                                       
                                       id obj = [[NSClassFromString(holeClassName) alloc] init];
                                       
                                       Jastor * jFromObj =(Jastor*)obj;
                                       
                                       Jastor *resmodel = [jFromObj initWithDictionary:dataDic];
                                       
                                       completeBlock(resmodel, nil);
                                       
                                   }else {
                                       MOSLog(@"网络访问失败");
                                       if ([[NSNull null] isEqual:statusstr]) {
                                           statusstr = @"网络访问失败";
                                       }
                                       
                                       ErrorResponse *errorRes = [[ErrorResponse alloc] init];
                                       if ( [statusstr isKindOfClass:[NSDictionary class]]) {
                                           NSDictionary *state = (NSDictionary *)statusstr;
                                           errorRes.msg = @"网络访问失败";
                                           errorRes.msgDic = state;
                                           
                                       }else if([statusstr isKindOfClass:[NSString class]]){
                                           NSString *state = (NSString *)statusstr;
                                           errorRes.msg = state;
                                       }
                                       errorRes.code = resCodeNum;
                                       
                                       if ([errorRes.code intValue]==401) {
                                           errorRes.msg = @"登录过期，请重新登录";
                                           errorRes.code = @(401);
                                           [self resetLogin];
                                           
                                       }
                                       
                                       completeBlock(nil, errorRes);
                                   }
                                   
                               }
                               
                           } ];
}
- (void)putFilereqWithModel:(BaseRequest *)requestModel
              completeBlock:(ProcessCompleteBlockType)completeBlock andPath:(NSURL*)purl
{
    NSMutableDictionary *parameReqDic = [[requestModel toDictionary] mutableCopy];
    
    [parameReqDic removeObjectsForKeys:@[@"reqClassName", @"reqMethod", @"reqUrlPath"]];
    
    //    NSString *reqUrlStr = [@"/v4" stringByAppendingString:[requestModel.reqUrlPath stringByAppendingString:@"?"]];
    NSString *reqUrlStr = [NSString stringWithFormat:@"%@%@",UIHURL_TEST_SERVER,requestModel.reqUrlPath ];
//    for (NSString *parKey in parameReqDic) {
//        NSString *parValue = [parameReqDic objectForKey:parKey];
//        reqUrlStr = [reqUrlStr stringByAppendingString:
//                     [[NSString alloc] initWithFormat:@"%@=%@&", parKey, parValue]];
//    }
//    reqUrlStr = @"http://uat.api.youaibingyou.com/index.php/v1/";
    // 1. url 最后一个是要上传的文件名
    NSURL *url = [NSURL URLWithString:reqUrlStr]; //abcd为文件名
    
    // 2. request
    NSMutableURLRequest *request = [NSMutableURLRequest requestWithURL:url];
    request.HTTPMethod = @"PUT";
//    request.HTTPMethod = @"DELETE";
    
    // 设置用户授权
    // BASE64编码：一种对字符串和二进制数据进行编码的一种“最常用的网络编码方式”，此编码可以将二进制数据转换成字符串！
    // 是很多加密算法的底层算法
    // BASE64支持反编码，是一种双向的编码方案
    NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
    token =  [token urlEncodeForSymbol];
//    NSString *authStr = @"admin:123";
    
    NSString *authBase64 = [NSString stringWithFormat:@"Basic %@", [self base64Encode:token]];
    [request setValue:authBase64 forHTTPHeaderField:@"Authorization"];
    
    // 3. URLSession
    NSURLSession *session = [NSURLSession sharedSession];
    
    // 4. 由session发起任务
    NSURL *localURL = [[NSBundle mainBundle] URLForResource:@"001.png" withExtension:nil];
    
    [[session uploadTaskWithRequest:request fromFile:purl completionHandler:^(NSData *data, NSURLResponse *response, NSError *error) {
        
        
        
        NSString *result = [[NSString alloc] initWithData:data encoding:NSUTF8StringEncoding];
        MOSLog(@"sesult---> %@ %@", result, [NSThread currentThread]);
    }] resume];
}
*/
- (NSString *)base64Encode:(NSString *)str
{
    // 1. 将字符串转换成二进制数据
    NSData *data = [str dataUsingEncoding:NSUTF8StringEncoding];
    
    // 2. 对二进制数据进行base64编码
    NSString *result = [data base64EncodedStringWithOptions:0];
    
    MOSLog(@"base464--> %@", result);
    
    return result;
}

#pragma mark - 监测网络状态

+(void)networkOBserverMonitor
{
    [[AFNetworkReachabilityManager sharedManager] startMonitoring];
    [[AFNetworkReachabilityManager sharedManager] setReachabilityStatusChangeBlock:^(AFNetworkReachabilityStatus status){
        
        if (status == AFNetworkReachabilityStatusNotReachable) {
            
        } else {
            
        }
    }];
}

@end

