//
//  BasicUIButton.h
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    ButtonFont_14 = 300,
    ButtonFont_15,
    ButtonFont_16,
    ButtonFont_13,
    ButtonFont_12
    
}ButtonContentFontType;
@interface BasicUIButton : UIButton

@property (nonatomic,assign) CGRect titleLabelFrame;
@property (nonatomic,assign) CGRect imageFrame;
@property (nonatomic,assign) UIEdgeInsets imageSet;
@property (nonatomic,assign) UIEdgeInsets titleLabelSet;

@property (nonatomic,assign) ButtonContentFontType type;

@end
