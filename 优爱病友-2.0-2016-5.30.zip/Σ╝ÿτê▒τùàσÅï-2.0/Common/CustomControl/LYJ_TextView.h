//
//  LYJ_TextView.h
//  IMTest
//
//  Created by chenchen on 16/5/27.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LYJ_textViewProtocol <NSObject>

-(void)newContentSize:(CGSize)newSize;

@end
@interface LYJ_TextView : UITextView

@property (nonatomic,assign) id<LYJ_textViewProtocol> lyj_delegate;
@end
