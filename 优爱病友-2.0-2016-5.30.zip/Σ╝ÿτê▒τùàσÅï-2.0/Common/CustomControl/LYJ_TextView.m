
//
//  LYJ_TextView.m
//  IMTest
//
//  Created by chenchen on 16/5/27.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJ_TextView.h"
static NSString *const contentHeight = @"contentheight";

@implementation LYJ_TextView

- (instancetype)init
{
    self = [super init];
    if (self) {
         [self addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:(__bridge void*)(contentHeight)];
         [self addObserver:self forKeyPath:@"text" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:(__bridge void*)(contentHeight)];
    }
    return self;
}

-(void)awakeFromNib{
    
    [self addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew context:(__bridge void*)(contentHeight)];
    [self addObserver:self forKeyPath:@"text" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:(__bridge void*)(contentHeight)];

}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    if ([keyPath isEqualToString: @"contentSize"]) {
        if (self.lyj_delegate && [self.lyj_delegate respondsToSelector:@selector(newContentSize:)]) {
            [self.lyj_delegate newContentSize:self.contentSize];
        }
    }
}

-(void)dealloc{
    [self removeObserver:self forKeyPath:@"contentSize" context:(__bridge void*)contentHeight];
    [self removeObserver:self forKeyPath:@"text" context:(__bridge void*)contentHeight];
}
@end
