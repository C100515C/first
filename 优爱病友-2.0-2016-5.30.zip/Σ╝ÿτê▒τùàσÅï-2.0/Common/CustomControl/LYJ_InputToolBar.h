//
//  LYJ_InputToolBar.h
//  IMTest
//
//  Created by chenchen on 16/5/26.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

static const CGFloat LYJ_TextViewBasicHeight = 16.0f;
//@class LYJ_TextView;
@protocol LYJ_InputToolBar <NSObject>

-(void)newToolBarHeight:(CGFloat)height;

@end
@interface LYJ_InputToolBar : UIView
@property (weak, nonatomic) IBOutlet UITextView *contentField;
@property (nonatomic,strong) NSString *st;
@property (nonatomic,assign) id<LYJ_InputToolBar> lyj_delegate;
@end
