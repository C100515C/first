//
//  CC_LabelsOfView.m
//  MoscoperV2
//
//  Created by mac on 15/7/27.
//  Copyright (c) 2015年 moscoper. All rights reserved.
//

#import "CC_LabelsOfView.h"

#define CC_LABEL_BASE_TAG 1000
#define CC_LABEL_DISTANCE _interval
#define CC_LABEL_FONT 10
#define CC_SYSTEM_FONT(a) [UIFont systemFontOfSize:a];

@interface CC_LabelsOfView (){
    CGFloat _start_x;
    CGFloat _y;
    CGFloat _interval;
    CGFloat _height;
    CGFloat _endDis;
    NSInteger _rows;
    CCLabelType _labeltype;
}


@end

@implementation CC_LabelsOfView

-(id)initWithFrame:(CGRect)frame andStart_x:(CGFloat)start_x andY:(CGFloat)y andInterval:(CGFloat)interval andLabelHeight:(CGFloat)height andEndDistance:(CGFloat)endDis{
    self = [super initWithFrame:frame];
    if (self) {
        _start_x = start_x;
        _y = y;
        _interval = interval;
        _height = height;
        _endDis = endDis;
        _rows = 1;
        _labeltype = CCNormalLabel;
        self.backgroundColor = [UIColor clearColor];
    }
    return self;
}

-(id)initWithFrame:(CGRect)frame andStart_x:(CGFloat)start_x andY:(CGFloat)y andInterval:(CGFloat)interval andLabelHeight:(CGFloat)height andEndDistance:(CGFloat)endDis andLabelType:(CCLabelType)type{
    self = [super initWithFrame:frame];
    if (self) {
        _start_x = start_x;
        _y = y;
        _interval = interval;
        _height = height;
        _endDis = endDis;
        _rows = 1;
        self.backgroundColor = [UIColor clearColor];
        _labeltype = type;
        
    }
    return self;
}

-(void)setStart_x:(CGFloat)start_x andY:(CGFloat)y andInterval:(CGFloat)interval andLabelHeight:(CGFloat)height andEndDistance:(CGFloat)endDis andLabelType:(CCLabelType)type{
    
    _start_x = start_x;
    _y = y;
    _interval = interval;
    _height = height;
    _endDis = endDis;
    _rows = 1;
    _labeltype = type;
}

-(void)set_MyLabelsWith:(NSArray *)labels{
    [self createLabelsWith:labels andSuperView:self andStartDistance_x:_start_x andDistance_y:_y andLableHeight:_height andEndWidth:_endDis];
}

-(CGFloat)set_MyLabelsCanChangeRowsWith:(NSArray *)labels{
    [self createLabelsCanChangeRowsWith:labels andSuperView:self andStartDistance_x:_start_x andDistance_y:_y andLableHeight:_height andEndWidth:_endDis];
    
    return (_rows-1)*(_height+_y);
}

+(CGFloat)setStart_x:(CGFloat)start_x andY:(CGFloat)y andInterval:(CGFloat)interval andLabelHeight:(CGFloat)height andEndDistance:(CGFloat)endDis andLabelFrame:(CGRect)frame andLabels:(NSArray*)labels{
    return 0;
    
}

#pragma mark - 添加标签


/**
 *  创建 标签
 *
 *  @param labels     标签数组
 *  @param superView  添加到得的view
 *  @param distance_x 第一个标签的x
 *  @param distance_y 第一个标签的y
 *  @param height     标签高度
 *  @param endWidth   最后一个标签的位置
 */
-(void)createLabelsWith:(NSArray*)labels andSuperView:(UIView*)superView andStartDistance_x:(CGFloat)distance_x andDistance_y:(CGFloat)distance_y andLableHeight:(CGFloat)height andEndWidth:(CGFloat)endWidth{
     [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
//    [self removeOldLabelWithLabelCounts:(int)labels.count];

    for (int i=0; i<labels.count; i++) {
        
        UILabel *frontLabel = (UILabel*)[superView viewWithTag:CC_LABEL_BASE_TAG+i-1];
        float new_distance = 0.0;
        
        if (frontLabel) {
            new_distance = frontLabel.frame.origin.x+frontLabel.frame.size.width+CC_LABEL_DISTANCE;
        }else{
            new_distance = distance_x;
        }
        
        NSString *text = labels[i];
        CGFloat currentFont = CC_LABEL_FONT;
        if (_labeltype==CCGrayPoundLabel) {
            text = [NSString stringWithFormat:@"#%@",text];
            currentFont = CC_LABEL_FONT+2;
        }
        CGSize size = [self getSizeWithString:text andFont:currentFont andSetStartSize:CGSizeMake(100, 2000)];
        
        float new_width = size.width+5;
        new_width = new_width<30.0?30.0:new_width;
        
        UILabel *label = [self creatMyLabelWith:CGRectMake(new_distance, distance_y, new_width, height) andLabels:labels andNum:i];
        /*
        UILabel *label = [[UILabel alloc ] initWithFrame:CGRectMake(new_distance, distance_y, new_width, height)];
        label.text = labels[i];
        label.font = SYSTEM_FONT(LABEL_FONT)
        label.textColor = RGB(51, 179, 239, 1);//[UIColor blueColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.tag = LABEL_BASE_TAG+i;
        label.backgroundColor = [UIColor whiteColor];
        label.layer.borderColor = [RGB(51, 179, 239, 1) CGColor];
        label.layer.borderWidth = 0.5;
        label.layer.cornerRadius = 1;//*/
        [superView addSubview:label];

        
        if (size.width+new_distance>superView.frame.size.width-endWidth-3) {//需要减去后面的要留出的宽度
            label.frame = CGRectMake(new_distance, distance_y, 8, height);
            label.text = @"...";
//            [label removeFromSuperview];
            return ;
        }
    }
    
}


/**
 *  创建 标签  （可以换行的）
 *
 *  @param labels     标签数组
 *  @param superView  添加到得的view
 *  @param distance_x 第一个标签的x
 *  @param distance_y 第一个标签的y
 *  @param height     标签高度
 *  @param endWidth   最后一个标签的位置
 */
-(void)createLabelsCanChangeRowsWith:(NSArray*)labels andSuperView:(UIView*)superView andStartDistance_x:(CGFloat)distance_x andDistance_y:(CGFloat)distance_y andLableHeight:(CGFloat)height andEndWidth:(CGFloat)endWidth{
    
    [self.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];

    CGFloat new_y = (_rows-1)*(height+distance_y);
    
    for (int i=0; i<labels.count; i++) {
        
        UILabel *frontLabel = (UILabel*)[superView viewWithTag:CC_LABEL_BASE_TAG+i-1];
        float new_distance = 0.0;
        
        if (frontLabel) {
            new_distance = frontLabel.frame.origin.x+frontLabel.frame.size.width+CC_LABEL_DISTANCE;
        }else{
            new_distance = distance_x;
        }
        
        NSString *text = labels[i];
        CGFloat currentFont = CC_LABEL_FONT;

        if (_labeltype==CCGrayPoundLabel) {
            text = [NSString stringWithFormat:@"#%@",text];
            currentFont = CC_LABEL_FONT+2;

        }
        CGSize size = [self getSizeWithString:text andFont:currentFont andSetStartSize:CGSizeMake(100, 2000)];
        
        float new_width = size.width+5;
        new_width = new_width<30.0?30.0:new_width;

       UILabel *label = [self creatMyLabelWith:CGRectMake(new_distance, distance_y+new_y, new_width, height) andLabels:labels andNum:i];
        /*
        UILabel *label = [[UILabel alloc ] initWithFrame:CGRectMake(new_distance, distance_y+new_y, new_width, height)];
        label.text = labels[i];
        label.font = SYSTEM_FONT(LABEL_FONT)
        label.textColor = RGB(51, 179, 239, 1);//[UIColor blueColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.tag = LABEL_BASE_TAG+i;
        label.backgroundColor = [UIColor whiteColor];
        [superView addSubview:label];
        label.layer.borderColor = [RGB(51, 179, 239, 1) CGColor];
        label.layer.borderWidth = 0.5;
        label.layer.cornerRadius = 1;//*/
        
        [superView addSubview:label];
        if (size.width+new_distance>superView.frame.size.width-endWidth) {//需要减去后面的要留出的宽度
            _rows ++;
            new_distance = distance_x;
            new_y = (_rows-1)*(height+distance_y);
            label.frame = CGRectMake(new_distance, distance_y + new_y, new_width, height);
        }
    }
    
    CGRect oldFame = self.frame;
    self.frame = CGRectMake(oldFame.origin.x, oldFame.origin.y, oldFame.size.width, oldFame.size.height+(_rows-1)*(height+distance_y));
}

-(UILabel *)creatMyLabelWith:(CGRect)frame andLabels:(NSArray*)labels andNum:(int)i{
    UILabel *label = nil;
    label = [[UILabel alloc ] initWithFrame:frame];
    label.text = labels[i];
    label.font = CC_SYSTEM_FONT(CC_LABEL_FONT)
    if (_labeltype==CCNormalLabel) {
        label.textColor = RGB(51, 179, 239, 1);//[UIColor blueColor];
        label.textAlignment = NSTextAlignmentCenter;
        label.tag = CC_LABEL_BASE_TAG+i;
        label.backgroundColor = [UIColor whiteColor];
        label.layer.borderColor = [RGB(51, 179, 239, 1) CGColor];
        label.layer.borderWidth = 0.5;
        label.layer.cornerRadius = 1;
    }else if(_labeltype==CCGrayPoundLabel){
    
        label.textColor = RGB(156, 156, 156,1);
        label.textAlignment = NSTextAlignmentCenter;
        label.tag = CC_LABEL_BASE_TAG+i;
        label.font = SYSTEMFONT(CC_LABEL_FONT+2);
        label.backgroundColor = [UIColor clearColor];
        label.text = [NSString stringWithFormat:@"#%@",labels[i]];
    }else if(_labeltype==CCBlueOvalLabel){
    
        label.textColor = [UIColor whiteColor];;
        label.textAlignment = NSTextAlignmentCenter;
        label.tag = CC_LABEL_BASE_TAG+i;
        label.backgroundColor = G_COLOR_NAVGATION_BACK;
        
        label.clipsToBounds = YES;
        label.layer.cornerRadius = 10;
        
        
    }
    MOSLog(@"%f",frame.size.width);
    
    return label;
}

//移除之前创建的标签
-(void)removeOldLabelWithLabelCounts:(int)count{
    
    for (int i=0; i<count; i++) {
        UILabel *frontLabel = (UILabel*)[self viewWithTag:CC_LABEL_BASE_TAG+i];
        [frontLabel removeFromSuperview];
    }
    
}

/**
 *  获取字符串宽高
 *
 *  @param string 字符串
 *  @param font   字体大小
 *  @param startSize 设定初始宽高 获取以此为模板
 *
 *  @return 宽高
 */
-(CGSize)getSizeWithString:(NSString*)string andFont:(CGFloat)font andSetStartSize:(CGSize)startSize{
//    MOSLog(@"%@",string);
    CGSize size = [string boundingRectWithSize:startSize options:NSStringDrawingTruncatesLastVisibleLine|NSStringDrawingUsesFontLeading|NSStringDrawingUsesLineFragmentOrigin attributes:@{NSFontAttributeName:[UIFont systemFontOfSize:font]} context:nil].size;
    
    return size;
}
@end
