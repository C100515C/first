

//
//  BasicLabel.m
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicLabel.h"

@implementation BasicLabel

-(void)awakeFromNib{
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

-(void)setBorder{
    self.clipsToBounds = YES;
    self.layer.cornerRadius = 3.0f;
    self.layer.borderColor = [[UIColor redColor]CGColor];
    self.layer.borderWidth = 1.0f;
    self.textColor = [UIColor redColor];
    self.textAlignment = NSTextAlignmentCenter;
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
