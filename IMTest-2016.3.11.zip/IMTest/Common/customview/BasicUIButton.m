//
//  BasicUIButton.m
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicUIButton.h"

@implementation BasicUIButton

-(CGRect)titleRectForContentRect:(CGRect)contentRect{
    return CGRectMake(21, 3, 40, 16);
}

-(CGRect)imageRectForContentRect:(CGRect)contentRect{
    return CGRectMake(3, 3, 16, 16);
}

-(UIEdgeInsets)imageEdgeInsets{
    UIEdgeInsets  edge = UIEdgeInsetsMake(0, -5, 0, 0);
    return edge;
}

@end
