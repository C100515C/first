//
//  LYJToolbar.h
//  IMTest
//
//  Created by chenchen on 16/2/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LYJToolBarDelegate <NSObject>
/**
 *  点击发送执行回调
 *
 *  @param currentText 输入的内容
 */
-(void)clickedSendBtn:(NSString*)currentText;

@end

@interface LYJToolbar : UIToolbar

@property (nonatomic,assign) id<LYJToolBarDelegate>sendDelegate;

@property (nonatomic,copy) NSString *textPlaceholder;
/**
 *  收起键盘
 */
-(void)takeBackKeyboard;

-(BOOL)keyboardCurrentAppearStyle;
-(void)keybaordAppear;

@end
