//
//  LYJToolbar.m
//  IMTest
//
//  Created by chenchen on 16/2/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJToolbar.h"
static const CGFloat keyboard_height = 0.0f;
@interface LYJToolbar ()<UITextFieldDelegate>{

    UITextField *_textField;
    UIButton *_sendBtn;
    UIView *_backgroundView;
    CGRect _selfOriginalFrame;
}

@property (nonatomic,assign) BOOL keyboardAppear;

@end

@implementation LYJToolbar

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        _selfOriginalFrame = frame;
        _backgroundView = [[UIView alloc] initWithFrame:frame];
        _backgroundView.backgroundColor = [UIColor grayColor];
        [self addSubview:_backgroundView];
        
        _textField = [[UITextField alloc] initWithFrame:CGRectZero];
        _textField.delegate = self;
        [_backgroundView addSubview:_textField];
        _textField.placeholder = @"请输入您回复的内容";
        _sendBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        _sendBtn.frame = CGRectZero;
        [_backgroundView addSubview:_sendBtn];
        [_sendBtn addTarget:self action:@selector(sendBtnAction:) forControlEvents:UIControlEventTouchUpInside];
        
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillAppear:) name:UIKeyboardWillShowNotification object:nil];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keboardWillDisappeat:) name:UIKeyboardWillHideNotification object:nil];
        [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidAppear:) name:UIKeyboardDidShowNotification object:nil];
        [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keboardDidDisappeat:) name:UIKeyboardDidHideNotification object:nil];
        
        self.keyboardAppear = NO;

        [self interfaceLayout];
    }
    return self;
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];

}

-(void)setTextPlaceholder:(NSString *)textPlaceholder{
    _textField.placeholder = textPlaceholder;

}

#pragma mark - 布局
-(void)interfaceLayout{
    CGFloat self_w = self.frame.size.width;
//    CGFloat self_h = self.frame.size.height;
    
    CGFloat spacing = 10.0f;
    CGFloat btn_w = 45.0f;
    CGFloat btn_h = 35.0f;
    CGFloat textField_w = self_w-3*spacing-btn_w;
    
    _textField.frame = CGRectMake(spacing, spacing/3.0f, textField_w, btn_h);
    _sendBtn.frame = CGRectMake(spacing*2+textField_w, spacing/3.0f, btn_w, btn_w);
    
    _textField.borderStyle = UITextBorderStyleRoundedRect;
    _sendBtn.clipsToBounds = YES;
    _sendBtn.layer.cornerRadius  = 3.0f;
    _sendBtn.backgroundColor = [UIColor greenColor];
    [_sendBtn setTitle:@"发送" forState:UIControlStateNormal];
    
    [_backgroundView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.center.equalTo(self);
        make.width.equalTo(self);
        make.height.equalTo(self);
    }];
    
    [_textField mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(_backgroundView.mas_left).with.offset(spacing);
        make.top.equalTo (@(spacing/3.0f));
        make.right.equalTo(_sendBtn.mas_left).with.offset(-spacing);
        make.height.equalTo(@(btn_h));
    }];
    
    [_sendBtn mas_makeConstraints:^(MASConstraintMaker *make) {
       
        make.top.equalTo (@(spacing/3.0f));
        make.right.equalTo(_backgroundView.mas_right).with.offset(-spacing);
        make.width.equalTo(@(btn_w));
        make.height.equalTo(@(btn_h));
        
    }];
    
    
}

-(BOOL)keyboardCurrentAppearStyle{
    return _keyboardAppear;
}

#pragma mark -UITextFieldDelegate
-(BOOL)textFieldShouldReturn:(UITextField *)textField{
    return YES;
}
//随键盘的移动界面移动
#pragma mark- 监听方法
-(void)keyboardWillAppear:(NSNotification*)notification{
    CGSize size = [[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    self.frame = CGRectMake(_selfOriginalFrame.origin.x,_selfOriginalFrame.origin.y-size.height-keyboard_height , _selfOriginalFrame.size.width, _selfOriginalFrame.size.height);

}

-(void)keboardWillDisappeat:(NSNotification*)notification{
    self.frame = _selfOriginalFrame;
    self.keyboardAppear = NO;
}

-(void)keyboardDidAppear:(NSNotification*)notification{
    self.keyboardAppear = YES;

}

-(void)keboardDidDisappeat:(NSNotification*)notification{
    self.keyboardAppear = NO;
    
}


#pragma mark - btn 
-(void)sendBtnAction:(UIButton*)sender{
    
    if (self.sendDelegate && [self.sendDelegate respondsToSelector:@selector(clickedSendBtn:)]) {
        [self.sendDelegate clickedSendBtn:_textField.text];
    }
    MOSLog(@"发送 ＝ %@",_textField.text);
    [_textField resignFirstResponder];
    _textField.text = @"";
}

#pragma mark- method
-(void)takeBackKeyboard{
    if (_keyboardAppear) {
        [_textField resignFirstResponder];
    }
}

-(void)keybaordAppear{
    if (!_keyboardAppear) {
        [_textField becomeFirstResponder];
    }
}

@end
