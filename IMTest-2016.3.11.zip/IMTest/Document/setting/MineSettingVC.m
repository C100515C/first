//
//  MineSettingVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MineSettingVC.h"
#import "UserInforCell.h"
#import "SetMenuCell.h"
#import "UserProfileManager.h"



@interface MineSettingVC (){
    NSMutableArray *_source;
    
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;

@end

@implementation MineSettingVC


- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.title = @"我的";
    
    self.myTable.delegate = self;
    self.myTable.dataSource = self;
    
    [self.myTable registerNib:[UINib nibWithNibName:@"UserInforCell" bundle:nil] forCellReuseIdentifier:inforCell_id];
    [self.myTable registerNib:[UINib nibWithNibName:@"SetMenuCell" bundle:nil] forCellReuseIdentifier:setMenuCell_id];
    
//    [[UserProfileManager sharedInstance] storeUserInfor:@{@"objectId":@"1",@"username":@"cc",@"imageUrl":@"123",@"nickname":@"lyj",@"signature":@"lllllll",@"gender":@"1"}];

    [self makeDataSource];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}


#pragma mark - data
-(void)makeDataSource{
    _source = [NSMutableArray array];
    
    UserProfileEntity *user_model = [[UserProfileManager sharedInstance] getCurUserProfile];
    [_source addObject:user_model];
    
    NSArray *menu_name = @[@"家庭病历夹",@"我收藏的",@"我关注的",@"问题反馈",@"关于我们",@"设置"];
    NSArray *menu_img = @[@"chat_item_file.png",@"chat_item_file.png",@"chat_item_file.png",@"chat_item_file.png",@"chat_item_file.png",@"chat_item_file.png"];
    
    for (int i=0;i<menu_img.count ; i++) {
     
        NSDictionary *dic = @{@"name":menu_name[i],@"img":menu_img[i]};
        [_source addObject:dic];
        
    }
    [_myTable reloadData];
}

#pragma mark - table
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _source.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        return 131.0f;
    }
    return 40.0f;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{

    if (indexPath.row==0 ) {
       UserInforCell *cell = [tableView dequeueReusableCellWithIdentifier:inforCell_id];
        
        if (cell==nil) {
            cell  = [[[NSBundle mainBundle] loadNibNamed:@"UserInforCell" owner:nil options:nil] firstObject];
        }
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

        return cell;
    }else{
      SetMenuCell *cell = [tableView dequeueReusableCellWithIdentifier:setMenuCell_id];
        
        if (cell==nil) {
            cell  = [[[NSBundle mainBundle] loadNibNamed:@"SetMenuCell" owner:nil options:nil] firstObject];
        }
        
        NSDictionary *dic = [_source objectAtIndex:indexPath.row];
        
        cell.icon.image = [UIImage imageNamed:dic[@"img"]];
        cell.name.text = dic[@"name"];
        
        return cell;
    }
}


@end
