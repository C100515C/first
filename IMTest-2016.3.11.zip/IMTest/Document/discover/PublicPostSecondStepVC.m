//
//  PublicPostSecondStepVC.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PublicPostSecondStepVC.h"

@interface PublicPostSecondStepVC ()

@end

@implementation PublicPostSecondStepVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setNav];
    
    self.tableView.hidden = YES;
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setNav{
    self.title = @"发新帖";

    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
    [nav setNavBarBtnItemImageWith:@"faceDelete.png" andRightItem:YES andAction:@selector(nextClickdAction:) andTarget:self andVCIndex:3];
    
}

-(void)nextClickdAction:(UIButton*)sender{
    
    MOSLog(@"发布");
}

@end
