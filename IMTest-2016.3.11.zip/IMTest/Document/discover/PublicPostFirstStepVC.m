//
//  PublicPostFirstStepVC.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PublicPostFirstStepVC.h"
#import "PublicPostSecondStepVC.h"

#import "LYJDBManager.h"

@interface PublicPostFirstStepVC ()

- (IBAction)btnaction:(UIButton *)sender;

- (IBAction)show:(UIButton *)sender;

@end

@implementation PublicPostFirstStepVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    [self setNav];
    
    self.tableView.hidden = YES;
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    [[LYJDBManager getSharedInstance] createDB];

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setNav{
    
    self.title = @"发新帖";
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
    [nav setNavBarBtnItemImageWith:@"faceDelete.png" andRightItem:YES andAction:@selector(nextClickdAction:) andTarget:self andVCIndex:2];
    
}

-(void)nextClickdAction:(UIButton*)sender{
    
    PublicPostSecondStepVC *vc = [[PublicPostSecondStepVC alloc] init];
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
    
}

- (IBAction)btnaction:(UIButton *)sender {
    
//    [[LYJDBManager getSharedInstance] saveData:@"1" name:@"cc" department:@"lyj" year:@"2016"];
    [[LYJDBManager getSharedInstance] deletByRegisterNumber:@"1"];
}

- (IBAction)show:(UIButton *)sender {
    
    MOSLog(@"%@",[[LYJDBManager getSharedInstance] findByRegisterNumber:@"1"]);
}
@end
