//
//  CCWaterFlowLayout.m
//  test
//
//  Created by MS on 16-1-21.
//  Copyright (c) 2016年 MS. All rights reserved.
//

#import "CCWaterFlowLayout.h"

#define CCCollectionW self.collectionView.frame.size.width

/** 每一行之间的间距 */
static const CGFloat CCDefaultRowMargin = 1;
/** 每一列之间的间距 */
static const CGFloat CCDefaultColumnMargin = 1;
/** 每一列之间的间距 top, left, bottom, right */
static const UIEdgeInsets CCDefaultInsets = {1, 1, 1, 1};
/** 默认的列数 */
static const int CCDefaultColumsCount = 3;

@interface CCWaterFlowLayout()

/** 每一列的最大Y值 */
@property (nonatomic, strong) NSMutableArray *columnMaxYs;
/** 存放所有cell的布局属性 */
@property (nonatomic, strong) NSMutableArray *attrsArray;

@end

@implementation CCWaterFlowLayout

#pragma mark - 懒加载
- (NSMutableArray *)columnMaxYs
{
    if (!_columnMaxYs) {
        _columnMaxYs = [[NSMutableArray alloc] init];
    }
    return _columnMaxYs;
}

- (NSMutableArray *)attrsArray
{
    if (!_attrsArray) {
        _attrsArray = [[NSMutableArray alloc] init];
    }
    return _attrsArray;
}

#pragma mark - 实现内部的方法
/**
 * 决定了collectionView的contentSize
 - (CGSize)collectionViewContentSize
 */
- (CGSize)collectionViewContentSize
{
    // 找出最长那一列的最大Y值
    CGFloat destMaxY = [self.columnMaxYs[0] doubleValue];
    for (NSUInteger i = 1; i<self.columnMaxYs.count; i++) {
        // 取出第i列的最大Y值
        CGFloat columnMaxY = [self.columnMaxYs[i] doubleValue];
        
        // 找出数组中的最大值
        if (destMaxY < columnMaxY) {
            destMaxY = columnMaxY;
        }
    }
    return CGSizeMake(0, destMaxY + CCDefaultInsets.bottom);
}
//- (void)prepareLayout
- (void)prepareLayout
{
    [super prepareLayout];
    
    // 重置每一列的最大Y值
    [self.columnMaxYs removeAllObjects];
    for (NSUInteger i = 0; i<CCDefaultColumsCount; i++) {
        [self.columnMaxYs addObject:@(CCDefaultInsets.top)];
        MOSLog(@"maxY=%@",self.columnMaxYs);

    }
    
    // 计算所有cell的布局属性
    [self.attrsArray removeAllObjects];
    
    NSIndexPath *indexPath = [NSIndexPath indexPathForItem:0 inSection:0];
    UICollectionViewLayoutAttributes *attributes = [self layoutAttributesForSupplementaryViewOfKind:UICollectionElementKindSectionHeader atIndexPath:indexPath];
    [self.attrsArray addObject:attributes];
    attributes = [self layoutAttributesForSupplementaryViewOfKind:UICollectionElementKindSectionHeader atIndexPath:indexPath];
    [self.attrsArray addObject:attributes];
    
    NSUInteger count = [self.collectionView numberOfItemsInSection:0];
    for (NSUInteger i = 0; i < count; ++i) {
        //获取 布局 属性
        NSIndexPath *indexPath = [NSIndexPath indexPathForItem:i inSection:0];
        UICollectionViewLayoutAttributes *attrs = [self layoutAttributesForItemAtIndexPath:indexPath];
        [self.attrsArray addObject:attrs];
        MOSLog(@"attrs=%@",self.attrsArray);

    }
    
    MOSLog(@"maxY=%@---attrs=%@",self.columnMaxYs,self.attrsArray);
}

/**
 * 说明所有元素（比如cell、补充控件、装饰控件）的布局属性
 - (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect
 */
- (NSArray *)layoutAttributesForElementsInRect:(CGRect)rect
{
    
    return self.attrsArray;
}

/**
 * 说明cell的布局属性
 - (UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath
 获取item的布局属性 设置每一个item的frame
 */
- (UICollectionViewLayoutAttributes *)layoutAttributesForItemAtIndexPath:(NSIndexPath *)indexPath
{
    UICollectionViewLayoutAttributes *attrs = [UICollectionViewLayoutAttributes layoutAttributesForCellWithIndexPath:indexPath];
    
    /** 计算indexPath位置cell的布局属性 */
    
    // 水平方向上的总间距
    CGFloat xMargin = CCDefaultInsets.left + CCDefaultInsets.right + (CCDefaultColumsCount - 1) * CCDefaultColumnMargin;
    // cell的宽度
//    CGFloat w = (CCCollectionW - xMargin) / CCDefaultColumsCount;
    CGFloat w_b = (CCCollectionW - xMargin)/CCDefaultColumsCount+50;
    CGFloat w_s = (CCCollectionW - xMargin-w_b)/2.0;
    
    // cell的高度
    CGFloat h_b = 180.0f;
    CGFloat h_s = (h_b-CCDefaultRowMargin)/2.0;
    
    // 找出最短那一列的 列号 和 最大Y值
    CGFloat destMaxY = [self.columnMaxYs[0] doubleValue];
    NSUInteger destColumn = 0;
    for (NSUInteger i = 1; i<self.columnMaxYs.count; i++) {
        // 取出第i列的最大Y值
        CGFloat columnMaxY = [self.columnMaxYs[i] doubleValue];
        
        // 找出数组中的最小值
        if (destMaxY > columnMaxY) {
            destMaxY = columnMaxY;
            destColumn = i;
        }
    }
    
    CGFloat x_sp = 0.0f;
    if (destColumn>=1) {
        x_sp = w_b-w_s;
    }
    
    if (attrs.indexPath.row % 5==0) {
        // cell的x值
        CGFloat x = CCDefaultInsets.left +  destColumn*(w_b + CCDefaultColumnMargin)+x_sp;
        // cell的y值
        CGFloat y = destMaxY + CCDefaultRowMargin;
        // cell的frame
        attrs.frame = CGRectMake(x, y, w_b, h_b);
    }else{
        // cell的x值
        CGFloat x = CCDefaultInsets.left + destColumn * (w_s + CCDefaultColumnMargin)+x_sp;
        // cell的y值
        CGFloat y = destMaxY + CCDefaultRowMargin;
        // cell的frame
        attrs.frame = CGRectMake(x, y, w_s, h_s);
    }
    
    
    // 更新数组中的最大Y值
    self.columnMaxYs[destColumn] = @(CGRectGetMaxY(attrs.frame));
    
    return attrs;
}
//组上下 头 view
-(UICollectionViewLayoutAttributes*)layoutAttributesForSupplementaryViewOfKind:(NSString *)elementKind atIndexPath:(NSIndexPath *)indexPath{
    UICollectionViewLayoutAttributes *attrs = [UICollectionViewLayoutAttributes layoutAttributesForSupplementaryViewOfKind:elementKind withIndexPath:indexPath];
    
    attrs.size = CGSizeMake(SCREEN_WIDTH, 100);
    if([elementKind isEqual:UICollectionElementKindSectionHeader])
    {
        attrs.center = CGPointMake(SCREEN_WIDTH/2.0, -attrs.size.height/2.0);
//        self.headerReferenceSize = attrs.size;
    }
    else
    {
        attrs.center = CGPointMake(SCREEN_WIDTH/2.0, SCREEN_HEIGHT+40);
//        self.footerReferenceSize = attrs.size;

    }
    
    return attrs;
}
//滑动方向
//- (UICollectionViewLayoutAttributes *)layoutAttributesForDecorationViewOfKind:(NSString*)elementKind atIndexPath:(NSIndexPath *)indexPath{
//    UICollectionViewLayoutAttributes *attrs = [UICollectionViewLayoutAttributes layoutAttributesForDecorationViewOfKind:elementKind withIndexPath:indexPath];
//    return attrs;
//}

@end
