//
//  CCCollectionCell.m
//  test
//
//  Created by MS on 16-1-21.
//  Copyright (c) 2016年 MS. All rights reserved.
//

#import "CCCollectionCell.h"

@interface CCCollectionCell ()


@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UIImageView *pic;


@end

@implementation CCCollectionCell

-(void)awakeFromNib{
   
}

@end
