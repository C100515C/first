//
//  CircleDetailHeaderView.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleDetailHeaderView.h"
#import "BasicUIButton.h"

@interface CircleDetailHeaderView ()

@property (weak, nonatomic) IBOutlet UIImageView *headerIcon;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *counts;
@property (weak, nonatomic) IBOutlet BasicUIButton *focusBtn;

- (IBAction)focusAction:(BasicUIButton *)sender;

@end

@implementation CircleDetailHeaderView

-(void)awakeFromNib{
    self.focusBtn.clipsToBounds = YES;
    self.focusBtn.layer.cornerRadius = 3.0f;
}

-(void)setHeaerViewWith:(NSDictionary *)dic{
    
    MOSLog(@"头 view  未写数居 赋值");
    
}

- (IBAction)focusAction:(BasicUIButton *)sender {
    MOSLog(@"dd");
}

@end
