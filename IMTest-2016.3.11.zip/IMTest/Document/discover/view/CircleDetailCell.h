//
//  CircleDetailCell.h
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"
@class CircleDetailResponse;
static NSString * const circleDetailCell_id = @"circledetail";

@interface CircleDetailCell : BasicTableViewCell

-(void)setCellWith:(CircleDetailResponse*)model;

@end
