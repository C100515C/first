//
//  CCCollectionCell.h
//  test
//
//  Created by MS on 16-1-21.
//  Copyright (c) 2016年 MS. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CCCollectionCell : UICollectionViewCell

@end
