//
//  RegisterUserInforVC.m
//  IMTest
//
//  Created by chenchen on 16/3/8.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "RegisterUserInforVC.h"
#import "BasicUIImageView.h"
#import "UIAlertController+LYJAlertView.h"

@interface RegisterUserInforVC ()<UINavigationControllerDelegate, UIImagePickerControllerDelegate,BasicUIImageTapProtocol,UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;
@property (weak, nonatomic) IBOutlet UIView *mideBackView;
@property (weak, nonatomic) IBOutlet UITextField *nickNameField;
@property (weak, nonatomic) IBOutlet UITextField *passwordField;
@property (weak, nonatomic) IBOutlet UIButton *agreeAction;

- (IBAction)agreeBtnAction:(UIButton *)sender;

@property (strong, nonatomic) UIImagePickerController *imagePickerController;

@end

@implementation RegisterUserInforVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = YES;
    self.nickNameField.delegate = self;
    self.passwordField.delegate = self;
    
    [self setNav];
    [self.headerIcon setRaduis];
    [self.headerIcon setTapUse];
    self.headerIcon.lyj_delegate = self;
    

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setNav{
    // 设置navigationBar的背景颜色，根据需要自己设置
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    //     设置navigationController的title的字体颜色
    NSDictionary * dict=[NSDictionary dictionaryWithObject:[UIColor darkGrayColor] forKey:NSForegroundColorAttributeName];
    self.navigationController.navigationBar.titleTextAttributes = dict;
    self.title = @"注册";
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
    [nav setNavBarBtnItemImageWith:@"faceDelete.png" andRightItem:NO andAction:@selector(popVC:) andTarget:self andVCIndex:2];
    [nav setNavBarBtnItemTitleWith:@"提交注册" andRightItem:YES andAction:@selector(pushVC:) andTarget:self andVCIndex:2];
}

-(void)popVC:(UIButton*)btn{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)pushVC:(UIButton*)btn{
    MOSLog(@"注册");
}

- (IBAction)agreeBtnAction:(UIButton *)sender {
    
}

#pragma mark - image tap 
-(void)imageTapWith:(UITapGestureRecognizer*)sender{
    [self cellAvatarPress];
}

#pragma mark - 头像模块
- (void)cellAvatarPress
{
    MOSLog(@"Cell avatar press.");
    __weak typeof (self) weakSelf = self;
    UIAlertControllerActionBlock takephoto = ^(UIAlertAction *action){
        MOSLog(@"拍照");
        weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypeCamera;
        weakSelf.imagePickerController.editing = YES;
        weakSelf.imagePickerController.allowsEditing = YES;
        [weakSelf presentViewController:weakSelf.imagePickerController
                           animated:YES
                         completion:^{
                             //
                         }];
    };
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"取消");
    };
    UIAlertControllerActionBlock pics = ^(UIAlertAction *action){
        MOSLog(@"从手机相册选择");
        weakSelf.imagePickerController.sourceType = UIImagePickerControllerSourceTypePhotoLibrary;
        [weakSelf presentViewController:weakSelf.imagePickerController
                           animated:YES
                         completion:^{
                             
//                             [[UIApplication sharedApplication] setStatusBarHidden:NO];
//                             [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
                             
                             [self prefersStatusBarHidden ];
                             [self preferredStatusBarStyle];
                         }];
    };
    [UIAlertController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"拍照":takephoto,@"从手机相册选择":pics} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet];
    
    
}



#pragma mark - Property method

- (UIImagePickerController *)imagePickerController
{
    if (_imagePickerController == nil) {
        _imagePickerController = [[UIImagePickerController alloc] init];
        _imagePickerController.navigationBar.barTintColor = G_COLOR_NAVGATION_BACK;
        _imagePickerController.navigationBar.tintColor = [UIColor whiteColor];
        _imagePickerController.navigationBar.titleTextAttributes = @{NSForegroundColorAttributeName:G_COLOR_NAVGATION_TITLE,
                                                                     NSFontAttributeName:G_FONT_NAVGATION_TITLE};
//        [[UIApplication sharedApplication] setStatusBarHidden:NO];
//        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
        [self prefersStatusBarHidden ];
        [self preferredStatusBarStyle];
        
        _imagePickerController.delegate = self;
    }
    return _imagePickerController;
}

-(BOOL)prefersStatusBarHidden{
    return NO;
}

-(UIStatusBarStyle)preferredStatusBarStyle{
    return UIStatusBarStyleLightContent;
}

#pragma mark - UIImagePickerControllerDelegate

- (void)imagePickerController:(UIImagePickerController *)picker didFinishPickingMediaWithInfo:(NSDictionary *)info
{
    UIImage *picImage;
    //    = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    
    if (picker.sourceType == UIImagePickerControllerSourceTypeCamera) {
        picImage = [info objectForKey:@"UIImagePickerControllerEditedImage"];
    } else {
        picImage = [info objectForKey:@"UIImagePickerControllerOriginalImage"];
    }
    
    __weak typeof(self) weakSelf = self;

    [self.imagePickerController dismissViewControllerAnimated:YES completion:^{
        MOSLog(@"dismiss self");
        NSData *data = UIImageJPEGRepresentation(picImage , 0.1);
        weakSelf.headerIcon.image = picImage;
        
    }];
}
-(void)imagePickerControllerDidCancel:(UIImagePickerController *)picker
{
    [self preferredStatusBarStyle];
//    [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
    [picker dismissViewControllerAnimated:YES completion:^{
//        [[UIApplication sharedApplication] setStatusBarStyle:UIStatusBarStyleLightContent];
        [self preferredStatusBarStyle];
    }];
    
}
#pragma mark - text field

@end
