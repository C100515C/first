//
//  CC_SsoModel.h
//  StoryBoardTest
//
//  Created by mac on 15/7/14.
//  Copyright (c) 2015年 CC. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef enum {
    QQ=10,
    Sina,
    WeiChat
    
}PlatformName_cc;

@interface CC_SsoModel : NSObject

@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *gender;
@property (nonatomic,copy) NSString *access_token;
@property (nonatomic,copy) NSString *user_icon_url;
/**
 *  为model设置授权返回信息
 *
 *  @param inforDic 信息字典
 */
-(void)set_myModelWith:(NSDictionary*)inforDic andPlatform:(PlatformName_cc)name;

@end
