//
//  PostRepeatListResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface PostRepeatListResponse : BasicResponse

@property (nonatomic,copy) NSString *nickname;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *type;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *label;
@property (nonatomic,copy) NSString *time;
@property (nonatomic,copy) NSString *count;



@end
