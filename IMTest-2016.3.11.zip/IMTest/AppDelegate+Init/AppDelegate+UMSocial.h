//
//  AppDelegate+UMSocial.h
//  IMTest
//
//  Created by chenchen on 16/3/9.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (UMSocial)

- (void)umSocialApplication:(UIApplication *)application
didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
                    appkey:(NSString *)appkey
              apnsCertName:(NSString *)apnsCertName
               otherConfig:(NSDictionary *)otherConfig;

@end
