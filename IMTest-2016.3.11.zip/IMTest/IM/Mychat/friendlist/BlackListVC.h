//
//  BlackListVC.h
//  IMTest
//
//  Created by chenchen on 16/2/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "EaseUsersListViewController.h"

@interface BlackListVC : EaseUsersListViewController

@end
