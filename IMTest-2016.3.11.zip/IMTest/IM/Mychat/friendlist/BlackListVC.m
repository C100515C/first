//
//  BlackListVC.m
//  IMTest
//
//  Created by chenchen on 16/2/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BlackListVC.h"
#import "EMSearchBar.h"
#import "EMSearchDisplayController.h"
#import "UIAlertController+LYJAlertView.h"
#import "UIViewController+HUD.h"
#import "RealtimeSearchUtil.h"
#import "UserProfileManager.h"
#import "EaseChineseToPinyin.h"


@implementation NSString (search)

//根据用户昵称进行搜索
- (NSString*)showName
{
    return [[UserProfileManager sharedInstance] getNickNameWithUsername:self];
}
@end

typedef void (^isGetBlacklist)(BOOL isfinish);

@interface BlackListVC ()<UISearchBarDelegate, UISearchDisplayDelegate,UIActionSheetDelegate,EaseUserCellDelegate>

@property (strong, nonatomic) NSMutableArray *sectionTitles;
@property (strong, nonatomic) NSMutableArray *contactsSource;

@property (strong, nonatomic) EMSearchBar *searchBar;

@property (strong, nonatomic) EMSearchDisplayController *searchController;

@end

@implementation BlackListVC

- (void)viewDidLoad {
    [super viewDidLoad];
    
    _contactsSource = [NSMutableArray array];
    _sectionTitles = [NSMutableArray array];
    
    [self searchController];
    self.searchBar.frame = CGRectMake(0, 0, self.view.frame.size.width, 44);
    [self.view addSubview:self.searchBar];
    
    self.tableView.frame = CGRectMake(0, self.searchBar.frame.size.height, self.view.frame.size.width, self.view.frame.size.height - self.searchBar.frame.size.height);
    
    //获取黑名单
    [self getMyBlackList:nil];
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    self.showTableBlankView = YES;
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (EMSearchDisplayController *)searchController
{
    if (_searchController == nil) {
        _searchController = [[EMSearchDisplayController alloc] initWithSearchBar:self.searchBar contentsController:self];
        _searchController.delegate = self;
        _searchController.searchResultsTableView.separatorStyle = UITableViewCellSeparatorStyleNone;
        
        __weak BlackListVC *weakSelf = self;
        [_searchController setCellForRowAtIndexPathCompletion:^UITableViewCell *(UITableView *tableView, NSIndexPath *indexPath) {
            static NSString *CellIdentifier = @"ContactListCell";
            BaseTableViewCell *cell = (BaseTableViewCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
            
            // Configure the cell...
            if (cell == nil) {
                cell = [[BaseTableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];
            }
            
            NSString *buddy = [weakSelf.searchController.resultsSource objectAtIndex:indexPath.row];
            cell.imageView.image = [UIImage imageNamed:@"chatListCellHead.png"];
            cell.textLabel.text = buddy;
            cell.username = buddy;
            
            return cell;
        }];
        
        [_searchController setHeightForRowAtIndexPathCompletion:^CGFloat(UITableView *tableView, NSIndexPath *indexPath) {
            return 50;
        }];
        
        [_searchController setDidSelectRowAtIndexPathCompletion:^(UITableView *tableView, NSIndexPath *indexPath) {
            [tableView deselectRowAtIndexPath:indexPath animated:YES];
            
            NSString *buddy = [weakSelf.searchController.resultsSource objectAtIndex:indexPath.row];
            NSString *loginUsername = [[EMClient sharedClient] currentUsername];
            if (loginUsername && loginUsername.length > 0) {
                if ([loginUsername isEqualToString:buddy]) {
                    
                    UIAlertControllerActionBlock ok=^(UIAlertAction *acton){
                        MOSLog(@"ok");
                    };
                    [UIAlertController showAlertTltileWith:NSLocalizedString(@"prompt", @"Prompt") andMessage:NSLocalizedString(@"friend.notChatSelf", @"can't talk to yourself") andActions:@{NSLocalizedString(@"ok", @"OK"):ok} andShowVC:weakSelf andAlertStyle:UIAlertControllerStyleAlert];
            
                    
                    return;
                }
            }
            
            [weakSelf.searchController.searchBar endEditing:YES];
            
        }];
    }
    
    return _searchController;
}
- (UISearchBar *)searchBar
{
    if (_searchBar == nil) {
        _searchBar = [[EMSearchBar alloc] init];
        _searchBar.delegate = self;
        _searchBar.placeholder = NSLocalizedString(@"search", @"Search");
        _searchBar.backgroundColor = [UIColor colorWithRed:0.747 green:0.756 blue:0.751 alpha:1.000];
    }
    
    return _searchBar;
}

#pragma mark - load data
-(void)getMyBlackList:(isGetBlacklist)finish{
    
    __weak typeof(self) weakself = self;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
        EMError *error = nil;

        NSArray *blacklist = [[EMClient sharedClient].contactManager getBlackListFromServerWithError:&error];
        dispatch_async(dispatch_get_main_queue(), ^{
            if (!error) {
                MOSLog(@"%@",blacklist);
                [_contactsSource addObjectsFromArray:blacklist];

//                EaseUserModel *model = [[EaseUserModel alloc] initWithBuddy:buddy];//数组里面的是buddy
                [weakself _sortDataArray:blacklist];
                
            }else{
                [self showHint:error.description];
            }
            
            if (finish) {
                finish(YES);
            }
            
        });
       
        
    });
    
}

- (void)_sortDataArray:(NSArray *)buddyList
{
    [self.dataArray removeAllObjects];
    [self.sectionTitles removeAllObjects];
    
    NSMutableArray *contactsSource = [NSMutableArray array];
    
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{

        for (NSString *buddy in buddyList) {
            EaseUserModel *model = [[EaseUserModel alloc] initWithBuddy:buddy];//数组里面的是buddy
            [contactsSource addObject:model];
        }
        
        //建立索引的核心, 返回27，是a－z和＃
        UILocalizedIndexedCollation *indexCollation = [UILocalizedIndexedCollation currentCollation];
        [self.sectionTitles addObjectsFromArray:[indexCollation sectionTitles]];
        
        NSInteger highSection = [self.sectionTitles count];
        NSMutableArray *sortedArray = [NSMutableArray arrayWithCapacity:highSection];
        for (int i = 0; i < highSection; i++) {
            NSMutableArray *sectionArray = [NSMutableArray arrayWithCapacity:1];
            [sortedArray addObject:sectionArray];
        }
        
        //按首字母分组
        for (EaseUserModel *model in contactsSource) {
            if (model) {
                model.avatarImage = [UIImage imageNamed:@"EaseUIResource.bundle/user"];
                model.nickname = [[UserProfileManager sharedInstance] getNickNameWithUsername:model.buddy];
                
                NSString *firstLetter = [EaseChineseToPinyin pinyinFromChineseString:[[UserProfileManager sharedInstance] getNickNameWithUsername:model.buddy]];
                NSInteger section = [indexCollation sectionForObject:[firstLetter substringToIndex:1] collationStringSelector:@selector(uppercaseString)];
                
                NSMutableArray *array = [sortedArray objectAtIndex:section];
                [array addObject:model];
            }
        }
        
        //每个section内的数组排序
        for (int i = 0; i < [sortedArray count]; i++) {
            NSArray *array = [[sortedArray objectAtIndex:i] sortedArrayUsingComparator:^NSComparisonResult(EaseUserModel *obj1, EaseUserModel *obj2) {
                NSString *firstLetter1 = [EaseChineseToPinyin pinyinFromChineseString:obj1.nickname];
                firstLetter1 = [[ self secondSubStringWith:firstLetter1] uppercaseString];
                NSString *firstLetter2 = [EaseChineseToPinyin pinyinFromChineseString:obj2.nickname];
                firstLetter2 = [[self secondSubStringWith:firstLetter2] uppercaseString];
                
                return [firstLetter1 caseInsensitiveCompare:firstLetter2];
            }];
            
            
            [sortedArray replaceObjectAtIndex:i withObject:[NSMutableArray arrayWithArray:array]];
        }
        
        //去掉空的section
        for (NSInteger i = [sortedArray count] - 1; i >= 0; i--) {
            NSArray *array = [sortedArray objectAtIndex:i];
            if ([array count] == 0) {
                [sortedArray removeObjectAtIndex:i];
                [self.sectionTitles removeObjectAtIndex:i];
            }
        }
        
        [self.dataArray addObjectsFromArray:sortedArray];
        
        dispatch_async(dispatch_get_main_queue(), ^{
            
            
            [self.tableView reloadData];
            
        });
        
    });
    
}

//按第二个字母排序
-(NSString*)secondSubStringWith:(NSString*)str{
    if (str&&str.length>1) {
        return [str substringWithRange:NSMakeRange(1, 1)];
    }
    return @"a";
}

#pragma mark - Table view data source

- (NSInteger)numberOfSectionsInTableView:(UITableView *)tableView
{
    // Return the number of sections.
    return [self.dataArray count];
}

- (NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section
{
    // Return the number of rows in the section.

    return [[self.dataArray objectAtIndex:(section)] count];
}

- (UITableViewCell *)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath
{
    static NSString *CellIdentifier = @"blacklist";
    EaseUserCell *cell = (EaseUserCell *)[tableView dequeueReusableCellWithIdentifier:CellIdentifier];
    
    // Configure the cell...
    if (cell == nil) {
        cell = [[EaseUserCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:CellIdentifier];

    }
    
    EaseUserModel *model = [[self.dataArray objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
    cell.titleLabel.text = model.nickname;
    cell.indexPath = indexPath;
    cell.avatarView.imageView.image = [UIImage imageNamed:@"chat_item_file"];
    cell.delegate = self;
    
    return cell;
}

#pragma mark - Table view delegate



- (NSArray *)sectionIndexTitlesForTableView:(UITableView *)tableView
{
    return self.sectionTitles;
}

- (CGFloat)tableView:(UITableView *)tableView heightForHeaderInSection:(NSInteger)section
{
    
    return 22;
    
}

- (UIView *)tableView:(UITableView *)tableView viewForHeaderInSection:(NSInteger)section
{
    
    UIView *contentView = [[UIView alloc] init];
    [contentView setBackgroundColor:[UIColor colorWithRed:0.88 green:0.88 blue:0.88 alpha:1.0]];
    UILabel *label = [[UILabel alloc] initWithFrame:CGRectMake(10, 0, 100, 22)];
    label.backgroundColor = [UIColor clearColor];
    [label setText:[self.sectionTitles objectAtIndex:(section )]];
    [contentView addSubview:label];
    return contentView;
}

- (UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath
{
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath
{
    [tableView deselectRowAtIndexPath:indexPath animated:YES];
    
    NSInteger section = indexPath.section;
    NSInteger row = indexPath.row;
     EaseUserModel *model = [[self.dataArray objectAtIndex:section] objectAtIndex:row];
    MOSLog(@"%@-%@",model.nickname,model.buddy);
}

- (BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath
{
    // Return NO if you do not want the specified item to be editable.

    return YES;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        NSString *loginUsername = [[EMClient sharedClient] currentUsername];
        EaseUserModel *model = [[self.dataArray objectAtIndex:(indexPath.section - 1)] objectAtIndex:indexPath.row];
        if ([model.buddy isEqualToString:loginUsername]) {
            
            UIAlertControllerActionBlock ok=^(UIAlertAction *acton){
                MOSLog(@"ok");
            };
            [UIAlertController showAlertTltileWith:NSLocalizedString(@"prompt", @"Prompt") andMessage:NSLocalizedString(@"friend.notDeleteSelf", @"can't delete self") andActions:@{NSLocalizedString(@"ok", @"OK"):ok} andShowVC:self andAlertStyle:UIAlertControllerStyleAlert];
            
            
            return;
        }
        
        EMError *error = [[EMClient sharedClient].contactManager deleteContact:model.buddy];
        if (!error) {
            [[EMClient sharedClient].chatManager deleteConversation:model.buddy deleteMessages:YES];
            
            [tableView beginUpdates];
            [[self.dataArray objectAtIndex:(indexPath.section )] removeObjectAtIndex:indexPath.row];
            [self.contactsSource removeObject:model.buddy];
            [tableView  deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            [tableView endUpdates];
        }
        else{
            [self showHint:[NSString stringWithFormat:NSLocalizedString(@"deleteFailed", @"Delete failed:%@"), error.errorDescription]];
            [tableView reloadData];
        }
    }
}

#pragma mark - UISearchBarDelegate

- (BOOL)searchBarShouldBeginEditing:(UISearchBar *)searchBar
{
    [searchBar setShowsCancelButton:YES animated:YES];
    
    return YES;
}

- (void)searchBar:(UISearchBar *)searchBar textDidChange:(NSString *)searchText
{
    __weak typeof(self) weakSelf = self;
    [[RealtimeSearchUtil currentUtil] realtimeSearchWithSource:self.contactsSource searchText:(NSString *)searchText collationStringSelector:@selector(showName) resultBlock:^(NSArray *results) {
        if (results) {
            dispatch_async(dispatch_get_main_queue(), ^{
                [weakSelf.searchController.resultsSource removeAllObjects];
                [weakSelf.searchController.resultsSource addObjectsFromArray:results];
                [weakSelf.searchController.searchResultsTableView reloadData];
            });
        }
    }];
}

- (BOOL)searchBarShouldEndEditing:(UISearchBar *)searchBar
{
    return YES;
}

- (void)searchBarSearchButtonClicked:(UISearchBar *)searchBar
{
    [searchBar resignFirstResponder];
}

- (void)searchBarCancelButtonClicked:(UISearchBar *)searchBar
{
    searchBar.text = @"";
    [[RealtimeSearchUtil currentUtil] realtimeSearchStop];
    [searchBar resignFirstResponder];
    [searchBar setShowsCancelButton:NO animated:YES];
}

#pragma mark - EaseUserCellDelegate

- (void)cellLongPressAtIndexPath:(NSIndexPath *)indexPath
{
    UIAlertControllerActionBlock cancel= ^(UIAlertAction *action){};
    UIAlertControllerActionBlock  remove = ^(UIAlertAction *action){
        __weak typeof(self) weakSelf = self;
        
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            EaseUserModel *model = [[self.dataArray objectAtIndex:indexPath.section] objectAtIndex:indexPath.row];
            EMError *error = nil;
           error = [[EMClient sharedClient].contactManager removeUserFromBlackList:model.buddy];
            
            dispatch_async(dispatch_get_main_queue(), ^{
                
                if (!error) {
                    
                    [weakSelf.tableView beginUpdates];
                    [[weakSelf.dataArray objectAtIndex:(indexPath.section)] removeObjectAtIndex:indexPath.row];
                    [weakSelf.contactsSource removeObject:model.buddy];
                    [weakSelf.tableView  deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
                    [weakSelf.tableView endUpdates];
                    
                }else{
                    [self showHint:error.description];
                }
                
            });
            
        });
    
    };
    
    [UIAlertController showAlertTltileWith:nil andMessage:nil andActions:@{NSLocalizedString(@"cancel", @"Cancel"):cancel,NSLocalizedString(@"friend.remove", @"remove the blacklist"):remove} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet];

}

#pragma mark - refresh 
- (void)tableViewDidTriggerHeaderRefresh{
    __weak typeof(self) weakSelf = self;
    [self getMyBlackList:^(BOOL isfinish) {
        [weakSelf tableViewDidFinishTriggerHeader:YES reload:NO];
    }];

    
}//下拉刷新事件

- (void)tableViewDidTriggerFooterRefresh{

    __weak typeof(self) weakSelf = self;
    [self getMyBlackList:^(BOOL isfinish) {
        [weakSelf tableViewDidFinishTriggerHeader:NO reload:NO];
    }];

    
}//上拉加载事件

@end
