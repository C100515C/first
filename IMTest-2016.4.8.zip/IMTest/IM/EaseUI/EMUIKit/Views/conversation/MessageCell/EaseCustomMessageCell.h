//
//  CustomMessageCell.h
//  ChatDemo-UI3.0
//
//  Created by EaseMob on 15/8/26.
//  Copyright (c) 2015年 easemob.com. All rights reserved.
//

#import "EaseBaseMessageCell.h"

@interface EaseCustomMessageCell : EaseBaseMessageCell

@end
