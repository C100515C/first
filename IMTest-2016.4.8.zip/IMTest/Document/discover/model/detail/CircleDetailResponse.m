//
//  CircleDetailResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleDetailResponse.h"

static const CGFloat BasicHeight = 58.0f;
static const CGFloat TopView_height = 37.0f;

@implementation CircleDetailResponse

-(UIColor*)getLabelColor{
    if ([_thread_type isEqualToString:@"1"]) {
        return [UIColor redColor];
    }else if ([_thread_type isEqualToString:@"2"]){
        return [UIColor orangeColor];
    }else{
        
        return RGB(57, 189,104, 1);
    }
}

-(NSString*)thread_type{
    if ([_thread_type integerValue]==1) {
        return @"吐槽";
        
    }else if ([_thread_type integerValue]==2){
        return @"提问" ;
        
    }else{
        return @"推荐";
    }
}

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size_content = [self getStringSizeWith:_postInfo.content fontSize:15.0f showSize:CGSizeMake(SCREEN_WIDTH-16, 2000)];
        _cellHeight = size_content.height+BasicHeight+self.new_topHeight;
        
        return _cellHeight;
    }
}

-(CGFloat)new_topHeight{
    
    if (_new_topHeight) {
        return _new_topHeight;
    }else{
        CGSize size_title = [self getStringSizeWith:_title fontSize:16.0f showSize:CGSizeMake(SCREEN_WIDTH-16, 2000)];
        return size_title.height+TopView_height;
    }
}

-(NSMutableAttributedString*)timeFrom{
    
    if (_timeFrom) {
        return _timeFrom;
    }
    NSMutableAttributedString *tmp = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@ 来自%@圈",self.created_at,self.forum_name]];
        
    [tmp addAttribute:NSForegroundColorAttributeName value:RGB(145, 145, 145, 1) range:NSMakeRange(0, tmp.length) ];
    [tmp addAttribute:NSForegroundColorAttributeName value:RGB(67, 195, 122, 1) range:NSMakeRange(self.created_at.length+3, self.forum_name.length)];
    _timeFrom = tmp;
    return _timeFrom;
    
}

@end

static const CGFloat HotBasicHeight = 40.0f;

@implementation CircleDetailHotResponse

-(CGFloat)cellHeight{
    if (_cellHeight) {
        return _cellHeight;
    }else{
        _cellHeight = HotBasicHeight;
        return _cellHeight;
    }
}

-(NSString*)thread_type{
    if ([_thread_type integerValue]==1) {
        return @"置顶";
        
    }else if ([_thread_type integerValue]==2){
        return @"置顶" ;
        
    }else{
        return @"置顶";
    }
}

-(UIColor*)getLabelColor{
    if ([_thread_type isEqualToString:@"1"]) {
        return [UIColor redColor];
    }else if ([_thread_type isEqualToString:@"2"]){
        return [UIColor redColor];
    }else{
        
        return [UIColor redColor];
    }
}

@end

@implementation CircleDetailItemListResponse

-(NSMutableArray*)itemList{
    if (_itemList==nil) {
        _itemList = [NSMutableArray array ];
    }
    return _itemList;
}

+(Class)itemList_class{
    return [CircleDetailResponse class];
}

@end

@implementation CircleDetailPostInforResponse

@end
@implementation CircleDetailUserInforResponse

@end

@implementation CircleDetailItemListOfFindResponse

-(NSMutableArray *)items{
    if (_items==nil) {
        _items = [NSMutableArray array];
    }
    return _items;
}
-(NSMutableArray *)recommend{
    if (_recommend==nil) {
        _recommend = [NSMutableArray array];
    }
    return _recommend;
}

+(Class)items_class{
    return [CircleDetailResponse class];

}

+(Class)recommend_class{
    return [CircleDetailHotResponse class];
}
@end

@implementation CircleDetail_metaResponse

@end

@implementation CircleDetailHeaderResponse

-(NSMutableAttributedString*)attFollow_count{
    
    if (_attFollow_count) {
        return _attFollow_count;
    }
    NSMutableAttributedString *tmp = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@个人关注",self.follow_count]];
        
    [tmp addAttribute:NSForegroundColorAttributeName value:RGB(145, 145, 145, 1) range:NSMakeRange(self.follow_count.length, 4) ];
    [tmp addAttribute:NSForegroundColorAttributeName value:RGB(67, 195, 122, 1) range:NSMakeRange(0, self.follow_count.length)];
    _attFollow_count = tmp;
    return _attFollow_count;
    
}

-(NSString*)forum_name{
    if (_forum_name) {
        return  [NSString stringWithFormat:@"%@圈",_forum_name];
    }
    return _forum_name;
}

@end