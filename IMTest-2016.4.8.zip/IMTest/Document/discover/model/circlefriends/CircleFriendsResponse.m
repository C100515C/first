//
//  CircleFriendsResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/15.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleFriendsResponse.h"

static const CGFloat BasicHeight = 65.0f;
static const CGFloat font = 10.0f;
static const CGFloat focusHeight = 31.0f;

@implementation CircleFriendsResponse

+(Class)forum_label_class{
    return [NSDictionary class];
}

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size_content = [self getStringSizeWith:_signature fontSize:14.0f showSize:CGSizeMake(SCREEN_WIDTH-24, 2000)];
        
        _cellHeight = size_content.height+BasicHeight+self.labelBackViewHeight;
        
        return _cellHeight;
    }
}

-(CGFloat)labelBackViewHeight{
    if (_labelBackViewHeight) {
        return _labelBackViewHeight;
    }
    if (self.forum_label.count!=0) {
        CGFloat x=0,dis_x=5.0f,enddis=10.0f;
        CGFloat height = 15.0f,dis_y = 5.0f;
        
        CGFloat tmpWidth = x;
        CGFloat row = 1;
        
        for (NSString *str in [self getForumLabelNames]) {
            CGSize size = [self getStringSizeWith:str fontSize:font showSize:CGSizeMake(100, 2000)];
            tmpWidth = tmpWidth +size.width+dis_x;
            if (tmpWidth>SCREEN_WIDTH-enddis) {//需要减去后面的要留出的宽度
                row ++;
                tmpWidth = tmpWidth-SCREEN_WIDTH+enddis;
            }
        }
        _labelBackViewHeight = (row*height+(row-1)*dis_y);
        return _labelBackViewHeight;
    }
    return focusHeight;
}

-(NSArray*)getForumLabelNames{
    NSMutableArray *arr = [NSMutableArray array];
    
    if (self.forum_label && self.forum_label.count!=0) {
        
        for (NSDictionary *dic in self.forum_label) {
            [arr addObject:dic[@"forum_name"]];
        }
    }else{
        return @[@"无"];
    }
    
    return arr;
}

@end

@implementation CircleFriendsItemsResponse

-(NSMutableArray*)items{
    if (_items==nil) {
        _items = [NSMutableArray array];
    }
    return _items;
}

+(Class)items_class{
    return [CircleFriendsResponse class];
}
@end

@implementation CircleFriends_metaResponse

@end
