//
//  CircleFriendsVC.m
//  IMTest
//
//  Created by chenchen on 16/3/15.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleFriendsVC.h"

#import "CircleFriendsCell.h"

#import "UIViewController+HUD.h"

#import "CircleFriendsResponse.h"
#import "CircleFriendsRequest.h"
#import "SingletonServ.h"

#import "PersonalHomepageVC.h"

@interface CircleFriendsVC (){
    NSMutableArray *_dataSource;
    int _page;
}

@property (weak, nonatomic) IBOutlet UITableView *myTable;

@end

@implementation CircleFriendsVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self setNav];
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _dataSource = [[NSMutableArray alloc] init];
    _page = 1;
    [self.tableView registerNib:[UINib nibWithNibName:@"CircleFriendsCell" bundle:nil] forCellReuseIdentifier:CircleFriendsCell_id];
    
    [self makeModelWith:_page with:nil andHeaderRef:YES];

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setNav{
    [super setNav];

}

-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    
    CircleFriendsRequest *req = [[CircleFriendsRequest alloc] init];
    [req mySetForum_id:self.forum_id];
    req.page = [NSString stringWithFormat:@"%d", page ];
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
       
        if (responeseError==nil) {
            if (isHeaderRef) {
                [_dataSource removeAllObjects];
            }
            CircleFriendsItemsResponse *model = (CircleFriendsItemsResponse*)responseDataModel;
            [_dataSource addObjectsFromArray:model.items];
            [weakself.tableView reloadData];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        [weakself hideHud];
        
        if (finishBlock) {
            finishBlock(YES);
        }
    }];
    
}

#pragma mark - table
- (void)tableViewDidTriggerHeaderRefresh{
    _page = 1;
    __weak typeof(self) weakself = self;
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:YES reload:NO];
        
    } andHeaderRef:YES];
//    [self tableViewDidFinishTriggerHeader:YES reload:NO];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    _page ++;
    __weak typeof(self) weakself = self;
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:NO reload:NO];
        
    } andHeaderRef:NO];
//    [self tableViewDidFinishTriggerHeader:NO reload:NO];
    
}//上拉加载事件

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    CircleFriendsResponse *model = (CircleFriendsResponse*)[_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    
    CircleFriendsCell *cell = [tableView dequeueReusableCellWithIdentifier:CircleFriendsCell_id];
        
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"CircleFriendsCell" owner:nil options:nil] firstObject];
    }
        
    CircleFriendsResponse *model = (CircleFriendsResponse*)[_dataSource objectAtIndex:indexPath.row];
        
    [cell setCellWith:model];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CircleFriendsResponse *model = (CircleFriendsResponse*)[_dataSource objectAtIndex:indexPath.row];
    PersonalHomepageVC *vc = [[PersonalHomepageVC alloc] init];
    vc.userid = model.user_id;
    [self.navigationController pushViewController:vc animated:YES];
}


@end
