//
//  CircleDetailCell.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleDetailCell.h"
#import "CircleDetailResponse.h"
//#import "BasicUIImageView.h"
//#import "BasicLabel.h"

@interface CircleDetailCell ()

@property (weak, nonatomic) IBOutlet BasicUIImageView *headerImage;
@property (weak, nonatomic) IBOutlet UILabel *nickname;
@property (weak, nonatomic) IBOutlet BasicLabel *titileType;

@property (weak, nonatomic) IBOutlet UILabel *title;
@property (weak, nonatomic) IBOutlet UILabel *content;
@property (weak, nonatomic) IBOutlet UILabel *timeAndFrom;
@property (weak, nonatomic) IBOutlet UILabel *counts;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topViewHeight;

@end

@implementation CircleDetailCell

-(void)awakeFromNib{
    [self.headerImage setRaduis];
    [self.titileType setBorder];
}

-(void)setCellWith:(CircleDetailResponse *)model andFormName:(NSString *)name{
    
    if (name) {
        model.forum_name = name;
    }
    self.title.text = model.title;
    self.content.text = model.postInfo.content;
//    self.timeAndFrom.text = model.created_at;
    self.timeAndFrom.attributedText = model.timeFrom;
    self.titileType.text = model.thread_type;
    self.titileType.LYJ_textColor = [model getLabelColor];
    self.counts.text = model.post_count;
    
    [self.headerImage sd_setImageWithURL:[NSURL URLWithString:model.user_info.avatar] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.topViewHeight.constant = model.new_topHeight;
    
}

@end
