//
//  CircleFriendsCell.m
//  IMTest
//
//  Created by chenchen on 16/3/15.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleFriendsCell.h"
#import "CircleFriendsResponse.h"
#import "CC_LabelsOfView.h"

@interface CircleFriendsCell ()

@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;

@property (weak, nonatomic) IBOutlet UIImageView *genderImage;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet CC_LabelsOfView *labelBackView;
@property (weak, nonatomic) IBOutlet UILabel *content;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *labelBackViewHeight;

@end

@implementation CircleFriendsCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self.headerIcon setRaduis];
    [_labelBackView setStart_x:0 andY:5.0f andInterval:5.0f andLabelHeight:15.0f andEndDistance:10.0f andLabelType:CCBlueFrameLabel];
}

-(void)setCellWith:(CircleFriendsResponse *)model{
    
    self.name.text = model.username;
//    model.labelBackViewHeight = [_labelBackView set_MyLabelsCanChangeRowsWith:@[@"老大老老大老老大老",@"老大老老大老老大老",@"老老大老老大老大老",@"老大老大老老",@"老大老大老老"]];
    self.labelBackViewHeight.constant = model.labelBackViewHeight;
    self.time.text = model.recently_online;
    self.content.text = model.signature;
    [self.labelBackView set_MyLabelsCanChangeRowsWith:[model getForumLabelNames]];
    
    if ([model.gender intValue]==1) {
        self.genderImage.image = [UIImage imageNamed:@"icon_sm"];
    }else{
        self.genderImage.image = [UIImage imageNamed:@"icon_sw"];
    }
    
//    [self.labelBackView layoutIfNeeded];
//    [self.content layoutIfNeeded];
//    [self layoutIfNeeded];
    
}

@end
