//
//  NoticeCellResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface NoticeCellResponse : BasicResponse

@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *type;
@property (nonatomic,copy) NSMutableArray *title;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *from_user_id;
@property (nonatomic,copy) NSString *to_user_id;
@property (nonatomic,copy) NSString *source_url;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *is_read;
@property (nonatomic,copy) NSString *from_user_name;
@property (nonatomic,copy) NSString *type_name;
@property (nonatomic,copy) NSString *from_username;
@property (nonatomic,copy) NSString *thread_id;

@property (nonatomic,copy) NSString *nicknameAndOp;

+(Class)title_class;
@end

@interface NoticeCellItems_metaResponse : BasicResponse
@property (nonatomic,copy) NSString *totalCount;
@property (nonatomic,copy) NSString *pageCount;
@property (nonatomic,copy) NSString *currentPage;
@property (nonatomic,copy) NSString *perPage;
@end

@interface NoticeCellItemsResponse : BasicResponse

@property (nonatomic,strong) NSMutableArray *items;
@property (nonatomic,strong) NoticeCellItems_metaResponse *_meta;

+(Class)items_class;

@end