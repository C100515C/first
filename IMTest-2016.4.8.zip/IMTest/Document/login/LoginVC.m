//
//  LoginVC.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LoginVC.h"

#import "RegisterVC.h"
#import "RootVC.h"
#import "AppDelegate.h"
#import "RootVC.h"

#import "UMSocial.h"
#import "CC_SsoModel.h"

#import "UIViewController+HUD.h"

#import "SingletonServ.h"
#import "LoginRequest.h"
#import "LoginResponse.h"

@interface LoginVC ()<UITextFieldDelegate,UMSocialUIDelegate,UIAlertViewDelegate>//,UMSocialDataDelegate

@property (weak, nonatomic) IBOutlet UIScrollView *backScrollView;
@property (weak, nonatomic) IBOutlet UIView *scrollContentView;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *scrollContentViewHeight;

@property (weak, nonatomic) IBOutlet UITextField *phoneNumber;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UIButton *forgetPassword;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;
@property (weak, nonatomic) IBOutlet UIButton *passwordState;

@property (assign,nonatomic) BOOL showPassword;

@property (nonatomic,assign) PlatformName_cc currentPlatformName;
@property (nonatomic,strong) LoginResponse *loginModel;
@property (nonatomic,copy) NSString *loginUserName;

- (IBAction)changePasswordState:(UIButton *)sender;

- (IBAction)weiboLoginAction:(UIButton *)sender;
- (IBAction)loginAction:(UIButton *)sender;
- (IBAction)registerAction:(UIButton *)sender;
- (IBAction)weichatLoginAction:(UIButton *)sender;
- (IBAction)QQLoginAction:(UIButton *)sender;
- (IBAction)forgetPasswordClicked:(UIButton *)sender;

@end

@implementation LoginVC

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    
}

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = YES;
    
    [self setScrollSize];
    
    self.phoneNumber.delegate = self;
    self.password.delegate = self;
    self.showPassword = NO;
    self.password.secureTextEntry = YES;
    
    [self setNav];
    
    [self setMyLoginBtn];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - property
-(void)setLoginUserName:(NSString *)loginUserName{
    if (loginUserName) {
        _loginUserName = [CC_NSStringHandle filteringTheBlankSpaceWith:loginUserName];
    }
}

#pragma mark - UI
-(void)setMyLoginBtn{
    
    self.loginBtn.clipsToBounds = YES;
    self.loginBtn.layer.cornerRadius = 3.0f;
}

-(void)setScrollSize{
    self.backScrollView.contentSize = CGSizeMake(SCREEN_WIDTH, 2.0*SCREEN_WIDTH);
    self.scrollContentViewHeight.constant = 2.0*SCREEN_WIDTH;
    self.backScrollView.scrollEnabled = YES;
    self.backScrollView.delegate = self;
}

-(void)setNav{
    
    [super setNav];
    
    self.title = @"登录";
    
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;

    [nav navItemBtnHidenWith:YES andIsRight:NO andCurrentVC:self];
    
}
#pragma mark - EMPushManagerDelegateDevice
// 打印收到的apns信息
-(void)didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    MOSLog(@"%@",userInfo);
}

#pragma mark - btn action

-(void)dismissVC:(UIButton*)btn{

    [self dismissViewControllerAnimated:YES completion:^{
        //*
         BOOL isAutoLogin = [EMClient sharedClient].options.isAutoLogin;
         if (!isAutoLogin) {
         dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
             NSString *userid = [NSString stringWithFormat:@"%@",[[UserProfileManager sharedInstance] getUserId]];

             EMError *error = [[EMClient sharedClient] loginWithUsername:userid password:@"123456"];
             dispatch_async(dispatch_get_main_queue(), ^{
                 if (!error) {
                     MOSLog(@"登陆成功");
                     //设置成自动登陆
                     [[EMClient sharedClient].options setIsAutoLogin:YES];
                     NSString *name = [[UserProfileManager sharedInstance] getCurUsername];
                     [[EMClient sharedClient] setApnsNickname:name];
         
                 }else{
                     MOSLog(@"登陆失败=%@",error.errorDescription);
                 }
             });
         
            });
         }
         //*/
        
        AppDelegate *app = [UIApplication sharedApplication].delegate;
        RootVC *root = (RootVC*)app.window.rootViewController;
        
        [root refreshVCWith:0];
    }];
}

- (IBAction)loginAction:(UIButton *)sender {
    
    if ([self judgeVerificationCodeWith:self.phoneNumber.text] && [self judgePhoneWith:self.password.text]) {
        
        [self loginRequest];
        
    }else{
        [self showHint:@"昵称和密码不能为空" yOffset:-300];
    }
    
}

-(void)didAutoLoginWithError:(EMError*)error{
    MOSLog(@"自动登陆回掉");
}

- (IBAction)registerAction:(UIButton *)sender {
    RegisterVC *vc = [[RegisterVC alloc] init];
    vc.isFindPassword = NO;
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)forgetPasswordClicked:(UIButton *)sender {
    RegisterVC *vc = [[RegisterVC alloc] init];
    vc.isFindPassword = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

- (IBAction)weichatLoginAction:(UIButton *)sender {
    self.currentPlatformName = WeiChat;
    [self showHint:@"功能尚未开通" yOffset:-200];
    return;
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToWechatSession]) {
    
        MOSLog(@"未授权");
        [self get_SsoWith:UMSocialSnsTypeWechatSession];

        return;
    }
    [self get_SsoInforWith:UMShareToWechatSession];

}

- (IBAction)QQLoginAction:(UIButton *)sender {
    self.currentPlatformName = QQ;
    [self showHint:@"功能尚未开通" yOffset:-200];
    return;
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToQQ]) {
        MOSLog(@"未授权");
        [self get_SsoWith:UMSocialSnsTypeMobileQQ];
        
        return;
    }
    [self get_SsoInforWith:UMShareToQQ];

}

- (IBAction)weiboLoginAction:(UIButton *)sender {
    self.currentPlatformName = Sina;
    
    [self showHint:@"功能尚未开通" yOffset:-200];
    return;
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToSina]) {
        
        
        MOSLog(@"未授权");
        [self get_SsoWith:UMSocialSnsTypeSina];
        
        return;
    }
    [self get_SsoInforWith:UMShareToSina];
}

#pragma mark - UM

/**
 *  根据不同的type 获取不同的平台授权
 *
 *  @param tag 平台标识
 */
-(void)get_SsoWith:(UMSocialSnsType)type{
    
    NSString *platformName = [UMSocialSnsPlatformManager getSnsPlatformString:type];
    
    [UMSocialControllerService defaultControllerService].socialUIDelegate = self;
    UMSocialSnsPlatform *snsPlatform = [UMSocialSnsPlatformManager getSocialPlatformWithName:platformName];
    snsPlatform.loginClickHandler(self,[UMSocialControllerService defaultControllerService],YES,^(UMSocialResponseEntity *response){
        //          获取用户名、uid、token等
        MOSLog(@"获取授权=%@",response);
        if (response.responseCode == UMSResponseCodeSuccess) {
            UMSocialAccountEntity *snsAccount = [[UMSocialAccountManager socialAccountDictionary] valueForKey:platformName];
            MOSLog(@"username is %@, uid is %@, token is %@ iconUrl is %@",snsAccount.userName,snsAccount.usid,snsAccount.accessToken,snsAccount.iconURL);
            [self get_SsoInforWith:platformName];
            
        }
    });
}
/**
 *  获取授权平台 信息
 *
 *  @param platformName 平台名字
 */
-(void)get_SsoInforWith:(NSString*)platformName{
    
    [[UMSocialDataService defaultDataService] requestSnsInformation:platformName  completion:^(UMSocialResponseEntity *response){
        MOSLog(@"SnsInformation is %@",response.data);
        CC_SsoModel *model = [[CC_SsoModel alloc] init];
        [model set_myModelWith:response.data andPlatform:self.currentPlatformName];
        [self finishSsoPushCheckViewWith:model];
    }];
}
/**
 *  取消授权
 *
 *  @param platformName 平台名字
 */
-(void)cancel_SsoWith:(NSString*)platformName{
    
    [[UMSocialDataService defaultDataService] requestUnOauthWithType:platformName  completion:^(UMSocialResponseEntity *response){
        MOSLog(@"response is %@",response);
    }];
}
/**
 *  判断是否能跳转应用
 *
 *  @param urlStr 应用跳转url
 *
 *  @return 能否跳转
 */
-(BOOL)isCanJumpTarget:(NSString*)urlStr{
    NSString *url = [NSString stringWithFormat:@"%@://",urlStr];
    NSURL * myURL_APP = [NSURL URLWithString:url];
    BOOL iscan = NO;
    if ([[UIApplication sharedApplication] canOpenURL:myURL_APP]) {
        iscan = YES;
        //        [[UIApplication sharedApplication] openURL:myURL_APP];
        
    }
    
    return iscan;
}

/**
 *  取消授权
 *
 *  @param sender
 */
- (IBAction)cancelSso:(id)sender {
    //取消授权
    [self cancel_SsoWith:UMShareToSina];
    [self cancel_SsoWith:UMShareToQQ];
    [self cancel_SsoWith:UMShareToWechatSession];
    
}

/**
 *  新浪授权按钮点击
 *
 *  @param sender 按钮
 */
- (IBAction)sina_sso:(id)sender {
    self.currentPlatformName = Sina;
    
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToSina]) {
        
    
        return;
    }
    
        NSString *platformName = [UMSocialSnsPlatformManager getSnsPlatformString:UMSocialSnsTypeSina];
        [self get_SsoInforWith:platformName];
        [self get_SsoWith:UMSocialSnsTypeSina];
        

    
}
/**
 *  qq 授权按钮点击
 *
 *  @param sender 按钮
 */
- (IBAction)QQ_Sso:(id)sender {
    self.currentPlatformName = QQ;
    
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToQQ]) {
        
        return;
    }
    
        NSString *platformName = [UMSocialSnsPlatformManager getSnsPlatformString:UMSocialSnsTypeMobileQQ];
        [self get_SsoInforWith:platformName];

    
}
/**
 *  微信授权点击按钮
 *
 *  @param sender按钮
 */
- (IBAction)weichat_Sso:(id)sender {
    self.currentPlatformName = WeiChat;
    
    if (![UMSocialAccountManager isOauthAndTokenNotExpired:UMShareToWechatSession]) {
        
        return;
    }
    

        NSString *platformName = [UMSocialSnsPlatformManager getSnsPlatformString:UMSocialSnsTypeWechatSession];
        [self get_SsoInforWith:platformName];
    
}
/**
 *  完成授权 切换验证界面
 *  信息字典传到下级界面
 */
-(void)finishSsoPushCheckViewWith:(CC_SsoModel*)inforModel{
    MOSLog(@"拿到授权信息");
}

#pragma mark - btn
- (IBAction)changePasswordState:(UIButton *)sender {
    [self changePasswordStateWith:self.showPassword];

    self.showPassword = !self.showPassword;
}

-(void)changePasswordStateWith:(BOOL)showPassword{
    
    if (showPassword) {
        [self.passwordState setBackgroundImage:[UIImage imageNamed:@"dlicon_ck2"] forState:UIControlStateNormal];
        
    }else{
        [self.passwordState setBackgroundImage:[UIImage imageNamed:@"dlicon_ck1"] forState:UIControlStateNormal];
        
    }
    self.password.secureTextEntry = showPassword;

}


#pragma mark - scroll
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self.password resignFirstResponder];
    [self.phoneNumber resignFirstResponder];
}

#pragma mark - text field
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSInteger lenth = textField.text.length+string.length;
    if (textField == self.phoneNumber) {
        if (!(lenth<=16)) {
            [self showHint:@"昵称为2～16个字符" yOffset:-400];
            
            return NO;
        }
    }else{
        if (!(lenth<=16)) {
            [self showHint:@"密码为6～16个字符" yOffset:-400];
            
            return NO;
        }
    }
    
    return YES;
}

#pragma mark - net work
-(void)loginRequest{
    
    self.loginUserName = self.phoneNumber.text;
    
    LoginRequest *req = [[LoginRequest alloc] init];
    req.password = self.password.text;
    req.username = self.loginUserName;//self.phoneNumber.text;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"登陆中..."];
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            LoginResponse *model = (LoginResponse*)responseDataModel;
            weakself.loginModel = model;
            MOSLog(@"%@-%@-%@-%@",model.user_id,model.phone,model.token,model.avatar);
            NSDictionary *dic = @{@"imageUrl":model.avatar,@"signature":@" ",@"gender":@"0",@"isLogin":@(1),@"objectId":model.user_id,@"username":model.phone,@"nickname":model.token,@"address":@" ",@"answerCount":@"0",@"publicCount":@"0",@"friendCount":@"0",@"labels":@[@" ",@" ",@" ",@" "],@"birthdate":@" ",@"addres_id":@" ",@"avatar":model.avatar};
            [[UserProfileManager sharedInstance] storeUserInfor:dic];

            [weakself dismissVC:nil];
        }else{
            [weakself showHint:responeseError.msg yOffset:-100];
        }
        
        [weakself hideHud];
    }];
}

#pragma mark - judge str

-(BOOL)judgePhoneWith:(NSString*)num{
    if (self.phoneNumber.text.length>=2 && self.phoneNumber.text.length<=16) {
        return YES;
    }else{
        return NO;
    }
}

-(BOOL)judgeVerificationCodeWith:(NSString*)num{
    
    if (self.password.text.length>=2 && self.password.text.length<=16) {
        return YES;
        
    }else{
        return NO;
    }
}


@end
