//
//  GetSMSRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/21.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "GetSMSRequest.h"

@implementation GetSMSRequest

- (id)init
{
    self = [super init];
    if (self) {
        self.reqUrlPath = @"sms";
        
        //        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"GetSMS";
    }
    return self;
}

@end
