//
//  RegisterRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/21.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "RegisterRequest.h"

@implementation RegisterRequest

- (id)init
{
    self = [super init];
    if (self) {
        self.reqUrlPath = @"registers";
        
//        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"Register";
    }
    return self;
}

@end
