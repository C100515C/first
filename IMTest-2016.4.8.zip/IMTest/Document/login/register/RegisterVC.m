//
//  RegisterVC.m
//  IMTest
//
//  Created by chenchen on 16/3/8.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "RegisterVC.h"
#import "RegisterUserInforVC.h"
#import "ForgetAndFindPasswordVC.h"

#import "SingletonServ.h"
#import "GetSMSRequest.h"
#import "GetSMSResponse.h"

#import "UIViewController+HUD.h"

@interface RegisterVC ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *phoneNumber;
@property (weak, nonatomic) IBOutlet UITextField *verificationCode;
@property (weak, nonatomic) IBOutlet UIButton *getVerificationCodeBtn;

@property (strong, nonatomic) NSTimer *countTimer;
@property (nonatomic) int timeRemain;

@property (weak, nonatomic) IBOutlet UIView *topBackView;
- (IBAction)getVerificationCodeAction:(UIButton *)sender;

@end

@implementation RegisterVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = YES;
    
    self.verificationCode.delegate = self;
    self.phoneNumber.delegate = self;
    
    self.timeRemain = 60;
    
    [self.getVerificationCodeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
    
    [self setNav];
    
    [self setUIInit];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    [self.countTimer invalidate];
    self.countTimer = nil;
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    
    [self.countTimer invalidate];
    self.countTimer = nil;
    [self.getVerificationCodeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];

}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    [self.phoneNumber resignFirstResponder];
    [self.verificationCode resignFirstResponder];
}



#pragma mark - set UI
-(void)setUIInit{
    self.phoneNumber.keyboardType = UIKeyboardTypeNumberPad;
    self.verificationCode.keyboardType = UIKeyboardTypeNumberPad;

}

#pragma mark - net work
-(void)getSMSWith:(NSString*)phoneNum{

    GetSMSRequest *req = [[GetSMSRequest alloc] init];
    req.phone =  [self getPhoneNumberWith:self.phoneNumber.text andSeparateStr:@"-"];//self.phoneNumber.text;

    [[SingletonServ sharedInstance ] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
       
        if (responeseError == nil) {
            
            MOSLog(@"获取短信请求成功");
        }else{
            [self showHint:responeseError.msg yOffset:-200];

        }
        
    }];
}

#pragma mark - nav
-(void)setNav{
    [super setNav];

    // 设置navigationBar的背景颜色，根据需要自己设置
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    //     设置navigationController的title的字体颜色
    NSDictionary * dict=[NSDictionary dictionaryWithObject:[UIColor darkGrayColor] forKey:NSForegroundColorAttributeName];
    self.navigationController.navigationBar.titleTextAttributes = dict;
    self.title = @"注册";
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
//    [nav setNavBarBtnItemImageWith:@"topicon_back" andRightItem:NO andAction:@selector(popVC:) andTarget:self andVCIndex:1];
    [nav setBackBtnWith:@"topicon_back" withCurrentVC:self andBackAction:@selector(popVC:)];
    [nav setNavBarBtnItemTitleWith:@"下一步" andRightItem:YES andAction:@selector(pushVC:) andTarget:self andVCIndex:1 andTitleColor:RGB(81, 196, 127, 1)];
}

-(void)popVC:(UIButton*)btn{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)pushVC:(UIButton*)btn{
    
    if ([self judgeVerificationCodeWith:self.verificationCode.text] && [self judgePhoneWith:self.phoneNumber.text]) {
        BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
       
        if (self.isFindPassword) {
            ForgetAndFindPasswordVC *vc = [[ForgetAndFindPasswordVC alloc] init];
            NSString *userPhone = [self getPhoneNumberWith:self.phoneNumber.text andSeparateStr:@"-"];//self.phoneNumber.text;
            vc.userPhone = [CC_NSStringHandle filteringTheBlankSpaceWith:userPhone];
            vc.userVerCode = [CC_NSStringHandle filteringTheBlankSpaceWith:self.verificationCode.text];
            [nav CustomPushviewWith:vc];
        }else{
            RegisterUserInforVC *vc = [[RegisterUserInforVC alloc] init];
            NSString *userPhone = [self getPhoneNumberWith:self.phoneNumber.text andSeparateStr:@"-"];//self.phoneNumber.text;
            vc.userPhone = userPhone;
            vc.userVerCode = [CC_NSStringHandle filteringTheBlankSpaceWith:self.verificationCode.text];
            [nav CustomPushviewWith:vc];
        }
        
    }else{
        [self showHint:@"输入正确的验证码和电话号码" yOffset:-300];
    }
}

#pragma mark - timer
-(NSTimer*)countTimer{
    
    if (!_countTimer) {
        _countTimer = [NSTimer scheduledTimerWithTimeInterval:1
                                                           target:self
                                                         selector:@selector(oneSecondFlip)
                                                         userInfo:nil
                                                          repeats:YES];
    }
    
    return _countTimer;
}

-(UIButton*)getVerificationCodeBtn{
    
    if (_getVerificationCodeBtn) {
        _getVerificationCodeBtn.clipsToBounds = YES;
        _getVerificationCodeBtn.layer.cornerRadius = 5.0f;
    }
    
    return _getVerificationCodeBtn;
}

#pragma mark - judge str

-(BOOL)judgePhoneWith:(NSString*)num{
    if (self.phoneNumber.text.length>0 && self.phoneNumber.text.length<=13) {
        return YES;
    }else{
        return NO;
    }
}

-(BOOL)judgeVerificationCodeWith:(NSString*)num{
    
    if (self.verificationCode.text.length>0 && self.verificationCode.text.length<=6) {
        return YES;
        
    }else{
        return NO;
    }
}

#pragma mark - text field

-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
//    MOSLog(@"%@-%@-%@",self.phoneNumber.text,textField.text,string);

    if (![self judeTextNumWith:textField.text andNextChar:string]) {
        
        [self showHint:@"非法字符" yOffset:-400];
        
        return NO;
    }
    
     NSInteger lenth = textField.text.length+string.length;
    if (textField == self.phoneNumber) {
        if (lenth>13) {
            [self showHint:@"电话号码为11位" yOffset:-400];
            
            return NO;
        }
        
        if (range.location==3||range.location==8) {
            if (textField.text.length==3||textField.text.length==8) {
                NSString *s=[textField.text stringByAppendingString:@"-"];
                textField.text=s;
            }
        }
        
        return YES;

    }else{
        if (lenth>6) {
            [self showHint:@"验证码为6位" yOffset:-400];
            
            return NO;
        }
        return YES;

    }
}

-(BOOL)judeTextNumWith:(NSString*)text andNextChar:(NSString*)str{
    NSArray *arr = @[@"0",@"1",@"2",@"3",@"4",@"5",@"6",@"7",@"8",@"9",@""];
    for (int i=0; i<arr.count; i++ ) {
        if ([arr[i] isEqualToString:str]) {
            return YES;
        }
    }
    return NO;
}

-(NSString*)getPhoneNumberWith:(NSString*)phoneNumberText andSeparateStr:(NSString*)str{
    
    return [[phoneNumberText componentsSeparatedByString:str] componentsJoinedByString:@""];
}

#pragma mark 倒计时功能
- (void)timeCountStart
{
    [self.getVerificationCodeBtn setTitle:@"60秒后重新发验证码" forState:UIControlStateNormal];
    [self.countTimer fire];
}

- (void)oneSecondFlip
{
    self.timeRemain = self.timeRemain - 1;
    if (self.timeRemain == 0) {
        
        [self.countTimer invalidate];
        self.countTimer = nil;
        self.timeRemain = 60;
        self.getVerificationCodeBtn.enabled = YES;
        [self.getVerificationCodeBtn setTitle:@"重新发送" forState:UIControlStateNormal];
        return;
    }
    MOSLog(@"1 second flip");
    
    NSString *countTitle = [[NSString alloc] initWithFormat:@"%d秒后重新发验证码", self.timeRemain];
    
    [self.getVerificationCodeBtn setTitle:countTitle
                            forState:UIControlStateNormal];
}

#pragma mark - btn action
- (IBAction)getVerificationCodeAction:(UIButton *)sender {
    if (![self judgePhoneWith:self.phoneNumber.text]) {
        [self showHint:@"请输入正确电话号码" yOffset:-200];
        return;
    }
    [self timeCountStart];
    sender.enabled = NO;
    
    [self getSMSWith:nil];
}

@end
