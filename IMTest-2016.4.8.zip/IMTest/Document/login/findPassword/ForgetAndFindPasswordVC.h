//
//  ForgetAndFindPasswordVC.h
//  IMTest
//
//  Created by chenchen on 16/4/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface ForgetAndFindPasswordVC : BasicVC
@property (nonatomic,copy) NSString *userPhone;
@property (nonatomic,copy) NSString *userVerCode;

@end
