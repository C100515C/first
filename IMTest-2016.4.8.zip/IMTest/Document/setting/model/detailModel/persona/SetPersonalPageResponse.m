//
//  SetPersonalPageResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SetPersonalPageResponse.h"

static const CGFloat BasicHeight = 20.0f;
@interface SetPersonalPageResponse ()
{
    NSString *_name;
}

@end

@implementation SetPersonalPageResponse

-(CGFloat)cellHeight{
    
    if (self.style == SetPersonalPageResponseShowImage) {
        
        _cellHeight = 60.0f;
        
    }else if (self.style == SetPersonalPageResponseShowDes){
        
        CGSize size_content = [self getStringSizeWith:_content fontSize:17.0f showSize:CGSizeMake(SCREEN_WIDTH-83, 2000)];
        
        _cellHeight = size_content.height+BasicHeight;
        
    }else{
        
        _cellHeight = 40.0f;
    }
    
    return _cellHeight;
}

-(void)setName:(NSString *)name{
    // NSArray *arr = @[@{@"imageUrl":infor.imageUrl},@{@"username":infor.username},@{@"gender":infor.gender},@{@"birthday":infor.birthday},@{@"address":infor.address},@{@"signature":infor.signature}];
   NSDictionary *dic = @{@"imageUrl":@"头    像",@"username":@"昵    称",@"gender":@"性    别",@"birthdate":@"生    日",@"address":@"所在地",@"signature":@"签    名"};
    
    if (_name==nil) {
        _name = dic[name];
    }else{
        _name = nil;
        _name = dic[name];
    }
    
    if ([_name isEqualToString:@"头    像"]) {
        self.style = SetPersonalPageResponseShowImage;
    }else if ([_name isEqualToString:@"签    名"]){
        self.style = SetPersonalPageResponseShowDes;
    }
    else{
        self.style = SetPersonalPageResponseShowtitle;

    }
}

-(NSString*)name{

    return _name;
    
}

-(NSString*)content{

    if ([_content isEqualToString:@"0"]) {
        _content = @"无";
        return _content;
    }
    
    return _content;
}

@end
