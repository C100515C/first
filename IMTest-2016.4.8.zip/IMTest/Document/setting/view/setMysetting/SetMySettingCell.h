//
//  SetMySettingCell.h
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString *const SetMySetting_id = @"SetMySetting";

//typedef void (^SetMySettingCellSwithSelect)(BOOL open);
@interface SetMySettingCell : BasicTableViewCell

@property (weak, nonatomic) IBOutlet UILabel *titleName;
@property (weak, nonatomic) IBOutlet UISwitch *switchBtn;

@property (nonatomic,strong) void (^SetMySettingCellSwithSelect)(BOOL open);

@end
