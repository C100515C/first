//
//  MySettingVC.m
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MySettingVC.h"
#import "SetMySettingCell.h"

#import "UserProfileManager.h"

#import "RootVC.h"
#import "AppDelegate.h"

#import "NotificationManager.h"

#import "UIViewController+HUD.h"

@interface MySettingVC (){
    NSArray *_dataSource;
}

@property (weak, nonatomic) IBOutlet UIButton *logoutBtn;
@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (nonatomic,assign) BOOL isCanNotice;
@property (nonatomic,assign) BOOL isCanNoticeMessage;

- (IBAction)logoutBtnClicked:(BasicUIButton *)sender;

@end

@implementation MySettingVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    [self.tableView registerNib:[UINib nibWithNibName:@"SetMySettingCell" bundle:nil] forCellReuseIdentifier:SetMySetting_id];
    
    [self setNav];
    
    self.isCanNotice = [NotificationManager appPushIsOpen];
    self.isCanNoticeMessage = [NotificationManager appMessagePushIsOpen];
    _dataSource = @[@{@"name":@"消息提醒",@"state":@(self.isCanNoticeMessage)},@{@"name":@"推送提醒",@"state":@(self.isCanNotice)}];
    
    self.logoutBtn.clipsToBounds = YES;
    self.logoutBtn.layer.borderWidth = 0.5f;
    self.logoutBtn.layer.borderColor = [[UIColor blackColor]CGColor];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - nav
-(void)setNav{
    [super setNav];

    self.title = @"设置";
}

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 50.0f;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    SetMySettingCell *cell = [tableView dequeueReusableCellWithIdentifier:SetMySetting_id];
        
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"SetMySettingCell" owner:nil options:nil] firstObject];
    }
    NSDictionary *dic = _dataSource[indexPath.row];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.titleName.text = dic[@"name"];
    cell.switchBtn.on = [dic[@"state"] boolValue];
    
    __weak typeof(self) weakself = self;
    cell.SetMySettingCellSwithSelect = ^(BOOL open){
    
        if (indexPath.row==0) {
            if (open) {
                //开启消息提醒
                MOSLog(@"1");
                [weakself openNoticeMessage];
                
            }else{
                MOSLog(@"2");
                [weakself closeNoticeMessage];
            }
            
        }else{
            if (open) {
                //开启推送提醒
                MOSLog(@"3");
                [weakself openNotice];

            }else{
                MOSLog(@"4");
                [weakself closeNotice];

            }
        }
        [weakself resetDataSource];
    };
    return cell;

}

-(void)openNoticeMessage{
    [NotificationManager changeMessagePushStateWith:YES];
}

-(void)closeNoticeMessage{
    [NotificationManager changeMessagePushStateWith:NO];
}

-(void)openNotice{
    
    UIApplication *application = [UIApplication sharedApplication];
    application.applicationIconBadgeNumber = 0;
    
    if([application respondsToSelector:@selector(registerUserNotificationSettings:)])
    {
        UIUserNotificationType notificationTypes = UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert;
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:notificationTypes categories:nil];
        [application registerUserNotificationSettings:settings];
    }
    
#if !TARGET_IPHONE_SIMULATOR
    //iOS8 注册APNS
    if ([application respondsToSelector:@selector(registerForRemoteNotifications)]) {
        [application registerForRemoteNotifications];
    }else{
        UIRemoteNotificationType notificationTypes = UIRemoteNotificationTypeBadge |
        UIRemoteNotificationTypeSound |
        UIRemoteNotificationTypeAlert;
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:notificationTypes];
    }
#endif
    [NotificationManager changeAppPushStateWith:YES];

}

-(void)closeNotice{
    
    UIApplication *application = [UIApplication sharedApplication];
    
#ifdef __IPHONE_8_0
    if(NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_7_1) {
        
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings
                                                                             settingsForTypes:
                                                                             (UIUserNotificationType)
                                                                             (UIUserNotificationTypeNone)
                                                                             categories:nil]];
        
        [application unregisterForRemoteNotifications];
        
    }
    
    else
#endif
    {
        [application unregisterForRemoteNotifications];
        
    }

    [NotificationManager changeAppPushStateWith:NO];
}

-(void)resetDataSource{

//    self.isCanNotice = [self isAllowedNotification];
    self.isCanNotice = [NotificationManager appPushIsOpen];
    _dataSource = @[@{@"name":@"消息提醒",@"state":@(self.isCanNotice)},@{@"name":@"推送提醒",@"state":@(self.isCanNotice)}];
}

- (IBAction)logoutBtnClicked:(BasicUIButton *)sender {
    __weak typeof(self) weakself = self;
    dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
       
        EMError *error = [[EMClient sharedClient] logout:YES];
        
        dispatch_async(dispatch_get_main_queue(), ^{
           
            if (!error) {
                [[UserProfileManager sharedInstance] logoutDelInforWith:^(BOOL finish) {
                    
                    [weakself.navigationController popToRootViewControllerAnimated:YES];

//                    AppDelegate *app = [UIApplication sharedApplication].delegate;
//                    RootVC *root = (RootVC*)app.window.rootViewController;
//                    [root prensentLoginVC];
                    
                }];
            }else{
                [weakself showHint:@"退出失败" yOffset:-200];
            }
        });
        
    });
    
}

@end
