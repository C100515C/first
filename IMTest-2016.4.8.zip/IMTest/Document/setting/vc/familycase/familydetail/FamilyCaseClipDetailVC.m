//
//  FamilyCaseClipDetailVC.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "FamilyCaseClipDetailVC.h"

#import "CaseClipDetailResponse.h"
#import "FamilyCasesClipResponse.h"

#import "CaseClipDetailHeaderCell.h"
#import "CaseClipDetailRecordCell.h"

#import "AddFamilyCaseClipRecordVC.h"

#import "UIAlertController+LYJAlertView.h"
#import "UIViewController+HUD.h"

@interface FamilyCaseClipDetailVC (){
    NSMutableArray *_dataSource;
}

@property (weak, nonatomic) IBOutlet UITableView *myTable;


@end

@implementation FamilyCaseClipDetailVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self setNav];
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _dataSource = [[NSMutableArray alloc] init];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"CaseClipDetailHeaderCell" bundle:nil] forCellReuseIdentifier:CaseClipDetailHeader_id];
    [self.tableView registerNib:[UINib nibWithNibName:@"CaseClipDetailRecordCell" bundle:nil] forCellReuseIdentifier:CaseClipDetailRecord_id];
    
    [self makeModel];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Nav
-(void)setNav{
    [super setNav];

    self.title = @"家庭病例史详情";
}


-(void)makeModel{
    [_dataSource addObject:[self getFirstSection]];
    [_dataSource addObject:[self getSecondSection]];
    
//    MOSLog(@"%@",_dataSource);
    [_myTable reloadData];
}

-(NSMutableArray*)getFirstSection{
    NSMutableArray *sectionArr = [NSMutableArray array];

    FamilyCasesClipResponse *model = [[FamilyCasesClipResponse alloc] init];
    model.nickname = @"啦啦";
    model.caseCount = @"12";
    model.age = @"55";
    model.gender = @"男";
    model.needHighHeight = YES;
    [sectionArr addObject:model];
    
    return sectionArr;
}

-(NSMutableArray *)getSecondSection{
    NSMutableArray *sectionArr = [NSMutableArray array];
    for (int i=0 ; i<5; i++) {
        CaseClipDetailResponse *model = [[CaseClipDetailResponse alloc]init];
        model.time = @"2016-03-23";
        model.type = @"呼吸科";
        model.address = @"北京朝阳医院";
        model.pics = @[@"account",@"account",@"account"];
        [sectionArr addObject:model];
    }
    return sectionArr;
}



- (void)tableViewDidTriggerHeaderRefresh{
    
    [self tableViewDidFinishTriggerHeader:YES reload:NO];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    [self tableViewDidFinishTriggerHeader:NO reload:NO];
    
}//上拉加载事件

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return _dataSource.count;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==0) {
        NSArray *arr = [_dataSource objectAtIndex:indexPath.section];
        FamilyCasesClipResponse *model = [arr objectAtIndex:indexPath.row];
        return model.cellHeight;
    }else{
        NSArray *arr = [_dataSource objectAtIndex:indexPath.section];
        CaseClipDetailResponse *model = [arr objectAtIndex:indexPath.row];
        return model.cellHeight;
    }
    
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (section==0) {
        NSArray *arr = [_dataSource objectAtIndex:section];
        return arr.count;
    }else{
        NSArray *arr = [_dataSource objectAtIndex:section];
        return arr.count;
    }
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.section==0) {
        CaseClipDetailHeaderCell *cell = [tableView dequeueReusableCellWithIdentifier:CaseClipDetailHeader_id];
        
        if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"CaseClipDetailHeaderCell" owner:nil options:nil] firstObject];
        }
        NSArray *arr = [_dataSource objectAtIndex:indexPath.section];
        FamilyCasesClipResponse *model = (FamilyCasesClipResponse*)[arr objectAtIndex:indexPath.row];
        
        [cell setCellWith:model];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        __weak typeof(self) weakself = self;
        cell.addCaseClipRecordBlock = ^{
            AddFamilyCaseClipRecordVC *vc = [[AddFamilyCaseClipRecordVC alloc] init];
            [weakself.navigationController pushViewController:vc animated:YES];
        };
        return cell;
    }else{
        
        CaseClipDetailRecordCell *cell = [tableView dequeueReusableCellWithIdentifier:CaseClipDetailRecord_id];
        
        if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"CaseClipDetailRecordCell" owner:nil options:nil] firstObject];
        }
        
        NSArray *arr = [_dataSource objectAtIndex:indexPath.section];
        CaseClipDetailResponse *model = (CaseClipDetailResponse*)[arr objectAtIndex:indexPath.row];
        model.indexpath = indexPath;

        [cell setCellWith:model];
        
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        __weak typeof(self) weakself = self;
        cell.delBtnClickedBlock = ^(CaseClipDetailResponse *model){
            [weakself deleteOldCaseWith:model.indexpath];
        };
        
        cell.editBtnClickedBlock = ^(CaseClipDetailResponse *model){
            MOSLog(@"编辑＝%@",model.indexpath);
        };
        
        return cell;
    }
}

-(UIView*)tableView:(UITableView *)tableView viewForFooterInSection:(NSInteger)section{
    if (section==0) {
        UIView *view = [[UIView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, 15)];
        view.backgroundColor = RGB(247, 249, 249, 1);
        return view;
    }else{
        return [[UIView alloc] init];

    }
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForFooterInSection:(NSInteger)section{
    return 15.0f;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
}

-(BOOL)tableView:(UITableView *)tableView canEditRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.section==0) {
        return NO;
    }
    return YES;
}

-(UITableViewCellEditingStyle)tableView:(UITableView *)tableView editingStyleForRowAtIndexPath:(NSIndexPath *)indexPath{
    return UITableViewCellEditingStyleDelete;
}

- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath
{
    if (editingStyle == UITableViewCellEditingStyleDelete) {
        
        [tableView beginUpdates];
        NSMutableArray *arr = [_dataSource objectAtIndex:(indexPath.section)];
        [arr removeObjectAtIndex:indexPath.row];
        [tableView  deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [tableView endUpdates];
        
        [self showHint:[NSString stringWithFormat:NSLocalizedString(@"deleteFailed", @"Delete failed:%@"), @"成功"]];
        
    }
    
    if (editingStyle==UITableViewCellEditingStyleInsert) {
        
        [tableView beginUpdates];
        NSMutableArray *arr = [_dataSource objectAtIndex:(indexPath.section)];
        
        CaseClipDetailResponse *model = [[CaseClipDetailResponse alloc] init];
        model.time = @"2015-04-03";
        model.address = @"北京海淀医院";
        
        [arr insertObject:model atIndex:0];
        [tableView insertRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
        [tableView endUpdates];
        
        [self showHint:[NSString stringWithFormat:NSLocalizedString(@"deleteFailed", @"Delete failed:%@"), @"成功"]];
    }
}

-(void)deleteOldCaseWith:(NSIndexPath*)indexpath{
    [_myTable beginUpdates];
    NSMutableArray *arr = [_dataSource objectAtIndex:(indexpath.section)];
    [arr removeObjectAtIndex:indexpath.row];
    [_myTable  deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexpath] withRowAnimation:UITableViewRowAnimationFade];
    [_myTable endUpdates];
    
    [self showHint:[NSString stringWithFormat:NSLocalizedString(@"deleteFailed", @"Delete failed:%@"), @"成功"]];
}

-(void)interNewCase{
    
    NSIndexPath *indexpath = [NSIndexPath indexPathForRow:0 inSection:1];
    
    [_myTable beginUpdates];
    NSMutableArray *arr = [_dataSource objectAtIndex:1];
    
    CaseClipDetailResponse *model = [[CaseClipDetailResponse alloc] init];
    model.time = @"2015-04-03";
    model.address = @"北京海淀dd医院";
    
    [arr insertObject:model atIndex:0];
    [_myTable insertRowsAtIndexPaths:[NSArray arrayWithObject:indexpath] withRowAnimation:UITableViewRowAnimationFade];
    [_myTable endUpdates];
    
    [self showHint:[NSString stringWithFormat:NSLocalizedString(@"deleteFailed", @"Delete failed:%@"), @"成功"]];
}

@end
