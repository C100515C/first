//
//  PostsCell.h
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

@class PostsResponse;
@class BasicUIButton;
@class BasicUIImageView;
@class BasicLabel;

static NSString * const PostsCellIdentifier = @"posts";

@interface PostsCell : BasicTableViewCell

@property (weak, nonatomic) IBOutlet UILabel *contentLabel;

@property (weak, nonatomic) IBOutlet BasicUIImageView *userIcon;
@property (weak, nonatomic) IBOutlet UILabel *userNickname;
@property (weak, nonatomic) IBOutlet UILabel *postsTitle;
@property (weak, nonatomic) IBOutlet BasicLabel *postsKind;
@property (weak, nonatomic) IBOutlet UILabel *userOption;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;
@property (weak, nonatomic) IBOutlet BasicUIButton *praiseBtn;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *toBackViewHeight;

-(void)setCellWith:(PostsResponse*)model;

@end
