//
//  PostsCell.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostsCell.h"
#import "PostsResponse.h"
//#import "BasicUIButton.h"
//#import "BasicLabel.h"
//#import "BasicUIImageView.h"

@implementation PostsCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [_userIcon setRaduis];
    [_postsKind setBorder];
    
}

#pragma mark - view  init

-(void)setCellWith:(PostsResponse *)model{

    self.contentLabel.text = model.postInfo.content;
    self.userNickname.text = model.userInfo.username;
    self.userOption.attributedText = model.optionStr;
    
    self.postsKind.text = model.thread.thread_type;
    self.postsKind.LYJ_textColor = [model getLabelColor];
    
    self.postsTitle.text = model.thread.title;
    [self.praiseBtn setTitle:model.thread.post_count forState:UIControlStateNormal];
    self.timeLabel.attributedText = model.timeCircleStr;
    [self.userIcon sd_setImageWithURL:[NSURL URLWithString:model.userInfo.avatar] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.toBackViewHeight.constant = model.topNewHeight;
}

-(void)setAllLayoutIfNeeded{
    [self.contentLabel layoutIfNeeded];
    [self.userNickname layoutIfNeeded];
    [self.userOption layoutIfNeeded];
    [self.postsKind layoutIfNeeded];
    [self.postsTitle layoutIfNeeded];
    [self.praiseBtn layoutIfNeeded];
    [self.timeLabel layoutIfNeeded];
}

@end
