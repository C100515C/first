//
//  PersonalHomepageCell.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalHomepageCell.h"
#import "PersonalHomepageResponse.h"
#import "CC_LabelsOfView.h"

@interface PersonalHomepageCell ()<BasicUIImageTapProtocol>
@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;
@property (weak, nonatomic) IBOutlet UILabel *nickname;
@property (weak, nonatomic) IBOutlet UIImageView *gender;
@property (weak, nonatomic) IBOutlet UILabel *addressed;
@property (weak, nonatomic) IBOutlet UILabel *answerCount;
@property (weak, nonatomic) IBOutlet UILabel *publishedCount;

@property (weak, nonatomic) IBOutlet UILabel *illFriendsCount;

@property (weak, nonatomic) IBOutlet CC_LabelsOfView *focusLabelView;
@property (weak, nonatomic) IBOutlet UILabel *signature;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *focusLabelViewHeight;

@end

@implementation PersonalHomepageCell

-(void)setCellWithModel:(PersonalHomepageResponse *)model{
    
    self.nickname.text = model.username;
    self.addressed.text = model.location;
    [self.focusLabelView set_MyLabelsCanChangeRowsWith:[model getForumLabelNames]];
    
    self.focusLabelViewHeight.constant = model.focusLabelHeight;
    self.signature.text = model.signature;
    self.answerCount.text = [NSString stringWithFormat:@"%@",model.post_count];
    self.publishedCount.text = [NSString stringWithFormat:@"%@",model.feed_count];
    self.illFriendsCount.text = [NSString stringWithFormat:@"%@",model.following_count];
    [self.headerIcon sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"sctx"]];
    if ([model.gender isEqualToString:@"1"]) {
        self.gender.image = [UIImage imageNamed:@"icon_sm"];
    }else{
        self.gender.image = [UIImage imageNamed:@"icon_sw"];
    }
}

-(void)setCellWithUserModel:(UserProfileEntity *)model{
    self.nickname.text = model.username;
    self.addressed.text = model.location;
    [self.focusLabelView set_MyLabelsCanChangeRowsWith:[model getForumLabelNames]];
    
    self.focusLabelViewHeight.constant = model.focusLabelHeight;
    self.signature.text = model.signature;
    self.answerCount.text = [NSString stringWithFormat:@"%@",model.post_count];
    self.publishedCount.text = [NSString stringWithFormat:@"%@",model.feed_count];
    self.illFriendsCount.text = [NSString stringWithFormat:@"%@",model.following_count];
    [self.headerIcon sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:@"sctx"]];
    if ([model.gender isEqualToString:@"1"]) {
        self.gender.image = [UIImage imageNamed:@"icon_sm"];
    }else{
        self.gender.image = [UIImage imageNamed:@"icon_sw"];
    }
}

-(void)awakeFromNib{
    [super awakeFromNib];

    [self.headerIcon setRaduis];
    [self.headerIcon setTapUse];
    self.headerIcon.lyj_delegate = self;
    
    [_focusLabelView setStart_x:0 andY:5.0f andInterval:5.0f andLabelHeight:15.0f andEndDistance:10.0f andLabelType:CCBlueFrameLabel];
}


#pragma mark - image tap
-(void)imageTapWith:(UITapGestureRecognizer *)sender{
    if (_tapBlock) {
        _tapBlock();
    }
}

@end
