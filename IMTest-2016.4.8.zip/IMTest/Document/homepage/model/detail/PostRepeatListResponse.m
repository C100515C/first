//
//  PostRepeatListResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostRepeatListResponse.h"

static const CGFloat BasicHeight = 50.0f;

@implementation PostRepeatListResponse

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size = [self getStringSizeWith:_content fontSize:13.0f showSize:CGSizeMake(SCREEN_WIDTH-16, 2000)];
        _cellHeight = size.height+BasicHeight;
        
        return _cellHeight;
    }
}

//-(NSString*)created_at{
//    if (_created_at) {
//       return [CC_NSStringHandle formatTime:[_created_at integerValue]];
//    }
//    return _created_at;
//}

@end

@implementation PostRepeatListUserInforResponse


@end
