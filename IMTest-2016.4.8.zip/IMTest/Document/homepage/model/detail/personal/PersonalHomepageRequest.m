//
//  PersonalHomepageRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/30.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalHomepageRequest.h"

@implementation PersonalHomepageRequest

- (id)init
{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"users?access-token=%@&",token];
        
        self.reqMethod = @"GET";
//        self.reqMethod = @"POST";
        self.reqClassName = @"PersonalHomepage";
    }
    return self;
}

@end
