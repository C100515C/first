//
//  PostRepeatsRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/28.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface PostRepeatsRequest : BaseRequest

@property (nonatomic,copy) NSString *thread_id;
@property (nonatomic,copy) NSString *post_id;
@property (nonatomic,copy) NSString *page;

-(id)init;

@end
