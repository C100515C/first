//
//  PostDetailVC.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostDetailVC.h"
#import "PostDetailHeaderView.h"
#import "PostRepeatCell.h"

#import "PostDetailResponse.h"
#import "SingletonServ.h"
#import "PostDetailRequest.h"
#import "PostRepeatListResponse.h"
#import "SendRepeatRequest.h"
#import "SendRepeatsResponse.h"
#import "PostOptionRequest.h"
#import "PostOptionResponse.h"
#import "ReportPostRequest.h"

#import "LYJToolbar.h"
#import "LYJWindow.h"
#import "UIAlertController+LYJAlertView.h"
#import "LYJInputView.h"
#import "UIViewController+HUD.h"

#import "PostRepeatsVC.h"
#import "PersonalHomepageVC.h"

#import "UMSocial.h"

@interface PostDetailVC ()<LYJInputViewDelegate,LYJToolBarDelegate,UMSocialUIDelegate>{
    NSMutableArray *_dataSource;
    PostDetailHeaderResponse *_headerModel;
    int _page;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (nonatomic, strong ) PostDetailHeaderView *tableHeaderView;
@property (nonatomic, strong) LYJToolbar *inputBar;
@property (nonatomic,assign) CGFloat barBottonLayoutHeight;
@property (nonatomic, strong) LYJInputView *inputView;

@end

@implementation PostDetailVC
//重新init 则导航条 返回按钮 无法自定义 原因待查
//- (instancetype)init
//{
//    self = [super init];
//    if (self) {
//        
//    }
//    return self;
//}

-(void)initUI{
    self.tableHeaderView = [[[NSBundle mainBundle] loadNibNamed:@"PostDetailHeaderView" owner:nil options:nil]firstObject];
    self.inputView = [[[NSBundle mainBundle] loadNibNamed:@"LYJInputView" owner:nil options:nil] firstObject];
    self.inputView.lyj_delegate = self;
    [self.view addSubview: self.inputView];
    
    self.inputView.hidden = YES;
}

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self initUI];
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    self.tableView.tableHeaderView = _tableHeaderView;
    
    __weak typeof(self) weakSelf = self;
    __weak typeof (PostDetailHeaderResponse*) weakModel = _headerModel;
    _tableHeaderView.tapBlock = ^(UITapGestureRecognizer *sender){
        PersonalHomepageVC *vc = [[PersonalHomepageVC alloc] init];
        vc.userid = weakModel.user_id;
        [weakSelf.navigationController pushViewController:vc animated:YES];
    };
    
    _tableHeaderView.btnBlock = ^(PostDetailHeaderBtn btnname){
    
        if (btnname==PostDetailHeaderAttentionBtn) {
            [weakSelf postAttention];
        }else if (btnname==PostDetailHeaderCollectBtn){
            [weakSelf postCollect];
        }else{
            [weakSelf postShare];
        }
        
    };
    
    _dataSource = [[NSMutableArray alloc] init];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"PostRepeatCell" bundle:nil] forCellReuseIdentifier:PostsRepeatCellIdentifier];
    
    _page = 1;
    [self makeModelWith:_page with:nil andHeaderRef:YES];
    
    LYJToolbar *bar = [[LYJToolbar alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-44, self.view.frame.size.width, 44)];
    bar.sendDelegate = self;
    bar.textPlaceholder = @"请输入您回复的内容";
    [self.view addSubview:bar];
    
    [bar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view.mas_bottom).with.offset(0);
        make.left.equalTo(self.view.mas_left).with.offset(0);
        make.right.equalTo(self.view.mas_right).with.offset(0);
        make.height.equalTo(@(44));
    }];
    
    self.inputBar = bar;
    
    [self interceptEvent];
    
    [self setNav];

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    self.inputView.hidden = YES;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.inputView.hidden = YES;
}

-(void)dealloc{
    [LYJWindow currentWindow].currentView = nil;
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    //    [super touchesBegan:touches withEvent:event];
    
    for (UITouch *touch in event.allTouches) {
        if ([touch.view isKindOfClass:[LYJInputView class]] || [self isONInputViewWith:touch.view]) {
            return;
        }else{
            [_inputBar takeBackKeyboard];
        }
    }
}

-(BOOL)isONInputViewWith:(UIView*)view{
    
    for (UIView *sub in self.inputView.subviews) {
        if (view==sub) {
            return YES;
        }
        for (UIView *subsub in sub.subviews) {
            if (view==subsub) {
                return YES;
            }
        }
    }
    return NO;
}

#pragma mark- nav
-(void)setNav{
    [super setNav];
    self.title = @"帖子详情";
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    [nav setNavBarBtnItemImageWith:@"topicon_more" andRightItem:YES andAction:@selector(rightNavBtnClicked:) andTarget:self andVCIndex:1];
}

-(void)rightNavBtnClicked:(UIButton*)sender{
    //*
    __weak typeof(self) weakself = self;
     UIAlertControllerActionBlock repeat = ^(UIAlertAction *action){
     MOSLog(@"评论");
         [weakself.inputBar keybaordAppear];
     };
     UIAlertControllerActionBlock report = ^(UIAlertAction *action){
         [weakself reportMenu];
     };
     UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
     MOSLog(@"取消");
     };
     [UIAlertController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"举报":report,@"评论":repeat} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet];//*/
}

#pragma mark - net work

-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    
    PostDetailRequest *req = [[PostDetailRequest alloc] init];
    [req setMyPost_id:self.thread_id];
    
    req.page = [NSString stringWithFormat:@"%d",_page];
    
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            
            PostDetailResponse *model = (PostDetailResponse*)responseDataModel;
            
            if (isHeaderRef) {
                [_dataSource removeAllObjects];

            }
            [_dataSource addObjectsFromArray:model.post];
            _headerModel = model.thread;
            [_tableHeaderView setHeaderViewWith:_headerModel andThread_id:weakself.thread_id andFinish:^(BOOL isfinish) {
                [weakself hideHud];
                weakself.tableView.tableHeaderView = weakself.tableHeaderView;

            }];
            [weakself.tableView reloadData];
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
            [weakself hideHud];
        }
        
        if (finishBlock) {
            finishBlock(YES);
        }
    }];
    
}
//下拉刷新事件
- (void)tableViewDidTriggerHeaderRefresh{
    
    _page = 1;
    __weak typeof(self) weakself = self;
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:YES reload:NO];
        
    } andHeaderRef:YES];
    
}
//上拉加载事件
- (void)tableViewDidTriggerFooterRefresh{
    _page ++;
    __weak typeof(self) weakself = self;
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:NO reload:NO];
        
    } andHeaderRef:NO];
    
}

-(void)sendPostRepeatWith:(NSString*)content {

    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"发送中..."];
    SendRepeatRequest *req = [[SendRepeatRequest alloc] init];
    
    req.content = content;
    req.thread_id = self.thread_id;
    
    [[SingletonServ sharedInstance ] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            
//            MOSLog(@"%@",responseDataModel);
            [weakself refreshTablePostWith:nil];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        [weakself hideHud];
    }];
}

-(void)refreshTablePostWith:(HeaderOrFooterRefFinish)finishBlock{

    PostDetailRequest *req = [[PostDetailRequest alloc] init];
    [req setMyPost_id:self.thread_id];
    
    req.page = [NSString stringWithFormat:@"%d",1];
    
    __weak typeof(self) weakself = self;
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            
            PostDetailResponse *model = (PostDetailResponse*)responseDataModel;
            
            [_dataSource removeAllObjects];
            
            [_dataSource addObjectsFromArray:model.post];

            [weakself.tableView reloadData];
            
        }
        
        if (finishBlock) {
            finishBlock(YES);
        }
    }];
}
/**
 *  关注
 */
-(void)postAttention{

    if ([_headerModel.attentionAction intValue]==1) {
        return;
    }
    __weak typeof(self) weakself = self;
    PostOptionAttentionRequest *req = [[PostOptionAttentionRequest alloc] init];
    req.thread_id = self.thread_id;
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
       
        if (responeseError==nil) {
            MOSLog(@"关注成功");
            int newcout = [[[_headerModel.attention_count componentsSeparatedByString:@" "] lastObject] intValue] +1;
            _headerModel.attention_count =  [NSString stringWithFormat:@"%d",newcout];
            _headerModel.attentionAction = @"1";
            [weakself.tableHeaderView updateBtnCountWith:PostDetailHeaderAttentionBtn andNewCount:_headerModel];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
    }];
}
/**
 *  收藏
 */
-(void)postCollect{
    if ([_headerModel.collectAction intValue]==1) {
        return;
    }
    __weak typeof(self) weakself = self;
    PostOptionCollectionRequest *req = [[PostOptionCollectionRequest alloc] init];
    req.thread_id = self.thread_id;
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            MOSLog(@"收藏成功");
            int newcout = [[[_headerModel.attention_count componentsSeparatedByString:@" "] lastObject] intValue] +1;
            _headerModel.collect_count =  [NSString stringWithFormat:@"%d",newcout];
            _headerModel.collectAction = @"1";
            [weakself.tableHeaderView updateBtnCountWith:PostDetailHeaderCollectBtn andNewCount:_headerModel];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
    }];
}
/**
 *  分享
 */
-(void)postShare{

    
    NSString *shareStr = nil;
    
    shareStr = [NSString stringWithFormat:@"%@-%@-%@",[[UserProfileManager sharedInstance]getCurUsername],_headerModel.username,_headerModel.content];
    
    //自带分享界面
    [UMSocialData defaultData].extConfig.title=@"同病相连-分享";
    [UMSocialSnsService presentSnsIconSheetView:self appKey:UM_Key shareText:shareStr shareImage:[self.tableHeaderView getPicImage] shareToSnsNames:@[UMShareToSina,UMShareToQzone,UMShareToQQ,UMShareToWechatSession,UMShareToWechatTimeline] delegate:self];
}
/**
 *  点赞
 */
-(void)postRepeatPraiseWith:(NSIndexPath*)index{

    PostRepeatListResponse *model = [_dataSource objectAtIndex:index.row];
    if ([model.praiseAction intValue]==1) {
        return;
    }
    __weak typeof(self) weakself = self;
    PostOptionRequest *req = [[PostOptionRequest alloc] init];
    req.thread_id = model.thread_id;
    req.post_id = model.objectId;
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            MOSLog(@"点赞成功");
            int newcout = [model.praise_count intValue] +1;
            model.praise_count =  [NSString stringWithFormat:@"%d",newcout];
            model.praiseAction = @"1";
            [weakself.tableView reloadData];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
    }];
}

#pragma mark - 截获事件
-(void)interceptEvent{
    [LYJWindow currentWindow].currentView = self;;
}

#pragma mark - table

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    PostRepeatListResponse *model = [_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    PostRepeatCell *cell = [tableView dequeueReusableCellWithIdentifier:PostsRepeatCellIdentifier];
    
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"PostRepeatCell" owner:nil options:nil] firstObject];
    }
    PostRepeatListResponse *model = [_dataSource objectAtIndex:indexPath.row];
    
    [cell setCellWith:model];
    __weak typeof(self) weakself = self;
    cell.btnBlock = ^(PostRepeatCellBtn btnname){
        [weakself postRepeatPraiseWith:indexPath];
    };
    cell.selectionStyle = UITableViewCellSelectionStyleNone;

    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    PostRepeatListResponse *model = [_dataSource objectAtIndex:indexPath.row];
    
    PostRepeatsVC *vc = [[PostRepeatsVC alloc] init];
    vc.post_id = model.objectId;
    vc.thead_id = model.thread_id;
    [self.navigationController pushViewController:vc animated:YES];
    
}

#pragma  mark - report menu
-(void)reportMenu{
    __weak typeof(self) weakself = self;
//帖子类型1:造谣；2：诽谤；3：色情；4：反动；5：抄袭；
    UIAlertControllerActionBlock rumor = ^(UIAlertAction *action){
        [weakself reportPostWith:1];
    };
    UIAlertControllerActionBlock defame = ^(UIAlertAction *action){
        [weakself reportPostWith:2];

    };
    
    UIAlertControllerActionBlock violence = ^(UIAlertAction *action){
        [weakself reportPostWith:3];

    };
    UIAlertControllerActionBlock sexy = ^(UIAlertAction *action){
        [weakself reportPostWith:4];

    };
    UIAlertControllerActionBlock copy = ^(UIAlertAction *action){
        [weakself reportPostWith:5];

    };
    
    UIAlertControllerActionBlock cancle = ^(UIAlertAction *action){
        MOSLog(@"取消");
    };
    [UIAlertController showAlertTltileWith:nil andMessage:nil andActions:@{@"取消":cancle,@"造谣":rumor,@"诽谤":defame,@"暴力":violence,@"色情":sexy,@"抄袭":copy} andShowVC:self andAlertStyle:UIAlertControllerStyleActionSheet];
}

-(void)reportPostWith:(int)type{
    ReportPostRequest *req = [[ReportPostRequest alloc] init];
    req.thread_id = self.thread_id;
    req.type = [NSString stringWithFormat:@"%d",type];
    __weak typeof(self) weakself = self;
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        if (responeseError==nil) {
//            MOSLog(@"举报成功");
            [weakself showHint:@"举报成功" yOffset:-200];
            [weakself.navigationController popViewControllerAnimated:YES];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
    }];
}

#pragma mark - lyj tool bar
-(void)keyboardAppearWith:(CGFloat)height{
    
    self.inputView.hidden = NO;
    [self.inputView keyboardAppear];
}

#pragma mark - lyj inputView
-(void)sendBtnAction:(UIButton *)sender andText:(NSString *)text{
    MOSLog(@"%@",text);
    if (text.length!=0) {
        [self sendPostRepeatWith:text];
    }
}
-(void)cancleBtnAction:(UIButton *)sender andText:(NSString *)text{
    MOSLog(@"%@",text);
}

@end
