//
//  LYJPicturesBrowse.h
//  IMTest
//
//  Created by chenchen on 16/3/18.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYJPicturesBrowse : UIView

@property (nonatomic,copy) NSArray *pics;

@end
