//
//  LYJWindow.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJWindow.h"
#import "AppDelegate.h"
#import "PostDetailVC.h"


@implementation LYJWindow

- (void)sendEvent:(UIEvent *)event {
    
    [super sendEvent:event]; // 《＝＝＝ 不干扰原来的event chain
    
    if (_m_pDelegate) {
        [_m_pDelegate sendEvent:event];

    }
    
    if(_currentView && [_currentView isKindOfClass:[PostDetailVC class]]) {
        PostDetailVC *vc = (PostDetailVC *)_currentView;
        [_currentView touchesBegan:[event touchesForView:vc.tableView]  withEvent:event];
    }
}

+(LYJWindow*)currentWindow{
    AppDelegate *delegate = [UIApplication sharedApplication].delegate;
    
    return (LYJWindow*)delegate.window;
}

@end
