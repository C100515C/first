//
//  LYJSystemCallsJudgeManager.m
//  IMTest
//
//  Created by chenchen on 16/3/14.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJSystemCallsJudgeManager.h"

#import <Foundation/Foundation.h>
#import <AVFoundation/AVFoundation.h>
#import <AssetsLibrary/AssetsLibrary.h>

@implementation LYJSystemCallsJudgeManager

/**
 *  获取系统本地相片url
 *
 *  @param locationPictures 图片url存储数组
 *  @param showBlock        获取相片url结束后执行的block
 */
+(BOOL)iscanPictureAblumWith:(LYJSystemJudeAlertBlock) alert{
    
    ALAuthorizationStatus author = [ALAssetsLibrary authorizationStatus];
    if (author == ALAuthorizationStatusRestricted || author ==ALAuthorizationStatusDenied){
        //无权限
        if (alert) {
            alert();

        }
        return NO;
    }
    return YES;
}


+(BOOL)isCanUseCamera_CCWith:(LYJSystemJudeAlertBlock)alert{
    
    NSString *mediaType = AVMediaTypeVideo;
    AVAuthorizationStatus authStatus = [AVCaptureDevice authorizationStatusForMediaType:mediaType];
    BOOL iscan = YES;
    
    if(authStatus ==AVAuthorizationStatusRestricted){
        
        MOSLog(@"Restricted");
        
    }
    // The user has explicitly denied permission for media capture.
    else if(authStatus == AVAuthorizationStatusDenied){
        
        MOSLog(@"Denied");     //应该是这个，如果不允许的话
        //        UIAlertView *alert = [[UIAlertView alloc] initWithTitle:@"提示" message:@"没有允许使用相机，请去系统设置开启相机" delegate:nil cancelButtonTitle:@"确定" otherButtonTitles: nil];
        //        [alert show];
        iscan = NO;
    }
    // The user has explicitly granted permission for media capture, or explicit user permission is not necessary for the media type in question.
    else if(authStatus == AVAuthorizationStatusAuthorized){
        
        MOSLog(@"Authorized");
        
    }
    // Explicit user permission is required for media capture, but the user has not yet granted or denied such permission.
    else if(authStatus == AVAuthorizationStatusNotDetermined){
        
        [AVCaptureDevice requestAccessForMediaType:mediaType completionHandler:^(BOOL granted) {
            
            if(granted){
                
                MOSLog(@"Granted access to %@", mediaType);
                
            }
            
            else {
                
                MOSLog(@"Not granted access to %@", mediaType);
                
            }
            
        }];
        
    }
    
    if (!iscan) {
        if (alert) {
            alert();
            return iscan;
        }
    }
    
    return iscan;
}


@end
