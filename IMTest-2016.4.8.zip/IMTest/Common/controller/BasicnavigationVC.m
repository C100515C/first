//
//  BasicnavigationVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicnavigationVC.h"

@interface BasicnavigationVC ()

@end

@implementation BasicnavigationVC

- (void)viewDidLoad {
    [super viewDidLoad];
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

- (instancetype)initWithRootViewController:(UIViewController *)rootViewController
 {
     if (self = [super initWithRootViewController:rootViewController]) {
            // 设置navigationBar的背景颜色，根据需要自己设置
         self.navigationBar.barTintColor = G_COLOR_NAVGATION_BACK;
            // 设置navigationBar是否透明，不透明的话会使可用界面原点下移（0，0）点为导航栏左下角下方的那个点
            self.navigationBar.translucent = NO;
            // 设置navigationBar是不是使用系统默认返回，默认为YES
            self.interactivePopGestureRecognizer.enabled = YES;
            // 创建一个颜色，便于之后设置颜色使用
            UIColor * color = [UIColor blackColor];
            // 设置navigationBar元素的背景颜色，不包括title
            self.navigationBar.tintColor = color;
            // 设置navigationController的title的字体颜色
            NSDictionary * dict=[NSDictionary dictionaryWithObject:color forKey:NSForegroundColorAttributeName];
            self.navigationBar.titleTextAttributes = dict;
        
        }
     
         return self;
}

-(void)setBackBtnWith:(NSString*)image withCurrentVC:(UIViewController*)vc andBackAction:(SEL)action{
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:image] forState:UIControlStateNormal];
    
    btn.frame = CGRectMake(0, 0, 10, 18);
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:btn];
    
    vc.navigationItem.leftBarButtonItem = item;
    [btn addTarget:vc action:action forControlEvents:UIControlEventTouchUpInside];
}



- (void)CustomPushviewWith:(UIViewController*)vc {  //自定义切换动画效果
    CATransition *animation = [CATransition animation];
    [animation setDuration:1.5];
    [animation setType:kCATransitionFade]; //淡入淡出
    [animation setSubtype:kCATransitionFromLeft];
    [animation setTimingFunction:[CAMediaTimingFunction functionWithName:kCAMediaTimingFunctionDefault]];
    
    [self pushViewController:vc animated:NO];
    [self.view.layer addAnimation:animation forKey:nil];
    
}

-(void)navItemBtnHidenWith:(BOOL)isHiden andIsRight:(BOOL)isright andCurrentVC:(UIViewController *)vc{
    if (isright) {
        if (isHiden) {
            vc.navigationItem.rightBarButtonItem = nil;

        }
    }else{
        if (isHiden) {
            vc. navigationItem.leftBarButtonItem = nil;
            
        }
    }
}

-(void)setNavBarBtnItemImageWith:(NSString*)imageName andRightItem:(BOOL)isRight andAction:(SEL)action andTarget:(id)target andVCIndex:(NSInteger)index{
    
    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setBackgroundImage:[UIImage imageNamed:imageName] forState:UIControlStateNormal];
    
    btn.frame = CGRectMake(0, 0, 10, 10);
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:btn];
//    UIViewController *vc = self.viewControllers[index];
    UIViewController *vc = (UIViewController*)target;
    [btn sizeToFit];
    
    if (isRight) {
        
        vc.navigationItem.rightBarButtonItem = item;
        [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
        
    }else{
        vc.navigationItem.leftBarButtonItem = item;
        if (action) {
            [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];

        }else{
            [btn addTarget:self action:@selector(popAction:) forControlEvents:UIControlEventTouchUpInside];
            
        }
        
    }
    
}

-(void)setNavBarBtnItemTitleWith:(NSString*)title andRightItem:(BOOL)isRight andAction:(SEL)action andTarget:(id)target andVCIndex:(NSInteger)index andTitleColor:(UIColor *)color{

    UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
    [btn setTitle:title forState:UIControlStateNormal];
    btn.titleLabel.font = [UIFont systemFontOfSize:14];
    [btn setTitleColor:[UIColor whiteColor] forState:UIControlStateNormal];
    
    if (color) {
        [btn setTitleColor:color forState:UIControlStateNormal];

    }
    btn.frame = CGRectMake(0, 0, 80, 30);
    [btn sizeToFit];
    
    UIBarButtonItem *item = [[UIBarButtonItem alloc] initWithCustomView:btn];
//    UIViewController *vc = self.viewControllers[index];
    UIViewController *vc = (UIViewController*)target;
    if (isRight) {
        
        vc.navigationItem.rightBarButtonItem = item;
        [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
        
    }else{
        vc.navigationItem.leftBarButtonItem = item;
        if (action) {
            [btn addTarget:target action:action forControlEvents:UIControlEventTouchUpInside];
            
        }else{
            [btn addTarget:self action:@selector(popAction:) forControlEvents:UIControlEventTouchUpInside];
            
        }
        
    }
}

-(void)popAction:(UIButton*)sender{
    [self popViewControllerAnimated:YES];
}

-(void)setNavBarBtnItemNoneWithVCIndex:(NSInteger)index andIsRight:(BOOL)right{
    
//    UIViewController *vc = self.viewControllers[index];
    
    
}


@end
