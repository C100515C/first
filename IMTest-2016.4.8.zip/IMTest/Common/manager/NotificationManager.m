//
//  NotificationManager.m
//  IMTest
//
//  Created by chenchen on 16/4/6.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "NotificationManager.h"
#import "RootVC.h"
#import "AppDelegate.h"
#import "BasicVC.h"
#import "InformationVC.h"

static NSString *const Notification_key = @"storeNotiState";
static NSString *const Notification_message_key = @"storeNotiMessageState";

@implementation NotificationManager

#pragma mark - 注册推送
+(void)registerNotification
{
    if ([[[UIDevice currentDevice] systemVersion] floatValue] >= 8.0) {
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings settingsForTypes:(UIUserNotificationTypeSound | UIUserNotificationTypeAlert | UIUserNotificationTypeBadge) categories:nil]];
        [[UIApplication sharedApplication] registerForRemoteNotifications];
    }else {
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:(UIRemoteNotificationTypeBadge | UIRemoteNotificationTypeSound | UIRemoteNotificationTypeAlert)];
    }
}

+(BOOL)appPushIsOpen{
   return [[NSUserDefaults standardUserDefaults] boolForKey:Notification_key];
}

+(void)changeAppPushStateWith:(BOOL)isOpen{
    [[NSUserDefaults standardUserDefaults] setBool:isOpen forKey:Notification_key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+(BOOL)appMessagePushIsOpen{
    return [[NSUserDefaults standardUserDefaults] boolForKey:Notification_message_key];

}

+(void)changeMessagePushStateWith:(BOOL)isOpen{
    [[NSUserDefaults standardUserDefaults] setBool:isOpen forKey:Notification_message_key];
    [[NSUserDefaults standardUserDefaults] synchronize];
}

+ (BOOL)isAllowedNotification
{
    
    if(IOS8_OR_LATER) {// system is iOS8
        UIUserNotificationSettings *setting = [[UIApplication sharedApplication] currentUserNotificationSettings];
        
        if(UIUserNotificationTypeNone != setting.types) {
            
            return YES;
        }
    }
    else{//iOS7
        UIRemoteNotificationType type = [[UIApplication sharedApplication] enabledRemoteNotificationTypes];
        
        if(UIRemoteNotificationTypeNone != type)
            
            return YES;
    }
    
    return NO;
}

#pragma mark - 点击通知启动App
+(BOOL)startAppFromeNotificationWithOptions:(NSDictionary *)launchOptions
{
    NSDictionary *remoteNotification = [launchOptions objectForKey: UIApplicationLaunchOptionsRemoteNotificationKey];
    if (remoteNotification != nil) {
        //软件完全关闭，通过推送开启
        [self pushNotificationVCWith:remoteNotification];
//        MOSLog(@"推送来了3");
        return YES;
    }else{
        return NO;
    }
}

/**
 *  推送消息处理
 *
 *  @param infor 推送消息Dic
 */
+(void)pushNotificationVCWith:(NSDictionary*)infor{
//    MOSLog(@"%@",infor);
    
    AppDelegate *mainDelegate = [[UIApplication sharedApplication] delegate];
    
    BOOL isAppActivity = [[UIApplication sharedApplication] applicationState] == UIApplicationStateActive;
    if (!isAppActivity) {
        
        NSString *msg_type = [infor objectForKey:@"message_type"];
        
        RootVC *root = (RootVC*)mainDelegate.window.rootViewController;
        [root setSelectedIndex:1];
        UINavigationController *subNav = [root.viewControllers objectAtIndex:1];
        BasicVC *subVC = subNav.viewControllers[0];
        
        if ([msg_type isEqualToString:@"1"]) {
            
            [self performSelector:@selector(choiceIMVCWithVC:) withObject:root afterDelay:0.1];
            return;
            
        } else if ([msg_type isEqualToString:@"10101"]) {
            
        } else if ([msg_type isEqualToString:@"10102"]) {
           
        } else if ([msg_type isEqualToString:@"10201"]) {
           
        } else if ([msg_type isEqualToString:@"90101"]) {
            
        } else if ([msg_type isEqualToString:@"90201"]) {
           
        }
      
        [self performSelector:@selector(choiceSubVCNextVCWithVC:) withObject:@[subVC] afterDelay:0.1];
        
    }else{
        RootVC *root = (RootVC*)mainDelegate.window.rootViewController;
        [root getNotRead];
        //        AudioServicesPlaySystemSound(1007);
        //        AudioServicesPlayAlertSound(kSystemSoundID_Vibrate);//震动
    }
}
+(void)choiceSubVCNextVCWithVC:(NSArray*)objs{

}

+ (void)choiceIMVCWithVC:(RootVC *)imVC
{
    [imVC setSelectedIndex:2];
}

+(void)refreshSubVC{
    AppDelegate *app = (AppDelegate*)[UIApplication sharedApplication].delegate;
    RootVC *root = (RootVC*) app.window.rootViewController;
    UINavigationController *tabNav = [root.viewControllers objectAtIndex:2];
    InformationVC *infr = tabNav.viewControllers[0];
    [infr refreshTableWith:YES];
    [root getNotRead];
    
}

//处理IM 推送 的超市等信息
+ (void)reciveImNotification:(NSDictionary *)notificationDic
{
//    MOSLog(@"%@",notificationDic);
    
    [self myLocationNotificationWithIsIM:YES andInfor:notificationDic];
}

#pragma mark - 生成token和将token发送至服务器
+ (void)didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken
{
//    [UserInfoStore  refreshUserNotificationWithStatus:YES];
    
    NSString *deviceTokenStr = [[[[deviceToken description]
                                  stringByReplacingOccurrencesOfString: @"<" withString: @""]
                                 stringByReplacingOccurrencesOfString: @">" withString: @""]
                                stringByReplacingOccurrencesOfString: @" " withString: @""];
    
//    [UserInfoStore refreshMosDevToken:deviceTokenStr];
//    [DeviceTokenControl uploadDeviceToken];
}

#pragma mark - 处理远程推送
+ (void)didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    [self pushNotificationVCWith:userInfo];
}

#pragma mark -本地推送
//*//本地推送
+(void)myLocationNotificationWithIsIM:(BOOL)isIM andInfor:(NSDictionary*)infor{
    
    
    BOOL isAppActivity = [[UIApplication sharedApplication] applicationState] == UIApplicationStateActive;
    
    if (!isAppActivity) {
        
        UILocalNotification *notification = [self getMyLoactionNotificationWith:infor];
        
        if (!notification) {
            
            // 创建一个本地推送
            notification = [[UILocalNotification alloc] init] ;
        }
        
        //设置1秒之后
        NSDate *pushDate = [NSDate dateWithTimeIntervalSinceNow:1];
        
        if (notification != nil) {
            
            // 设置推送时间
            notification.fireDate = pushDate;
            // 设置时区
            notification.timeZone = [NSTimeZone defaultTimeZone];
            // 设置重复间隔
            notification.repeatInterval = 0;//kCFCalendarUnitDay
            // 推送声音
            notification.soundName = UILocalNotificationDefaultSoundName;//UILocalNotificationDefaultSoundName;
            
            if (isIM) {
                // 推送内容
                notification.alertBody = [infor objectForKey:@"desc"];
            }
            
            //显示在icon上的红色圈中的数子
            //            NSInteger  cout = notification.applicationIconBadgeNumber;
            //            notification.applicationIconBadgeNumber = 1+cout;
            //设置userinfo 方便在之后需要撤销的时候使用
            NSString *msg_type = [infor objectForKey:@"message_type"];
            NSString *att_id = [infor objectForKey:@"attention_id"];
            NSDictionary *info = [NSDictionary dictionaryWithObjectsAndKeys:msg_type,@"message_type",att_id,@"attention_id", nil];
            notification.userInfo = info;
            
            //添加推送到UIApplication
            UIApplication *app = [UIApplication sharedApplication];
            [app scheduleLocalNotification:notification];
        }
        
        
    }else{
        
        if (isIM) {
            //                AudioServicesPlaySystemSound(1007);
            //                AudioServicesPlayAlertSound(kSystemSoundID_Vibrate);//震动
            
            [self refreshSubVC];
        }
        
        /*
         if (![[[NSUserDefaults standardUserDefaults] objectForKey:@"Isopen"] isEqualToString:@"isopen"]) {
         //自定义声音
         NSString *path = [[NSBundle mainBundle] pathForResource:@"music" ofType:@"wav"];
         //组装并播放音效
         SystemSoundID soundID;
         NSURL *filePath = [NSURL fileURLWithPath:path isDirectory:NO];
         AudioServicesCreateSystemSoundID((__bridge CFURLRef)filePath, &soundID);
         AudioServicesPlaySystemSound(soundID);
         AudioServicesPlayAlertSound(kSystemSoundID_Vibrate);//震动
         }
         [[NSUserDefaults standardUserDefaults] setObject:@"noopen" forKey:@"Isopen"];
         //*/
        //声音停止
        //            AudioServicesDisposeSystemSoundID(soundID);
        
    }
    
}

+(void)removeMyLoactionNotificationWith:(NSDictionary*)infor{
    
    // 获得 UIApplication
    UIApplication *app = [UIApplication sharedApplication];
    //获取本地推送数组
    NSArray *localArray = [app scheduledLocalNotifications];
    //声明本地通知对象
    UILocalNotification *localNotification ;
    if (localArray) {
        for (UILocalNotification *noti in localArray) {
            NSString *dict = noti.alertBody;
            if (dict) {
                NSString *inKey = [infor objectForKey:@"desc"];
                if ([dict isEqualToString:inKey]) {
                    if (localNotification){
                        localNotification = nil;
                    }
                    localNotification = noti;
                    break;
                }
            }
        }
        //判断是否找到已经存在的相同key的推送
        if (!localNotification) {
            //不存在初始化
            localNotification = [[UILocalNotification alloc] init];
        }
        
        if (localNotification) {
            //不推送 取消推送
            [app cancelLocalNotification:localNotification];
            //            [localNotification release];
            return;
        }
    }
    
}

+(UILocalNotification *)getMyLoactionNotificationWith:(NSDictionary*)infor{
    // 获得 UIApplication
    UIApplication *app = [UIApplication sharedApplication];
    //获取本地推送数组
    NSArray *localArray = [app scheduledLocalNotifications];
    //声明本地通知对象
    UILocalNotification *localNotification ;
    if (localArray) {
        for (UILocalNotification *noti in localArray) {
            //            NSDictionary *dict = noti.userInfo;
            NSString *dict = noti.alertBody;
            
            if (dict) {
                NSString *inKey = [infor objectForKey:@"desc"];
                if ([dict isEqualToString:inKey]) {
                    if (localNotification){
                        localNotification = noti;
                    }
                    //                    localNotification = noti;
                    break;
                }
            }
        }
        
    }
    return localNotification;
}

@end
