//
//  CaseClipCommonResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"
#import "BaseRequest.h"

@interface  CaseClipCommonRequest: BaseRequest

@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *birthday;
@property (nonatomic,copy) NSString *gender;

-(id)init;

@end

@interface CaseClipRecordCommonRequest : BaseRequest
@property (nonatomic,copy) NSString *dossier_id;
@property (nonatomic,copy) NSString *visit_time;
@property (nonatomic,copy) NSString *hospital;
@property (nonatomic,copy) NSString *illness_category;

-(id)init;
-(void)setReqUrlWith:(NSString *)caseId;

@end

@interface CaseClipRecordCommonDeletePicRequest : BaseRequest
@property (nonatomic,copy) NSString *filename;
@property (nonatomic,copy) NSString *user_id;

-(id)init;
-(void)setReqUrlWith:(NSString*)caseId;
@end

@interface CaseClipCommonResponse : BasicResponse

@property (nonatomic,copy) NSString *nameTitle;
@property (nonatomic,copy) NSString *content;

@property (nonatomic,copy) NSString *parma;
@property (nonatomic,assign) BOOL isHideImage;

@property (nonatomic,assign) BOOL needNewHeight;
@property (nonatomic,copy) NSMutableArray *pics;

@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *user_id;

@property (nonatomic,assign) BOOL isEdit;

@end
