
//
//  FamilyCasesClipResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "FamilyCasesClipResponse.h"

@implementation FamilyCasesClipRequest

- (id)init
{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"dossier-details?user_id=%@&access-token=%@&",[[UserProfileManager sharedInstance] getUserId],token];
        
        self.reqMethod = @"GET";
        //        self.reqMethod = @"POST";
        self.reqClassName = @"FamilyCasesClip";
    }
    return self;
}

@end

static const CGFloat BasicHeight = 148.0f;
static const CGFloat AnotherHeight = 110.0;

@implementation FamilyCasesClipResponse

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }
   
    if (self.needHighHeight) {
        _cellHeight = AnotherHeight;
    }else{
        _cellHeight = BasicHeight;

    }
    
    return _cellHeight;
}

@end
