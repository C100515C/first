//
//  CaseClipDetailResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipDetailResponse.h"

@implementation CaseClipDetailRequest

- (id)init
{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"dossier-details?user_id=%@&access-token=%@&",[[UserProfileManager sharedInstance] getUserId],token];
        
        self.reqMethod = @"GET";
        //        self.reqMethod = @"POST";
        self.reqClassName = @"CaseClipDetailItmes";
    }
    return self;
}

@end

@implementation CaseClipDetailItmesResponse
-(NSMutableArray*)itemList{
    if (_itemList==nil) {
        _itemList = [NSMutableArray array];
    }
    return _itemList;
}

+(Class)itemList_class{
    return [CaseClipDetailResponse class];
}

@end

static const CGFloat BasicHeight = 160.0f;

@implementation CaseClipDetailResponse

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }
    
    _cellHeight = BasicHeight;
    if (!_photos.count) {
        _cellHeight = BasicHeight-84;
    }
    return _cellHeight;
}

-(NSString*)showAddress{
    if (_showAddress) {
        return _showAddress;
    }else{
        _showAddress = [NSString stringWithFormat:@"%@/%@",self.hospital,self.illness_category];
        return _showAddress;
    }
}

+(Class)photos_class{
    return [NSString class];
}

-(NSArray*)getNeedPhotos{
    NSMutableArray *arr = [[NSMutableArray alloc] init];
    for (NSString *str in self.photos) {
        NSDictionary *dic = [NSDictionary dictionaryWithObjectsAndKeys:str,@"image",[str substringFromIndex:str.length-3],@"type", nil];
        [arr addObject:dic];
    }
    return arr;
}

@end
