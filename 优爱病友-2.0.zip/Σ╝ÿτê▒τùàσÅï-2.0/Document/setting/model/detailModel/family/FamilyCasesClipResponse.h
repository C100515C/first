//
//  FamilyCasesClipResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"
#import "BaseRequest.h"

@interface  FamilyCasesClipRequest: BaseRequest
@property (nonatomic,copy) NSString *page;
@property (nonatomic,copy) NSString *dossier_id;
-(id)init;
@end

@interface FamilyCasesClipResponse : BasicResponse

@property (nonatomic,copy) NSString *userid;
@property (nonatomic,copy) NSString *nickname;
@property (nonatomic,copy) NSString *gender;
@property (nonatomic,copy) NSString *age;
@property (nonatomic,copy) NSString *caseCount;
@property (nonatomic,copy) NSString *icon;
@property (nonatomic,copy) NSString *time;
@property (nonatomic,copy) NSString *address;
@property (nonatomic,copy) NSArray *arr;

@property (nonatomic,assign) BOOL needHighHeight;

@end
