//
//  MyDynamicRequest.m
//  IMTest
//
//  Created by chenchen on 16/5/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MyDynamicRequest.h"

@implementation MyDynamicRequest

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"feeds?access-token=%@&",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        self.reqMethod = @"GET";
        //        self.reqMethod = @"POST";
        self.reqClassName = @"PostsItemList";
    }
    return self;
}
@end
