//
//  MyNoticeVC.h
//  IMTest
//
//  Created by chenchen on 16/5/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface MyNoticeVC : BasicVC

@end
