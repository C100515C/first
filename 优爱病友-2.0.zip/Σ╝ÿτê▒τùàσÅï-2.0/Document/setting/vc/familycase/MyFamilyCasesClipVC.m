//
//  MyFamilyCasesClipVC.m
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MyFamilyCasesClipVC.h"

#import "FamilyCasesClipCell.h"

#import "FamilyCasesClipResponse.h"
#import "SingletonServ.h"

#import "FamilyCaseClipDetailVC.h"
#import "AddFamilyCaseClipVC.h"
#import "AddFamilyCaseClipRecordVC.h"

#import "UIViewController+HUD.h"

@interface MyFamilyCasesClipVC (){
//    NSMutableArray *_dataSource;
    int _page;
}

@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (strong,nonatomic) NSMutableArray *dataSource;
@end

@implementation MyFamilyCasesClipVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self setNav];
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _dataSource = [[NSMutableArray alloc] init];
    
//    self.tableView.separatorStyle = UITableViewCellSeparatorStyleNone;
    __weak typeof(self) weakself = self;
    [self.emptyTableTipsView setAlertImageWith:@"meiyouguanzhu" andTitle:@"没有病例夹"];
    self.tableFinish = ^(BOOL finish){
        weakself.emptyTableTipsView.hidden = weakself.dataSource.count;
    };
    
    [self.tableView registerNib:[UINib nibWithNibName:@"FamilyCasesClipCell" bundle:nil] forCellReuseIdentifier:FamilyCasesClip_id];
    
    [self makeModel];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"myfamilyclip"];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"myfamilyclip"];
    
}

#pragma mark - Nav
-(void)setNav{
    [super setNav];

    self.title = @"家庭病例夹";
    
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    [nav setNavBarBtnItemImageWith:@"topicon_add" andRightItem:YES andAction:@selector(editClickdAction:) andTarget:self andVCIndex:1];
}

-(void)editClickdAction:(UIButton*)sender{
    
    MOSLog(@"添加");
    __weak typeof(self) weakself = self;
    AddFamilyCaseClipVC *vc = [[AddFamilyCaseClipVC alloc] init];
    vc.RefreshPreviousVCNewDataWhenThisVCDiscover = ^(BOOL isDiscover){
        [weakself tableViewDidTriggerHeaderRefresh];
    };
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - network data
-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    __weak typeof(self) weakself = self;
    
    FamilyCasesClipRequest *req = [[FamilyCasesClipRequest alloc] init];

    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        if (responeseError==nil) {
            
            if (isHeaderRef) {
                [weakself.dataSource removeAllObjects];
            }
            
            //
            [weakself.myTable reloadData];
            
        }else{
        
        }
        [weakself hideHud];
        weakself.emptyTableTipsView.hidden = weakself.dataSource.count;

        if (finishBlock) {
            finishBlock(YES);
        }
    }];
}

-(void)makeModel{
    
    [_dataSource addObjectsFromArray:[self getSecondSection]];
    
    [_myTable reloadData];
}


-(NSArray *)getSecondSection{
    NSMutableArray *sectionArr = [NSMutableArray array];
    for (int i=0 ; i<5; i++) {
        FamilyCasesClipResponse *model = [[FamilyCasesClipResponse alloc] init];
        model.nickname = @"啦啦";
        model.caseCount = @"12";
        model.age = @"55";
        model.gender = @"男";
        model.time = @"2016-01-15";
        model.icon = @"no";
        model.address = @"北京";
        UIImage *image = [UIImage imageNamed:@"callBg"];
        UIImage *image1 = [UIImage imageNamed:@"callBg"];
        UIImage *image2 = [UIImage imageNamed:@"chat_location_preview"];
        model.arr = @[image,image1,image2];
        [sectionArr addObject:model];
    }
    return sectionArr;
}

- (void)tableViewDidTriggerHeaderRefresh{
    _page = 1;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];

    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:YES reload:NO];

    } andHeaderRef:YES];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    _page ++;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];

    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:NO reload:NO];

    } andHeaderRef:NO];
    
}//上拉加载事件

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    FamilyCasesClipResponse *model = (FamilyCasesClipResponse*)[_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    __weak typeof(self) weakself = self;

    FamilyCasesClipCell *cell = [tableView dequeueReusableCellWithIdentifier:FamilyCasesClip_id];
    
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"FamilyCasesClipCell" owner:nil options:nil] firstObject];
    }
    
    FamilyCasesClipResponse *model = (FamilyCasesClipResponse*)[_dataSource objectAtIndex:indexPath.row];
    
    [cell setCellWith:model];
    cell.AddBtnClickedBlock = ^(UIButton *btn){
        AddFamilyCaseClipRecordVC *vc = [[AddFamilyCaseClipRecordVC alloc] init];
        
        [weakself.navigationController pushViewController:vc animated:YES];
    };
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    FamilyCasesClipResponse *model = (FamilyCasesClipResponse*)[_dataSource objectAtIndex:indexPath.row];
    
    FamilyCaseClipDetailVC *vc = [[FamilyCaseClipDetailVC alloc] init];
    vc.caseId = @"7";//model.userid;
    [self.navigationController pushViewController:vc animated:YES];
}

@end
