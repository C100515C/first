//
//  MyDynamicVC.h
//  IMTest
//
//  Created by chenchen on 16/5/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface MyDynamicVC : BasicVC
@property (nonatomic,copy) NSString *user_id;
@end
