//
//  CaseClipCommonHeaderView.m
//  IMTest
//
//  Created by chenchen on 16/5/18.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipCommonHeaderView.h"
#import "BasicUIImageView.h"

@interface CaseClipCommonHeaderView ()<BasicUIImageTapProtocol>
@property (nonatomic,weak) IBOutlet UIView *view;
@end
@implementation CaseClipCommonHeaderView
- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        NSString *className = NSStringFromClass([self class]);
        self.view = [[[NSBundle mainBundle] loadNibNamed:className owner:self options:nil] firstObject];
        [self addSubview:self.view];
        return self;
    }
    return nil;
}

-(void)awakeFromNib{
    [self.uerIcon setRaduis];
    [self.uerIcon setTapUse];
    self.uerIcon.lyj_delegate = self;
}

#pragma mark - tap
-(void)imageTapWith:(UITapGestureRecognizer *)sender{
    if (_tapImageBlock) {
        _tapImageBlock(self.uerIcon);
    }
}

@end
