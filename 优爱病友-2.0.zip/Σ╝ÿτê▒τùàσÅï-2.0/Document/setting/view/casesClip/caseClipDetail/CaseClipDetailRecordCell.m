//
//  CaseClipDetailRecordCell.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipDetailRecordCell.h"
#import "CaseClipDetailResponse.h"

#import "LYJPicturesBrowse.h"

#import<objc/runtime.h>

static NSString *const DelModelKey = @"del";
static NSString *const EditModelKey = @"edit";

@interface CaseClipDetailRecordCell ()
@property (weak, nonatomic) IBOutlet BasicUIButton *delBtn;

@property (weak, nonatomic) IBOutlet BasicUIButton *editbtn;

@property (weak, nonatomic) IBOutlet BasicLabel *time;
@property (weak, nonatomic) IBOutlet BasicLabel *addres;

- (IBAction)deleteBtnClicked:(BasicUIButton *)sender;
- (IBAction)editBtnClicked:(BasicUIButton *)sender;
@property (weak, nonatomic) IBOutlet LYJPicturesBrowse *picsBrowse;

@end

@implementation CaseClipDetailRecordCell

-(void)awakeFromNib{
    [super awakeFromNib];
    self.time.type = LabelFont_12;
    self.addres.type = LabelFont_15;
}

-(void)setCellWith:(CaseClipDetailResponse *)model{

    self.time.text = model.visit_time;
    self.addres.text = model.showAddress;
    
    [self setBtnBindModel:model];
    
    self.picsBrowse.isHidenDelete = YES;
    
    self.picsBrowse.pics = [model.photos mutableCopy];
    
}

-(void)setBtnBindModel:(CaseClipDetailResponse*)model{
    objc_setAssociatedObject(_delBtn, (__bridge const void *)(DelModelKey), model, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    objc_setAssociatedObject(_editbtn, (__bridge const void *)(EditModelKey), model, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
}

-(CaseClipDetailResponse*)getCellWith:(NSString*)key andObj:(BasicUIButton*)obj{
    CaseClipDetailResponse *model = (CaseClipDetailResponse*) objc_getAssociatedObject(obj, (__bridge const void *)(key));
    return model;
}

- (IBAction)deleteBtnClicked:(BasicUIButton *)sender {
//    MOSLog(@"xx");
    
    if (_delBtnClickedBlock) {
        _delBtnClickedBlock([self getCellWith:DelModelKey andObj:sender]);
    }
}

- (IBAction)editBtnClicked:(BasicUIButton *)sender {
//    MOSLog(@"xx");

    if (_editBtnClickedBlock) {
        _editBtnClickedBlock([self getCellWith:EditModelKey andObj:sender]);
    }
}

@end
