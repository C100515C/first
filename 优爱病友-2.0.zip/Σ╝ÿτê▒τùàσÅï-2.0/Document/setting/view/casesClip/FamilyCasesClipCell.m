//
//  FamilyCasesClipCell.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "FamilyCasesClipCell.h"
#import "FamilyCasesClipResponse.h"

#import "LYJPicturesBrowse.h"

@interface FamilyCasesClipCell ()

@property (weak, nonatomic) IBOutlet BasicLabel *callName;

@property (weak, nonatomic) IBOutlet BasicLabel *gender;
@property (weak, nonatomic) IBOutlet BasicLabel *age;
@property (weak, nonatomic) IBOutlet BasicLabel *caseCount;
@property (weak, nonatomic) IBOutlet BasicLabel *caseAddress;
@property (weak, nonatomic) IBOutlet BasicUIImageView *icon;
@property (weak, nonatomic) IBOutlet BasicLabel *time;
@property (weak, nonatomic) IBOutlet BasicUIButton *addCaseBtn;
@property (weak, nonatomic) IBOutlet LYJPicturesBrowse *picBrowser;

@end

@implementation FamilyCasesClipCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self.icon setRaduis];
    
    self.gender.type = LabelFont_15;
    self.callName.type = LabelFont_17;
    self.age.type = LabelFont_15;
    self.caseAddress.type = LabelFont_15;
    self.caseCount.type = LabelFont_15;
    self.time.type = LabelFont_12;
    [self.addCaseBtn addTarget:self action:@selector(addCaseBtnAciton:) forControlEvents:UIControlEventTouchUpInside];
    self.picBrowser.backContentView.backgroundColor = RGB(247, 249, 249, 1);
}

-(void)setCellWith:(FamilyCasesClipResponse *)model{

    self.callName.text = model.nickname;
    
    self.gender.text = model.gender;

    self.age.text = model.age;

    self.caseCount.text = model.caseCount;
    
    [self.icon sd_setImageWithURL:[NSURL URLWithString:model.icon] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    
    self.caseAddress.text = model.address;
    self.time.text = model.time;
    
    self.picBrowser.isHidenDelete = YES;

    if (model.arr.count==0) {
        self.picBrowser.hidden = YES;
        
    }else{

        self.picBrowser.pics = model.arr;
        self.picBrowser.hidden = NO;
    }
    
}
#pragma mark - btn
-(void)addCaseBtnAciton:(UIButton*)sender{
    if (_AddBtnClickedBlock) {
        _AddBtnClickedBlock(sender);
    }
}
@end
