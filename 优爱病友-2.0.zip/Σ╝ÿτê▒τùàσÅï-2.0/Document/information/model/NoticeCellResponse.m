//
//  NoticeCellResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "NoticeCellResponse.h"

static const CGFloat BasicHeight = 38.0f;

@implementation NoticeCellResponse

@synthesize nicknameAndOp = _nicknameAndOp;
@synthesize created_at = _created_at;

-(NSMutableArray *)title{
    if (_title==nil) {
        _title = [NSMutableArray array];
    }
    return _title;
}
+(Class)title_class{
    return [NSString class];
}

-(void)setNicknameAndOp:(NSString *)nicknameAndOp{
    _nicknameAndOp = nicknameAndOp;
}

-(NSString*)nicknameAndOp{
    if (_nicknameAndOp) {
        return _nicknameAndOp;
    }else{
        if ([self.system intValue]==0) {
            return [NSString stringWithFormat:@"%@ %@",self.from_user_name,self.type_name];

        }else{
            return [NSString stringWithFormat:@"系统消息 %@",self.type_name];
        }
    }
}

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size = [self getStringSizeWith:_content fontSize:FontSize_15 showSize:CGSizeMake(SCREEN_WIDTH, 2000)];
        _cellHeight = size.height+BasicHeight;
        return _cellHeight;
    }
}

@end

@implementation NoticeCellItemsResponse
-(NSMutableArray*)items{
    if (_items==nil) {
        _items = [NSMutableArray array];
    }
    return _items;
}

+(Class)items_class{
    return [NoticeCellResponse class];
}
@end

@implementation NoticeCellItems_metaResponse

@end
