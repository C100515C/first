//
//  NoticeTableCell.h
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

@class NoticeCellResponse;
static NSString * const NoticeCell_id = @"notice";

@interface NoticeTableCell : BasicTableViewCell
@property (weak, nonatomic) IBOutlet BasicLabel *nicknameLabel;
@property (weak, nonatomic) IBOutlet BasicLabel *desContentLabel;
@property (weak, nonatomic) IBOutlet BasicLabel *timeLabel;

-(void)setCellWithModel:(NoticeCellResponse*)model;

@end
