//
//  CircleDetailAttentonRequset.m
//  IMTest
//
//  Created by chenchen on 16/3/31.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleDetailAttentonRequset.h"

@implementation CircleDetailAttentonRequset

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"forums?access-token=%@",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        //        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"PublishPost";
    }
    return self;
}

@end
