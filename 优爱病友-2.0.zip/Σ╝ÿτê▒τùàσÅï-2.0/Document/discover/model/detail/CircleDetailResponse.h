//
//  CircleDetailResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface CircleDetailItemListResponse : BasicResponse
@property (nonatomic,strong) NSMutableArray *itemList;

+(Class)itemList_class;

@end

@interface CircleDetailHeaderResponse : BasicResponse
@property (nonatomic,copy) NSString *forum_id;
@property (nonatomic,copy) NSString *forum_name;
@property (nonatomic,copy) NSString *forum_icon;
@property (nonatomic,copy) NSString *follow_count;
@property (nonatomic,copy) NSString *thread_count;
@property (nonatomic,copy) NSString *isFollow;
@property (nonatomic,copy) NSString *posts;

@property (nonatomic,strong) NSMutableAttributedString *attFollow_count;
@property (nonatomic,strong) NSMutableAttributedString *posts_count;
@end

@interface CircleDetail_metaResponse : BasicResponse
@property (nonatomic,copy) NSString *totalCount;
@property (nonatomic,copy) NSString *pageCount;
@property (nonatomic,copy) NSString *currentPage;
@property (nonatomic,copy) NSString *perPage;
@end

@interface CircleDetailItemListOfFindResponse : BasicResponse
@property (nonatomic,strong) NSMutableArray *recommend;
@property (nonatomic,strong) NSMutableArray *items;
@property (nonatomic,strong) CircleDetail_metaResponse *_meta;
@property (nonatomic,strong) CircleDetailHeaderResponse *forum;

+(Class)recommend_class;
+(Class)items_class;

@end


@interface CircleDetailUserInforResponse : BasicResponse
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *username;
@property (nonatomic,copy) NSString *avatar;

@end

@interface CircleDetailPostInforResponse : BasicResponse
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *username;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *avatar;

@end

@interface CircleDetailResponse : BasicResponse

@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *updated_at;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *board_id;
@property (nonatomic,copy) NSString *post_count;
@property (nonatomic,copy) NSString *edited_at;
@property (nonatomic,copy) NSString *status;
@property (nonatomic,copy) NSString *sources;
@property (nonatomic,copy) NSString *forum_id;
@property (nonatomic,copy) NSString *thread_status;
@property (nonatomic,copy) NSString *thread_type;
@property (nonatomic,copy) NSString *browse_count;
@property (nonatomic,copy) NSString *shares_count;
@property (nonatomic,copy) NSString *collect_count;
@property (nonatomic,copy) NSString *attention_count;
@property (nonatomic,copy) NSString *forum_name;

@property (nonatomic,strong) CircleDetailUserInforResponse *user_info;
@property (nonatomic,strong) CircleDetailPostInforResponse *postInfo;
@property (nonatomic,strong) CircleDetailUserInforResponse *userInfo;


@property (nonatomic,assign) CGFloat new_topHeight;
@property (nonatomic,strong) NSMutableAttributedString *timeFrom;
-(UIColor*)getLabelColor;


@end

@interface CircleDetailHotResponse : BasicResponse

@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *attention_count;
@property (nonatomic,copy) NSString *board_id;
@property (nonatomic,copy) NSString *browse_count;
@property (nonatomic,copy) NSString *collect_count;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *edited_at;
@property (nonatomic,copy) NSString *forum_id;
@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *post_count;
@property (nonatomic,copy) NSString *shares_count;
@property (nonatomic,copy) NSString *sources;
@property (nonatomic,copy) NSString *status;
@property (nonatomic,copy) NSString *thread_status;
@property (nonatomic,copy) NSString *thread_type;
@property (nonatomic,copy) NSString *title;
@property (nonatomic,copy) NSString *updated_at;
@property (nonatomic,copy) NSString *user_id;

-(UIColor*)getLabelColor;

@end