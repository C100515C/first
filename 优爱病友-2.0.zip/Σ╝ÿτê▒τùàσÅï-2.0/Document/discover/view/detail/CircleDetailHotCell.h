//
//  CircleDetailHotCell.h
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"


static NSString * const CircleDetailHotCell_id = @"circledetailhot";

@class CircleDetailHotResponse;

@interface CircleDetailHotCell : BasicTableViewCell

-(void)setCellWith:(CircleDetailHotResponse*)model;

@end
