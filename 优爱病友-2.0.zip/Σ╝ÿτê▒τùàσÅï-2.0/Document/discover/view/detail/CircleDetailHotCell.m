//
//  CircleDetailHotCell.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleDetailHotCell.h"
#import "CircleDetailResponse.h"

@interface CircleDetailHotCell ()
@property (weak, nonatomic) IBOutlet BasicLabel *titleType;
@property (weak, nonatomic) IBOutlet BasicLabel *content;

@end

@implementation CircleDetailHotCell

-(void)awakeFromNib{
    [super awakeFromNib];
    [self.titleType setBorder];
    
    self.titleType.type = LabelFont_12;
    self.content.type = LabelFont_16;
}

-(void)setCellWith:(CircleDetailHotResponse *)model{
    self.titleType.text = model.thread_type;
    self.titleType.LYJ_textColor = [model getLabelColor];
    
    self.content.text = model.title;
}

@end
