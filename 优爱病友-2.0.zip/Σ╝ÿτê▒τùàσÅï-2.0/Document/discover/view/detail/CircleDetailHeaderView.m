//
//  CircleDetailHeaderView.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleDetailHeaderView.h"
#import "BasicUIButton.h"
#import "BasicUIImageView.h"
#import "BasicLabel.h"

#import "CircleDetailResponse.h"

@interface CircleDetailHeaderView ()<BasicUIImageTapProtocol>

@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;
@property (weak, nonatomic) IBOutlet BasicLabel *name;
@property (weak, nonatomic) IBOutlet BasicLabel *counts;
@property (weak, nonatomic) IBOutlet BasicLabel *postsCount;
@property (weak, nonatomic) IBOutlet BasicUIButton *focusBtn;

@property (nonatomic,assign) BOOL isfollow;

- (IBAction)focusAction:(BasicUIButton *)sender;

@end

@implementation CircleDetailHeaderView

-(void)awakeFromNib{
    self.focusBtn.clipsToBounds = YES;
    self.focusBtn.layer.cornerRadius = 3.0f;
    self.focusBtn.titleLabelFrame = CGRectMake(18, 5, 50, 20);
    self.focusBtn.imageFrame = CGRectMake(5, 11, 10, 10);
    
    [self.headerIcon setTapUse];
    self.headerIcon.lyj_delegate = self;
    
    self.name.type = LabelFont_17;
    self.counts.type = LabelFont_12;
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    if (_CircleDetailHeaderImageTapBlock) {
        _CircleDetailHeaderImageTapBlock(nil);
    }
}

-(void)setHeaerViewWith:(CircleDetailHeaderResponse *)model{
    
    [self.headerIcon sd_setImageWithURL:[NSURL URLWithString:model.forum_icon] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.name.text = model.forum_name;
//    self.counts.text = model.follow_count;
    self.counts.attributedText = model.attFollow_count;
    self.postsCount.attributedText = model.posts_count;
    self.isfollow = [model.isFollow boolValue];
    if ([model.isFollow intValue]==1) {
//        [self.focusBtn setTitle:@"已关注" forState:UIControlStateNormal];
        [self.focusBtn setBackgroundImage:[UIImage imageNamed:@"yiguanzhu"] forState:UIControlStateNormal];
    }else{
//        [self.focusBtn setTitle:@"关注" forState:UIControlStateNormal];
        [self.focusBtn setBackgroundImage:[UIImage imageNamed:@"guanzhu"] forState:UIControlStateNormal];
    }
}

-(void)attentionBtnClickedWith:(CircleDetailHeaderResponse *)model{
    if ([model.isFollow intValue]==1) {
//        [self.focusBtn setTitle:@"已关注" forState:UIControlStateNormal];
        [self.focusBtn setBackgroundImage:[UIImage imageNamed:@"yiguanzhu"] forState:UIControlStateNormal];

    }else{
//        [self.focusBtn setTitle:@"关注" forState:UIControlStateNormal];
        [self.focusBtn setBackgroundImage:[UIImage imageNamed:@"guanzhu"] forState:UIControlStateNormal];

    }
    model.attFollow_count = nil;
    self.counts.attributedText = model.attFollow_count;

}

- (IBAction)focusAction:(BasicUIButton *)sender {

//    if (self.isfollow) {
//        MOSLog(@"已关注");
//        return;
//    }
    
    if (_CircleDetailHeaderBtnTapBlocl) {
        _CircleDetailHeaderBtnTapBlocl(sender);
    }
}

#pragma mark - tap image
-(void)imageTapWith:(UITapGestureRecognizer *)sender{

    if (_CircleDetailHeaderImageTapBlock) {
        _CircleDetailHeaderImageTapBlock(sender);
    }
}

@end
