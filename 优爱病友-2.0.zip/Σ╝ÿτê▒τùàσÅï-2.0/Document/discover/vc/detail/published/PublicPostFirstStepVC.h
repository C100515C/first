//
//  PublicPostFirstStepVC.h
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface PublicPostFirstStepVC : BasicVC
@property (nonatomic,copy) NSString *forum_id;

@end
