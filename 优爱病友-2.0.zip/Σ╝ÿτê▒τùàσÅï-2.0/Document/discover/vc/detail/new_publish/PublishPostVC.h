//
//  PublishPostVC.h
//  IMTest
//
//  Created by chenchen on 16/5/18.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface PublishPostVC : BasicVC
@property (nonatomic,copy) NSString *forum_id;

@end
