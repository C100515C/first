//
//  PersonalHomepageResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MineSetUserInforResponse.h"

@interface PersonalHomepageResponse : MineSetUserInforResponse

@property (nonatomic,assign) CGFloat signatureHeight;
@property (nonatomic,assign) CGFloat focusLabelHeight;

@end
