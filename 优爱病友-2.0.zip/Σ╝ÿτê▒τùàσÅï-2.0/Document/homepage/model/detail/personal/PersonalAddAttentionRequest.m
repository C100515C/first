//
//  PersonalAddAttentionRequest.m
//  IMTest
//
//  Created by chenchen on 16/4/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalAddAttentionRequest.h"

@implementation PersonalAddAttentionRequest
- (id)init
{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"follows?access-token=%@&",token];
        
//        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"PersonalAddAttention";
    }
    return self;
}
@end
