//
//  PostRepeatsVC.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostRepeatsVC.h"

#import "PostRepeatsResponse.h"
#import "PostRepeatsRequest.h"
#import "SingletonServ.h"
#import "SendRepeatRequest.h"
#import "SendRepeatsResponse.h"

#import "PostRepeatsCell.h"

#import "LYJToolbar.h"
#import "LYJInputView.h"

#import "UIViewController+HUD.h"

@interface PostRepeatsVC ()<LYJInputViewDelegate,LYJToolBarDelegate>{
//    NSMutableArray *_dataSource;
    int _page;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (strong,nonatomic)     NSMutableArray *dataSource;

@property (nonatomic, strong) LYJToolbar *inputBar;
@property (nonatomic,assign) CGFloat barBottonLayoutHeight;
@property (nonatomic, strong) LYJInputView *inputView;

@property (nonatomic,copy) NSString *parent_id;
@property (nonatomic,copy) NSString *parent_user_id;
@property (nonatomic,assign) BOOL isRepeatSomeone;

@end

@implementation PostRepeatsVC

//重新init 则导航条 返回按钮 无法自定义 原因待查
//- (instancetype)init
//{
//    self = [super init];
//    if (self) {
//        
//    }
//    return self;
//}

-(void)initUI{
    self.inputView = [[[NSBundle mainBundle] loadNibNamed:@"LYJInputView" owner:nil options:nil] firstObject];
    self.inputView.lyj_delegate = self;
    self.inputView.inputTitle.text = @"回复";
    
    [self.view addSubview: self.inputView];
    
    self.inputView.hidden = YES;
}

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    [super viewDidLoad];
    
    [self initUI];
    
    __weak typeof(self) weakself = self;
    [self.emptyTableTipsView setAlertImageWith:@"meiyouguanzhu" andTitle:@"这里还没人说哈"];
    self.tableFinish = ^(BOOL finish){
        weakself.emptyTableTipsView.hidden = weakself.dataSource.count;
    };
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _dataSource = [[NSMutableArray alloc] init];
    _page = 1;
    self.isRepeatSomeone = NO;
    [self.tableView registerNib:[UINib nibWithNibName:@"PostRepeatsCell" bundle:nil] forCellReuseIdentifier:PostRepeatsCell_id];
    
    LYJToolbar *bar = [[LYJToolbar alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-44, self.view.frame.size.width, 44)];
    bar.textPlaceholder = @"请输入您回复的内容";
    bar.sendDelegate = self;
    [self.view addSubview:bar];
    self.inputBar = bar;
    
    [bar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view.mas_bottom).with.offset(0);
        make.left.equalTo(self.view.mas_left).with.offset(0);
        make.right.equalTo(self.view.mas_right).with.offset(0);
        make.height.equalTo(@(44));
    }];
    
    [self makeModelWith:_page with:nil andHeaderRef:YES];
    
    [self setNav];

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setNav{
    [super setNav];
    self.title = @"回复评论";
   
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    self.inputView.hidden = YES;
    [MobClick endLogPageView:@"postRepeats"];

}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.inputView.hidden = YES;
    [MobClick beginLogPageView:@"postRepeats"];

}

-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{

    PostRepeatsRequest *req = [[PostRepeatsRequest alloc] init];
    req.post_id = self.post_id;
    req.thread_id = self.thead_id;
    req.page = [NSString stringWithFormat:@"%d", page ];
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
       
        if (responeseError==nil) {
            
            if (isHeaderRef) {
                [weakself.dataSource removeAllObjects];
            }
            
            PostRepeatsItemsResponse *model = (PostRepeatsItemsResponse*)responseDataModel;
            
            [weakself.dataSource addObjectsFromArray:model.item];
            [weakself.tableView reloadData];
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
        if (finishBlock) {
            finishBlock(YES);
        }
        weakself.emptyTableTipsView.hidden = weakself.dataSource.count;
        [weakself hideHud];
    }];
    
}

- (void)tableViewDidTriggerHeaderRefresh{
    __weak typeof(self) weakself = self;
    _page = 1;
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:YES reload:NO];

    } andHeaderRef:YES];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    __weak typeof(self) weakself = self;
    _page++;
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:NO reload:NO];
        
    } andHeaderRef:NO];
    
}//上拉加载事件

-(void)sendPostRepeatWith:(NSString*)content {
    
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"发送中..."];
    SendRepeatCommentRequest *req = [[SendRepeatCommentRequest alloc] init];
    
    req.content = content;
    req.thread_id = self.thead_id;
    req.post_id = self.post_id;
    
    [[SingletonServ sharedInstance ] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            [weakself showHint:@"评论成功" yOffset:-200];

//            MOSLog(@"%@",responseDataModel);
            [weakself refreshTablePostWith:nil];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        [weakself hideHud];
    }];
}

-(void)sendPostSomeoneRepeatWith:(NSString*)content{

    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"发送中..."];
    SendRepeatSomeoneCommentRequest *req = [[SendRepeatSomeoneCommentRequest alloc] init];
    
    req.content = content;
    req.thread_id = self.thead_id;
    req.post_id = self.post_id;
    req.parent_id = self.parent_id;
    req.parent_user_id = self.parent_user_id;
    
    [[SingletonServ sharedInstance ] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            [weakself showHint:@"回复成功" yOffset:-200];

            [weakself refreshTablePostWith:nil];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        [weakself hideHud];
    }];
}

-(void)refreshTablePostWith:(HeaderOrFooterRefFinish)finishBlock{
    
    PostRepeatsRequest *req = [[PostRepeatsRequest alloc] init];
    req.post_id = self.post_id;
    req.thread_id = self.thead_id;
    
    __weak typeof(self) weakself = self;

    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            
            [weakself.dataSource removeAllObjects];
       
            PostRepeatsItemsResponse *model = (PostRepeatsItemsResponse*)responseDataModel;
            
            [weakself.dataSource addObjectsFromArray:model.item];
            [weakself.tableView reloadData];
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        weakself.emptyTableTipsView.hidden = weakself.dataSource.count;
        if (finishBlock) {
            finishBlock(YES);
        }
    }];
}

#pragma mark - table

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    PostRepeatsResponse *model = [_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    PostRepeatsCell *cell = [tableView dequeueReusableCellWithIdentifier:PostRepeatsCell_id];
    
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"PostRepeatsCell" owner:nil options:nil] firstObject];
    }
    PostRepeatsResponse *model = [_dataSource objectAtIndex:indexPath.row];
    
    [cell setCellWithModel:model];
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    PostRepeatsResponse *model = [_dataSource objectAtIndex:indexPath.row];

    NSString *pu_id = model.userInfo.user_id;
    NSString *userid = [[UserProfileManager sharedInstance]getUserId];
    if ([pu_id integerValue]!=[userid integerValue]) {
        [_inputBar keybaordAppear];
        NSString *text = [NSString stringWithFormat:@"回复 %@的评论",model.userInfo.username];
        _inputBar.textPlaceholder = text;
        self.isRepeatSomeone = YES;
        self.parent_id = model.objectId;
        self.parent_user_id = model.userInfo.user_id;
    }else{
        [self showHint:@"自己不能回复自己" yOffset:-200];
    }
    
}

-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [_inputBar takeBackKeyboard];
}

#pragma mark -lyj tool bar
-(void)keyboardAppearWith:(CGFloat)height{
    
    self.inputView.hidden = NO;
    [self.inputView keyboardAppear];
}



#pragma mark - lyj inputView
-(void)sendBtnAction:(UIButton *)sender andText:(NSString *)text{
    MOSLog(@"%@",text);
    if (text.length!=0) {
        if (self.isRepeatSomeone) {
            [self sendPostSomeoneRepeatWith:text];
        }else{
            [self sendPostRepeatWith:text];
        }
    }
}
-(void)cancleBtnAction:(UIButton *)sender andText:(NSString *)text{
    MOSLog(@"%@",text);
}

@end
