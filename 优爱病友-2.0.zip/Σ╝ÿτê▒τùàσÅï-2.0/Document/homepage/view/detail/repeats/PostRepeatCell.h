//
//  PostRepeatCell.h
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString * const PostsRepeatCellIdentifier = @"postrepeat";
typedef enum {
    PostRepeatCellPraiseBtn = 50,
    PostRepeatCellRepeatBtn
}PostRepeatCellBtn;
typedef void (^PostRepeatCellLongPressBlock)(UILongPressGestureRecognizer *sender);
typedef void (^PostRepeatCellBtnBlock)(PostRepeatCellBtn btnname);

typedef void (^PostRepeatCellHeaderTapBlock)(NSString* userId);
@class  PostRepeatListResponse;
@interface PostRepeatCell : BasicTableViewCell

@property (nonatomic,copy) PostRepeatCellLongPressBlock longPressBlock;
@property (nonatomic,copy) PostRepeatCellBtnBlock btnBlock;

@property (nonatomic,copy) PostRepeatCellHeaderTapBlock tapBlock;

-(void)setCellWith:(PostRepeatListResponse*)model;
@end
