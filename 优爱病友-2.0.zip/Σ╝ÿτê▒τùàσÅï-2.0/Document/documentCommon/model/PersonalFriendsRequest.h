//
//  PersonalFriendsRequest.h
//  IMTest
//
//  Created by chenchen on 16/4/27.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"
#import "BasicResponse.h"

@interface PersonalFriendsRequest : BaseRequest
@property (nonatomic,copy) NSString *page;
@property (nonatomic,copy) NSString *user_id;

-(id)init;
@end

@interface PersonalFriends_meta : BasicResponse
@property (nonatomic,copy) NSString *currentPage;
@property (nonatomic,copy) NSString *pageCount;
@property (nonatomic,copy) NSString *perPage;
@property (nonatomic,copy) NSString *totalCount;

@end

@interface PersonalFriends_userInfo : BasicResponse
@property (nonatomic,copy) NSString *avatar;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *username;

@end


@interface PersonalFriends_items : BasicResponse
@property (nonatomic,copy) NSString *location;
@property (nonatomic,copy) NSString *people_id;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *signature;
@property (nonatomic,copy) NSString *status;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *id;

@property (nonatomic,strong) PersonalFriends_userInfo *userInfo;

@end

@interface PersonalFriendsResponse : BasicResponse

@property (nonatomic,strong) NSMutableArray *items;
@property (nonatomic,strong) PersonalFriends_meta *_meta;

+(Class)items_class;

@end