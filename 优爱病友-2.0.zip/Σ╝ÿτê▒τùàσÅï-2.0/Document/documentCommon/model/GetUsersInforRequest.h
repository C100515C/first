//
//  GetUsersInforRequest.h
//  IMTest
//
//  Created by chenchen on 16/4/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"
#import "BasicResponse.h"

@interface GetUsersInforRequest : BaseRequest
@property (nonatomic,copy) NSString *user_id;

-(id)init;

@end

@interface GetUsersInforItemResponse : BasicResponse
@property (nonatomic,strong) NSMutableArray *itemList;

+(Class)itemList_class;

@end

@interface GetUsersInforResponse : BasicResponse
@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *username;
@property (nonatomic,copy) NSString *avatar;
@property (nonatomic,copy) NSString *user_id;

@end