//
//  PersonalAnswersRequest.m
//  IMTest
//
//  Created by chenchen on 16/4/26.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalAnswersRequest.h"

static const CGFloat BasicHeight = 39.0f;
static const CGFloat TopBasicHeight = 40.0f;

@implementation PersonalAnswersRequest
-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"posts?access-token=%@&",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        self.reqMethod = @"GET";
        //        self.reqMethod = @"POST";
        self.reqClassName = @"PersonalAnswers";
    }
    return self;
}
@end

@implementation PersonalAnswersResponse

-(NSMutableArray*)items{
    if (_items==nil) {
        _items = [NSMutableArray array];
    }
    return _items;
}

+(Class)items_class{
    return [PersonalAnswers_items class];
}

@end

@implementation PersonalAnswers_items

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size = [self getStringSizeWith:self.content fontSize:FontSize_14 showSize:CGSizeMake(SCREEN_WIDTH-51, 2000)];
        _cellHeight = size.height+5+BasicHeight+self.topNewHeight;
        
        return _cellHeight;
    }
    
}

-(CGFloat)topNewHeight{
    if (_topNewHeight) {
        return _topNewHeight;
    }else{
        
        CGSize size = [self getStringSizeWith:self.thread_title fontSize:FontSize_15 showSize:CGSizeMake(SCREEN_WIDTH-51, 2000)];
        _topNewHeight = size.height+5+TopBasicHeight;
        return _topNewHeight;
    }
}

-(NSString*)thread_type{
    
    if ([_thread_type integerValue]==2) {
        return @"吐槽";
        
    }else if ([_thread_type integerValue]==1){
        return @"提问" ;
        
    }else{
        return @"推荐";
    }
}

-(UIColor*)getLabelColor{
    if ([self.thread_type isEqualToString:@"吐槽"]) {
        return [UIColor redColor];
    }else if ([self.thread_type isEqualToString:@"提问"]){
        return [UIColor orangeColor];
    }else{
        return RGB(57, 189,104, 1);
    }
}


@end

@implementation PersonalAnswers_meta

@end

@implementation PersonalAnswers_userInfo

@end
