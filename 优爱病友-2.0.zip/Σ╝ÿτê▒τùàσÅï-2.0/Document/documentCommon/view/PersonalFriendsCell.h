//
//  PersonalFriendsCell.h
//  IMTest
//
//  Created by chenchen on 16/4/27.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString * const PersonalFriends_id = @"PersonalFriends";
@class PersonalFriends_items;
@interface PersonalFriendsCell : BasicTableViewCell

@property (nonatomic,copy) void (^AttentionBtnClickedBlock)(NSInteger isAttented);

-(void)setMyCellWith:(PersonalFriends_items*)model;
-(void)changeAttendBtnStateWith:(NSString*)state;
-(void)hidenAttendBtnWith:(BOOL)isHide;

@end
