//
//  PersonalPublicCell.m
//  IMTest
//
//  Created by chenchen on 16/4/27.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalPublicCell.h"
#import "PersonalPublicRequest.h"

@interface PersonalPublicCell ()
@property (weak, nonatomic) IBOutlet BasicLabel *postType;
@property (weak, nonatomic) IBOutlet BasicLabel *postTitle;

@property (weak, nonatomic) IBOutlet BasicLabel *repeatCount;
@property (weak, nonatomic) IBOutlet BasicLabel *attentionCount;

@end

@implementation PersonalPublicCell

-(void)awakeFromNib{
    [super awakeFromNib];
    [self.postType setBorder];
    
    self.postTitle.type = LabelFont_15;
    self.repeatCount.type = LabelFont_12;
    self.attentionCount.type = LabelFont_12;
}

-(void)setMyCellWith:(PersonalPublic_items *)model{
    
    self.postType.text = model.thread_type;
    self.postType.LYJ_textColor = [model getLabelColor];
    
    self.postTitle.text = model.title;
    self.repeatCount.text = model.post_count;
    self.attentionCount.text = model.attention_count;
}

@end
