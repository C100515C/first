//
//  PersonalAnswersVC.m
//  IMTest
//
//  Created by chenchen on 16/4/26.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalAnswersVC.h"

#import "PostDetailVC.h"

#import "PersonalAnswersCell.h"

#import "PersonalAnswersRequest.h"
#import "SingletonServ.h"

#import "UIViewController+HUD.h"

@interface PersonalAnswersVC (){
    int _page;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (nonatomic,strong) NSMutableArray *myDataSource;

@end

@implementation PersonalAnswersVC

- (void)viewDidLoad {
    self.tableView = self.myTable;
    
    [super viewDidLoad];
    
    self.myDataSource = [[NSMutableArray alloc] init];
    
    self.myTable.delegate = self;
    self.myTable.dataSource = self;
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _page = 1;
    
    [self.myTable registerNib:[UINib nibWithNibName:@"PersonalAnswersCell" bundle:nil] forCellReuseIdentifier:PersonalAnswers_id];
    
    __weak typeof(self) weakself = self;
    [self.emptyTableTipsView setAlertImageWith:@"meiyouguanzhu" andTitle:@"还没有评论过"];
    self.tableFinish = ^(BOOL finish){
        weakself.emptyTableTipsView.hidden = weakself.myDataSource.count;
    };
    
    [self setNav];
    [self showHudInView:self.view hint:@"加载中..."];
    [self makeModelWith:_page with:nil andHeaderRef:YES];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - property

#pragma mark - net work
-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    
    PersonalAnswersRequest *req = [[PersonalAnswersRequest alloc] init];
    req.user_id = self.userid;
    req.page = [NSString stringWithFormat:@"%d",page];
    
    __weak typeof(self) weakself = self;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
       
        if (responeseError==nil) {
            
            if (isHeaderRef) {
                [weakself.myDataSource removeAllObjects];
            }
            
            PersonalAnswersResponse *model = (PersonalAnswersResponse*)responseDataModel;
            [weakself.myDataSource addObjectsFromArray:model.items];
            
            [weakself.myTable reloadData];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        [weakself hideHud];
        weakself.emptyTableTipsView.hidden = weakself.myDataSource.count;

        if (finishBlock) {
            finishBlock(YES);
        }
    }];
    
}
#pragma mark - refresh
- (void)tableViewDidTriggerHeaderRefresh{
    _page = 1;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:YES reload:NO];
        
    } andHeaderRef:YES];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    _page ++;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:NO reload:NO];
        
    } andHeaderRef:NO];
    
}//上拉加载事件
#pragma mark - table
-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return self.myDataSource.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    PersonalAnswersResponse *model = [self.myDataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    PersonalAnswersCell *cell = [tableView dequeueReusableCellWithIdentifier:PersonalAnswers_id];
    
    if (cell==nil) {
        cell  = [[[NSBundle mainBundle] loadNibNamed:@"PersonalAnswersCell" owner:nil options:nil] firstObject];
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    PersonalAnswers_items *model = [self.myDataSource objectAtIndex:indexPath.row];
    [cell setMyCellWith:model];
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    PersonalAnswers_items *model = (PersonalAnswers_items*)[_myDataSource objectAtIndex:indexPath.row];
    
    PostDetailVC *vc = [[PostDetailVC alloc] init];
//    vc.hidesBottomBarWhenPushed = YES;
    vc.thread_id = model.thread_id;
//    vc.post_id = model.post_id;
    vc.title = [NSString stringWithFormat:@"%@详情",model.forum_name];
    [self.navigationController pushViewController:vc animated:YES];
}



@end
