//
//  Discover_newVC.m
//  IMTest
//
//  Created by chenchen on 16/5/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "Discover_newVC.h"
#import "Discover_newCell.h"

#import "UIViewController+HUD.h"

#import "circleDetailVC.h"

#import "DiscoverRequest.h"
#import "DiscoverResponse.h"
#import "SingletonServ.h"

@interface Discover_newVC ()
{
    int _page;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (nonatomic,strong) NSMutableArray *dataSource;
@end

@implementation Discover_newVC

- (void)viewDidLoad {
    
    self.tableView = self.myTable;
    
    [super viewDidLoad];
    
    self.title = @"发现";
    
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    self.showSearchBar = NO;
    
    [self.myTable registerNib:[UINib nibWithNibName:@"Discover_newCell" bundle:nil] forCellReuseIdentifier:Discover_newId];
    self.myTable.separatorStyle = UITableViewCellSeparatorStyleNone;
    
    __weak typeof(self) weakself = self;
    [self.emptyTableTipsView setAlertImageWith:@"meiyouguanzhu" andTitle:@"没有内容"];
    self.tableFinish = ^(BOOL finish){
        weakself.emptyTableTipsView.hidden = weakself.dataSource.count;
    };
    
    _page = 1;
    _dataSource = [[NSMutableArray alloc] init];
    
    [self showHudInView:self.view hint:@"加载中..."];
    [self makeModelWith:_page with:nil andHeaderRef:YES];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"find"];
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"find"];
}

-(void)refreshTableAndNeedHint:(BOOL)isNeed{
    [self makeModelWith:0 with:nil andHeaderRef:YES];
}

#pragma mark - net work
-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    __weak typeof(self) weakself = self;
    //    [self showHudInView:self.view hint:@""];
    DiscoverRequest *req = [[DiscoverRequest alloc] init];
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            DiscoverResponse *model = (DiscoverResponse*)responseDataModel;
            if (isHeaderRef) {
                [weakself.dataSource removeAllObjects];
            }
            [weakself.dataSource addObjectsFromArray:model.itemList];
            [weakself.myTable reloadData];
        }else {
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        [weakself hideHud];
        if (finishBlock) {
            finishBlock(YES);
        }
    }];
}

- (void)tableViewDidTriggerHeaderRefresh{
    _page = 1;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:YES reload:NO];
        
    } andHeaderRef:YES];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    _page ++;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:NO reload:NO];
        
    } andHeaderRef:NO];
    
}//上拉加载事件

#pragma mark - table

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    DiscoverItemResponse *model = (DiscoverItemResponse*)[_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    Discover_newCell *cell = [tableView dequeueReusableCellWithIdentifier:Discover_newId];
    
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"Discover_newCell" owner:nil options:nil] firstObject];
    }
    DiscoverItemResponse *model = (DiscoverItemResponse*)[_dataSource objectAtIndex:indexPath.row];
    
    [cell setCellWith:model];
    
//    __weak typeof(DiscoverItemResponse*) weakmodel = model;
//    __weak typeof (self) weakself = self;
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    DiscoverItemResponse *model = [_dataSource objectAtIndex:indexPath.row];
    circleDetailVC *vc = [[circleDetailVC alloc] init];
    vc.title = model.forum_name;
    vc.forum_id = model.objectId;
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
    
}

@end
