//
//  Discover_newCell.m
//  IMTest
//
//  Created by chenchen on 16/5/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "Discover_newCell.h"
#import "DiscoverResponse.h"

@interface Discover_newCell ()
@property (weak, nonatomic) IBOutlet UIView *backView;

@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;
@property (weak, nonatomic) IBOutlet BasicLabel *circleTitle;
@property (weak, nonatomic) IBOutlet BasicLabel *focusCount;
@property (weak, nonatomic) IBOutlet BasicLabel *publicCount;
@property (weak, nonatomic) IBOutlet BasicLabel *des;

@end

@implementation Discover_newCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self.headerIcon setRaduis];
    self.backView.clipsToBounds = YES;
    self.backView.layer.cornerRadius = 5.0f;
    self.backView.layer.borderColor = RGB(212, 212, 212, 1).CGColor;
    self.backView.layer.borderWidth = 0.5f;
    
    self.circleTitle.type = LabelFont_17;
    self.des.type = LabelFont_15;
}

-(void)setCellWith:(DiscoverItemResponse*)model{

    [self.headerIcon sd_setImageWithURL:[NSURL URLWithString:model.forum_icon] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.circleTitle.text = model.forum_name;
    self.focusCount.text = model.follow_count;
    self.publicCount.text = model.thread_count;
    self.des.text = model.forum_desc;
}

@end
