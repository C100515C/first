//
//  GetSMSRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/21.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "GetSMSRequest.h"
static  NSString *const KEY = @"fjdaJKofjK%&#*(flajfj)-";
@implementation GetSMSRequest

- (id)init
{
    self = [super init];
    if (self) {
        self.reqUrlPath = @"sms";
        
        //        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"GetSMS";
    }
    return self;
}

-(NSString*)time{
    NSDate *date = [NSDate date];
    NSTimeInterval interval = [date timeIntervalSince1970] * 1000;
    NSString *dateStr = [NSString stringWithFormat:@"%f",interval];
    _time = dateStr;
    return _time;
}

-(NSString*)sign{

     NSString *sign = [NSString stringWithFormat:@"%@&%@&%@",self.phone,self.time,KEY];
    _sign = [NSString md5:sign];
    return _sign;
}

@end
