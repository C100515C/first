//
//  GetSMSRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/21.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface GetSMSRequest : BaseRequest

@property (strong, nonatomic) NSString *phone;
@property (nonatomic,copy) NSString *sign;
@property (nonatomic,copy) NSString *time;

- (id)init;

@end
