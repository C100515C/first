//
//  UIAlertController+LYJAlertView.m
//  IMTest
//
//  Created by chenchen on 16/2/25.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "UIViewController+LYJAlertView.h"

@implementation UIViewController (LYJAlertView)

+(void)showAlertTltileWith:(NSString *)title andMessage:(NSString *)message andActions:(NSDictionary *)actions andShowVC:(id)showVC andAlertStyle:(UIAlertControllerStyle)style andalertTag:(NSInteger)tag{

    if (IOS7_OR_LOW) {
        if (style==UIAlertControllerStyleAlert) {
            
            UIAlertView *alert = [[UIAlertView alloc] initWithTitle:title message:message delegate:showVC cancelButtonTitle:@"取消" otherButtonTitles:nil];
            
            for (NSString *str in [actions allKeys]) {
                if (![str isEqualToString:@"取消"]) {
                    [alert addButtonWithTitle:str];
                }
            }
            alert.tag = tag;
            [alert show];
            return;
        }else{
            UIActionSheet *sheet = [[UIActionSheet alloc] initWithTitle:title delegate:showVC cancelButtonTitle:@"取消" destructiveButtonTitle:nil otherButtonTitles:nil];
            UIViewController *vc = (UIViewController*)showVC;
            for (NSString *str in [actions allKeys]) {
                if (![str isEqualToString:@"取消"]) {
                    [sheet addButtonWithTitle:str];
                }
            }
            sheet.tag = tag;
            [sheet showInView:vc.view];
        }
        
    }else{
        
        UIAlertController *alertController = [UIAlertController alertControllerWithTitle:title message:message preferredStyle:(style)];
        
        for (NSString *s in [actions allKeys]) {
            if (![s isEqualToString:@"取消"]) {
                UIAlertAction *okAction = [UIAlertAction actionWithTitle:s style:(UIAlertActionStyleDefault) handler:[actions objectForKey:s]];
                [alertController addAction:okAction];
            }
        }
        
        UIAlertAction *okAction = [UIAlertAction actionWithTitle:@"取消" style:(UIAlertActionStyleDefault) handler:[actions objectForKey:@"取消"]];
        [alertController addAction:okAction];
        
        [showVC presentViewController:alertController animated:YES completion:nil];
    }
    
}

@end
