//
//  NSString+UrlCode.h
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NSString (UrlCode)

- (NSString *)urlEncodeForSymbol;
+(NSString *) md5:(NSString *)str;

@end
