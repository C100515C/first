//
//  NotificationManager.h
//  IMTest
//
//  Created by chenchen on 16/4/6.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface NotificationManager : NSObject

//注册推送
+(void)registerNotification;

//点击推送启动App
+(BOOL)startAppFromeNotificationWithOptions:(NSDictionary *)launchOptions;

//生成token和将token发送至服务器
+ (void)didRegisterForRemoteNotificationsWithDeviceToken:(NSData *)deviceToken;

//处理远程推送
+ (void)didReceiveRemoteNotification:(NSDictionary *)userInfo;

//处理IM 推送 的超市等信息
+ (void)reciveImNotification:(NSDictionary *)notificationDic;
/**
 *  判断推送是否开启
 *
 *  @return
 */
+(BOOL)appPushIsOpen;
/**
 *  改变推送状态
 *
 *  @param isOpen
 */
+(void)changeAppPushStateWith:(BOOL)isOpen;
+(BOOL)appMessagePushIsOpen;
+(void)changeMessagePushStateWith:(BOOL)isOpen;

+ (BOOL)isAllowedNotification;
#pragma mark -本地推送
//*//本地推送
+(void)myLocationNotificationWithIsIM:(BOOL)isIM andInfor:(NSDictionary*)infor;

@end
