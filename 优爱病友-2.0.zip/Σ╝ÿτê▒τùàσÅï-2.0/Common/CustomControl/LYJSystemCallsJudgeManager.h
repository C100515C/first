//
//  LYJSystemCallsJudgeManager.h
//  IMTest
//
//  Created by chenchen on 16/3/14.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <Foundation/Foundation.h>

typedef void (^LYJSystemJudeAlertBlock)(void);

@interface LYJSystemCallsJudgeManager : NSObject

/**
 *  判断是否可以使用相机
 *
 *  @return yes 可以用  no 不可以用
 */
+(BOOL)isCanUseCamera_CCWith:(LYJSystemJudeAlertBlock)alert;
+(BOOL)iscanPictureAblumWith:(LYJSystemJudeAlertBlock) alert;
@end
