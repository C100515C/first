//
//  LYJBannerView.m
//  IMTest
//
//  Created by chenchen on 16/3/10.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJBannerView.h"
#define CURRENT_WIDTH self.frame.size.width

@interface LYJBannerModel : NSObject<NSCopying>

@property (nonatomic,copy) NSString *imageStr;
@property (nonatomic,copy) NSString *imageId;
@property (nonatomic,copy) NSString *url;

@end

@implementation LYJBannerModel

- (id)copyWithZone:(NSZone *)zone
{
    LYJBannerModel *copy = [[self class] allocWithZone: zone];
    
    copy.imageId = self.imageId;
    copy.imageStr = self.imageStr;
    copy.url = self.url;
    
    return copy;
}

@end

static NSString * const cell_id = @"cell_id";
static const NSInteger cell_image = 11;
static NSString const* contentOffset_Changed = @"contentOffset_Changed";

@interface LYJBannerView ()<UITableViewDataSource,UITableViewDelegate>

@property (nonatomic,strong) UITableView *myTableView;
@property (nonatomic,retain) NSMutableArray *dataSource;

@property (nonatomic,assign) int currentIndex;
@property (nonatomic,assign) int index;
@property (nonatomic,strong) NSTimer *timer;

@end

@implementation LYJBannerView

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
        self.dataSource = [[NSMutableArray alloc] init];
        [self setUIWith:frame];
        [self reloadTableWithDataSource:nil];
        [self addObserver:self forKeyPath:@"myTableView.contentOffset" options:NSKeyValueObservingOptionNew context:(__bridge void *)(contentOffset_Changed)];
        _index= 1;
    }
    return self;
}

-(void)dealloc{
    [self removeObserver:self forKeyPath:@"myTableView.contentOffset" context:(__bridge void *)(contentOffset_Changed)];
    [self overTimer];
}

-(void)setMyTableView:(UITableView *)myTableView{
    
    if (!_myTableView) {
        CGRect new_frame = myTableView.frame;
        new_frame.size.width = myTableView.frame.size.height;
        new_frame.size.height = myTableView.frame.size.width;
        myTableView.frame = new_frame;
        
        myTableView.transform = CGAffineTransformMakeRotation(-M_PI / 2);
        myTableView.center = CGPointMake((self.frame.size.width)/2.0,self.frame.size.height/2.0);
        myTableView.bounces = YES;
    }
    _myTableView = myTableView;
}

-(void)setUIWith:(CGRect)frame{
    
    UITableView *table = [[UITableView alloc] initWithFrame:frame style:UITableViewStylePlain];
    table.delegate = self;
    table.dataSource = self;
    table.showsHorizontalScrollIndicator = NO;
    table.showsVerticalScrollIndicator = NO;
    table.pagingEnabled = YES;
    table.separatorStyle = UITableViewCellSeparatorStyleNone;
    [self addSubview:table];
    self.myTableView = table;
    self.myTableView.backgroundColor =[UIColor blackColor];
}

-(void)setCustomCellWith:(UITableViewCell*)cell{
    
    cell.contentView.transform = CGAffineTransformMakeRotation(M_PI / 2);
    
    UIImageView *image = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, self.frame.size.width,self.frame.size.height)];
    image.tag = cell_image;
    [cell.contentView addSubview:image];
    image.image = [UIImage imageNamed:@"account"];
    
}

-(void)reloadTableWithDataSource:(NSDictionary*)dic{
#warning 假的数据
    NSArray *arr = @[@"account",@"chat_location_preview",@"call_silence",@"callBg",@"chat_item_file"];
    for (int i=0; i<5; i++) {
        LYJBannerModel *model = [[LYJBannerModel alloc] init];
        model.imageId = arr[i];
        [_dataSource addObject:model];
        
    }
    LYJBannerModel *firstModel = (LYJBannerModel*)[[_dataSource firstObject] copy];
    LYJBannerModel *lastModel = (LYJBannerModel*)[[_dataSource lastObject] copy];

    [_dataSource insertObject:lastModel atIndex:0 ];
    [_dataSource insertObject:firstModel atIndex:_dataSource.count];
    
    [_myTableView reloadData];
}

-(void)setCellWith:(LYJBannerModel*)model andCell:(UITableViewCell*)cell{

    UIImageView *image = (UIImageView*)[cell viewWithTag:cell_image];
    image.image = [UIImage imageNamed:model.imageId];
    
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    
    if ([keyPath isEqualToString: @"myTableView.contentOffset"]) {
        LYJBannerView *p = (LYJBannerView*)object;
//        MOSLog(@"name after change = %@,%f,%@",[change valueForKey:NSKeyValueChangeNewKey],p.myTableView.contentOffset.y,(__bridge NSString*)context);
        self.currentIndex = [self getPageWith:p.myTableView.contentOffset.y];
        
    }else{
        MOSLog(@"test after change = %@,%@",[change valueForKey:NSKeyValueChangeNewKey],(__bridge NSString*)context);
    }
}

#pragma mark - table 
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    
    return _dataSource.count;
    
}

-(CGFloat )tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    return self.frame.size.width;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    UITableViewCell *cell = [tableView dequeueReusableCellWithIdentifier:cell_id];
    
    if (cell==nil) {
        cell = [[UITableViewCell alloc] initWithStyle:UITableViewCellStyleDefault reuseIdentifier:cell_id];
        [self setCustomCellWith:cell];
    
    }
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    LYJBannerModel *model = [_dataSource objectAtIndex:indexPath.row];
    [self setCellWith:model andCell:cell];
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    MOSLog(@"%ld",indexPath.row);
}

-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [self overTimer];
    
    if (_currentIndex == _dataSource.count-1) {
        self.myTableView.contentOffset = CGPointMake(0, CURRENT_WIDTH*1);
    }
    
    if (_currentIndex == 1) {
        self.myTableView.contentOffset = CGPointMake(0, CURRENT_WIDTH*(_dataSource.count-1));
    }
    MOSLog(@"start");
}


- (void)scrollViewDidEndDecelerating:(UIScrollView *)scrollView{
    _index = _currentIndex;
    _currentIndex = 0;
    [self timerStart];
    
    MOSLog(@"over");
}

#pragma mark - timer

-(NSTimer*)timer{
    
    if (!_timer) {
        _timer = [NSTimer scheduledTimerWithTimeInterval:2.0f
                                                       target:self
                                                     selector:@selector(oneSecondFlip)
                                                     userInfo:nil
                                                      repeats:YES];
    }
    
    return _timer;
}

- (void)oneSecondFlip
{
    if (_index == _dataSource.count-1) {
        _index = 1;
    }
    
    self.myTableView.contentOffset = CGPointMake(0, CURRENT_WIDTH*_index);
    _index ++;
}

- (void)timerStart
{
    
//    self.index = 1;
    self.myTableView.contentOffset = CGPointMake(0, CURRENT_WIDTH*_index);

    [self.timer fire];
}

-(void)overTimer{
    [self.timer invalidate];
    _timer = nil;
}

-(int)getPageWith:(CGFloat)offset{
    int page = 0;
    
    page = offset/CURRENT_WIDTH;
    
    return page;
}

@end

