//
//  EmptyTableTipsView.m
//  IMTest
//
//  Created by chenchen on 16/4/14.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "EmptyTableTipsView.h"

@interface EmptyTableTipsView ()
@property (weak, nonatomic) IBOutlet UIImageView *alertImage;
@property (weak, nonatomic) IBOutlet UILabel *alerttitle;
@property (weak, nonatomic) IBOutlet UIView *alertLineOne;
@property (weak, nonatomic) IBOutlet UIView *alertLineTwo;

@end

@implementation EmptyTableTipsView

-(void)awakeFromNib{

}

-(void)setAlertImageWith:(NSString*)image andTitle:(NSString*)title{
    self.alertImage.image = [UIImage imageNamed:image];
    self.alerttitle.text = title;
}

@end
