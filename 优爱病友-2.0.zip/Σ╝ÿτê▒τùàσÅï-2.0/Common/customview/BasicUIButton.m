//
//  BasicUIButton.m
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicUIButton.h"

@implementation BasicUIButton
-(void)awakeFromNib{
    
}

-(void)setType:(ButtonContentFontType)type{
    if (type==ButtonFont_14) {
        self.titleLabel.font = [UIFont systemFontOfSize:FontSize_14];//[UIFont fontWithName:@".PingFang-SC-Thin" size:ContentFontSize_14];
    }else if(type==ButtonFont_15){
        self.titleLabel.font = [UIFont systemFontOfSize:FontSize_15];//[UIFont fontWithName:@".PingFang-SC-Thin" size:TitleFontSize_15];
    }else if(type==ButtonFont_12){
        self.titleLabel.font = [UIFont systemFontOfSize:FontSize_12];//[UIFont fontWithName:@".PingFang-SC-Thin" size:AlertFontSize_12];
    }else if(type==ButtonFont_16){
        self.titleLabel.font = [UIFont systemFontOfSize:FontSize_16];//[UIFont fontWithName:@".PingFang-SC-Thin" size:NickNameFontSize_16];
    }else if(type==ButtonFont_13){
        self.titleLabel.font = [UIFont systemFontOfSize:FontSize_13];//[UIFont fontWithName:@".PingFang-SC-Thin" size:RepeatContentFontSize_13];
    }else{
        self.titleLabel.font = [UIFont systemFontOfSize:FontSize_17];//[UIFont fontWithName:@".PingFang-SC-Thin" size:BigFontSize_17];
    }
}

-(CGRect)titleRectForContentRect:(CGRect)contentRect{
    
    if ([self judeRectWith:_titleLabelFrame] ) {
        return _titleLabelFrame;
    }
    return [super titleRectForContentRect:contentRect];
    return CGRectMake(21, 3,60, 16);
}

-(CGRect)imageRectForContentRect:(CGRect)contentRect{
    
    if ([self judeRectWith:_imageFrame]) {
        return _imageFrame;
    }
    return [super imageRectForContentRect:contentRect];
    return CGRectMake(3, 4, 16, 16);
}

-(UIEdgeInsets)imageEdgeInsets{
    if ([self judeEdgeInset:_imageSet ]) {
        return _imageSet;
    }
    UIEdgeInsets  edge = UIEdgeInsetsMake(0, -5, 0, 0);
    return edge;
}

-(BOOL)judeRectWith:(CGRect)rect{
    CGFloat s = [self flagWith:rect.size.width] +[self flagWith:rect.size.height]+[self flagWith:rect.origin.x]+[self flagWith:rect.origin.y];
    if (s) {
        return YES;
    }
    return NO;
}

-(CGFloat)flagWith:(CGFloat)f{
    if (f>0) {
        return f;
    }
    else{
        return (-1)*f;
    }
}

-(BOOL)judeEdgeInset:(UIEdgeInsets)edge{
    CGFloat s = [self flagWith:edge.top ]+[self flagWith:edge.bottom ]+[self flagWith:edge.right ]+[self flagWith:edge.left ];
    if (s) {
        return  YES;
    }
    return NO;
}

@end
