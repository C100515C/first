//
//  BaseResponse.h
//  ufenqiDemo
//
//  Created by uchange on 14/12/3.
//  Copyright (c) 2014年 youthcode. All rights reserved.
//

#import "Jastor.h"

@interface BaseResponse : Jastor

@property (strong, nonatomic) NSString *responseType;  // 返回类名称

@end
