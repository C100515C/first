//
//  BaseResponse.m
//  ufenqiDemo
//
//  Created by uchange on 14/12/3.
//  Copyright (c) 2014年 youthcode. All rights reserved.
//

#import "BaseResponse.h"

@implementation BaseResponse

@end
