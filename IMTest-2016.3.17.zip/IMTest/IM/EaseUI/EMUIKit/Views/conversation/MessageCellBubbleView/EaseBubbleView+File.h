//
//  EaseBubbleView+File.h
//  ChatDemo-UI3.0
//
//  Created by dhc on 15/7/1.
//  Copyright (c) 2015年 easemob.com. All rights reserved.
//

#import "EaseBubbleView.h"

@interface EaseBubbleView (File)

- (void)setupFileBubbleView;

- (void)updateFileMargin:(UIEdgeInsets)margin;

@end
