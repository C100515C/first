//
//  LYJDBManager.h
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <Foundation/Foundation.h>

@interface LYJDBManager : NSObject

+(LYJDBManager*)getSharedInstance;

-(BOOL)createDBWith:(NSString*)table With:(NSArray*)param;

-(BOOL) saveData:(NSString*)sql withParam:(NSArray*)params;

-(NSArray*) findBySql:(NSString*)sql withParams:(NSArray*)params;

-(BOOL)deletBySql:(NSString *)sql withParams:(NSArray*)params;

-(BOOL)updateWithSql:(NSString*)sql andParams:(NSArray*)params;


/***************************sql*************************/

/*
 创建表
 */
+ (BOOL)createTableWithSql:(NSString *)sql;

/*
 插入数据
 */
+ (BOOL)insertTableWithSql:(NSString *)sql params:(NSArray *)params;

/*
 查询数据(数组)
 */
+(NSArray *)queryForArrayWithSql:(NSString *)sql Params:(NSArray *)params;

/*
 更新数据
 */
+(BOOL)updateTableWithSql:(NSString *)sql Params:(NSArray *)params;


/*
 删除数据
 */
+(BOOL)deleteTableWithSql:(NSString *)sql Params:(NSArray *)params;

/*
 获取包装后的Text类型参数
 */
+(NSArray *)getTextParamsByArray:(NSArray *)valueArray;

@end
