//
//  LYJDBManager.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJDBManager.h"
#import <sqlite3.h>


static LYJDBManager *sharedInstance = nil;
static sqlite3 *database = nil;
static sqlite3_stmt *statement = nil;

@interface LYJDBManager (){
    NSString *databasePath;
}

@end

@implementation LYJDBManager

+(LYJDBManager*)getSharedInstance{

    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (sharedInstance==nil) {
            sharedInstance = [[LYJDBManager alloc]init];
        }
        
    });
    
    return sharedInstance;
}
-(BOOL)createDBWith:(NSString *)table With:(NSArray *)param{
    /*NSString *docsDir;
    NSArray *dirPaths;
    // Get the documents directory
    dirPaths = NSSearchPathForDirectoriesInDomains
    (NSDocumentDirectory, NSUserDomainMask, YES);
    docsDir = dirPaths[0];
    // Build the path to the database file
    databasePath = [[NSString alloc] initWithString:
                    [docsDir stringByAppendingPathComponent:@"my.db"]];
    BOOL isSuccess = YES;
    NSFileManager *filemgr = [NSFileManager defaultManager];
    if ([filemgr fileExistsAtPath: databasePath ] == NO)
    {
        const char *dbpath = [databasePath UTF8String];
        if (sqlite3_open(dbpath, &database) == SQLITE_OK)
        {
            char *errMsg;
            const char *sql_stmt =
            "create table if not exists collection (regno integerprimary key, name text, department text, year text)";//表字段 设置
            
            if (sqlite3_exec(database, sql_stmt, NULL, NULL, &errMsg)
                != SQLITE_OK)
            {
                isSuccess = NO;
                MOSLog(@"Failed to create table");
            }
            sqlite3_close(database);
            return  isSuccess;
        }
        else {
            isSuccess = NO;
            MOSLog(@"Failed to open/create database");
        }
    }
    return isSuccess;*/
    
//    @"create table t_main(columnId text,isRead text,cellType text,eDirection text,textContent text,audioLength text,audioUrl text, picUrlStr text,time text)"
    
    
    BOOL ok = [LYJDBManager createTableWithSql:table];
    return ok;
}

-(BOOL) saveData:(NSString*)sql withParam:(NSArray*)params{
    /*const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *insertSQL = [NSString stringWithFormat:@"insert into collection (regno,name, department, year) values(\"%ld\",\"%@\", \"%@\", \"%@\")",(long)[registerNumber integerValue],name, department, year];
        const char *insert_stmt = [insertSQL UTF8String];
        sqlite3_prepare_v2(database, insert_stmt,-1, &statement, NULL);
        if (sqlite3_step(statement) == SQLITE_DONE){
            return YES;
        }else {
            sqlite3_reset(statement);
            return NO;
        }
    }
    return NO;*/
    
   return  [LYJDBManager insertTableWithSql:sql params:params];
}


-(NSArray*) findBySql:(NSString*)sql withParams:(NSArray*)params{
    
    /*const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK)
    {
        NSString *querySQL = [NSString stringWithFormat:
                              @"select name, department, year from collection where regno= \"%ld\"",(long)[registerNumber integerValue]];
        
        const char *query_stmt = [querySQL UTF8String];
        NSMutableArray *resultArray = [[NSMutableArray alloc]init];
        if (sqlite3_prepare_v2(database,
                               query_stmt, -1, &statement, NULL) == SQLITE_OK)
        {
            if (sqlite3_step(statement) == SQLITE_ROW)
            {
                NSString *name = [[NSString alloc] initWithUTF8String:
                                  (const char *) sqlite3_column_text(statement, 0)];
                [resultArray addObject:name];
                NSString *department = [[NSString alloc] initWithUTF8String:
                                        (const char *) sqlite3_column_text(statement, 1)];
                [resultArray addObject:department];
                NSString *year = [[NSString alloc]initWithUTF8String:
                                  (const char *) sqlite3_column_text(statement, 2)];
                [resultArray addObject:year];
                return resultArray;
            }
            else{
                MOSLog(@"Not found");
                sqlite3_reset(statement);
                return nil;
            }
        }
    }
    return nil;*/
    
    return  [LYJDBManager queryForArrayWithSql:sql Params:params];
}

-(BOOL)deletBySql:(NSString *)sql withParams:(NSArray*)params{
    
   /* const char *dbpath = [databasePath UTF8String];
    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        NSString *querySQL = [NSString stringWithFormat:
                              @"delete from collection where regno = \"%ld\"",(long)[registerNumber integerValue]];
        
        const char *query_stmt = [querySQL UTF8String];
        
        //将SQL语句放入sqlite3_stmt中
        int success = sqlite3_prepare_v2(database, query_stmt, -1, &statement, NULL);
        
        if (success != SQLITE_OK) {
            MOSLog(@"Error: failed to delete:testTable");
            sqlite3_close(database);
            return NO;
            
        }else{
            
            if (sqlite3_step(statement) == SQLITE_ROW)
            {
                sqlite3_finalize(statement);
                sqlite3_close(database);
                
            }
            sqlite3_finalize(statement);
            sqlite3_close(database);
            return YES;
        }
        
    }
    return NO;*/
    
   return [LYJDBManager deleteTableWithSql:sql  Params:params];
}

-(BOOL)updateWithSql:(NSString*)sql andParams:(NSArray*)params{
    
    /*const char *dbpath = [databasePath UTF8String];

    if (sqlite3_open(dbpath, &database) == SQLITE_OK) {
        sqlite3_stmt *statement;//这相当一个容器，放转化OK的sql语句
//        NSString * sqlStr = [NSString stringWithFormat:@"update collection set name = \"%@\" and department = \"%@\" and year = \"%@\" where regno = \"%ld\"",name,department,year,(long)[registerNumber integerValue]];
        //组织SQL语句
//        char *sql = "update collection set testValue = ? and testName = ? WHERE testID = ?";
        char *sql = "update collection set name = ? and department = ? and year = ? where regno = ?";
//        const char *sql = [sqlStr UTF8String];
        
        //将SQL语句放入sqlite3_stmt中
        int success = sqlite3_prepare_v2(database, sql, -1, &statement, NULL);
        if (success != SQLITE_OK) {
            MOSLog(@"Error: failed to update:collection");
            sqlite3_close(database);
            return NO;
        }
        
        sqlite3_bind_text(statement, 4, [name UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(statement, 3, [department UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_text(statement, 2, [year UTF8String], -1, SQLITE_TRANSIENT);
        sqlite3_bind_int(statement, 1, (int)[registerNumber integerValue]);

        //执行SQL语句。这里是更新数据库
        success = sqlite3_step(statement);
        //释放statement
        sqlite3_finalize(statement);
        
        //如果执行失败
        if (success == SQLITE_ERROR) {
            MOSLog(@"Error: failed to update the database with message.");
            //关闭数据库
            sqlite3_close(database);
            return NO;
        }
        //执行成功后依然要关闭数据库
        sqlite3_close(database);
        return YES;
    }
    return NO;*/
    
    return [LYJDBManager updateTableWithSql:sql  Params:params];
}

/****************************sql*****************************************/

//数据库路径
#define sqlite_db_path [NSHomeDirectory() stringByAppendingPathComponent:@"Documents/midea.db"]
//列：字段类型
#define column_type sqlite3_column_type(stmt, i)
//列：名
#define column_name [NSString stringWithUTF8String:sqlite3_column_name(stmt,i)]
//列：text值
#define column_value_text [NSString stringWithUTF8String:(char *)sqlite3_column_text(stmt, i)]
#define column_value_int  [NSString stringWithFormat:@"%d",sqlite3_column_int(stmt, i)]

+ (BOOL)createTableWithSql:(NSString *)sql
{
    //获取数据库路径
    NSString *path = sqlite_db_path;
    
    //创建数据库的指针对象对象
    sqlite3 *db = nil;
    
    //打开数据库
    int db_open = sqlite3_open([path UTF8String], &db);
    if (db_open != SQLITE_OK) {
        NSLog(@"--------------------------打开失败--------------------------");
        sqlite3_close(db);
        return NO;
    }
    
    //执行创建表的sql语句
    char *error = nil;
    int db_exec = sqlite3_exec(db, [sql UTF8String], NULL, NULL, &error);
    if (db_exec != SQLITE_OK) {
        sqlite3_close(db);
        return NO;
    }
    sqlite3_close(db);
    return YES;
}

+ (BOOL)insertTableWithSql:(NSString *)sql params:(NSArray *)params
{
    sqlite3 *db = nil;
    //创建一个数据句柄
    sqlite3_stmt *stmt = nil;
    //获取数据库路径
    NSString *path = sqlite_db_path;
    
    int db_open = sqlite3_open([path UTF8String], &db);
    if (db_open != SQLITE_OK) {
        NSLog(@"--------------------------打开失败--------------------------");
        sqlite3_close(db);
        return NO;
    }
    
    int db_v2 = sqlite3_prepare_v2(db, [sql UTF8String], -1, &stmt, nil);
    if (db_v2 != SQLITE_OK) {
        NSLog(@"--------------------------编译失败--------------------------");
        sqlite3_close(db);
        return NO;
    }
    
    //3.想占位符中绑定数据
    for (int i = 0; i < params.count; i++) {
        
        NSDictionary *dic = params[i];
        NSLog(@"%@",params);
        if ([[dic objectForKey:@"type"] isEqualToString:@"text"]) {
            
            sqlite3_bind_text(stmt, i + 1, [dic[@"value"] UTF8String], -1, NULL);
            
        }else if ([[dic objectForKey:@"type"] isEqualToString:@"int"]) {
            
            sqlite3_bind_int(stmt, i + 1, [dic[@"value"] intValue]);
            
        }
    }
    
    //执行sql语句
    int result = sqlite3_step(stmt);
    if (result == SQLITE_ERROR || result == SQLITE_MISUSE) {
        NSLog(@"--------------------------插入失败--------------------------");
        sqlite3_finalize(stmt);
        sqlite3_close(db);
        return NO;
    }
    
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return YES;
}

+(NSArray *)queryForArrayWithSql:(NSString *)sql Params:(NSArray *)params
{
    //创建数据库指针对象
    sqlite3 *db = nil;
    //创建一个数据句柄
    sqlite3_stmt *stmt = nil;
    //数据库路径
    NSString *path = sqlite_db_path;
    
    int db_open = sqlite3_open([path UTF8String], &db);
    if (db_open != SQLITE_OK) {
        NSLog(@"--------------------------打开失败--------------------------");
        sqlite3_close(db);
        return nil;
    }
    
    //编译sql语句
    int db_v2 = sqlite3_prepare_v2(db, [sql UTF8String], -1, &stmt, nil);
    if (db_v2) {
        NSLog(@"--------------------------编译失败--------------------------");
        sqlite3_close(db);
        return nil;
    }
    
    //占位符绑定参数
    //3.想占位符中绑定数据
    if (params != nil) {
        for (int i = 0; i < params.count; i++) {
            
            NSDictionary *dic = params[i];
            
            if ([[dic objectForKey:@"type"] isEqualToString:@"text"]) {
                
                sqlite3_bind_text(stmt, i + 1, [dic[@"value"] UTF8String], -1, NULL);
                
            }else if ([[dic objectForKey:@"type"] isEqualToString:@"int"]) {
                
                sqlite3_bind_int(stmt, i + 1, [dic[@"value"] intValue]);
                
            }
        }
    }
    
    //执行查询
    int db_step = sqlite3_step(stmt);
    NSMutableArray *mArray = [NSMutableArray array];
    
    while (db_step == SQLITE_ROW) {
        //获取查询了多少列
        int count = sqlite3_column_count(stmt);
        
        //创建字典
        NSMutableDictionary *dic = [NSMutableDictionary dictionary];
        
        for (int i = 0; i<count; i++) {
            
            //如果是text类型
            if (column_type == SQLITE_TEXT) {
                [dic setValue:column_value_text forKeyPath:column_name];
            }
            if (column_type == SQLITE_INTEGER) {
                [NSString stringWithFormat:@"%d",sqlite3_column_int(stmt, i)];
                [dic setValue:column_value_int forKeyPath:column_name];
            }
        }
        //字典添加到数组中
        [mArray addObject:dic];
        
        db_step = sqlite3_step(stmt);
    }
    
    return mArray;
}


+(BOOL)updateTableWithSql:(NSString *)sql Params:(NSArray *)params
{
    sqlite3 *db = nil;
    //创建一个数据句柄
    sqlite3_stmt *stmt = nil;
    //获取数据库路径
    NSString *path = sqlite_db_path;
    
    int db_open = sqlite3_open([path UTF8String], &db);
    if (db_open != SQLITE_OK) {
        NSLog(@"--------------------------打开失败--------------------------");
        sqlite3_close(db);
        return NO;
    }
    
    int db_v2 = sqlite3_prepare_v2(db, [sql UTF8String], -1, &stmt, nil);
    if (db_v2 != SQLITE_OK) {
        NSLog(@"--------------------------编译失败--------------------------");
        sqlite3_close(db);
        return NO;
    }
    
    //3.想占位符中绑定数据
    for (int i = 0; i < params.count; i++) {
        
        NSDictionary *dic = params[i];
        
        if ([[dic objectForKey:@"type"] isEqualToString:@"text"]) {
            
            sqlite3_bind_text(stmt, i + 1, [dic[@"value"] UTF8String], -1, NULL);
            
        }else if ([[dic objectForKey:@"type"] isEqualToString:@"int"]) {
            
            sqlite3_bind_int(stmt, i + 1, [dic[@"value"] intValue]);
            
        }
    }
    
    //执行sql语句
    int result = sqlite3_step(stmt);
    if (result == SQLITE_ERROR || result == SQLITE_MISUSE) {
        NSLog(@"--------------------------更新失败--------------------------");
        sqlite3_finalize(stmt);
        sqlite3_close(db);
        return NO;
    }
    
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return YES;
}


+(BOOL)deleteTableWithSql:(NSString *)sql Params:(NSArray *)params
{
    sqlite3 *db = nil;
    //创建一个数据句柄
    sqlite3_stmt *stmt = nil;
    //获取数据库路径
    NSString *path = sqlite_db_path;
    
    int db_open = sqlite3_open([path UTF8String], &db);
    if (db_open != SQLITE_OK) {
        NSLog(@"--------------------------打开失败--------------------------");
        sqlite3_close(db);
        return NO;
    }
    
    int db_v2 = sqlite3_prepare_v2(db, [sql UTF8String], -1, &stmt, nil);
    if (db_v2 != SQLITE_OK) {
        NSLog(@"--------------------------编译失败--------------------------");
        sqlite3_close(db);
        return NO;
    }
    
    //3.想占位符中绑定数据
    for (int i = 0; i < params.count; i++) {
        
        NSDictionary *dic = params[i];
        
        if ([[dic objectForKey:@"type"] isEqualToString:@"text"]) {
            
            sqlite3_bind_text(stmt, i + 1, [dic[@"value"] UTF8String], -1, NULL);
            
        }else if ([[dic objectForKey:@"type"] isEqualToString:@"int"]) {
            
            sqlite3_bind_int(stmt, i + 1, [dic[@"value"] intValue]);
            
        }
    }
    
    //执行sql语句
    int result = sqlite3_step(stmt);
    if (result == SQLITE_ERROR || result == SQLITE_MISUSE) {
        NSLog(@"--------------------------删除失败--------------------------");
        sqlite3_finalize(stmt);
        sqlite3_close(db);
        return NO;
    }
    
    sqlite3_finalize(stmt);
    sqlite3_close(db);
    return YES;
}

+(NSArray *)getTextParamsByArray:(NSArray *)valueArray
{
    NSMutableArray *params = [NSMutableArray array];
    //将所有字段设置成text类型
    for (int i =0 ;i<valueArray.count;i++) {
        NSDictionary *dic = [NSMutableDictionary dictionary];
        [dic setValue:(valueArray[i] == nil)?@"":valueArray[i] forKey:@"value"];
        [dic setValue:@"text" forKey:@"type"];
        [params addObject:dic];
    }
    return params;
}

@end
