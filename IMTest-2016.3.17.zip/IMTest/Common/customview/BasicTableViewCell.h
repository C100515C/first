//
//  BasicTableViewCell.h
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BasicLabel.h"
#import "BasicUIButton.h"
#import "BasicUIImageView.h"

@interface BasicTableViewCell : UITableViewCell

@end
