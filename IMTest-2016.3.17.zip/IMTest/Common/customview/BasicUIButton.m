//
//  BasicUIButton.m
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicUIButton.h"

@implementation BasicUIButton

-(CGRect)titleRectForContentRect:(CGRect)contentRect{
    
    if ([self judeRectWith:_titleLabelFrame] ) {
        return _titleLabelFrame;
    }
    return CGRectMake(21, 3, 40, 16);
}

-(CGRect)imageRectForContentRect:(CGRect)contentRect{
    
    if ([self judeRectWith:_imageFrame]) {
        return _imageFrame;
    }
    return CGRectMake(3, 3, 16, 16);
}

-(UIEdgeInsets)imageEdgeInsets{
    UIEdgeInsets  edge = UIEdgeInsetsMake(0, -5, 0, 0);
    return edge;
}

-(BOOL)judeRectWith:(CGRect)rect{
    CGFloat s = [self flagWith:rect.size.width] +[self flagWith:rect.size.height]+[self flagWith:rect.origin.x]+[self flagWith:rect.origin.y];
    if (s) {
        return YES;
    }
    return NO;
}

-(CGFloat)flagWith:(CGFloat)f{
    if (f>0) {
        return f;
    }
    else{
        return (-1)*f;
    }
}

@end
