//
//  CC_LabelsOfView.h
//  MoscoperV2
//
//  Created by mac on 15/7/27.
//  Copyright (c) 2015年 moscoper. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    CCBlueFrameLabel = 10,
    CCBlueOvalLabel,
    CCGrayPoundLabel,
    CCNormalLabel = CCBlueFrameLabel
    
}CCLabelType;

@interface CC_LabelsOfView : UIView
/**
 *  初始化方法 （默认标签类型）
 *
 *  @param frame    view frame
 *  @param start_x  view上第一个标签的起始x
 *  @param y        view 上标签的y
 *  @param interval 每个标签间隔
 *  @param height   每个标签高度
 *  @param endDis   所有标签宽度和与view宽度的差
 *
 *  @return view
 */
-(id)initWithFrame:(CGRect)frame andStart_x:(CGFloat)start_x andY:(CGFloat)y andInterval:(CGFloat)interval andLabelHeight:(CGFloat)height andEndDistance:(CGFloat)endDis;
/**
 初始化方法
 *
 *  @param frame    view frame
 *  @param start_x  view上第一个标签的起始x
 *  @param y        view 上标签的y
 *  @param interval 每个标签间隔
 *  @param height   每个标签高度
 *  @param endDis   所有标签宽度和与view宽度的差
 *  @param type     标签类型(传0 为默认标签类型)
 *
 *  @return view
 */
-(id)initWithFrame:(CGRect)frame andStart_x:(CGFloat)start_x andY:(CGFloat)y andInterval:(CGFloat)interval andLabelHeight:(CGFloat)height andEndDistance:(CGFloat)endDis andLabelType:(CCLabelType)type;
/**
 *  设置标签
 *
 *  @param labels 标签数组
 */
-(void)set_MyLabelsWith:(NSArray *)labels;

/**
 *  设置标签（可以换行的）
 *
 *  @param labels 标签数组
 *
 *  @return 换行后的背景图高度变化
 */
-(CGFloat)set_MyLabelsCanChangeRowsWith:(NSArray *)labels;

-(void)setStart_x:(CGFloat)start_x andY:(CGFloat)y andInterval:(CGFloat)interval andLabelHeight:(CGFloat)height andEndDistance:(CGFloat)endDis andLabelType:(CCLabelType)type;

+(CGFloat)setStart_x:(CGFloat)start_x andY:(CGFloat)y andInterval:(CGFloat)interval andLabelHeight:(CGFloat)height andEndDistance:(CGFloat)endDis andLabelFrame:(CGRect)frame andLabels:(NSArray*)labels;

@end
