//
//  Common.h
//  IMTest
//
//  Created by chenchen on 16/2/24.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#ifdef __OBJC__
/*****************************************头文件*************************************/
#import <UIKit/UIKit.h>

#import "EMClient.h"
#import "EMClientDelegate.h"
#import "EMConversation.h"
#import "EMMessage.h"
#import "EMGroup.h"
#import "EMChatroom.h"
#import "EMTextMessageBody.h"
#import "EMImageMessageBody.h"
#import "EMLocationMessageBody.h"
#import "EMVoiceMessageBody.h"
#import "EMVideoMessageBody.h"
#import "EMFileMessageBody.h"
#import "EMGroupManagerDelegate.h"
#import "EMChatroomManagerDelegate.h"
#import "UIImageView+EMWebCache.h"
#import "EMAlertView.h"

#import "Masonry.h"
#import "BasicnavigationVC.h"
#import "LYJSystemCallsJudgeManager.h"

/*****************************************************宏定义*****************************************/
/***************************************三方 key***********************************************/
#define UM_Key @"545b2490fd98c5541700389b"
#define EM_Key @"cl#cc"
#define EM_apns @"c"
/******************************网络环境调试********************************/
#define UIH_DEBUG @"UIH_DEBUG" //调试时候打开

//#define UIH_DEV @"UIH_DEV" // 测试环境宏
#define UIH_PRE @"UIH_PRE" // 预发布环境宏
//#define UIH_DIS @"UIH_DIS" // 发布环境宏

#ifdef UIH_DEV
// 本地测试环境
#define UIHURL_TEST_SERVER @"http://10.0.0.13:8080/v4/"
#define UIHURL_TFS_SERVER  @"http://10.0.0.13:80/v1/tfs"
#else
#ifdef UIH_PRE
// 预发布环境
#define UIHURL_TEST_SERVER @"http://123.56.227.136:8080/v4/"
#define UIHURL_TFS_SERVER  @"http://img.moscoper.com/v1/tfs"
#else
// 生产环境
#define UIHURL_TEST_SERVER @"http://api.moscoper.com/v4/"
#define UIHURL_TFS_SERVER  @"http://img.moscoper.com/v1/tfs"
#endif
#endif


#define IS_IPHONE_5 ( fabs( ( double )[ [ UIScreen mainScreen ] bounds ].size.height - ( double )568 ) < DBL_EPSILON )

#define NSEaseLocalizedString(key, comment) [[NSBundle bundleWithURL:[[NSBundle mainBundle] URLForResource:@"EaseUIResource" withExtension:@"bundle"]] localizedStringForKey:(key) value:@"" table:nil]

#ifdef DEBUG
#define MOSLog(...) NSLog(__VA_ARGS__)
#else
#define MOSLog(...)
#endif

#define RGB(r, g, b, a)    [UIColor colorWithRed:(r)/255.f green:(g)/255.f blue:(b)/255.f alpha:(a)]

#pragma mark - NavigationBar配置
// NavigationBar背景色
#define G_COLOR_NAVGATION_BACK [UIColor colorWithRed:0/255.0 green:184/255.0 blue:238/255.0 alpha:1]

// NavigationBar字体颜色
#define G_COLOR_NAVGATION_TITLE [UIColor whiteColor]

// NavigationBar字体大小
#define G_FONT_NAVGATION_TITLE BOLDFONT(16)

// 灰色
#define G_COLOR_GREEN [UIColor colorWithRed:172/255.0 green:172/255.0 blue:172/255.0 alpha:1]

// 浅蓝色
#define G_COLOR_LITTLE_BLUE [UIColor colorWithRed:0 green:184/255.0 blue:238/255.0 alpha:1]


//所有背景色颜色(iZP)
#define EveryView_BackGroundColor [UIColor colorWithRed:238/255.0 green:238/255.0 blue:238/255.0 alpha:1]

//***********************************系统全局配置*********************************************************//
#define APP_STATUSBAR_NVIGATIONBAR_HEIGHT    64
#define APP_STATUSBAR_TABBAR_HEIGHT 49

#define IOS7_OR_LOW ([[[UIDevice currentDevice] systemVersion] intValue] < 8.0)

#define IOS7_OR_LATER   ( [[[UIDevice currentDevice] systemVersion] compare:@"7.0"] != NSOrderedAscending )
#define IOS8_OR_LATER   ( [[[UIDevice currentDevice] systemVersion] compare:@"8.0"] != NSOrderedAscending )

#define iPhone5 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(640, 1136), [[UIScreen mainScreen] currentMode].size) : NO)

#define iPhone6 ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(750, 1334), [[UIScreen mainScreen] currentMode].size) : NO)

#define iPhone6_Scale_W (750.0/640)
#define iPhone6_Scale_H (1334.0/1136)

#define iPhone6P ([UIScreen instancesRespondToSelector:@selector(currentMode)] ? CGSizeEqualToSize(CGSizeMake(1242, 2208), [[UIScreen mainScreen] currentMode].size) : NO)

#define iPhone6P_Scale_W (1242.0/640)
#define iPhone6P_Scale_H (2208.0/1136)

//******************************************字体适配*****************************************************//

#define BOLDFONT(size) iPhone6 || iPhone6P ? [UIFont boldSystemFontOfSize:(size + 2)] : [UIFont boldSystemFontOfSize:(size)]
#define SYSTEMFONT(size) iPhone6 || iPhone6P ? [UIFont systemFontOfSize:(size + 2)] : [UIFont systemFontOfSize:(size)]

//******************************************屏幕尺寸适配*****************************************************//

#define SCREEN_WIDTH [[UIScreen mainScreen] bounds].size.width
#define SCREEN_HEIGHT [[UIScreen mainScreen] bounds].size.height

#define is_IOS_7 ([[[UIDevice currentDevice] systemVersion] floatValue] >= 7.0)

#endif