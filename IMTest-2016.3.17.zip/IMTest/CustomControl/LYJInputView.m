//
//  LYJInputView.m
//  IMTest
//
//  Created by chenchen on 16/3/15.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJInputView.h"

@interface LYJInputView ()<UITextViewDelegate>

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *backViewBottomHeight;
- (IBAction)notSend:(UIButton *)sender;

- (IBAction)send:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet UITextView *contentTextView;

@end

@implementation LYJInputView

-(void)awakeFromNib{
    self.contentTextView.delegate = self;
    self.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:0.5f];
    
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardWillAppear:) name:UIKeyboardWillShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keboardWillDisappeat:) name:UIKeyboardWillHideNotification object:nil];
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(keyboardDidAppear:) name:UIKeyboardDidShowNotification object:nil];
    [[NSNotificationCenter defaultCenter]addObserver:self selector:@selector(keboardDidDisappeat:) name:UIKeyboardDidHideNotification object:nil];
}

-(void)dealloc{
    [[NSNotificationCenter defaultCenter] removeObserver:self];
    
}

- (IBAction)notSend:(UIButton *)sender {
    [self.contentTextView resignFirstResponder];
    
    if (self.lyj_delegate && [self.lyj_delegate respondsToSelector:@selector(cancleBtnAction:andText:)]) {
        [self.lyj_delegate cancleBtnAction:sender andText:self.contentTextView.text];
    }
    self.contentTextView.text = @"";
    self.hidden = YES;
}

- (IBAction)send:(UIButton *)sender {
    [self.contentTextView resignFirstResponder];
    
    if (self.lyj_delegate && [self.lyj_delegate respondsToSelector:@selector(sendBtnAction:andText:)]) {
        [self.lyj_delegate sendBtnAction:sender andText:self.contentTextView.text];
    }
    self.contentTextView.text = @"";
    self.hidden = YES;
}

-(void)keyboardAppear{
    [self.contentTextView becomeFirstResponder];
}

-(void)keyboardDisappear{
    [self.contentTextView resignFirstResponder];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    self.hidden = YES;
    [self.contentTextView resignFirstResponder];

}

-(void)updateInputConstraintsWith:(CGFloat)newHeight{
    self.backViewBottomHeight.constant = newHeight;
}


//随键盘的移动界面移动
#pragma mark- 监听方法
-(void)keyboardWillAppear:(NSNotification*)notification{
    CGSize size = [[notification.userInfo objectForKey:UIKeyboardFrameEndUserInfoKey] CGRectValue].size;
    
    [self updateInputConstraintsWith:size.height+60];

}

-(void)keboardWillDisappeat:(NSNotification*)notification{
    //    self.frame = _selfOriginalFrame;
    [self updateInputConstraintsWith:200];

    
}

-(void)keyboardDidAppear:(NSNotification*)notification{
    
}

-(void)keboardDidDisappeat:(NSNotification*)notification{
    
}

#pragma mark - animation
-(void)customAnimation{

}

@end
