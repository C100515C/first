//
//  LYJWindow.h
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LYJTouchDelegate

-(void)sendEvent:(UIEvent *)event;

@end

@interface LYJWindow : UIWindow

@property (nonatomic,assign) id<LYJTouchDelegate> m_pDelegate;
@property (nonatomic,assign) id currentView;

+(LYJWindow*)currentWindow;

@end
