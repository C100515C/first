//
//  AppDelegate+EaseMob.h
//  IMTest
//
//  Created by chenchen on 16/2/24.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "AppDelegate.h"

@interface AppDelegate (EaseMob)

- (void)easemobApplication:(UIApplication *)application
didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
                    appkey:(NSString *)appkey
              apnsCertName:(NSString *)apnsCertName
               otherConfig:(NSDictionary *)otherConfig;
@end
