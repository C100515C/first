//
//  PostRepeatsVC.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostRepeatsVC.h"
#import "PostRepeatsResponse.h"
#import "PostRepeatsCell.h"
#import "LYJToolbar.h"
#import "LYJInputView.h"


@interface PostRepeatsVC ()<LYJInputViewDelegate,LYJToolBarDelegate>{
    NSMutableArray *_dataSource;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (nonatomic, strong) LYJToolbar *inputBar;
@property (nonatomic,assign) CGFloat barBottonLayoutHeight;
@property (nonatomic, strong) LYJInputView *inputView;

@end

@implementation PostRepeatsVC
- (instancetype)init
{
    self = [super init];
    if (self) {
        self.inputView = [[[NSBundle mainBundle] loadNibNamed:@"LYJInputView" owner:nil options:nil] firstObject];
        self.inputView.lyj_delegate = self;
        
        [self.view addSubview: self.inputView];
        
        [self.inputView mas_makeConstraints:^(MASConstraintMaker *make) {
            make.top.equalTo(self.view.mas_top).with.offset(0);
            make.bottom.equalTo(self.view.mas_bottom).with.offset(0);
            make.left.equalTo(self.view.mas_left).with.offset(0);
            make.right.equalTo(self.view.mas_right).with.offset(0);
            
        }];
        self.inputView.hidden = YES;
    }
    return self;
}
- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    [super viewDidLoad];
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _dataSource = [[NSMutableArray alloc] init];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"PostRepeatsCell" bundle:nil] forCellReuseIdentifier:PostRepeatsCell_id];
    
    LYJToolbar *bar = [[LYJToolbar alloc] initWithFrame:CGRectMake(0, self.view.frame.size.height-44, self.view.frame.size.width, 44)];
    bar.textPlaceholder = @"请输入您回复的内容";
    bar.sendDelegate = self;
    [self.view addSubview:bar];
    self.inputBar = bar;
    
    [bar mas_makeConstraints:^(MASConstraintMaker *make) {
        make.bottom.equalTo(self.view.mas_bottom).with.offset(0);
        make.left.equalTo(self.view.mas_left).with.offset(0);
        make.right.equalTo(self.view.mas_right).with.offset(0);
        make.height.equalTo(@(44));
    }];
    
    [self makeModel];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    
    self.inputView.hidden = YES;
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.inputView.hidden = YES;
}

-(void)makeModel{
    
    for (int i=0 ; i<5; i++) {
        PostRepeatsResponse *model = [[PostRepeatsResponse alloc] init];
        model.content = @"但肯定没卡读书噶开始的感觉啊卡是的公司打工发撒高发但是搜噶是股份撒过烦噶生f发生噶发给发噶舒服噶是嘎嘎嘎撒给个说法股份 撒干撒啊公司法股份搜噶傻瓜是";
        model.time = @"两天前来自心脏圈";
        model.type = @"lyj 关注了该问题";
        model.nickname = @"cc";
        model.label = @"吐槽";
        model.title = @"跟本不知道是什么";
        model.count = @"1234";
        [_dataSource addObject:model];
    }
    [self.tableView reloadData];

    
}

- (void)tableViewDidTriggerHeaderRefresh{
    
    [self tableViewDidFinishTriggerHeader:YES reload:NO];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    [self tableViewDidFinishTriggerHeader:NO reload:NO];
    
}//上拉加载事件

#pragma mark - table

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    PostRepeatsResponse *model = [_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    PostRepeatsCell *cell = [tableView dequeueReusableCellWithIdentifier:PostRepeatsCell_id];
    
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"PostRepeatsCell" owner:nil options:nil] firstObject];
    }
    PostRepeatsResponse *model = [_dataSource objectAtIndex:indexPath.row];
    
    [cell setCellWithModel:model];
    
    return cell;
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    [_inputBar keybaordAppear];
    PostRepeatsResponse *model = [_dataSource objectAtIndex:indexPath.row];
    NSString *text = [NSString stringWithFormat:@"回复 %@的评论",model.nickname];
    _inputBar.textPlaceholder = text;
    
    
}

-(void)scrollViewWillBeginDragging:(UIScrollView *)scrollView{
    [_inputBar takeBackKeyboard];
}

#pragma mark -lyj tool bar
-(void)keyboardAppearWith:(CGFloat)height{
    
    self.inputView.hidden = NO;
    [self.inputView keyboardAppear];
}



#pragma mark - lyj inputView
-(void)sendBtnAction:(UIButton *)sender andText:(NSString *)text{
    MOSLog(@"%@",text);
}
-(void)cancleBtnAction:(UIButton *)sender andText:(NSString *)text{
    MOSLog(@"%@",text);
}

@end
