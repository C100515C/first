//
//  PostRepeatsCell.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostRepeatsCell.h"
#import "PostRepeatsResponse.h"
//#import "BasicUIImageView.h"

@interface PostRepeatsCell ()
@property (weak, nonatomic) IBOutlet BasicUIImageView *icon;
@property (weak, nonatomic) IBOutlet UILabel *nickname;
@property (weak, nonatomic) IBOutlet UILabel *content;
@property (weak, nonatomic) IBOutlet UILabel *time;

@end

@implementation PostRepeatsCell

-(void)awakeFromNib{
    [super awakeFromNib];

    [self.icon setRaduis];
}

-(void)setCellWithModel:(PostRepeatsResponse *)model{

    self.content.text = model.content;
    self.nickname.text = model.nickname;
    [self.content layoutIfNeeded];
    [self layoutIfNeeded];
}

@end
