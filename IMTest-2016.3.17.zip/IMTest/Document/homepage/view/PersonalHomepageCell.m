//
//  PersonalHomepageCell.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalHomepageCell.h"
#import "PersonalHomepageResponse.h"
#import "CC_LabelsOfView.h"
//#import "BasicUIImageView.h"
#import "UserProfileManager.h"

@interface PersonalHomepageCell ()
@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;
@property (weak, nonatomic) IBOutlet UILabel *nickname;
@property (weak, nonatomic) IBOutlet UIImageView *gender;
@property (weak, nonatomic) IBOutlet UILabel *addressed;
@property (weak, nonatomic) IBOutlet UILabel *answerCount;
@property (weak, nonatomic) IBOutlet UILabel *publishedCount;

@property (weak, nonatomic) IBOutlet UILabel *illFriendsCount;

@property (weak, nonatomic) IBOutlet CC_LabelsOfView *focusLabelView;
@property (weak, nonatomic) IBOutlet UILabel *signature;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *focusLabelViewHeight;

@end

@implementation PersonalHomepageCell

-(void)setCellWithModel:(PersonalHomepageResponse *)model{
    
    self.nickname.text = model.nickname;
    self.addressed.text = model.title;
    [self.focusLabelView set_MyLabelsCanChangeRowsWith:model.labels];
//    model.focusLabelHeight = [_focusLabelView set_MyLabelsCanChangeRowsWith:@[@"老大老老大老老大老",@"老大老老大老老大老",@"老老大老老大老大老",@"老大老大老老",@"老大老大老老"]];
    self.focusLabelViewHeight.constant = model.focusLabelHeight;
    self.signature.text = model.content;
    
    [self.focusLabelView layoutIfNeeded];
    [self.nickname layoutIfNeeded];
    [self.addressed layoutIfNeeded];
    [self layoutIfNeeded];

}

-(void)setCellWithUserModel:(UserProfileEntity *)model{
    self.nickname.text = model.nickname;
    self.addressed.text = model.address;
    [self.focusLabelView set_MyLabelsCanChangeRowsWith:model.labels];
    //    model.focusLabelHeight = [_focusLabelView set_MyLabelsCanChangeRowsWith:@[@"老大老老大老老大老",@"老大老老大老老大老",@"老老大老老大老大老",@"老大老大老老",@"老大老大老老"]];
    self.focusLabelViewHeight.constant = model.focusLabelHeight;
    self.signature.text = model.signature;
    
    [self.focusLabelView layoutIfNeeded];
    [self.nickname layoutIfNeeded];
    [self.addressed layoutIfNeeded];
    [self layoutIfNeeded];
}

-(void)awakeFromNib{
    [super awakeFromNib];

    [self.headerIcon setRaduis];
    [_focusLabelView setStart_x:0 andY:5.0f andInterval:5.0f andLabelHeight:15.0f andEndDistance:10.0f andLabelType:CCBlueFrameLabel];
}

@end
