//
//  PostDetailHeaderView.h
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class PostDetailHeaderResponse;
typedef void (^HeaderIconTapActionBlock)(UITapGestureRecognizer *sender);
@interface PostDetailHeaderView : UIView

@property (nonatomic,copy) HeaderIconTapActionBlock tapBlock;

-(void)setHeaerViewWith:(PostDetailHeaderResponse*)model;

@end
