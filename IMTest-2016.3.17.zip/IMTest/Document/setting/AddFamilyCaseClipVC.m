//
//  AddFamilyCaseClipVC.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "AddFamilyCaseClipVC.h"

#import "CaseClipCommonCell.h"
#import "CaseClipCommonResponse.h"

@interface AddFamilyCaseClipVC ()
{
    NSMutableArray *_dataSource;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;

@end

@implementation AddFamilyCaseClipVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self setNav];
    
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    _dataSource = [[NSMutableArray alloc] init];

    [self.tableView registerNib:[UINib nibWithNibName:@"CaseClipCommonCell" bundle:nil] forCellReuseIdentifier:CaseClipCommon_id];
    
    [self makeModel];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Nav
-(void)setNav{
    self.title = @"添加病例夹";
    
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
}

#pragma mark - data

-(void)makeModel{
    
    [_dataSource addObjectsFromArray:[self getSecondSection]];
    
    [_myTable reloadData];
}


-(NSArray *)getSecondSection{
    NSMutableArray *sectionArr = [NSMutableArray array];
    NSArray *names = @[@"称呼",@"性别",@"生日"];
    NSArray *title = @[@"请输入您对该家庭成员的称呼",@"女",@"选择该成员的出生日期"];
    for (int i=0 ; i<3; i++) {
        CaseClipCommonResponse *model = [[CaseClipCommonResponse alloc] init];
        model.content = title[i];
        if (i==0) {
            model.isHideImage = YES;

        }else{
            model.isHideImage = NO;

        }
        model.nameTitle = names[i];
        [sectionArr addObject:model];
    }
    return sectionArr;
}

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CaseClipCommonResponse *model = (CaseClipCommonResponse*)[_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CaseClipCommonCell *cell = [tableView dequeueReusableCellWithIdentifier:CaseClipCommon_id];
    
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"CaseClipCommonCell" owner:nil options:nil] firstObject];
    }
    
    CaseClipCommonResponse *model = (CaseClipCommonResponse*)[_dataSource objectAtIndex:indexPath.row];
    
    [cell setCellWith:model];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    
    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.row) {
        case 0:
        {
            //称呼
        }
            break;
        case 1:
        {
            //性别
        }
            break;
        case 2:
        {
            //生日
        }
            break;
            
        default:
            break;
    }
    
}

@end
