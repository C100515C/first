//
//  SetPersonalPageResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

typedef enum {

    SetPersonalPageResponseShowImage,
    SetPersonalPageResponseShowtitle,
    SetPersonalPageResponseShowDes
    
}SetPersonalPageResponseStyle;

@interface SetPersonalPageResponse : BasicResponse

@property (nonatomic,copy) NSString *name;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,assign) SetPersonalPageResponseStyle style;

@end
