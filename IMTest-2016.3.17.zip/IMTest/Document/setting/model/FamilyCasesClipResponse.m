
//
//  FamilyCasesClipResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "FamilyCasesClipResponse.h"

static const CGFloat BasicHeight = 110.0f;
static const CGFloat AnotherHeight = 157.0;

@implementation FamilyCasesClipResponse

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }
   
    if (self.needHighHeight) {
        _cellHeight = AnotherHeight;
    }else{
        _cellHeight = BasicHeight;

    }
    
    return _cellHeight;
}

@end
