//
//  CaseClipDetailResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface CaseClipDetailResponse : BasicResponse

@property (nonatomic,copy) NSString *time;
@property (nonatomic,copy) NSString *address;
@property (nonatomic,copy) NSString *type;//圈子类型
@property (nonatomic,copy) NSArray *pics;

@property (nonatomic,copy) NSString *showAddress;//合成的地址圈子

@end
