//
//  MySettingVC.m
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MySettingVC.h"
#import "SetMySettingCell.h"

@interface MySettingVC (){
    NSArray *_dataSource;
}

@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (nonatomic,assign) BOOL isCanNotice;

@end

@implementation MySettingVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    [self.tableView registerNib:[UINib nibWithNibName:@"SetMySettingCell" bundle:nil] forCellReuseIdentifier:SetMySetting_id];
    
    [self setNav];
    
    self.isCanNotice = [self isAllowedNotification];
    
    _dataSource = @[@{@"name":@"消息提醒",@"state":@(self.isCanNotice)},@{@"name":@"推送提醒",@"state":@(self.isCanNotice)}];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - nav
-(void)setNav{
    
    self.title = @"设置";
}

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    return 50.0f;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    SetMySettingCell *cell = [tableView dequeueReusableCellWithIdentifier:SetMySetting_id];
        
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"SetMySettingCell" owner:nil options:nil] firstObject];
    }
    NSDictionary *dic = _dataSource[indexPath.row];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;
    cell.titleName.text = dic[@"name"];
    cell.switchBtn.on = [dic[@"state"] boolValue];
    
    __weak typeof(self) weakself = self;
    cell.SetMySettingCellSwithSelect = ^(BOOL open){
    
        if (indexPath.row==0) {
            if (open) {
                //开启消息提醒
                MOSLog(@"1");
                [weakself openNotice];
                
            }else{
                MOSLog(@"2");
                [weakself closeNotice];
            }
            
        }else{
            if (open) {
                //开启推送提醒
                MOSLog(@"3");
                [weakself openNotice];

            }else{
                MOSLog(@"4");
                [weakself closeNotice];

            }
        }
        [weakself resetDataSource];
    };
    return cell;

}

-(void)openNotice{
    
    UIApplication *application = [UIApplication sharedApplication];
    application.applicationIconBadgeNumber = 0;
    
    if([application respondsToSelector:@selector(registerUserNotificationSettings:)])
    {
        UIUserNotificationType notificationTypes = UIUserNotificationTypeBadge | UIUserNotificationTypeSound | UIUserNotificationTypeAlert;
        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:notificationTypes categories:nil];
        [application registerUserNotificationSettings:settings];
    }
    
#if !TARGET_IPHONE_SIMULATOR
    //iOS8 注册APNS
    if ([application respondsToSelector:@selector(registerForRemoteNotifications)]) {
        [application registerForRemoteNotifications];
    }else{
        UIRemoteNotificationType notificationTypes = UIRemoteNotificationTypeBadge |
        UIRemoteNotificationTypeSound |
        UIRemoteNotificationTypeAlert;
        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:notificationTypes];
    }
#endif
    
}

-(void)closeNotice{
    
    UIApplication *application = [UIApplication sharedApplication];
//    application.applicationIconBadgeNumber = 0;
//    
//    if([application respondsToSelector:@selector(registerUserNotificationSettings:)])
//    {
//        UIUserNotificationType notificationTypes = UIUserNotificationTypeNone;
//        UIUserNotificationSettings *settings = [UIUserNotificationSettings settingsForTypes:notificationTypes categories:nil];
//        [application registerUserNotificationSettings:settings];
//    }
//    
//#if !TARGET_IPHONE_SIMULATOR
//    //iOS8 注册APNS
//    if ([application respondsToSelector:@selector(registerForRemoteNotifications)]) {
//        [application registerForRemoteNotifications];
//    }else{
//        UIRemoteNotificationType notificationTypes = UUIUserNotificationTypeNone;
//        [[UIApplication sharedApplication] registerForRemoteNotificationTypes:notificationTypes];
//    }
//#endif
    
#ifdef __IPHONE_8_0
    if(NSFoundationVersionNumber > NSFoundationVersionNumber_iOS_7_1) {
        
        [[UIApplication sharedApplication] registerUserNotificationSettings:[UIUserNotificationSettings
                                                                             settingsForTypes:
                                                                             (UIUserNotificationType)
                                                                             (UIUserNotificationTypeNone)
                                                                             categories:nil]];
        
        [application unregisterForRemoteNotifications];
        
    }
    
    else
#endif
    {
        [application unregisterForRemoteNotifications];
        
    }

}

-(void)resetDataSource{

    self.isCanNotice = [self isAllowedNotification];
//    self.isCanNotice = [[UIApplication sharedApplication] isRegisteredForRemoteNotifications];
    
    _dataSource = @[@{@"name":@"消息提醒",@"state":@(self.isCanNotice)},@{@"name":@"推送提醒",@"state":@(self.isCanNotice)}];
//    [self.myTable reloadData];
}

- (BOOL)isAllowedNotification
{
    
//    if (IOS7_OR_LOW) {
//        //ios7系统
//        self.isCanNotice = [[UIApplication sharedApplication] enabledRemoteNotificationTypes];// == 0; //不能接收推送，不为0时可以接收推送，是个枚举型
//        
//    }else{
//        //ios8以上系统
//        self.isCanNotice = [[UIApplication sharedApplication] currentUserNotificationSettings].types;// == 0;
//    }
    //iOS8 check if user allow notification
    
    if(IOS8_OR_LATER) {// system is iOS8
            UIUserNotificationSettings *setting = [[UIApplication sharedApplication] currentUserNotificationSettings];
            
            if(UIUserNotificationTypeNone != setting.types) {
                    
                    return YES;
                }
        }
    else{//iOS7
        UIRemoteNotificationType type = [[UIApplication sharedApplication] enabledRemoteNotificationTypes];
        
        if(UIRemoteNotificationTypeNone != type)
            
            return YES;
    }
    
    return NO;
}

@end
