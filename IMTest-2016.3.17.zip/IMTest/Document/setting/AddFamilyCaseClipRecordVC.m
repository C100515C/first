//
//  AddFamilyCaseClipRecordVC.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "AddFamilyCaseClipRecordVC.h"
#import "CaseClipCommonCell.h"
#import "CaseClipCommonResponse.h"

@interface AddFamilyCaseClipRecordVC ()
{
    NSMutableArray *_dataSource;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;

@end

@implementation AddFamilyCaseClipRecordVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self setNav];
    
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    _dataSource = [[NSMutableArray alloc] init];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"CaseClipCommonCell" bundle:nil] forCellReuseIdentifier:CaseClipCommon_id];
    
    [self makeModel];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - Nav
-(void)setNav{
    self.title = @"添加门诊记录";
    
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
}

#pragma mark - data

-(void)makeModel{
    
    [_dataSource addObjectsFromArray:[self getSecondSection]];
    
    [_myTable reloadData];
}


-(NSArray *)getSecondSection{
    NSMutableArray *sectionArr = [NSMutableArray array];
    NSArray *names = @[@"就诊时间：",@"就诊医院：",@"疾病分类：",@"检查报告："];
    NSArray *title = @[@"请选择就诊时间",@"请输入就诊医院",@"请选疾病分类",@"拍照上传就诊的处方、报告等"];

    for (int i=0 ; i<4; i++) {
        CaseClipCommonResponse *model = [[CaseClipCommonResponse alloc] init];
        model.content = title[i];
        
        model.isHideImage = NO;
        
        model.nameTitle = names[i];
        [sectionArr addObject:model];
    }
    return sectionArr;
}

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    CaseClipCommonResponse *model = (CaseClipCommonResponse*)[_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    CaseClipCommonCell *cell = [tableView dequeueReusableCellWithIdentifier:CaseClipCommon_id];
    
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"CaseClipCommonCell" owner:nil options:nil] firstObject];
    }
    
    CaseClipCommonResponse *model = (CaseClipCommonResponse*)[_dataSource objectAtIndex:indexPath.row];
    
    [cell setCellWith:model];
    
    cell.selectionStyle = UITableViewCellSelectionStyleNone;

    return cell;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    switch (indexPath.row) {
        case 0:
        {
            //时间
        }
            break;
        case 1:
        {
            //医院
        }
            break;
        case 2:
        {
            //病类
        }
            break;
        case 3:
        {
            //照片
        }
            break;
        default:
            break;
    }
}

@end
