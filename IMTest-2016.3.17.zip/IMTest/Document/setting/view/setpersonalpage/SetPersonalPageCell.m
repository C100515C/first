//
//  SetPersonalPageCell.m
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SetPersonalPageCell.h"
#import "SetPersonalPageResponse.h"

@interface SetPersonalPageCell ()
@property (weak, nonatomic) IBOutlet UILabel *name;

@end

@implementation SetPersonalPageCell

-(void)awakeFromNib{
    [self.icon setRaduis];
}

-(void)setCellWith:(SetPersonalPageResponse *)model{

    self.name.text = model.name;
    self.content.text = model.content;
    self.des.text = model.content;
    self.icon.image = [UIImage imageNamed:model.content];
    
    
    if (model.style == SetPersonalPageResponseShowImage) {
        self.content.hidden = YES;
        self.des.hidden = YES;
        self.icon.hidden = NO;
        
    }else if (model.style == SetPersonalPageResponseShowDes){
        self.content.hidden = YES;
        self.des.hidden = NO;
        self.icon.hidden = YES;
        
    }
    else{
        self.content.hidden = NO;
        self.des.hidden = YES;
        self.icon.hidden = YES;
        
    }
}

@end
