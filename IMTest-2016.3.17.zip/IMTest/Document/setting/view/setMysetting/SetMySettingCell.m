//
//  SetMySettingCell.m
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SetMySettingCell.h"

@interface SetMySettingCell ()
- (IBAction)switchClicked:(id)sender;

@end

@implementation SetMySettingCell

-(void)awakeFromNib{

}

- (IBAction)switchClicked:(id)sender {
    
    UISwitch *sw = (UISwitch*)sender;
    
    if (_SetMySettingCellSwithSelect) {
        _SetMySettingCellSwithSelect(sw.on);
    }
}


@end
