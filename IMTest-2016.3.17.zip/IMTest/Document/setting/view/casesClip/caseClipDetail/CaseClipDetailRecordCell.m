//
//  CaseClipDetailRecordCell.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipDetailRecordCell.h"
#import "CaseClipDetailResponse.h"

@interface CaseClipDetailRecordCell ()
@property (weak, nonatomic) IBOutlet BasicUIButton *delBtn;

@property (weak, nonatomic) IBOutlet BasicUIButton *editbtn;

@property (weak, nonatomic) IBOutlet UILabel *time;
@property (weak, nonatomic) IBOutlet UILabel *addres;

- (IBAction)deleteBtnClicked:(BasicUIButton *)sender;
- (IBAction)editBtnClicked:(BasicUIButton *)sender;

@end

@implementation CaseClipDetailRecordCell

-(void)setCellWith:(CaseClipDetailResponse *)model{

    self.time.text = model.time;
    self.addres.text = model.showAddress;
    
    
}

- (IBAction)deleteBtnClicked:(BasicUIButton *)sender {
}

- (IBAction)editBtnClicked:(BasicUIButton *)sender {
}
@end
