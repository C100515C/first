//
//  FamilyCasesClipCell.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString *const FamilyCasesClip_id = @"FamilyCasesClip";
@class FamilyCasesClipResponse;
@interface FamilyCasesClipCell : BasicTableViewCell

-(void)setCellWith:(FamilyCasesClipResponse*)model;

@end
