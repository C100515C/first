//
//  FamilyCasesClipCell.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "FamilyCasesClipCell.h"
#import "FamilyCasesClipResponse.h"

@interface FamilyCasesClipCell ()

@property (weak, nonatomic) IBOutlet UILabel *callName;

@property (weak, nonatomic) IBOutlet UILabel *gender;
@property (weak, nonatomic) IBOutlet UILabel *age;
@property (weak, nonatomic) IBOutlet UILabel *caseCount;

@end

@implementation FamilyCasesClipCell

-(void)setCellWith:(FamilyCasesClipResponse *)model{

    self.callName.text = model.nickname;
    
    self.gender.text = model.gender;

    self.age.text = model.age;

    self.caseCount.text = model.caseCount;

}

@end
