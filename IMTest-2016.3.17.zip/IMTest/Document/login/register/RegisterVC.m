//
//  RegisterVC.m
//  IMTest
//
//  Created by chenchen on 16/3/8.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "RegisterVC.h"
#import "RegisterUserInforVC.h"

@interface RegisterVC ()<UITextFieldDelegate>

@property (weak, nonatomic) IBOutlet UITextField *phoneNumber;
@property (weak, nonatomic) IBOutlet UITextField *verificationCode;
@property (weak, nonatomic) IBOutlet UIButton *getVerificationCodeBtn;

@property (strong, nonatomic) NSTimer *countTimer;
@property (nonatomic) int timeRemain;

@property (weak, nonatomic) IBOutlet UIView *topBackView;
- (IBAction)getVerificationCodeAction:(UIButton *)sender;

@end

@implementation RegisterVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = YES;
    
    self.verificationCode.delegate = self;
    self.phoneNumber.delegate = self;
    
    self.timeRemain = 60;
    [self.getVerificationCodeBtn setTitle:@"获取验证码" forState:UIControlStateNormal];
    [self setNav];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)dealloc{
    [self.countTimer invalidate];
    self.countTimer = nil;
}

-(void)setNav{
    // 设置navigationBar的背景颜色，根据需要自己设置
    self.navigationController.navigationBar.barTintColor = [UIColor whiteColor];
    //     设置navigationController的title的字体颜色
    NSDictionary * dict=[NSDictionary dictionaryWithObject:[UIColor darkGrayColor] forKey:NSForegroundColorAttributeName];
    self.navigationController.navigationBar.titleTextAttributes = dict;
    self.title = @"注册";
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
    [nav setNavBarBtnItemImageWith:@"faceDelete.png" andRightItem:NO andAction:@selector(popVC:) andTarget:self andVCIndex:1];
    [nav setNavBarBtnItemTitleWith:@"下一步" andRightItem:YES andAction:@selector(pushVC:) andTarget:self andVCIndex:1];
}

-(void)popVC:(UIButton*)btn{
    [self.navigationController popViewControllerAnimated:YES];
}

-(void)pushVC:(UIButton*)btn{
    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    RegisterUserInforVC *vc = [[RegisterUserInforVC alloc] init];
    [nav CustomPushviewWith:vc];
}


-(NSTimer*)countTimer{
    
    if (!_countTimer) {
        _countTimer = [NSTimer scheduledTimerWithTimeInterval:1
                                                           target:self
                                                         selector:@selector(oneSecondFlip)
                                                         userInfo:nil
                                                          repeats:YES];
    }
    
    return _countTimer;
}

-(UIButton*)getVerificationCodeBtn{
    
    if (_getVerificationCodeBtn) {
        _getVerificationCodeBtn.clipsToBounds = YES;
        _getVerificationCodeBtn.layer.cornerRadius = 5.0f;
    }
    
    return _getVerificationCodeBtn;
}

#pragma mark - text field

#pragma mark 倒计时功能
- (void)timeCountStart
{
    [self.getVerificationCodeBtn setTitle:@"60秒后重新发验证码" forState:UIControlStateNormal];
    [self.countTimer fire];
}

- (void)oneSecondFlip
{
    self.timeRemain = self.timeRemain - 1;
    if (self.timeRemain == 0) {
        
        [self.countTimer invalidate];
        self.countTimer = nil;
        self.timeRemain = 60;
        self.getVerificationCodeBtn.enabled = YES;
        [self.getVerificationCodeBtn setTitle:@"重新发送" forState:UIControlStateNormal];
        return;
    }
    MOSLog(@"1 second flip");
    
    NSString *countTitle = [[NSString alloc] initWithFormat:@"%d秒后重新发验证码", self.timeRemain];
    
    [self.getVerificationCodeBtn setTitle:countTitle
                            forState:UIControlStateNormal];
}

#pragma mark - btn action
- (IBAction)getVerificationCodeAction:(UIButton *)sender {
    [self timeCountStart];
    sender.enabled = NO;
}

@end
