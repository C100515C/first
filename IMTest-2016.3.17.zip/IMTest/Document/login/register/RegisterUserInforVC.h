//
//  RegisterUserInforVC.h
//  IMTest
//
//  Created by chenchen on 16/3/8.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface RegisterUserInforVC : BasicVC

@end
