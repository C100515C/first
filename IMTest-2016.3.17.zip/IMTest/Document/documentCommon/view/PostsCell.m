//
//  PostsCell.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostsCell.h"
#import "PostsResponse.h"
//#import "BasicUIButton.h"
//#import "BasicLabel.h"
//#import "BasicUIImageView.h"

@implementation PostsCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [_userIcon setRaduis];
    [_postsKind setBorder];
    
}

#pragma mark - view  init

-(void)setCellWith:(PostsResponse *)model{
    self.contentLabel.text = model.content;
    [self.contentLabel layoutIfNeeded];

    self.userNickname.text = model.nickname;
    self.userOption.text = model.type;
    self.postsKind.text = model.label;
    self.postsTitle.text = model.title;
    [self.praiseBtn setTitle:model.count forState:UIControlStateNormal];
    self.timeLabel.text = model.time;
    
//    [self setAllLayoutIfNeeded];
}

-(void)setAllLayoutIfNeeded{
    [self.contentLabel layoutIfNeeded];
    [self.userNickname layoutIfNeeded];
    [self.userOption layoutIfNeeded];
    [self.postsKind layoutIfNeeded];
    [self.postsTitle layoutIfNeeded];
    [self.praiseBtn layoutIfNeeded];
    [self.timeLabel layoutIfNeeded];
}

@end
