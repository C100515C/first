//
//  CircleDetailHeaderView.h
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface CircleDetailHeaderView : UIView

-(void)setHeaerViewWith:(NSDictionary*)dic;

@property (nonatomic,copy) void (^imageTapBlock)(UITapGestureRecognizer * sender);

@end
