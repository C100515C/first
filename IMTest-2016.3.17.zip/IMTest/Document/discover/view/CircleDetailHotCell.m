//
//  CircleDetailHotCell.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleDetailHotCell.h"
#import "CircleDetailResponse.h"

@interface CircleDetailHotCell ()
@property (weak, nonatomic) IBOutlet BasicLabel *titleType;
@property (weak, nonatomic) IBOutlet UILabel *content;

@end

@implementation CircleDetailHotCell

-(void)awakeFromNib{

    [self.titleType setBorder];
}

-(void)setCellWith:(CircleDetailHotResponse *)model{
    self.titleType.text = model.hotType;
    self.content.text = model.content;
}

@end
