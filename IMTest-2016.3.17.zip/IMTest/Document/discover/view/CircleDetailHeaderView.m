//
//  CircleDetailHeaderView.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleDetailHeaderView.h"
#import "BasicUIButton.h"
#import "BasicUIImageView.h"

@interface CircleDetailHeaderView ()<BasicUIImageTapProtocol>

@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;
@property (weak, nonatomic) IBOutlet UILabel *name;
@property (weak, nonatomic) IBOutlet UILabel *counts;
@property (weak, nonatomic) IBOutlet BasicUIButton *focusBtn;

- (IBAction)focusAction:(BasicUIButton *)sender;

@end

@implementation CircleDetailHeaderView

-(void)awakeFromNib{
    self.focusBtn.clipsToBounds = YES;
    self.focusBtn.layer.cornerRadius = 3.0f;
    [self.headerIcon setTapUse];
    self.headerIcon.lyj_delegate = self;
}

-(void)setHeaerViewWith:(NSDictionary *)dic{
    
    MOSLog(@"头 view  未写数居 赋值");
    
}

- (IBAction)focusAction:(BasicUIButton *)sender {
    MOSLog(@"dd");
}

#pragma mark - tap image
-(void)imageTapWith:(UITapGestureRecognizer *)sender{

    if (_imageTapBlock) {
        _imageTapBlock(sender);
    }
}

@end
