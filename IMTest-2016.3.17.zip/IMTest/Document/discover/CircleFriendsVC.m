//
//  CircleFriendsVC.m
//  IMTest
//
//  Created by chenchen on 16/3/15.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleFriendsVC.h"
#import "CircleFriendsCell.h"
#import "CircleFriendsResponse.h"

@interface CircleFriendsVC (){
    NSMutableArray *_dataSource;
    
}

@property (weak, nonatomic) IBOutlet UITableView *myTable;

@end

@implementation CircleFriendsVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self setNav];
    
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _dataSource = [[NSMutableArray alloc] init];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"CircleFriendsCell" bundle:nil] forCellReuseIdentifier:CircleFriendsCell_id];
    
    [self makeModel];

    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)setNav{

}

-(void)makeModel{
    for (int i=0 ; i<5; i++) {
        CircleFriendsResponse *model = [[CircleFriendsResponse alloc] init];
        model.content = @"但肯定没卡读书噶开始的感觉啊卡是的公司打工发撒高发但是搜噶是股份撒过烦噶生股份搜噶傻瓜是";
        model.time = @"两天前来自心脏圈";
        model.type = @"lyj 关注了该问题";
        model.nickname = @"cc";
        model.label = @"吐槽";
        model.title = @"跟本不知道是什么";
        model.count = @"1234";
        model.labels = @[@"老大老老大老老大老",@"老大老老大老老大老",@"老老大老老大老大老",@"老大老大老老",@"老大老大老老"];
        [_dataSource addObject:model];
    }
    [self.tableView reloadData];
}

#pragma mark - table
- (void)tableViewDidTriggerHeaderRefresh{
    
    [self tableViewDidFinishTriggerHeader:YES reload:NO];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    [self tableViewDidFinishTriggerHeader:NO reload:NO];
    
}//上拉加载事件

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{

    CircleFriendsResponse *model = (CircleFriendsResponse*)[_dataSource objectAtIndex:indexPath.row];
    return model.cellHeight;
    
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
    
    CircleFriendsCell *cell = [tableView dequeueReusableCellWithIdentifier:CircleFriendsCell_id];
        
    if (cell==nil) {
        cell= [[[NSBundle mainBundle]loadNibNamed:@"CircleFriendsCell" owner:nil options:nil] firstObject];
    }
        
    CircleFriendsResponse *model = (CircleFriendsResponse*)[_dataSource objectAtIndex:indexPath.row];
        
    [cell setCellWith:model];
        
    return cell;
    
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    
}


@end
