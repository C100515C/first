//
//  CircleDetailResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleDetailResponse.h"

static const CGFloat BasicHeight = 51.0f;
static const CGFloat TopView_height = 51.0f;

@implementation CircleDetailResponse

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size_content = [self getStringSizeWith:_content fontSize:15.0f showSize:CGSizeMake(SCREEN_WIDTH-48, 2000)];
//        CGSize size_title = [self getStringSizeWith:_title fontSize:16.0f showSize:CGSizeMake(SCREEN_WIDTH-16, 2000)];
        _cellHeight = size_content.height+BasicHeight+self.new_topHeight;
        
        return _cellHeight;
    }
}

-(CGFloat)new_topHeight{
    
    if (_new_topHeight) {
        return _new_topHeight;
    }else{
        CGSize size_title = [self getStringSizeWith:_title fontSize:16.0f showSize:CGSizeMake(SCREEN_WIDTH-16, 2000)];
        return size_title.height+TopView_height;
    }
}

@end

static const CGFloat HotBasicHeight = 40.0f;

@implementation CircleDetailHotResponse

-(CGFloat)cellHeight{
    if (_cellHeight) {
        return _cellHeight;
    }else{
        _cellHeight = HotBasicHeight;
        return _cellHeight;
    }
}

@end
