//
//  DiscoverVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "DiscoverVC.h"

#import "CCWaterFlowLayout.h"
#import "CCCollectionCell.h"
#import "CCCollectionReusableView.h"

#import "circleDetailVC.h"

static const CGFloat edgeSpace = 50.0f;
static const CGFloat menuBtnWidth = 80.0f;
static const CGFloat menuBtnSpace = 10.0f;
static NSString * const CollectionCell_id = @"collectioncellid";
static NSString * const CollectionViewFooter = @"footerid";
static NSString * const CollectionViewHeader = @"headerid";


@interface DiscoverVC ()<UICollectionViewDataSource,UICollectionViewDelegate,UICollectionViewDelegateFlowLayout>{
    NSMutableArray *_menuBtnsArr;
}

@property (nonatomic,strong) UIView *backMenuView;
@property (nonatomic, strong) UICollectionView *collection;
@property (nonatomic,assign) CCCollectionReusableView *resuableview;

@end

@implementation DiscoverVC

- (void)viewDidLoad {

    [super viewDidLoad];
    
    _menuBtnsArr = [[NSMutableArray alloc] init];
    self.title = @"发现";
    self.tableView.hidden = YES;
    
    
    
    for (int i=0; i<10; i++) {
        [_menuBtnsArr addObject: @"chat_item_file"];

    }
    
    [self setUI];
    
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewDidAppear:(BOOL)animated{
    [super viewDidAppear:animated];
    [self.resuableview bannerStart];
}

-(void)viewDidDisappear:(BOOL)animated{
    [super viewDidDisappear:animated];
    [self.resuableview bannerOver];

}


#pragma mark - ui
-(void)setUI{

    UICollectionViewFlowLayout *layout = [[CCWaterFlowLayout alloc] init];//CCWaterFlowLayout
    //    layout.headerReferenceSize = CGSizeMake(320, 80);
    self.collection = [[UICollectionView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT-APP_STATUSBAR_NVIGATIONBAR_HEIGHT-APP_STATUSBAR_TABBAR_HEIGHT) collectionViewLayout:layout];
    [self.view addSubview:self.collection];
    self.collection.delegate = self;
    self.collection.dataSource = self;
    
    self.collection.backgroundColor = [UIColor whiteColor];
    self.collection.contentInset = UIEdgeInsetsMake(100, 0, 0, 0);
    //    [self.collection registerClass:[CCCollectionCell class] forCellWithReuseIdentifier:@"cellID"];
    
    [self.collection registerNib:[UINib nibWithNibName:@"CCCollectionCell" bundle:nil] forCellWithReuseIdentifier:CollectionCell_id];
    
//        [self.collection registerClass:[CCCollectionReusableView class] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:CollectionViewHeader];
    
    [self.collection registerNib:[UINib nibWithNibName:@"CCCollectionReusableView" bundle:nil] forSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:CollectionViewHeader];

}

#pragma mark - collection view 
//分多少组
-(NSInteger)numberOfSectionsInCollectionView:(UICollectionView *)collectionView{
    return 1;
}
//每组多少个item
- (NSInteger)collectionView:(UICollectionView *)collectionView numberOfItemsInSection:(NSInteger)section {
    return _menuBtnsArr.count;
}
// 创建item
- (UICollectionViewCell *)collectionView:(UICollectionView *)collectionView cellForItemAtIndexPath:(NSIndexPath *)indexPath {
    
    CCCollectionCell *cell = [collectionView dequeueReusableCellWithReuseIdentifier:CollectionCell_id forIndexPath:indexPath];
    
    return cell;
}

//设置 item  size
-(CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout sizeForItemAtIndexPath:(NSIndexPath *)indexPath{
    return CGSizeMake(80, 50);
}

/**需要组footer或者 header 需要执行的回调  同时需要注册footer 或者  header  view **/
//footer  header 每个组的
-(UICollectionReusableView*)collectionView:(UICollectionView *)collectionView viewForSupplementaryElementOfKind:(NSString *)kind atIndexPath:(NSIndexPath *)indexPath{
    
   CCCollectionReusableView *cell = [collectionView dequeueReusableSupplementaryViewOfKind:UICollectionElementKindSectionHeader withReuseIdentifier:CollectionViewHeader forIndexPath:indexPath];
    self.resuableview = cell;
    
    if (kind==UICollectionElementKindSectionHeader) {

        return cell;
    }else{
        return [[CCCollectionReusableView alloc]init];
    }
    
}

////设置每一个组的上下左右距离
-(UIEdgeInsets)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout *)collectionViewLayout insetForSectionAtIndex:(NSInteger)section{
    return UIEdgeInsetsZero;
}

//- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForFooterInSection:(NSInteger)section{
//    return CGSizeMake(self.collection.frame.size.width, 80);
//}

- (CGSize)collectionView:(UICollectionView *)collectionView layout:(UICollectionViewLayout*)collectionViewLayout referenceSizeForHeaderInSection:(NSInteger)section{
    return CGSizeMake(self.collection.frame.size.width, 80);
}

-(void)collectionView:(UICollectionView *)collectionView didSelectItemAtIndexPath:(NSIndexPath *)indexPath{
//    MOSLog(@"select = %ld",indexPath.row);
    
    circleDetailVC *vc = [[circleDetailVC alloc] init];
    vc.title = @"肺部圈";
    vc.hidesBottomBarWhenPushed = YES;
    [self.navigationController pushViewController:vc animated:YES];
}

/*******************************************暂时不用***********************************************/
-(CGSize )getBackMenuSize{
    CGSize size;
    int x = 0,y = 0;
    
    x= ((int)_menuBtnsArr.count)%3;
    y = ((int)_menuBtnsArr.count)/3;
    
    if (y==0) {
        size.height = menuBtnWidth;
        size.width = x*(menuBtnSpace+menuBtnWidth)-menuBtnSpace;
    }else{
        size.width = 3*(menuBtnSpace+menuBtnWidth)-menuBtnSpace;
        size.height = y*(menuBtnSpace+menuBtnWidth)-menuBtnSpace;
        
    }
    
    return size;
}

-(UIView*)backMenuView{
    
    if (!_backMenuView) {
       CGSize size = [self getBackMenuSize];
        _backMenuView =[[UIView alloc] initWithFrame:CGRectMake(0, 0, size.width, size.height)];
        _backMenuView.backgroundColor = [UIColor whiteColor];
        _backMenuView.center = CGPointMake(self.view.frame.size.width/2.0, (self.view.frame.size.height-APP_STATUSBAR_NVIGATIONBAR_HEIGHT)/2.0-edgeSpace);
        [self.view addSubview:_backMenuView];
        
        for (int i=0; i<_menuBtnsArr.count; i++) {
            
            UIButton *btn = [UIButton buttonWithType:UIButtonTypeCustom];
            [_backMenuView addSubview:btn];
            btn.frame = CGRectMake(i%3*(menuBtnWidth+menuBtnSpace), i/3*(menuBtnWidth+menuBtnSpace), menuBtnWidth, menuBtnWidth);
            btn.tag = 1+i;
            [btn setBackgroundImage:[UIImage imageNamed:_menuBtnsArr[i]] forState:UIControlStateNormal];
            [btn addTarget:self action:@selector(menuBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
            
        }
        
    }
    
    return _backMenuView;
}

-(void)menuBtnClicked:(UIButton*)sender{
    
    MOSLog(@"%ld",(long)sender.tag);
}

@end
