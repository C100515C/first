//
//  RootVC.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "RootVC.h"
#import "DiscoverVC.h"
#import "HomePageVC.h"
#import "InformationVC.h"
#import "MineSettingVC.h"
#import "BasicnavigationVC.h"
//#import "ViewController.h"

#import "UserProfileManager.h"
#import "LoginVC.h"
#import "AppDelegate.h"

static NSString *const UPDATE_CHATLIST_KEY = @"updateChatList_Key"; //"Information"的未读消息数
static NSString *const UPDATE_TABBARCONTROLLER_UNREAD_MSG =   @"updateTabBarControllerUnreadMsg";//tabbar的未读消息数

@interface RootVC ()<UITabBarControllerDelegate>
// information 未读消息数
@property (nonatomic) NSInteger informationUnreadCount;
// dicover 未读消息数
@property (nonatomic) NSInteger dicoverUnreadCount;

@end

@implementation RootVC

- (instancetype)init
{
    self = [super init];
    if (self) {
//        UISwipeGestureRecognizer *right = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(rightSwipe:)];
//        right.numberOfTouchesRequired = 1;
//        right.direction = (UISwipeGestureRecognizerDirectionRight);
//        
//        [self.view addGestureRecognizer:right];
//        
//        UISwipeGestureRecognizer *left = [[UISwipeGestureRecognizer alloc] initWithTarget:self action:@selector(leftSwipe:)];
//        left.numberOfTouchesRequired = 1;
//        left.direction = (UISwipeGestureRecognizerDirectionLeft);
//        
//        [self.view addGestureRecognizer:left];
//        self.view.userInteractionEnabled = YES;
        
    }
    
    return self;
}

- (void)viewDidLoad {
    [super viewDidLoad];
    
    self.delegate = self;
    
    self.informationUnreadCount = 0;
    self.dicoverUnreadCount = 0;
    
//    [self prensentLoginVC];

    
    [self loadSubVC];
    
    //添加未读消息数通知
    [[NSNotificationCenter defaultCenter] addObserver:self selector:@selector(updateUnreadMsgCount:) name:UPDATE_TABBARCONTROLLER_UNREAD_MSG object:nil];
    
    // Do any additional setup after loading the view.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - UI
// 加载tab各VC
- (void)loadSubVC
{
    NSMutableArray *vcArray = [[NSMutableArray alloc] init];
    
    [self.tabBar setBarTintColor:[UIColor whiteColor]];
    [self.tabBar setTintColor:G_COLOR_NAVGATION_BACK];
    // 各模块名称
    NSArray *modelClass = @[@"HomePageVC", @"DiscoverVC", @"InformationVC", @"MineSettingVC"];
    // 各模块标题
    NSArray *modelTitle = @[@"首页", @"发现",@"消息", @"我的"];
    //无图
    // 普通状态tab icon
    NSArray *normalArray = @[@"ImgTabHomeNormal", @"ImgTabFocusNormal", @"ImgTabPublishNormal", @"ImgTabInfoNormal", @"ImgTabMeNormal"];
    // 高亮状态tab icon
    NSArray *highlightArray = @[@"ImgTabHomeHighlight", @"ImgTabFocusHighlight", @"ImgTabPublishHighlight", @"ImgTabInfoHighlight", @"ImgTabMeHighlight"];
    
    for (int i = 0; i < [modelClass count]; i++) {
        
        BasicnavigationVC *subNav;
        
        Class c = NSClassFromString(modelClass[i]);
        BasicVC *vc = [[c alloc] init];
        

            subNav = [[BasicnavigationVC alloc] initWithRootViewController:vc];
        
        // Tabbar icon图片
        subNav.tabBarItem.image=[[UIImage imageNamed:normalArray[i]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        subNav.tabBarItem.selectedImage = [[UIImage imageNamed:highlightArray[i]] imageWithRenderingMode:UIImageRenderingModeAlwaysOriginal];
        
        // Navgationbar 背景
        subNav.title = modelTitle[i];
        subNav.navigationBar.barTintColor = G_COLOR_NAVGATION_BACK;
        subNav.navigationBar.backgroundColor = G_COLOR_NAVGATION_BACK;
        subNav.navigationBar.translucent = NO;
        
        // Navgationbar 字体大小颜色
        NSDictionary *dict = @{NSForegroundColorAttributeName:G_COLOR_NAVGATION_TITLE,
                               NSFontAttributeName:G_FONT_NAVGATION_TITLE};
        
        subNav.navigationBar.titleTextAttributes = dict;
        
        subNav.navigationBar.tintColor = [UIColor whiteColor];
        
        [vcArray addObject:subNav];
    }
    
    self.viewControllers = vcArray;
}
#pragma mark - swipe
-(void)leftSwipe:(UISwipeGestureRecognizer*)sender{
//    MOSLog(@"%ld", sender.direction);
    
    NSInteger index = self.selectedIndex;
    
    if (index==self.viewControllers.count-1) {
        return;
    }
    self.selectedIndex = ++index;
    self.selectedViewController = self.viewControllers[index];

}

-(void)rightSwipe:(UISwipeGestureRecognizer*)sender{
//    MOSLog(@"%ld", sender.direction);
    NSInteger index = self.selectedIndex;
    
    if (index == 0) {
        return;
    }
    self.selectedIndex = --index;
    self.selectedViewController = self.viewControllers[index];
}

#pragma mark - 消息数 操作
- (void)updateUnreadMsgCount:(NSNotification*)notify{
    if (!self.viewControllers || [self.viewControllers count] == 0) {
        return;
    }
    
    //更新沟通消息个数
    NSNumber* chatListMsgCount = [[notify userInfo] objectForKey:UPDATE_CHATLIST_KEY];
    
    NSInteger msgNum = [chatListMsgCount integerValue];
    
    [self updateUnReadMsgCount:msgNum withTabIndex:TabIndexInformation];
}
// IM tabbar刷新未读消息条数
+(void)notificationTabBarUpdateUnreadMsgCount{

}

// 在其他设备登录
- (void)loginElseWhere{

}

// 我的关注 tabbar 未读消息条刷新
-(void)getNotRead{

}

#pragma makr - 我的关注消息通知

-(void)reduceNoReadNumWith:(NSInteger)IsReadedNum and:(TabIndexType)tabindex{
    UINavigationController *nav = self.viewControllers[tabindex];
    NSInteger oldNum = [nav.tabBarItem.badgeValue integerValue];
    NSInteger newNUm = oldNum-IsReadedNum;
    [self updateUnReadMsgCount:newNUm
                  withTabIndex:tabindex];
}

#pragma mark - TabBar未读消息UI刷新

-(void)updateUnReadMsgCount:(NSInteger)unReadMsgCount withTabIndex:(TabIndexType)tabIndex{
    NSString *numStr = nil;
    
    if (unReadMsgCount > 99) {
        numStr = @"99+";
    } else if (unReadMsgCount == 0) {
        numStr = nil;
    } else {
        numStr = [[NSString alloc] initWithFormat:@"%ld", (long)unReadMsgCount];
    }
    
    UINavigationController *nav = self.viewControllers[tabIndex];
    nav.tabBarItem.badgeValue = numStr;
    
    if (tabIndex == TabIndexInformation) {
        self.dicoverUnreadCount = unReadMsgCount;
    } else {
        self.informationUnreadCount = unReadMsgCount;
    }
    
    [UIApplication sharedApplication].applicationIconBadgeNumber = self.dicoverUnreadCount + self.informationUnreadCount;
}

#pragma mark - login 
-(void)prensentLoginVC{
    BOOL isLogin = [[UserProfileManager sharedInstance] getLoginState];

    if (!isLogin) {
        LoginVC *vc = [[LoginVC alloc] init];
        BasicnavigationVC *nav = [[BasicnavigationVC alloc] initWithRootViewController:vc];
        nav.modalPresentationStyle=UIModalPresentationOverFullScreen;
        [self presentViewController:nav animated:NO completion:^{
            
        }];
    }
}

@end
