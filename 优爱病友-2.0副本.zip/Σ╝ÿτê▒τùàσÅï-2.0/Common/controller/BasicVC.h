//
//  BasicVC.h
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>
#import "BasicRefreshVC.h"
#import "CC_NSStringHandle.h"

@interface BasicVC : BasicRefreshVC <UIAlertViewDelegate,UIActionSheetDelegate>

@property (nonatomic,copy) NSMutableArray *dataSearchSource;//搜索数据源
@property (nonatomic,assign) BOOL showSearchBar;//是否隐藏 搜索条
@property (nonatomic,assign) BOOL isPush;
@property (nonatomic,assign) BOOL isPop;
@property (nonatomic,copy) void (^RefreshPreviousVCNewDataWhenThisVCDiscover)(BOOL isDiscover);
/***********************************子类根据自己从写下面方法设置搜索cell等*********************************/
-(UITableViewCell*)setSearchTableCellWith:(UITableView *)tableView and:( NSIndexPath *)indexPath;
-(CGFloat)setSearchCellHeightWith:(UITableView *)tableView and:( NSIndexPath *)indexPath;
-(void)setSearchSelectedCellActionWith:(UITableView *)tableView and:( NSIndexPath *)indexPath;

-(id)initBottomBarHide;

-(void)setNav;
-(void)refreshTableAndNeedHint:(BOOL)isNeed;
-(void)popToViewIndex:(NSInteger)index;
@end
