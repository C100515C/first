//
//  BasicModel.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"
#import <objc/runtime.h>

@interface BasicResponse ()

@end

@implementation BasicResponse

-(CGSize)getStringSizeWith:(NSString *)str fontSize:(CGFloat)font showSize:(CGSize)size{
    return [CC_NSStringHandle getSizeWithString:str andFont:font andSetStartSize:size];
}

-(void)setCellHeight:(CGFloat)cellHeight{
}

-(CGFloat)cellHeight{
    return 0;
}


-(NSAttributedString*)getNewAttributeStrWith:(NSString *)str andRangesAndColors:(NSArray *)arr{
   
    NSMutableAttributedString *att = [[NSMutableAttributedString alloc] initWithString:str];
//    [att addAttribute:NSLinkAttributeName
//                             value:@"destinationController1"
//                             range:NSMakeRange(0, 2)];
    for (NSDictionary *dic in arr) {
        
        [att addAttribute:NSForegroundColorAttributeName value:[dic objectForKey:BaseTextColors] range:[BasicResponse getRangeWith:[dic objectForKey:BaseTextRanges]]];
        
    }
    
    
    return att;
}

//- (BOOL)textView:(UITextView *)textView shouldInteractWithURL:(NSURL *)URL inRange:(NSRange)characterRange
//{
//    if ([URL.scheme isEqualToString:@"destinationController1"]) {
//        // Launch View controller
//        return NO;
//    }
//    return YES;
//}

+(NSDictionary *)rangeTransformToDicWith:(NSRange)range{
    return @{@"lonction":@(range.location),@"length":@(range.length)};
}

+(NSRange)getRangeWith:(NSDictionary *)rangeDic{
    if (rangeDic && rangeDic[@"lonction"] && rangeDic[@"length"]) {
        return NSMakeRange([rangeDic[@"lonction"] integerValue], [rangeDic[@"length"] integerValue]);
    }
    return NSMakeRange(0, 0);
}

/* 获取对象的所有属性 */
//- ( NSDictionary  *)properties_apsWith:(id)model
//
//{
//    
//    NSMutableDictionary  *props = [ NSMutableDictionary  dictionary ];

    //    unsigned   int  outCount, i;
    
    //    objc_property_t  *properties =  class_copyPropertyList ([ UserProfileEntity   class ], &outCount);
    //
    //    for  (i =  0 ; i<outCount; i++)
    //
    //    {
    //
    //        objc_property_t  property = properties[i];
    //
    //        const   char * char_f = property_getName (property);
    //
    //        NSString  *propertyName = [ NSString  stringWithUTF8String :char_f];
    //
    //        id  propertyValue = [ self  valueForKey :( NSString  *)propertyName];
    //
    //        if  (propertyValue) [props  setObject :propertyValue  forKey :propertyName];
    //
    //    }
    
//    unsigned int count;
//    objc_property_t *properties = class_copyPropertyList([UserProfileEntity class], &count);
//    for(int i = 0; i < count; i++)
//    {
//        objc_property_t property = properties[i];
//        
//                NSLog(@"name:%s",property_getName(property));
//                NSLog(@"attributes:%s",property_getAttributes(property));
//        NSString *keyname = [NSString stringWithUTF8String:property_getName(property)];
//        if (keyname==nil) {
//            continue;
//        }
//        id value = [self valueForKey:keyname];
//        if (value==nil) {
//            value = @"";
//        }
//        [props setObject:value forKey:keyname];
//    }
//    //    free(properties);
//    
//    free (properties);
//    
//    return  props;
//    
//}

-(NSDictionary*)getUserProfileDic{
    NSMutableDictionary *dic = [NSMutableDictionary dictionary];
    NSArray *keys = [JastorRuntimeHelper propertyNames:[self class]];
    
    for (NSString *key in keys) {
        id value = [self valueForKey:key];
        if (value==nil) {
            continue;
        }
        [dic setObject:value forKey:key];
    }
    return dic;
}

-(NSInteger)LinesOfString:(NSString*)str andMaxLines:(NSInteger)max andStringFontSize:(CGFloat)size andLineMaxWidth:(CGFloat)maxwidth{
    if (str.length<=0) {
        return 0;
    }
    NSInteger numLines = [CC_NSStringHandle getNumberOfString:str andFont:size andSetStartSize:CGSizeMake(maxwidth, 2000)];
    if (numLines>max) {
        numLines = max;
    }
    
    return numLines;
}

-(CGSize)baseStrHeightWith:(CGFloat)fontSize {
    CGSize size = [self getStringSizeWith:@"我" fontSize:fontSize showSize:CGSizeMake(SCREEN_WIDTH, 2000)];
    size.height = size.height;
    return size;
}

-(CGSize)noLineLimitOfString:(NSString*)str andStringFontSize:(CGFloat)size andLineMaxWidth:(CGFloat)maxwidth{
    CGSize baseSize = [self baseStrHeightWith:size];
    if (str.length<=0) {
        return CGSizeMake(baseSize.width, 1);
    }
    NSInteger numLines = [CC_NSStringHandle getNumberOfString:str andFont:size andSetStartSize:CGSizeMake(maxwidth, 2000)];
    CGSize newsize = CGSizeMake(baseSize.width, baseSize.height*numLines);
//    MOSLog(@"%ld",numLines);
    return newsize;
}

- (NSString *)flattenHTML:(NSString *)html {
    
    NSScanner *theScanner;
    NSString *text = nil;
    
    theScanner = [NSScanner scannerWithString:html];
    
    while ([theScanner isAtEnd] == NO) {
        // find start of tag
        [theScanner scanUpToString:@"<" intoString:NULL] ;
        // find end of tag
        [theScanner scanUpToString:@">" intoString:&text] ;
        // replace the found tag with a space
        //(you can filter multi-spaces out later if you wish)
        html = [html stringByReplacingOccurrencesOfString:
                [NSString stringWithFormat:@"%@>", text]
                                               withString:@""];
        html = [html stringByReplacingOccurrencesOfString:@"/n" withString:@""];
    } // while //
    return html;
}

@end
