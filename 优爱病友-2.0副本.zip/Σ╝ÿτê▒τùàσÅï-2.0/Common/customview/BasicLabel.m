

//
//  BasicLabel.m
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicLabel.h"

@implementation BasicLabel

-(void)awakeFromNib{
}

-(void)setType:(LabelContentFontType)type{
    
    if (type==LabelFont_14) {
        self.font = [UIFont systemFontOfSize:FontSize_14];//[UIFont fontWithName:@".PingFang-SC-Thin" size:ContentFontSize_14];
    }else if(type==LabelFont_15){
        self.font = [UIFont systemFontOfSize:FontSize_15];//[UIFont fontWithName:@".PingFang-SC-Thin" size:TitleFontSize_15];
    }else if(type==LabelFont_12){
        self.font = [UIFont systemFontOfSize:FontSize_12];//[UIFont fontWithName:@".PingFang-SC-Thin" size:AlertFontSize_12];
    }else if(type==LabelFont_16){
        self.font = [UIFont systemFontOfSize:FontSize_16];//[UIFont fontWithName:@".PingFang-SC-Thin" size:NickNameFontSize_16];
    }else if(type==LabelFont_13){
        self.font = [UIFont systemFontOfSize:FontSize_13];//[UIFont fontWithName:@".PingFang-SC-Thin" size:RepeatContentFontSize_13];
    }else {
        self.font = [UIFont systemFontOfSize:FontSize_17];//[UIFont fontWithName:@".PingFang-SC-Thin" size:BigFontSize_17];
    }
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        
    }
    return self;
}

-(void)setBorder{
    self.clipsToBounds = YES;
    self.layer.cornerRadius = 3.0f;
    
   
    self.layer.borderColor = [[UIColor redColor]CGColor];
    self.textColor = [UIColor redColor];

    
    self.layer.borderWidth = 1.0f;
    self.textAlignment = NSTextAlignmentCenter;
}

-(void)setLYJ_textColor:(UIColor *)LYJ_textColor{
    
    if (LYJ_textColor) {
        _LYJ_textColor = nil;
        _LYJ_textColor = LYJ_textColor;
        self.layer.borderColor = [_LYJ_textColor CGColor];
        self.textColor = _LYJ_textColor;
    }else{
        _LYJ_textColor = nil;
        _LYJ_textColor = [UIColor redColor];
    }
}

/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect {
    // Drawing code
}
*/

@end
