//
//  BasicLabel.h
//  IMTest
//
//  Created by chenchen on 16/3/2.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

typedef enum {
    LabelFont_14 = 200,
    LabelFont_15,
    LabelFont_16,
    LabelFont_13,
    LabelFont_12,
    LabelFont_17
    
}LabelContentFontType;
@interface BasicLabel : UILabel

@property (nonatomic,strong) UIColor *LYJ_textColor;
@property (nonatomic,assign) LabelContentFontType type;

-(void)setBorder;

@end
