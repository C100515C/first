//
//  CC_CanDeleteImageView.m
//  CC_Managers
//
//  Created by mac on 15/7/23.
//  Copyright (c) 2015年 CC. All rights reserved.
//

#import "CC_CanDeleteImageView.h"

static const NSInteger DELETE_BTN_HEGIHT = 20;
static const NSInteger DELETE_Tag = 2223;
static const NSInteger RIGHTMARKTAG = 2222;

@interface CC_CanDeleteImageView ()
@property (nonatomic,strong) UIButton *deleteBtn;
@end

@implementation CC_CanDeleteImageView

-(id)initWithFrame:(CGRect)frame andSelected:(BOOL)isselected{
    self = [super initWithFrame:frame];
    
    if (self) {
        self.userInteractionEnabled = YES;
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(tapAction:)];
        [self addGestureRecognizer:tap];
        //选中图片标记
        UIImageView * rigthtMark = nil;
        rigthtMark = [[UIImageView alloc] init];
        rigthtMark.image = [UIImage imageNamed:@"photo_choice_icon"];
        rigthtMark.frame = CGRectMake(100-17, 5, 12, 12);
        rigthtMark.tag = RIGHTMARKTAG;
        [self addSubview:rigthtMark];
        rigthtMark.hidden = isselected;
        self.isUpload = NO;
        self.isSelected = isselected;

    }
    return self;
}

-(void)tapAction:(UITapGestureRecognizer*)tap{
    
    if (self.delegate && [self.delegate respondsToSelector:@selector(pictureSelectedWith:)]) {
        [self.delegate pictureSelectedWith:self];
    }
    UIImageView *image = (UIImageView*) [self viewWithTag:RIGHTMARKTAG];
    image.hidden = !image.hidden;
}

-(void)hidenRightMark{
    UIImageView *image = (UIImageView*) [self viewWithTag:RIGHTMARKTAG];
    image.hidden = !image.hidden;
}

-(void)hidenDeletMark{
    UIImageView *image = (UIImageView*) [self viewWithTag:DELETE_Tag];
    image.hidden = YES;
}

-(id)initWithFrame:(CGRect)frame{
    self = [super initWithFrame:frame];
    if (self) {
        self.userInteractionEnabled = YES;
        UIButton *deleteBtn = [UIButton buttonWithType:UIButtonTypeCustom];
        deleteBtn.frame = CGRectMake(frame.size.width-DELETE_BTN_HEGIHT, 0, DELETE_BTN_HEGIHT, DELETE_BTN_HEGIHT);
        [self addSubview:deleteBtn];
        deleteBtn.tag = DELETE_Tag;
//        deleteBtn.backgroundColor = [UIColor blackColor];
        [deleteBtn setBackgroundImage:[UIImage imageNamed:@"close"] forState:UIControlStateNormal];
        self.isUpload = NO;
        self.isSelected = NO;
        [deleteBtn addTarget:self action:@selector(deleteBtnClicked:) forControlEvents:UIControlEventTouchUpInside];
        self.deleteBtn = deleteBtn;
    }
    
    return self;
}

-(void)deleteBtnClicked:(UIButton*)sender{
    if (self.delegate && [self.delegate respondsToSelector:@selector(deletePictureWith:)]) {
        [self.delegate deletePictureWith:self];
    }
//    [self removeFromSuperview];
}
/**
 *  重设删除按钮位置
 */
-(void)set_NewDeleteBtnFrame{
    self.deleteBtn.frame = CGRectMake(self.frame.size.width-DELETE_BTN_HEGIHT, 0, DELETE_BTN_HEGIHT, DELETE_BTN_HEGIHT);
}

+(NSString*)getPicNameWith:(NSString *)fileName{
    NSArray *arr = [fileName componentsSeparatedByString:@"/"];
    if (arr.count>=1) {
        return [arr lastObject];
    }
    return @"";
}

@end
