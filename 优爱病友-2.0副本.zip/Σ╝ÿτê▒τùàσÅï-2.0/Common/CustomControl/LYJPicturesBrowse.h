//
//  LYJPicturesBrowse.h
//  IMTest
//
//  Created by chenchen on 16/3/18.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>
@class CC_CanDeleteImageView;
@protocol LYJPictureBrowser <NSObject>

-(void)deleteImage:(CC_CanDeleteImageView*)image;

@end
@interface LYJPicturesBrowse : UIView

@property (nonatomic,strong) NSMutableArray *pics;
@property (nonatomic,strong) UIScrollView *backContentView;
@property (nonatomic,assign) BOOL isHidenDelete;
@property (nonatomic,assign) id<LYJPictureBrowser>lyj_delegate;
@end
