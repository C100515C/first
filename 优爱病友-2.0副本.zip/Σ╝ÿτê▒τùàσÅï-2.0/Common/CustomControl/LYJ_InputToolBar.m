//
//  LYJ_InputToolBar.m
//  IMTest
//
//  Created by chenchen on 16/5/26.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJ_InputToolBar.h"
//#import "LYJ_TextView.h"

static NSString *const contentHeight = @"n_contentheight";
@interface LYJ_InputToolBar ()<UITextViewDelegate>
@property (strong, nonatomic) IBOutlet UIView *view;

@property (weak, nonatomic) IBOutlet UIButton *sendBtn;
- (IBAction)sendAction:(UIButton *)sender;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentLayoutHeight;
@end

@implementation LYJ_InputToolBar

-(void)awakeFromNib{

    [self.contentField addObserver:self forKeyPath:@"contentSize" options:NSKeyValueObservingOptionNew|NSKeyValueObservingOptionOld context:(__bridge void*)(contentHeight)];
    self.contentField.delegate = self;
}

- (instancetype)initWithCoder:(NSCoder *)aDecoder
{
    self = [super initWithCoder:aDecoder];
    if (self) {
        NSString *className = NSStringFromClass([self class]);
        self.view = [[[NSBundle mainBundle] loadNibNamed:className owner:self options:nil] firstObject];
        [self addSubview:self.view];
        return self;
    }
    return nil;
}

-(void)observeValueForKeyPath:(NSString *)keyPath ofObject:(id)object change:(NSDictionary *)change context:(void *)context{
    if ([keyPath isEqualToString: @"contentSize"]) {
        if (self.lyj_delegate && [self.lyj_delegate respondsToSelector:@selector(newToolBarHeight:)]) {
            [self.lyj_delegate newToolBarHeight:self.contentField.contentSize.height];
            self.contentLayoutHeight.constant = self.contentField.contentSize.height;
        }
    }
}

-(void)dealloc{
    [self.contentField removeObserver:self forKeyPath:@"contentSize" context:(__bridge void*)contentHeight];
}

-(void)textViewDidChange:(UITextView *)textView{
    self.st = textView.text;
}

- (IBAction)sendAction:(UIButton *)sender {
    
}

@end
