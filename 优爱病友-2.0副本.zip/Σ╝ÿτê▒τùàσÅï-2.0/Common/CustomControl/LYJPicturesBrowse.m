//
//  LYJPicturesBrowse.m
//  IMTest
//
//  Created by chenchen on 16/3/18.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJPicturesBrowse.h"
#import "AppDelegate.h"
#import "CC_CanDeleteImageView.h"

static const NSInteger basicTag = 10000;
@interface LYJPicturesBrowse ()<CC_CanDeleteImage>

//@property (nonatomic,strong) UIScrollView *backContentView;
@property (nonatomic,strong) UIScrollView *bigScreenPicContent;

@property (nonatomic,assign) NSInteger currentIndex;
@property (nonatomic,assign) BOOL isNewPics;

@end

@implementation LYJPicturesBrowse

-(void)awakeFromNib{
    self.backContentView = [[UIScrollView alloc] initWithFrame:self.bounds];
    [self addSubview:_backContentView];
//    _backContentView.backgroundColor = [UIColor whiteColor];
    _backContentView.pagingEnabled = YES;
}

- (instancetype)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        self.backContentView = [[UIScrollView alloc] initWithFrame:self.bounds];
        [self addSubview:_backContentView];
        _backContentView.backgroundColor = [UIColor whiteColor];
        _backContentView.pagingEnabled = YES;
    }
    return self;
}

#pragma mark - Property method

-(void)setPics:(NSMutableArray *)pics{
    
     [_backContentView.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    [_bigScreenPicContent.subviews makeObjectsPerformSelector:@selector(removeFromSuperview)];
    
    if (pics==nil) {
        _pics = [pics mutableCopy];

    }else{
        if (![pics isEqualToArray:_pics]) {
            _pics = nil;
            _pics = [pics mutableCopy];

        }
    }
    [self createImageviewWith:_pics];
}

-(UIScrollView*)bigScreenPicContent{
    
    if (_bigScreenPicContent==nil) {
        _bigScreenPicContent = [[UIScrollView alloc] initWithFrame:CGRectMake(0, 0, SCREEN_WIDTH, SCREEN_HEIGHT)];
        _bigScreenPicContent.backgroundColor = [[UIColor blackColor] colorWithAlphaComponent:1.0f];
        _bigScreenPicContent.pagingEnabled = YES;

        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(smallTap:)];
        tap.numberOfTapsRequired = 1;
        [_bigScreenPicContent addGestureRecognizer:tap];
    }
    _bigScreenPicContent.contentSize = CGSizeMake(SCREEN_WIDTH*_pics.count, SCREEN_HEIGHT);

    _bigScreenPicContent.hidden = NO;

    return _bigScreenPicContent;
}

-(void)createBigBrowseWith:(BOOL)isstore{
    if (isstore) {
        for (int i=0; i<_pics.count; i++) {
            id img = _pics[i];
            UIImage *image;
            if ([img isKindOfClass:[UIImage class]]) {
                image = (UIImage*)img;
                CGFloat height = image.size.height;
                CGFloat width = image.size.width;
                CGFloat scale = width/height;
                if (height>=SCREEN_HEIGHT-80) {
                    height = (SCREEN_HEIGHT-80);
                    width = height*scale;
                }
                
                if (width>=SCREEN_WIDTH) {
                    width = SCREEN_WIDTH-60;
                    height = width/scale;
                }
                
                UIImageView *pic = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, width, height)];
                pic.contentMode = UIViewContentModeScaleAspectFit;
                pic.image = image;
                pic.center = CGPointMake(SCREEN_WIDTH/2.0+(i*SCREEN_WIDTH), SCREEN_HEIGHT/2.0);
                pic.userInteractionEnabled = YES;
                [_bigScreenPicContent addSubview:pic];
                
                pic.tag = i;
                
            }else if([img isKindOfClass:[NSString class]]){
                
                UIImageView *pic = [[UIImageView alloc] initWithFrame:CGRectMake(0, 0, 80, 80)];
                pic.contentMode = UIViewContentModeScaleAspectFit;
                [pic sd_setImageWithURL:[NSURL URLWithString:img] completed:^(UIImage *image, NSError *error, EMSDImageCacheType cacheType, NSURL *imageURL) {
                    
                    CGFloat height = image.size.height;
                    CGFloat width = image.size.width;
                    CGFloat scale = width/height;
                    if (height>=SCREEN_HEIGHT-80) {
                        height = (SCREEN_HEIGHT-80);
                        width = height*scale;
                    }
                    
                    if (width>=SCREEN_WIDTH) {
                        width = SCREEN_WIDTH-60;
                        height = width/scale;
                    }
                    
                    pic.frame = CGRectMake(0, 0, width, height);
                    pic.center = CGPointMake(SCREEN_WIDTH/2.0+(i*SCREEN_WIDTH), SCREEN_HEIGHT/2.0);

                }];
                
                pic.center = CGPointMake(SCREEN_WIDTH/2.0+(i*SCREEN_WIDTH), SCREEN_HEIGHT/2.0);
                pic.userInteractionEnabled = YES;
                [_bigScreenPicContent addSubview:pic];
                
                pic.tag = i;
            }
          
        }
    }
}

#pragma mark - ui
-(void)createImageviewWith:(NSArray*)Pics{
    CGFloat height = _backContentView.frame.size.height;
//    CGFloat width = _backContentView.frame.size.width;
    CGFloat space = 8.0f;

//    CGFloat picWidth = (width-(space*(Pics.count+1)))/Pics.count;
    CGFloat picHeight = height-2*space;
    
    CGFloat sizeWidth = Pics.count*picHeight+(Pics.count+1)*space;
    
    _backContentView.contentSize = CGSizeMake(sizeWidth, height);
    
    for (int i=0; i<Pics.count; i++) {
        id img = Pics[i];
        UIImage *image;
        CC_CanDeleteImageView *pic = [[CC_CanDeleteImageView alloc] initWithFrame:CGRectMake(space+i*(space+picHeight), space, picHeight, picHeight)];
        pic.contentMode = UIViewContentModeScaleAspectFit;
        pic.userInteractionEnabled = YES;
        pic.delegate = self;
        pic.number = i;

        if (self.isHidenDelete) {
            [pic hidenDeletMark];
        }
        [_backContentView addSubview:pic];
        
        UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(bigTap:)];
        [pic addGestureRecognizer:tap];
        pic.tag = basicTag+i;
        if ([img isKindOfClass:[UIImage class]]) {
        image = (UIImage*)img;
            pic.image = image;
            pic.fileName = @"image";
        }else if ([img isKindOfClass:[NSString class]]){
            NSString *str = (NSString *)img;
            [pic sd_setImageWithURL:[NSURL URLWithString:str] placeholderImage:[UIImage imageNamed:DefaultIcon]];
            pic.fileName = str;
        }
    }
    
}

-(CC_CanDeleteImageView*)getImageWith:(NSInteger)num{
    CC_CanDeleteImageView *image = (CC_CanDeleteImageView*)[_backContentView viewWithTag:num];
    return image;
}

-(void)resetImageviewWith:(int)currentImageNum andTag:(NSInteger)currentTag;
{
    CGRect tmpRect = [self getImageWith:currentTag].frame;
    int tmpNum = currentImageNum;
    NSInteger tmpTag = currentTag;
//    MOSLog(@"%d--%d",_pics.count,currentImageNum);
    for (int i= (int)tmpNum+1; i<_pics.count; i++) {
        CC_CanDeleteImageView *imageview = [self getImageWith:basicTag+i];
        CGRect rect = imageview.frame;
        int num = imageview.number;
        NSInteger tag = imageview.tag;
        imageview.frame = tmpRect;
        imageview.number = tmpNum;
        imageview.tag = tmpTag;
        tmpNum = num;
        tmpRect = rect;
        tmpTag = tag;
    }
//    MOSLog(@"%d--%d",_pics.count,tmpNum);

    [self.pics removeObjectAtIndex:currentImageNum];

}

#pragma mark - tap
-(void)bigTap:(UITapGestureRecognizer*)tap{
    self.currentIndex = tap.view.tag-basicTag;
    [self showBigPicsWith:tap.view.tag];
}

-(void)smallTap:(UITapGestureRecognizer*)tap{
    _bigScreenPicContent.hidden = YES;
}

#pragma mark - big pic browse

-(void)showBigPicsWith:(NSInteger)index{
    
    AppDelegate *appdel = [UIApplication sharedApplication].delegate;
    [appdel.window addSubview:self.bigScreenPicContent];
    [self createBigBrowseWith:YES];
    [_bigScreenPicContent setContentOffset:CGPointMake(_currentIndex*SCREEN_WIDTH, 0) animated:YES];

}

#pragma mark- delete
-(void)deletePictureWith:(CC_CanDeleteImageView *)currentPicture{
    [self resetImageviewWith:currentPicture.number andTag:currentPicture.tag];
    [currentPicture removeFromSuperview];

    if (self.lyj_delegate && [self.lyj_delegate respondsToSelector:@selector(deleteImage:)]) {
        [self.lyj_delegate deleteImage:currentPicture];
    }
}

@end
