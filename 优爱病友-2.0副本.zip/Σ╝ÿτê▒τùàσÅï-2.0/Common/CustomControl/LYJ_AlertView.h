//
//  LYJ_AlertView.h
//  IMTest
//
//  Created by chenchen on 16/6/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@interface LYJ_AlertView : UIView

+(LYJ_AlertView*)share;

-(void)showLYJ_AlertViewWith:(NSString*)title andContent:(NSString*)content andBtnClicked:(void(^)(NSString *btn))block;

@end
