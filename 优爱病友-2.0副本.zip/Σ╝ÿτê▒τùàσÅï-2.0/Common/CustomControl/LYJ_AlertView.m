//
//  LYJ_AlertView.m
//  IMTest
//
//  Created by chenchen on 16/6/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LYJ_AlertView.h"
#import "CC_NSStringHandle.h"

static const CGFloat BasicHeight = 128.0f;
static LYJ_AlertView *shareAlert = nil;
typedef enum {
    CancleBtn = 10,
    SureBtn
}BtnName;

@interface LYJ_AlertView ()
@property (weak, nonatomic) IBOutlet UIView *contentView;
@property (weak, nonatomic) IBOutlet UILabel *titleLabel;
@property (weak, nonatomic) IBOutlet UILabel *contentLabel;
@property (weak, nonatomic) IBOutlet UIButton *cancleBtn;
@property (weak, nonatomic) IBOutlet UIButton *sureBtn;

- (IBAction)btnClicked:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *contentViewHeight;

@property (nonatomic,copy) void (^BtnClickedBlock)(NSString *btn);
@end

@implementation LYJ_AlertView
+(LYJ_AlertView*)share{
    
    static dispatch_once_t onceToken;
    dispatch_once(&onceToken, ^{
        if (shareAlert==nil) {
           shareAlert = [[[NSBundle mainBundle] loadNibNamed:@"LYJ_AlertView"
                                                owner:nil options:nil] firstObject];
        }
    });
    return shareAlert;
}

//-(instancetype)initWithCoder:(NSCoder *)aDecoder{
//    self = [super initWithCoder:aDecoder];
//    if (self) {
//        NSString *classname = NSStringFromClass([self class]);
//        self.view = [[[NSBundle mainBundle] loadNibNamed:classname owner:self options:nil] firstObject];
//        [self addSubview:self.view];
//        return self;
//    }
//    return nil;
//}

-(void)awakeFromNib{
    self.backgroundColor = [UIColor colorWithRed:30.0f/255.0f green:32.0f/255.0f blue:31.0f/255.0f alpha:0.6];
    
    self.contentView.clipsToBounds = YES;
    self.contentView.layer.cornerRadius = 5.0f;

}

- (IBAction)btnClicked:(UIButton *)sender {
    NSString *name = nil;
    if (sender.tag == SureBtn) {
        name = @"sure";
    }else if (sender.tag == CancleBtn){
        name = @"cancle";
    }
    [self removeFromSuperview];

    if (_BtnClickedBlock) {
        _BtnClickedBlock(name);
    }
}

-(void)showLYJ_AlertViewWith:(NSString *)title andContent:(NSString *)content andBtnClicked:(void (^)(NSString *btn))block{
    
    self.titleLabel.text = title;
    self.contentLabel.text = content;
    [self setNewHeightWith:title and:content];
    
    UIWindow *window = [UIApplication sharedApplication].keyWindow;   // 获得根窗口
    [window addSubview:self];
    self.frame = window.bounds;
    
    if (block) {
        _BtnClickedBlock = block;
    }
}

- (UIView *)rootView {
    UIView *rootView = self;
    
    while (rootView.superview) {
        
        if ([rootView.superview isKindOfClass:[UIWindow class]]) {
            break;
        }
        rootView = rootView.superview;
    }
    return rootView;
}

-(void)setNewHeightWith:(NSString*)title and:(NSString*)content{
    
    CGSize size1 = [self baseStrHeightWith:FontSize_17];
    NSInteger numLines1 = [self LinesOfString:title andMaxLines:100 andStringFontSize:FontSize_17 andLineMaxWidth:252];
    CGFloat newHeight1 = numLines1?size1.height:1.0f;
    
    CGSize size2 = [self baseStrHeightWith:FontSize_15];
    NSInteger numLines2 = [self LinesOfString:content andMaxLines:100 andStringFontSize:FontSize_15 andLineMaxWidth:252];
    CGFloat newHeight2 = numLines2?size2.height:1.0f;
    
    self.contentViewHeight.constant = newHeight1*numLines1+newHeight2*numLines2+BasicHeight-size2.height-size1.height;
}

-(CGSize)baseStrHeightWith:(CGFloat)fontSize {
    CGSize size = [self getStringSizeWith:@"我" fontSize:fontSize showSize:CGSizeMake(SCREEN_WIDTH, 2000)];
    size.height = size.height;
    return size;
}

-(CGSize)getStringSizeWith:(NSString *)str fontSize:(CGFloat)font showSize:(CGSize)size{
    return [CC_NSStringHandle getSizeWithString:str andFont:font andSetStartSize:size];
}

-(NSInteger)LinesOfString:(NSString*)str andMaxLines:(NSInteger)max andStringFontSize:(CGFloat)size andLineMaxWidth:(CGFloat)maxwidth{
    if (str.length<=0) {
        return 0;
    }
    NSInteger numLines = [CC_NSStringHandle getNumberOfString:str andFont:size andSetStartSize:CGSizeMake(maxwidth, 2000)];
    if (numLines>max) {
        numLines = max;
    }
    
    return numLines;
}

@end
