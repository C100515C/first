
//
//  AppDelegate+UMSocial.m
//  IMTest
//
//  Created by chenchen on 16/3/9.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "AppDelegate+UMSocial.h"
#import "UMSocial.h"

#import "UMSocialWechatHandler.h"
#import "UMSocialQQHandler.h"
#import "UMSocialSinaSSOHandler.h"
#import "UMFeedback.h"

@implementation AppDelegate (UMSocial)

- (void)umSocialApplication:(UIApplication *)application
didFinishLaunchingWithOptions:(NSDictionary *)launchOptions
                     appkey:(NSString *)appkey
               apnsCertName:(NSString *)apnsCertName
                otherConfig:(NSDictionary *)otherConfig{
    // 分享
    [UMSocialData setAppKey:appkey];
    [UMFeedback setAppkey:appkey];

//    [UMSocialSinaSSOHandler openNewSinaSSOWithRedirectURL:@"http://sns.whalecloud.com/sina2/callback"
    
    
    [UMSocialSinaSSOHandler openNewSinaSSOWithAppKey:@"1802853753"
                                              secret:@"0d61361c2ac2ceb2733b301ca9f5bf6e"
                                         RedirectURL:@"http://m.youaibingyou.com/download"];
    //设置微信AppId，设置分享url，默认使用友盟的网址
    [UMSocialWechatHandler setWXAppId:@"wx03e6124e99a02d11" appSecret:@"e2259387beed7fcf75b9d70616e1a997" url:@"http://m.youaibingyou.com/download"];//
    
    //设置分享到QQ空间的应用Id，和分享url 链接
    [UMSocialQQHandler setQQWithAppId:@"1105347540" appKey:@"pKBckNZGMzP6K7Q8" url:@"http://m.youaibingyou.com/download"];
    
    //统计
    NSString *version = [[[NSBundle mainBundle] infoDictionary] objectForKey:@"CFBundleShortVersionString"];
    [MobClick setAppVersion:version];
    
    [MobClick startWithAppkey:appkey reportPolicy:BATCH   channelId:@""];

    [MobClick setCrashReportEnabled:YES]; // 如果不需要捕捉异常，注释掉此行

}

- (BOOL)application:(UIApplication *)application openURL:(NSURL *)url sourceApplication:(NSString *)sourceApplication annotation:(id)annotation
{
    BOOL result = [UMSocialSnsService handleOpenURL:url];
    if (result == FALSE) {
        //调用其他SDK，例如支付宝SDK等
    }
    return result;
}

- (void)appUpdate:(NSDictionary *)appInfo{
    MOSLog(@"%@",appInfo);
}
@end
