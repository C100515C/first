//
//  ErrorResponse.m
//  ufenqi
//
//  Created by mac on 15/1/26.
//  Copyright (c) 2015年 mac. All rights reserved.
//

#import "ErrorResponse.h"

@implementation ErrorResponse

@end
