//
//  PersonalHomepageVC.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalHomepageVC.h"
#import "MyFocusVC.h"
#import "MyCollectionVC.h"
#import "ChatViewController.h"
#import "circleDetailVC.h"
#import "PersonalAnswersVC.h"
#import "PersonalFriendVC.h"
#import "PersonalPublicVC.h"
#import "MyDynamicVC.h"

#import "PersonalHomepageCell.h"
#import "SetMenuCell.h"

#import "PersonalHomepageResponse.h"
#import "SingletonServ.h"
#import "PersonalHomepageRequest.h"
#import "PersonalAddAttentionRequest.h"

#import "UIViewController+HUD.h"

@interface PersonalHomepageVC (){
    NSMutableArray *_dataSource;
}
@property (weak, nonatomic) IBOutlet UITableView *myTable;
- (IBAction)focusAction:(UIButton *)sender;
- (IBAction)sendMessageAction:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet UIButton *attentionBtn;
@property (weak, nonatomic) IBOutlet UIButton *sendMessageBtn;
@property (weak, nonatomic) IBOutlet UIView *separateOne;
@property (weak, nonatomic) IBOutlet UIView *separateTwo;


@property (assign,nonatomic) BOOL ismyself;
@property (assign,nonatomic) BOOL isman;
@end

@implementation PersonalHomepageVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;

    [super viewDidLoad];
    
    self.showRefreshFooter = NO;
    self.showRefreshHeader = NO;
    
    _dataSource = [[NSMutableArray alloc] init];
    
    [self.tableView registerNib:[UINib nibWithNibName:@"PersonalHomepageCell" bundle:nil] forCellReuseIdentifier:PersonalHomepageCell_id];
    [self.tableView registerNib:[UINib nibWithNibName:@"SetMenuCell" bundle:nil] forCellReuseIdentifier:setMenuCell_id];
    
    [self setNav];
    [self initUI];
    
    [self makeDataSource];
    
   
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"personal"];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"personal"];
    
}

-(void)setNav{
    [super setNav];
    self.title = @"他的主页";
    
}

-(void)initUI{
    
    if ([self.userid intValue]==[[[UserProfileManager sharedInstance] getUserId] intValue]) {
        self.attentionBtn.hidden = YES;
        self.sendMessageBtn.hidden = YES;
        self.separateOne.hidden = YES;
        self.separateTwo.hidden = YES;
        self.ismyself = YES;
    }
}

- (IBAction)focusAction:(UIButton *)sender {
    [self myAddAttentionBtnClicked];
}

- (IBAction)sendMessageAction:(UIButton *)sender {
    PersonalHomepageResponse *model = [_dataSource firstObject];
    if ([model.isFollow intValue]!=1) {
        [self showHint:@"未关注此人，不能聊天" yOffset:-200];
        return;
    }
    ChatViewController *chat = [[ChatViewController alloc] initWithConversationChatter:[NSString stringWithFormat:@"%@",model.user_id] conversationType:EMConversationTypeChat];
    chat.title = model.username;
    [self.navigationController pushViewController:chat animated:YES];
}

#pragma mark - data
-(void)makeDataSource{
    //第一个cell   头部 数据 模型
    PersonalHomepageRequest *req = [[PersonalHomepageRequest alloc] init];
    __weak typeof(self) weakself = self;
    req.user_id = self.userid;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            PersonalHomepageResponse *model = (PersonalHomepageResponse*)responseDataModel;
            
            [_dataSource addObject:model];
            weakself.isman = 2-[model.gender intValue];
            [weakself setUIData];
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
    }];
    
    
}

-(void)setUIData{
    
    [self changeBtnState];
    //收藏 关注 cell
    NSArray *menu_name = @[@"他的收藏",@"他的关注",@"他的动态"];
    
    if (self.ismyself) {
        menu_name = @[@"我的收藏",@"我的关注",@"我的动态"];
        self.title = @"我的主页";
    }else{
        if (!self.isman) {
            menu_name = @[@"她的收藏",@"她的关注",@"她的动态"];
        }
        if (!self.isman) {
            self.title = @"她的主页";
        }
    }
  
    NSArray *menu_img = @[@"icon_shoucan2",@"icon_guanzhu2",@"mydongtai"];
    
    for (int i=0;i<menu_img.count ; i++) {
        
        NSDictionary *dic = @{@"name":menu_name[i],@"img":menu_img[i]};
        [_dataSource addObject:dic];
        
    }
    [_myTable reloadData];
}

-(void)changeBtnState{
    PersonalHomepageResponse *model = [_dataSource firstObject];
    
    if ([model.isFollow intValue]==1) {
        
        [self.attentionBtn  setTitle:@"取消关注" forState:UIControlStateNormal];
    }else{
        [self.attentionBtn setTitle:@"加关注" forState:UIControlStateNormal];
    }
}

-(void)myAddAttentionBtnClicked{
    PersonalHomepageResponse *model = [_dataSource firstObject];

    PersonalAddAttentionRequest *req = [[PersonalAddAttentionRequest alloc] init];
    req.people_id = model.user_id;
    __weak typeof(self) weakself = self;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            model.isFollow = [NSString stringWithFormat:@"%d",1-[model.isFollow intValue]];
            [weakself changeBtnState];
            if ([model.isFollow intValue]==1) {
                [weakself showHint:@"关注成功" yOffset:-200];
            }else{
                [weakself showHint:@"取消关注" yOffset:-200];
            }
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
    }];
}

#pragma mark - table
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (indexPath.row==0) {
        PersonalHomepageResponse *model = [_dataSource firstObject];

        return model.cellHeight;
    }
    return 40.0f;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row==0 ) {
        PersonalHomepageCell *cell = [tableView dequeueReusableCellWithIdentifier:PersonalHomepageCell_id];
        
        if (cell==nil) {
            cell  = [[[NSBundle mainBundle] loadNibNamed:@"PersonalHomepageCell" owner:nil options:nil] firstObject];
        }
        __weak typeof(self) weakself = self;
        cell.isMySelf = self.ismyself;
        PersonalHomepageResponse *model = [_dataSource firstObject];
        cell.PersonalHeaderLabelTapBlock = ^(NSInteger index){
            if (model.forumLabel.count==0) {
                [weakself showHint:@"还没有关注的圈子" yOffset:-200];
                return ;
            }
            NSDictionary *dic = model.forumLabel[index];
            circleDetailVC *vc = [[circleDetailVC alloc] init];
            vc.forum_id = [NSString stringWithFormat:@"%@",dic[@"key"]];
            [weakself.navigationController pushViewController:vc animated:YES];
        };
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        [cell setCellWithModel:model];
        
        [cell setAnswerPublicAndFriendTapWith:^(PersonalLabelName name) {
            if (name==PersonalAnswer) {
                MOSLog(@"answer");
                PersonalAnswersVC *vc = [[PersonalAnswersVC alloc] init];
                vc.title = [NSString stringWithFormat:@"%@的回答",model.username];
                vc.userid = model.user_id;
                vc.hidesBottomBarWhenPushed = YES;
                [weakself.navigationController pushViewController:vc animated:YES];
            }else if(name==PersonalFriend){
                MOSLog(@"friend");
                PersonalFriendVC *vc = [[PersonalFriendVC alloc] init];
                vc.title = [NSString stringWithFormat:@"%@的病友",model.username];
                vc.userid = model.user_id;
                vc.isMyself = NO;
                vc.hidesBottomBarWhenPushed = YES;
                [weakself.navigationController pushViewController:vc animated:YES];
            }else{
                MOSLog(@"pub");
                PersonalPublicVC *vc = [[PersonalPublicVC alloc] init];
                vc.title = [NSString stringWithFormat:@"%@的发表",model.username];
                vc.userid = model.user_id;
                vc.hidesBottomBarWhenPushed = YES;
                [weakself.navigationController pushViewController:vc animated:YES];
            }
        }];
        
        return cell;
    }else{
        SetMenuCell *cell = [tableView dequeueReusableCellWithIdentifier:setMenuCell_id];
        
        if (cell==nil) {
            cell  = [[[NSBundle mainBundle] loadNibNamed:@"SetMenuCell" owner:nil options:nil] firstObject];
        }
        
        NSDictionary *dic = [_dataSource objectAtIndex:indexPath.row];
        
        cell.icon.image = [UIImage imageNamed:dic[@"img"]];
        cell.name.text = dic[@"name"];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;

        return cell;
    }
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (indexPath.row==1) {
        MyCollectionVC *vc = [[MyCollectionVC alloc] init];
        vc.hidesBottomBarWhenPushed = YES;
        vc.userid = self.userid;
        [self.navigationController pushViewController:vc animated:YES];
        
    }else if(indexPath.row==2){
    
        MyFocusVC *vc = [[MyFocusVC alloc] init];
        vc.hidesBottomBarWhenPushed = YES;
        vc.userid = self.userid;
        [self.navigationController pushViewController:vc animated:YES];
    }else if(indexPath.row==3){
        MyDynamicVC *vc = [[MyDynamicVC alloc] init];
        vc.user_id = self.userid;
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
    }
}

@end
