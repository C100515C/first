//
//  SendRepeatsResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SendRepeatsResponse.h"

@implementation SendRepeatsResponse

@end
