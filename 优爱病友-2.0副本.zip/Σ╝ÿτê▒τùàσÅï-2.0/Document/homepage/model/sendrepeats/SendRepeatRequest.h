//
//  SendRepeatRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface SendRepeatRequest : BaseRequest

@property (nonatomic,copy) NSString *thread_id;
@property (nonatomic,copy) NSString *content;

-(id)init;

@end

@interface SendRepeatCommentRequest : BaseRequest

@property (nonatomic,copy) NSString *thread_id;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *post_id;

-(id)init;

@end

@interface SendRepeatSomeoneCommentRequest : BaseRequest

@property (nonatomic,copy) NSString *thread_id;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *post_id;
@property (nonatomic,copy) NSString *parent_id;
@property (nonatomic,copy) NSString *parent_user_id;

-(id)init;

@end