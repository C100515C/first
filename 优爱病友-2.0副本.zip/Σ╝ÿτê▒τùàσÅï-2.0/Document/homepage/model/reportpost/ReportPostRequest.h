//
//  ReportPostRequest.h
//  IMTest
//
//  Created by chenchen on 16/4/6.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"
#import "BasicResponse.h"

@interface ReportPostRequest : BaseRequest

@property (nonatomic,copy) NSString *thread_id;
@property (nonatomic,copy) NSString *type;//帖子类型1:造谣；2：诽谤；3：色情；4：反动；5：抄袭；

-(id)init;
@end

@interface ReportPostResponse : BaseResponse

@end