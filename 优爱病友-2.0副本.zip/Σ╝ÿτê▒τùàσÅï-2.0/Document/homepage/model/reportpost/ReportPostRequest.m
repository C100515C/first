//
//  ReportPostRequest.m
//  IMTest
//
//  Created by chenchen on 16/4/6.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "ReportPostRequest.h"

@implementation ReportPostRequest

-(id)init{
   
    self = [super init];
    if (self) {
            
        NSString *urlStr = [NSString stringWithFormat:@"reports?access-token=%@",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
//        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"ReportPost";
    }
    return self;
}

@end

@implementation ReportPostResponse

@end