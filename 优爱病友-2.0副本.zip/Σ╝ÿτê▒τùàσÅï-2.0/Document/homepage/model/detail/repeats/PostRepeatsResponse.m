//
//  PostRepeatsResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostRepeatsResponse.h"

static const CGFloat BasicHeight = 50.0f;

@implementation PostRepeatsResponse

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        //_parentInfo.username,
        CGSize size = [self getStringSizeWith:[NSString stringWithFormat:@"回复%@：%@",self.parentInfo.username,_content] fontSize:FontSize_15 showSize:CGSizeMake(SCREEN_WIDTH-18, 2000)];
        _cellHeight = size.height+BasicHeight;
        
        return _cellHeight;
    }
}

-(PostRepeatsUserInforResponse*)parentInfo{
    
    if ([_parentInfo isKindOfClass:[PostRepeatsUserInforResponse class]]) {
        return _parentInfo;
    }else{
        _parentInfo = [[PostRepeatsUserInforResponse alloc] init];
        return _parentInfo;
    }
}

-(NSAttributedString*)repeatContent{
    
    if (self.parentInfo.username.length!=0) {
        if (_repeatContent) {
            return _repeatContent;
        }
        NSMutableAttributedString *tmp = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"回复%@：%@",self.parentInfo.username,_content]];
        
        [tmp addAttribute:NSForegroundColorAttributeName value:RGB(145, 145, 145, 1) range:NSMakeRange(0, _repeatContent.length) ];
        [tmp addAttribute:NSForegroundColorAttributeName value:RGB(67, 195, 122, 1) range:NSMakeRange(2, self.parentInfo.username.length)];
        _repeatContent = tmp;
        return _repeatContent;
    }else{
        _repeatContent = nil;
        return _repeatContent;
    }
    
}

@end

@implementation PostRepeatsItemsResponse

+(Class)item_class{
    return [PostRepeatsResponse class];
}

-(NSMutableArray*)item{
    if (_item==nil) {
        _item = [NSMutableArray array];
    }
    return _item;
}

@end

@implementation PostRepeatsMetaResponse

@end
@implementation PostRepeatsUserInforResponse

-(NSString*)username{
    if (_username==nil) {
        return @"";
    }
    return _username;
}
@end
