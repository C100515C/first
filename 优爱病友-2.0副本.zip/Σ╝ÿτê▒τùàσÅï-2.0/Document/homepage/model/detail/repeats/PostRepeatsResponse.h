//
//  PostRepeatsResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface PostRepeatsMetaResponse : BasicResponse

@property (nonatomic,copy) NSString *totalCount;
@property (nonatomic,copy) NSString *page;
@property (nonatomic,copy) NSString *currentPage;
@property (nonatomic,copy) NSString *perPage;

@end

@interface PostRepeatsUserInforResponse : BasicResponse
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *username;
@property (nonatomic,copy) NSString *avatar;

@end

@interface PostRepeatsResponse : BasicResponse

@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *thread_id;
@property (nonatomic,copy) NSString *post_id;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *status;
@property (nonatomic,copy) NSString *sources;
@property (nonatomic,copy) NSString *parent_id;
@property (nonatomic,strong) PostRepeatsUserInforResponse *userInfo;
@property (nonatomic,strong) PostRepeatsUserInforResponse *parentInfo;

@property (nonatomic,copy) NSAttributedString *repeatContent;

@end

@interface PostRepeatsItemsResponse : BasicResponse

@property (nonatomic,copy) NSMutableArray *item;
@property (nonatomic,strong) PostRepeatsMetaResponse *meta;

+(Class)item_class;

@end