//
//  PostDetailResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/28.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"
#import "PostDetailHeaderResponse.h"
#import "PostRepeatListResponse.h"

@interface PostDetailMetaResponse : BasicResponse
@property (nonatomic,copy) NSString *totalCount;
@property (nonatomic,copy) NSString *pageCount;
@property (nonatomic,copy) NSString *currentPage;
@property (nonatomic,copy) NSString *perPage;

@end

@interface PostDetailResponse : BasicResponse

@property (nonatomic,strong) PostDetailHeaderResponse *thread;
@property (nonatomic,strong) NSMutableArray *post;
@property (nonatomic,strong) PostDetailMetaResponse *_meta;

+(Class)post_class;

@end
