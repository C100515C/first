//
//  PersonalAddAttentionRequest.h
//  IMTest
//
//  Created by chenchen on 16/4/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"
#import "BasicResponse.h"

@interface PersonalAddAttentionRequest : BaseRequest
@property (nonatomic,copy) NSString *people_id;

-(id)init;
@end

@interface PersonalAddAttentionResponse : BasicResponse

@end