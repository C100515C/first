//
//  PostOptionRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface PostOptionRequest : BaseRequest

@property (nonatomic,copy) NSString *thread_id;
@property (nonatomic,copy) NSString *post_id;

-(id)init;
@end

@interface PostOptionAttentionRequest : BaseRequest

@property (nonatomic,copy) NSString *thread_id;
//@property (nonatomic,copy) NSString *post_id;

-(id)init;
@end

@interface PostOptionCollectionRequest : BaseRequest

@property (nonatomic,copy) NSString *thread_id;
//@property (nonatomic,copy) NSString *post_id;

-(id)init;
@end