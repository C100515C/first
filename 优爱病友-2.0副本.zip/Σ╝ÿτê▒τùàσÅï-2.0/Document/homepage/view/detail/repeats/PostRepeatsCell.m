//
//  PostRepeatsCell.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostRepeatsCell.h"
#import "PostRepeatsResponse.h"
//#import "BasicUIImageView.h"

@interface PostRepeatsCell ()
@property (weak, nonatomic) IBOutlet BasicUIImageView *icon;
@property (weak, nonatomic) IBOutlet BasicLabel *nickname;
@property (weak, nonatomic) IBOutlet BasicLabel *content;
@property (weak, nonatomic) IBOutlet BasicLabel *time;

@end

@implementation PostRepeatsCell

-(void)awakeFromNib{
    [super awakeFromNib];

    [self.icon setRaduis];
    
    self.nickname.type = LabelFont_17;
    self.content.type = LabelFont_15;
    self.time.type = LabelFont_12;
}

-(void)setCellWithModel:(PostRepeatsResponse *)model{

    if (model.parentInfo.username.length) {
        self.content.attributedText = model.repeatContent;
    }else{
        self.content.text = model.content;
    }
    self.nickname.text = model.userInfo.username;
    [self.icon sd_setImageWithURL:[NSURL URLWithString:model.userInfo.avatar] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.time.text = model.created_at;

}

@end
