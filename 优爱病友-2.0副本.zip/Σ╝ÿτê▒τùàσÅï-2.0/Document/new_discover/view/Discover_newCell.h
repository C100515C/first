//
//  Discover_newCell.h
//  IMTest
//
//  Created by chenchen on 16/5/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"
static NSString *const Discover_newId =@"Discover_new";
@class DiscoverItemResponse;
@interface Discover_newCell : BasicTableViewCell

-(void)setCellWith:(DiscoverItemResponse*)model;
@end
