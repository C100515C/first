//
//  NoticeDeleteRequest.m
//  IMTest
//
//  Created by chenchen on 16/4/14.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "NoticeDeleteRequest.h"

@implementation NoticeDeleteRequest
-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"notices/n_id?access-token=%@&",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        self.reqMethod = @"PUT";
        //        self.reqMethod = @"POST";
        self.reqClassName = @"NoticeDelete";
    }
    return self;
}

-(void)setNoticeIdWith:(NSString *)n_id{
    NSMutableString *url = [[NSMutableString alloc] initWithString:self.reqUrlPath];
    NSRange range = [url rangeOfString:@"n_id"];
    [url replaceCharactersInRange:range withString:n_id];
    self.reqUrlPath = url;
}

@end

@implementation NoticeDeleteResponse

@end