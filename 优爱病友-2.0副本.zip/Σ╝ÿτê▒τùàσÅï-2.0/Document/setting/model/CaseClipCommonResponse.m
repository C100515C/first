//
//  CaseClipCommonResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipCommonResponse.h"

@implementation CaseClipCommonRequest

- (id)init
{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"dossiers?user_id=%@&access-token=%@",[[UserProfileManager sharedInstance] getUserId],token];
        
//        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"CaseClipCommon";
    }
    return self;
}

-(void)setDeleteUrl:(NSString *)dosser_id{
    NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
    token =  [token urlEncodeForSymbol];
    self.reqUrlPath = [NSString stringWithFormat:@"dossiers/%@?user_id=%@&access-token=%@",dosser_id,[[UserProfileManager sharedInstance] getUserId],token];
    self.reqMethod = @"DELETE";
}

-(void)setEditUrl:(NSString *)dosser_id{
    NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
    token =  [token urlEncodeForSymbol];
    self.reqUrlPath = [NSString stringWithFormat:@"dossiers/%@?user_id=%@&access-token=%@",dosser_id,[[UserProfileManager sharedInstance] getUserId],token];
    self.reqMethod = @"PUT";
}

@end

@implementation CaseClipRecordCommonRequest

- (id)init
{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"dossier-details?user_id=%@&access-token=%@",[[UserProfileManager sharedInstance] getUserId],token]; // 
        
        //        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"CaseClipCommon";
    }
    return self;
}

-(void)setDeleteReqUrlWith:(NSString *)caseId and:(NSString*)dossier_id{
    NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
    token =  [token urlEncodeForSymbol];
    NSString *urlStr = [NSString stringWithFormat:@"dossier-details/caseId?user_id=%@&access-token=%@",[[UserProfileManager sharedInstance] getUserId],token];
    NSMutableString *str = [[NSMutableString alloc] initWithString:urlStr];
    [str replaceCharactersInRange:[urlStr rangeOfString:@"caseId"] withString:caseId];
    self.reqUrlPath = [NSString stringWithFormat:@"%@&dossier_id=%@",str,dossier_id];
    self.reqMethod = @"DELETE";
}

-(void)setEditReqUrlWith:(NSString *)caseId{
    NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
    token =  [token urlEncodeForSymbol];
    NSString *urlStr = [NSString stringWithFormat:@"dossier-details?user_id=%@&access-token=%@&id=%@",[[UserProfileManager sharedInstance] getUserId],token,caseId];
    self.reqUrlPath = urlStr;
}

-(NSString*)user_id{
    if (_user_id.length) {
        return _user_id;
    }
    _user_id = [[UserProfileManager sharedInstance] getUserId];
    return _user_id;
}

@end

static const CGFloat BasicHeight = 50.0f;
static const CGFloat AnotherHeight = 100.0f;
@implementation CaseClipCommonResponse

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }
    
    if (_needNewHeight) {
        _cellHeight = AnotherHeight;
    }else{
        _cellHeight = BasicHeight;
    }
    
    return _cellHeight;
}

-(NSString*)parma{
    if ([_content isEqualToString:@"女"]) {
        return @"W";
    }else if([_content isEqualToString:@"男"]){
        return @"M";
    }
    return _content;
}

-(NSMutableArray*)pics{
//    if (_isEdit) {
//        return _pics;
//    }
    if (_pics && _pics.count!=0) {
        
        NSMutableArray *arr = [NSMutableArray array ];
        
        for (NSDictionary *dic in _pics) {
            UIImage *image = dic[@"image"];
            [arr addObject:image];
        }
        return arr;
    }else{
        return _pics;
    }
}
@end

@implementation CaseClipRecordCommonDeletePicRequest

-(id)init{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"dossier-details/caseId?access-token=%@&",token];//user_id=%@& [[UserProfileManager sharedInstance] getUserId],
        
//        self.reqMethod = @"GET";
        self.reqMethod = @"DELETE";
        self.reqClassName = @"CaseClipCommon";
    }
    return self;
}

-(void)setReqUrlWith:(NSString *)caseId{
    NSMutableString *str = [[NSMutableString alloc] initWithString:self.reqUrlPath];
    [str replaceCharactersInRange:[self.reqUrlPath rangeOfString:@"caseId"] withString:caseId];
    self.reqUrlPath = str;
}

@end
