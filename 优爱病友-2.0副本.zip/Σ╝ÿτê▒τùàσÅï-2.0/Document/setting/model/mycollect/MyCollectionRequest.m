//
//  MyCollectionRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/30.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MyCollectionRequest.h"

@implementation MyCollectionRequest
- (id)init
{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"collects?&access-token=%@&",token];
        
        self.reqMethod = @"GET";
        //        self.reqMethod = @"POST";
        self.reqClassName = @"CircleDetailItemList";
    }
    return self;
}
//[[UserProfileManager sharedInstance] getUserId]
@end
