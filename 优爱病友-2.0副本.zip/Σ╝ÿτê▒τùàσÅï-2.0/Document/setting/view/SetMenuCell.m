//
//  SetMenuCell.m
//  IMTest
//
//  Created by chenchen on 16/3/3.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SetMenuCell.h"

@implementation SetMenuCell

-(void)awakeFromNib{
    [self tableViewDeleteBottomLineForUIEdge:UIEdgeInsetsMake(0, 12, 0, 0)];
    self.name.type = LabelFont_16;
}

-(void)tableViewDeleteBottomLineForUIEdge:(UIEdgeInsets)inset{
    if ([self respondsToSelector:@selector(setSeparatorInset:)]) {
        [self setSeparatorInset:inset];
    }
    
    if ([self respondsToSelector:@selector(setLayoutMargins:)]) {
        [self setLayoutMargins:inset];
    }
}

@end
