//
//  CaseClipDetailHeaderCell.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipDetailHeaderCell.h"
#import "FamilyCasesClipResponse.h"

@interface CaseClipDetailHeaderCell ()

@property (weak, nonatomic) IBOutlet BasicLabel *callName;

@property (weak, nonatomic) IBOutlet UIImageView *gender;
@property (weak, nonatomic) IBOutlet BasicLabel *time;
@property (weak, nonatomic) IBOutlet BasicUIImageView *userIcon;
@property (weak, nonatomic) IBOutlet BasicLabel *userAge;

- (IBAction)addClicked:(UIButton *)sender;

@end

@implementation CaseClipDetailHeaderCell
-(void)awakeFromNib{
//    [super awakeFromNib];
    [self.userIcon setRaduis];
    self.callName.type = LabelFont_17;
    self.time.type = LabelFont_12;
    self.userAge.type = LabelFont_15;
}

-(void)setCellWith:(FamilyCasesClipResponse *)model{

    [self.userIcon sd_setImageWithURL:[NSURL URLWithString:model.icon] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.callName.text = model.name;
    
    self.gender.image = [UIImage imageNamed:model.genderImage];
    
    self.time.text = model.count;
    self.userAge.text = model.theAge;
}

- (IBAction)addClicked:(UIButton *)sender {
    
    if (_addCaseClipRecordBlock) {
        _addCaseClipRecordBlock();
    }
}

@end
