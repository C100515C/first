//
//  CaseClipCommonCell.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CaseClipCommonCell.h"
#import "CaseClipCommonResponse.h"

@implementation CaseClipCommonCell
-(void)awakeFromNib{
    [super awakeFromNib];
    self.nametitle.type = LabelFont_17;
    self.content.type = LabelFont_15;
}
-(void)setCellWith:(CaseClipCommonResponse *)model{

    self.nametitle.text = model.nameTitle;
    self.content.text = model.content;
    self.arrowImage.hidden = model.isHideImage;
}

@end
