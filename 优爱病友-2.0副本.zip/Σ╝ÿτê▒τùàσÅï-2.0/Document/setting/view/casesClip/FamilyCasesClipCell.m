//
//  FamilyCasesClipCell.m
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "FamilyCasesClipCell.h"
#import "FamilyCasesClipResponse.h"

#import "LYJPicturesBrowse.h"

@interface FamilyCasesClipCell ()

@property (weak, nonatomic) IBOutlet BasicLabel *callName;

@property (weak, nonatomic) IBOutlet UIImageView *gender;
@property (weak, nonatomic) IBOutlet BasicLabel *age;
@property (weak, nonatomic) IBOutlet BasicLabel *caseCount;
@property (weak, nonatomic) IBOutlet BasicLabel *caseAddress;
@property (weak, nonatomic) IBOutlet BasicUIImageView *icon;
@property (weak, nonatomic) IBOutlet BasicLabel *time;
@property (weak, nonatomic) IBOutlet BasicUIButton *addCaseBtn;
@property (weak, nonatomic) IBOutlet LYJPicturesBrowse *picBrowser;

@end

@implementation FamilyCasesClipCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self.icon setRaduis];
    
    self.callName.type = LabelFont_17;
    self.age.type = LabelFont_15;
    self.caseAddress.type = LabelFont_15;
    self.caseCount.type = LabelFont_15;
    self.time.type = LabelFont_12;
    [self.addCaseBtn addTarget:self action:@selector(addCaseBtnAciton:) forControlEvents:UIControlEventTouchUpInside];
    self.picBrowser.backContentView.backgroundColor = RGB(247, 249, 249, 1);
}

-(void)setCellWith:(FamilyCasesClipResponse *)model{

    self.callName.text = model.caseName;
    
    self.gender.image = [UIImage imageNamed:model.genderImage];

    self.age.text = model.theAge;
    
    self.caseCount.text = model.count;

    self.caseAddress.text = [NSString stringWithFormat:@"%@/%@",model.detail.hospital,model.detail.illness_category];
    if (model.detail.hospital==nil) {
        self.caseAddress.hidden = YES;
    }else{
        self.caseAddress.hidden = NO;
    }
//    [self.icon sd_setImageWithURL:[NSURL URLWithString:model.icon] placeholderImage:[UIImage imageNamed:DefaultIcon]];
//
    if (model.detail==nil) {
        self.time.hidden = YES;

    }else{
        self.time.text = model.detail.visit_time;
        self.time.hidden = NO;
        
    }
    
    self.picBrowser.isHidenDelete = YES;
    if (model.detail.photos.count==0) {
        self.picBrowser.alpha = 0.0f;

    }else{
        self.picBrowser.pics = [model.detail.photos mutableCopy];
        self.picBrowser.alpha = 1.0f;
    }
}
#pragma mark - btn
-(void)addCaseBtnAciton:(UIButton*)sender{
    if (_AddBtnClickedBlock) {
        _AddBtnClickedBlock(sender);
    }
}
@end
