//
//  CaseClipCommonHeaderView.h
//  IMTest
//
//  Created by chenchen on 16/5/18.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>
@class BasicUIImageView;
@interface CaseClipCommonHeaderView : UIView
@property (weak, nonatomic) IBOutlet BasicUIImageView *uerIcon;
@property (nonatomic,copy) void (^tapImageBlock)(UIImageView *imageview);

@end
