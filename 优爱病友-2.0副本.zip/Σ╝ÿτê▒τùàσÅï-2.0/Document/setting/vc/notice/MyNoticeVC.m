//
//  MyNoticeVC.m
//  IMTest
//
//  Created by chenchen on 16/5/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MyNoticeVC.h"

#import "NoticeTableCell.h"

#import "NoticeCellResponse.h"
#import "NoticeCellRequest.h"
#import "SingletonServ.h"
#import "NoticeDeleteRequest.h"

#import "UIViewController+HUD.h"

#import "PostDetailVC.h"

typedef void (^OptionFinish)(BOOL isfinish);

@interface MyNoticeVC ()
{
    //    NSMutableArray *_dataSource;
    int _page;
}

@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (nonatomic,strong) NSMutableArray *dataSource;

@end

@implementation MyNoticeVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self setNav];
    
    __weak typeof(self) weakself = self;
    [self.emptyTableTipsView setAlertImageWith:@"meiyouguanzhu" andTitle:@"没有通知"];
    self.tableFinish = ^(BOOL finish){
        weakself.emptyTableTipsView.hidden = weakself.dataSource.count;
            
    };
    self.showRefreshFooter = YES;
    self.showRefreshHeader = YES;
    
    _dataSource = [[NSMutableArray alloc] init];
    [self.tableView registerNib:[UINib nibWithNibName:@"NoticeTableCell" bundle:nil] forCellReuseIdentifier:NoticeCell_id];
    
    [self makeModelWith:1 with:nil andHeaderRef:YES];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

#pragma mark - rf
- (void)tableViewDidTriggerHeaderRefresh{
    _page = 1;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:YES reload:NO];
        
    } andHeaderRef:YES];
    //    [self tableViewDidFinishTriggerHeader:YES reload:NO];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
    //    [self tableViewDidFinishTriggerHeader:NO reload:NO];
    _page ++;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:NO reload:NO];
        
    } andHeaderRef:NO];
}//上拉加载事件

#pragma mark - data
-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    NoticeCellRequest *req = [[NoticeCellRequest alloc] init];
    req.page = [NSString stringWithFormat:@"%d", page ];
    __weak typeof(self) weakself = self;
    //    [self showHudInView:self.view hint:@"加载中..."];
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            NoticeCellItemsResponse *model = (NoticeCellItemsResponse*)responseDataModel;
            if (isHeaderRef) {
                [weakself.dataSource removeAllObjects];
            }
            [weakself.dataSource addObjectsFromArray:model.items];
            [weakself.myTable reloadData];
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
        if (finishBlock) {
            finishBlock(YES);
        }
        weakself.emptyTableTipsView.hidden = weakself.dataSource.count;
        [weakself hideHud];
    }];
}

#pragma mark - Nav
-(void)setNav{
    [super setNav];
    self.title = @"通知";
    
}

#pragma mark - table
-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    return _dataSource.count;
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
        NoticeTableCell *cell = [tableView dequeueReusableCellWithIdentifier:NoticeCell_id];
        
        if (cell==nil) {
            cell = [[[NSBundle mainBundle] loadNibNamed:@"NoticeTableCell" owner:nil options:nil] firstObject];
        }
        NoticeCellResponse *model = [_dataSource objectAtIndex:indexPath.row];
        [cell setCellWithModel:model];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        return cell;
    
    
}

-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    
        NoticeCellResponse *model = [_dataSource objectAtIndex:indexPath.row];
        return model.cellHeight;
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
        MOSLog(@"通知cell点击");
        NoticeCellResponse *model = [_dataSource objectAtIndex:indexPath.row];
        
        if ([model.system intValue]==1) {
            return;
        }
        PostDetailVC *vc = [[PostDetailVC alloc]init];
        vc.thread_id = model.thread_id;
        vc.hidesBottomBarWhenPushed = YES;
        [self.navigationController pushViewController:vc animated:YES];
        
    
}
- (void)tableView:(UITableView *)tableView commitEditingStyle:(UITableViewCellEditingStyle)editingStyle forRowAtIndexPath:(NSIndexPath *)indexPath {
    
        //        __weak typeof(self) weakself = self;
        [self noticeDeleteWiht:indexPath and:^(BOOL isfinish) {
            
            [tableView beginUpdates];
            [_dataSource removeObjectAtIndex:indexPath.row];
            [tableView  deleteRowsAtIndexPaths:[NSArray arrayWithObject:indexPath] withRowAnimation:UITableViewRowAnimationFade];
            [tableView endUpdates];
            
        }];
        
   
}

-(void)noticeDeleteWiht:(NSIndexPath*)indexpath and:(OptionFinish)block{
    NoticeCellResponse *model = [_dataSource objectAtIndex:indexpath.row];
    NoticeDeleteRequest *req = [[NoticeDeleteRequest alloc] init];
    [req setNoticeIdWith:model.objectId];
    __weak typeof(self) weakself = self;
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            MOSLog(@"%@",responseDataModel);
        }else {
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        
        if (block) {
            block(YES);
        }
    }];
}


@end
