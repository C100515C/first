//
//  AddFamilyCaseClipVC.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"
@class FamilyCasesClipResponse;
@interface AddFamilyCaseClipVC : BasicVC

@property (nonatomic,strong) FamilyCasesClipResponse *oldEditModel;
@property (nonatomic,copy) void (^ AddFamilyCaseCallBackBlock)(FamilyCasesClipResponse *model);

@end
