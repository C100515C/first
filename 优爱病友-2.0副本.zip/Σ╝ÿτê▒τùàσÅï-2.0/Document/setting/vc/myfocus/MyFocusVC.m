//
//  MyFocusVC.m
//  IMTest
//
//  Created by chenchen on 16/3/16.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MyFocusVC.h"

#import "CircleDetailCell.h"
#import "SelectTableMenuView.h"
#import "Discover_newCell.h"

#import "CircleDetailResponse.h"
#import "SingletonServ.h"
#import "MyFocusRequest.h"
#import "DiscoverResponse.h"

#import "UIViewController+HUD.h"

#import "PostDetailVC.h"
#import "circleDetailVC.h"

@interface MyFocusVC ()<SelectMenuprotocol>
{
//    NSMutableArray *_dataSource;
    int _page;
}

@property (weak, nonatomic) IBOutlet UITableView *myTable;
@property (nonatomic,strong) NSMutableArray *dataSource;
@property (nonatomic,strong) NSMutableArray *dataSource_circle;
@property (nonatomic,strong) SelectTableMenuView *menuView;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *top;

@property (assign,nonatomic) BOOL isProblem;

@end

@implementation MyFocusVC

- (void)viewDidLoad {
    //将table赋值给父类继承的table父类不在创建table
    self.tableView = _myTable;
    
    [super viewDidLoad];
    
    [self setNav];
    [self createMenu];
    
    __weak typeof(self) weakself = self;
    [self.emptyTableTipsView setAlertImageWith:@"meiyouguanzhu" andTitle:@"没有关注"];
    self.tableFinish = ^(BOOL finish){
        if (weakself.isProblem) {
            weakself.emptyTableTipsView.hidden = weakself.dataSource.count;

        }else{
            weakself.emptyTableTipsView.hidden = weakself.dataSource_circle.count;

        }
    };
    self.showRefreshFooter = NO;
    self.showRefreshHeader = YES;
    
    self.isProblem = YES;
    
    _dataSource = [[NSMutableArray alloc] init];
    _dataSource_circle = [[NSMutableArray alloc] init];
    [self.tableView registerNib:[UINib nibWithNibName:@"CircleDetailCell" bundle:nil] forCellReuseIdentifier:circleDetailCell_id];
    [self.tableView registerNib:[UINib nibWithNibName:@"Discover_newCell" bundle:nil] forCellReuseIdentifier:Discover_newId];
    
    [self makeModelWith:1 with:nil andHeaderRef:YES];
    [self getCircleDataModel];
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"focus"];
    
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    [MobClick beginLogPageView:@"focus"];
    
}

#pragma mark - ui
-(void)createMenu{
    self.menuView = [[[NSBundle mainBundle] loadNibNamed:@"SelectTableMenuView" owner:nil options:nil]firstObject];
    [self.view addSubview:_menuView];
    
    CGRect frame = self.menuView.frame;
    frame.size.width = SCREEN_WIDTH;
    self.menuView.frame = frame;
    [self.menuView mas_makeConstraints:^(MASConstraintMaker *make) {
        make.left.equalTo(self.view.mas_left).with.offset(0);
        make.top.equalTo (@(0));
        make.right.equalTo(self.view.mas_right).with.offset(0);
        make.height.equalTo(@(frame.size.height));
    }];
    
    self.menuView.delegate = self;
    [self.menuView setTitles:@[@"问题",@"圈子"]];
    [self moveNoticeTablePosition];
}
/**
 *  根据顶部菜单移动消息通知table  位置  和大小
 */
-(void)moveNoticeTablePosition{
    CGFloat height = self.menuView.frame.size.height;
    self.top.constant = height;
}

#pragma mark - Nav
-(void)setNav{
    [super setNav];

    self.title = @"我的关注";
//    BasicnavigationVC *nav = (BasicnavigationVC*)self.navigationController;
    
}

#pragma mark - data
-(void)getCircleDataModel{
    
    __weak typeof(self) weakself = self;
    NSString *userid;
    if (self.userid) {
        userid = self.userid;
    }else{
        userid = [[UserProfileManager sharedInstance] getUserId];
    }
    
    MyFocusRequest *req = [[MyFocusRequest alloc] init];
    req.user_id = userid;
    req.page = [NSString stringWithFormat:@"%d",1];
    req.type = @"circle";
    
    [[SingletonServ sharedInstance ] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            
            DiscoverResponse *model = (DiscoverResponse*)responseDataModel;
            [weakself.dataSource_circle addObjectsFromArray:model.itemList];
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
    }];
}

-(void)makeModelWith:(int)page with:(HeaderOrFooterRefFinish)finishBlock andHeaderRef:(BOOL)isHeaderRef{
    
    __weak typeof(self) weakself = self;
    NSString *userid;
    if (self.userid) {
        userid = self.userid;
    }else{
        userid = [[UserProfileManager sharedInstance] getUserId];
    }
    
    MyFocusRequest *req = [[MyFocusRequest alloc] init];
    req.user_id = userid;
    req.page = [NSString stringWithFormat:@"%d",page];
    NSString *type = nil;
    if (self.isProblem) {
        type = @"thread";
    }else{
        type = @"circle";
    }
    
    req.type = type;
    
    [[SingletonServ sharedInstance ] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            if (weakself.isProblem) {
                if (isHeaderRef) {
                    [weakself.dataSource removeAllObjects];
                }
                CircleDetailItemListResponse *model = (CircleDetailItemListResponse*)responseDataModel;
                [weakself.dataSource addObjectsFromArray:model.itemList];
                [weakself.tableView reloadData];
            }else{
                if (isHeaderRef) {
                    [weakself.dataSource_circle removeAllObjects];
                }
                DiscoverResponse *model = (DiscoverResponse*)responseDataModel;
                [weakself.dataSource_circle addObjectsFromArray:model.itemList];
                [weakself.tableView reloadData];
            }
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-200];
        }
        [weakself hideHud];
        
        if (weakself.isProblem) {
            weakself.emptyTableTipsView.hidden = weakself.dataSource.count;

        }else{
            weakself.emptyTableTipsView.hidden = weakself.dataSource_circle.count;

        }
        if (finishBlock) {
            finishBlock(YES);
        }
    }];
    
}

- (void)tableViewDidTriggerHeaderRefresh{
    _page = 1;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:YES reload:NO];
        
    } andHeaderRef:YES];
//    [self tableViewDidFinishTriggerHeader:YES reload:NO];
    
}//下拉刷新事件
- (void)tableViewDidTriggerFooterRefresh{
//    [self tableViewDidFinishTriggerHeader:NO reload:NO];
    _page ++;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"加载中..."];
    
    [self makeModelWith:_page with:^(BOOL finish) {
        [weakself tableViewDidFinishTriggerHeader:NO reload:NO];
        
    } andHeaderRef:NO];
}//上拉加载事件

#pragma mark - table

-(NSInteger)numberOfSectionsInTableView:(UITableView *)tableView{
    return 1;
}


-(CGFloat)tableView:(UITableView *)tableView heightForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.isProblem) {
        CircleDetailResponse *model = (CircleDetailResponse*)[_dataSource objectAtIndex:indexPath.row];
        return model.cellHeight;
    }else{
        DiscoverItemResponse *model = (DiscoverItemResponse*)[_dataSource_circle objectAtIndex:indexPath.row];
        return model.cellHeight;
    }
   
}

-(NSInteger)tableView:(UITableView *)tableView numberOfRowsInSection:(NSInteger)section{
    if (self.isProblem) {
        return _dataSource.count;
    }else{
        return _dataSource_circle.count;
    }
}

-(UITableViewCell*)tableView:(UITableView *)tableView cellForRowAtIndexPath:(NSIndexPath *)indexPath{
    if (self.isProblem) {
        CircleDetailCell *cell = [tableView dequeueReusableCellWithIdentifier:circleDetailCell_id];
        
        if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"CircleDetailCell" owner:nil options:nil] firstObject];
        }
        
        CircleDetailResponse *model = (CircleDetailResponse*)[_dataSource objectAtIndex:indexPath.row];
        
        [cell setCellWith:model andFormName:nil];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }else{
    
        Discover_newCell *cell = [tableView dequeueReusableCellWithIdentifier:Discover_newId];
        
        if (cell==nil) {
            cell= [[[NSBundle mainBundle]loadNibNamed:@"Discover_newCell" owner:nil options:nil] firstObject];
        }
        
        DiscoverItemResponse *model = (DiscoverItemResponse*)[_dataSource_circle objectAtIndex:indexPath.row];
        
        [cell setCellWith:model];
        cell.selectionStyle = UITableViewCellSelectionStyleNone;
        
        return cell;
    }
   
    
}

-(void)tableView:(UITableView *)tableView didSelectRowAtIndexPath:(NSIndexPath *)indexPath{
    
    if (self.isProblem) {
        CircleDetailResponse *model = (CircleDetailResponse*)[_dataSource objectAtIndex:indexPath.row];
        
        PostDetailVC *vc = [[PostDetailVC alloc] init];
        vc.thread_id = model.objectId;
        [self.navigationController pushViewController:vc animated:YES];
    }else{
        DiscoverItemResponse *model = (DiscoverItemResponse*)[_dataSource_circle objectAtIndex:indexPath.row];
        
        circleDetailVC *vc = [[circleDetailVC alloc] init];
        vc.title = model.forum_name;
        vc.forum_id = model.forum_id;
        [self.navigationController pushViewController:vc animated:YES];
    }
    
}

#pragma mark - select menu
-(void)selectBtnClickedWith:(SelectMenuSelectBtn)btn{
    
    [self changeTableWith:btn];
}

-(void)changeTableWith:(SelectMenuSelectBtn)btn{
    if (SelectMenuNoticBtn==btn) {
        self.isProblem = YES;
        self.myTable.separatorStyle = UITableViewCellSeparatorStyleSingleLine;
    }else{
        self.isProblem = NO;
        self.myTable.separatorStyle = UITableViewCellSeparatorStyleNone;

    }
    
    [self.myTable reloadData];
    
    if (self.isProblem) {
        self.emptyTableTipsView.hidden = self.dataSource.count;
        
    }else{
        self.emptyTableTipsView.hidden = self.dataSource_circle.count;
        
    }
}

@end
