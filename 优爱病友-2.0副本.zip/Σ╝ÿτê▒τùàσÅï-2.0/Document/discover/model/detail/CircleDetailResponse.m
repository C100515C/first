//
//  CircleDetailResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleDetailResponse.h"

static const CGFloat BasicHeight = 27.0f;
static const CGFloat TopView_height = 41.0f;

@implementation CircleDetailResponse

-(UIColor*)getLabelColor{
    if ([_thread_type isEqualToString:@"2"]) {
        return [UIColor redColor];
    }else if ([_thread_type isEqualToString:@"1"]){
        return [UIColor orangeColor];
    }else{
        
        return RGB(57, 189,104, 1);
    }
}

-(NSString*)thread_type{
    if ([_thread_type integerValue]==2) {
        return @"吐槽";
        
    }else if ([_thread_type integerValue]==1){
        return @"提问" ;
        
    }else{
        return @"推荐";
    }
}

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
//        CGSize size_content = [self getStringSizeWith:_postInfo.content fontSize:FontSize_14 showSize:CGSizeMake(SCREEN_WIDTH-49, 2000)];
        CGSize size = [self baseStrHeightWith:FontSize_15];
        NSInteger numLines = 0;
        if (self.postInfo==nil) {
            numLines = [self LinesOfString:self.content andMaxLines:3 andStringFontSize:FontSize_15 andLineMaxWidth:SCREEN_WIDTH-49];
        }else{
            numLines = [self LinesOfString:self.postInfo.content andMaxLines:3 andStringFontSize:FontSize_15 andLineMaxWidth:SCREEN_WIDTH-49];
        }
        CGFloat newHeight = numLines?size.height:1.0f;
        
//        CGSize size_content;
//        if (self.postInfo==nil) {
//            size_content = [self noLineLimitOfString:self.content andStringFontSize:FontSize_15 andLineMaxWidth:SCREEN_WIDTH-49];
//        }else{
//            size_content = [self noLineLimitOfString:_postInfo.content andStringFontSize:FontSize_15 andLineMaxWidth:SCREEN_WIDTH-49];
//        }
        _cellHeight = newHeight*numLines+BasicHeight+self.new_topHeight;
        
        return _cellHeight;
    }
}

-(CGFloat)new_topHeight{
    
    if (_new_topHeight) {
        return _new_topHeight;
    }else{
//        CGSize size_title = [self getStringSizeWith:_title fontSize:FontSize_16 showSize:CGSizeMake(SCREEN_WIDTH-49, 2000)];
        CGSize size_title = [self noLineLimitOfString:_title andStringFontSize:FontSize_16 andLineMaxWidth:SCREEN_WIDTH-49];
        _new_topHeight = size_title.height+TopView_height;
        return _new_topHeight;
    }
}

-(NSMutableAttributedString*)timeFrom{
    
    if (_timeFrom) {
        return _timeFrom;
    }
    NSMutableAttributedString *tmp = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@ 来自%@",self.created_at,self.forum_name]];
        
    [tmp addAttribute:NSForegroundColorAttributeName value:RGB(145, 145, 145, 1) range:NSMakeRange(0, tmp.length) ];
    [tmp addAttribute:NSForegroundColorAttributeName value:RGB(67, 195, 122, 1) range:NSMakeRange(self.created_at.length+3, self.forum_name.length)];
    _timeFrom = tmp;
    return _timeFrom;
    
}

-(NSString*)content{
    if (_content.length!=0) {
        _content = [self flattenHTML:_content];
        return _content;
    }
    return _content;
}

@end

static const CGFloat HotBasicHeight = 40.0f;

@implementation CircleDetailHotResponse

-(CGFloat)cellHeight{
    if (_cellHeight) {
        return _cellHeight;
    }else{
        _cellHeight = HotBasicHeight;
        return _cellHeight;
    }
}

-(NSString*)thread_type{
    if ([_thread_type integerValue]==1) {
        return @"置顶";
        
    }else if ([_thread_type integerValue]==2){
        return @"置顶" ;
        
    }else{
        return @"置顶";
    }
}

-(UIColor*)getLabelColor{
    if ([_thread_type isEqualToString:@"1"]) {
        return [UIColor redColor];
    }else if ([_thread_type isEqualToString:@"2"]){
        return [UIColor redColor];
    }else{
        
        return [UIColor redColor];
    }
}

@end

@implementation CircleDetailItemListResponse

-(NSMutableArray*)itemList{
    if (_itemList==nil) {
        _itemList = [NSMutableArray array ];
    }
    return _itemList;
}

+(Class)itemList_class{
    return [CircleDetailResponse class];
}

@end

@implementation CircleDetailPostInforResponse
-(NSString*)content{
    if (_content && _username) {
        return [NSString stringWithFormat:@"%@：%@",_username,_content];
    }
    return _content;
}
@end
@implementation CircleDetailUserInforResponse

@end

@implementation CircleDetailItemListOfFindResponse

-(NSMutableArray *)items{
    if (_items==nil) {
        _items = [NSMutableArray array];
    }
    return _items;
}
-(NSMutableArray *)recommend{
    if (_recommend==nil) {
        _recommend = [NSMutableArray array];
    }
    return _recommend;
}

+(Class)items_class{
    return [CircleDetailResponse class];

}

+(Class)recommend_class{
    return [CircleDetailHotResponse class];
}
@end

@implementation CircleDetail_metaResponse

@end
static const CGFloat headerBasicHeight = 121.0f;
@implementation CircleDetailHeaderResponse
-(NSString*)forum_desc{
    if (_forum_desc!=nil) {
        _forum_desc = [NSString stringWithFormat:@"    %@",_forum_desc];
        return _forum_desc;
    }
    return _forum_desc;
}
-(NSMutableAttributedString*)attFollow_count{
    
    if (_attFollow_count) {
        return _attFollow_count;
    }
    NSMutableAttributedString *tmp = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@个人关注",self.follow_count]];
        
    [tmp addAttribute:NSForegroundColorAttributeName value:RGB(145, 145, 145, 1) range:NSMakeRange(self.follow_count.length, 4) ];
    [tmp addAttribute:NSForegroundColorAttributeName value:RGB(67, 195, 122, 1) range:NSMakeRange(0, self.follow_count.length)];
    _attFollow_count = tmp;
    return _attFollow_count;
    
}

-(NSMutableAttributedString*)posts_count{
    if (_posts_count) {
        return _posts_count;
    }
    NSMutableAttributedString *tmp = [[NSMutableAttributedString alloc] initWithString:[NSString stringWithFormat:@"%@个帖子",self.thread_count]];
    
    [tmp addAttribute:NSForegroundColorAttributeName value:RGB(145, 145, 145, 1) range:NSMakeRange(self.thread_count.length, 3)];
    [tmp addAttribute:NSForegroundColorAttributeName value:RGB(67, 195, 122, 1) range:NSMakeRange(0, self.thread_count.length)];
    _posts_count = tmp;
    return _posts_count;
}

-(NSString*)forum_name{
    if (_forum_name) {
        return  [NSString stringWithFormat:@"%@",_forum_name];
    }
    return _forum_name;
}

-(CGFloat)cellHeight{
    if (_cellHeight) {
        return _cellHeight;
    }
    
    CGSize size = [self baseStrHeightWith:FontSize_15];
    NSInteger numLines = [self LinesOfString:self.forum_desc andMaxLines:100 andStringFontSize:FontSize_15 andLineMaxWidth:SCREEN_WIDTH-17];
    CGFloat newHeight = numLines?size.height:1.0f;
    
    _cellHeight = newHeight*numLines+headerBasicHeight;
    
    return _cellHeight;
}

@end