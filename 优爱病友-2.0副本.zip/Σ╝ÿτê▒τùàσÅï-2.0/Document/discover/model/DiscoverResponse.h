//
//  DiscoverResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface DiscoverItemResponse : BasicResponse
@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *forum_name;
@property (nonatomic,copy) NSString *forum_desc;
@property (nonatomic,copy) NSString *forum_url;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *status;
@property (nonatomic,copy) NSString *forum_icon;
@property (nonatomic,copy) NSString *follow_count;
@property (nonatomic,copy) NSString *thread_count;
@property (nonatomic,copy) NSString *forum_id;

@end

@interface DiscoverResponse : BasicResponse

@property (nonatomic,strong) NSMutableArray *itemList;

+(Class)itemList_class;

@end
