//
//  DiscoverResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "DiscoverResponse.h"

@implementation DiscoverResponse

-(NSMutableArray*)itemList{
    if (_itemList==nil) {
        _itemList = [NSMutableArray array ];
    }
    return _itemList;
}

+(Class)itemList_class{
    return [DiscoverItemResponse class];
}
@end

static const CGFloat basicHeight = 59.5f;
@implementation DiscoverItemResponse

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }
    
//    CGSize size = [self getStringSizeWith:@"我" fontSize:RepeatContentFontSize_13 showSize:CGSizeMake(SCREEN_WIDTH-100, 2000)];
//    NSInteger numLines = [CC_NSStringHandle getNumberOfString:self.forum_desc andFont:13.0 andSetStartSize:CGSizeMake(SCREEN_WIDTH-100, 2000)];
//    if (numLines>2) {
//        numLines = 2;
//    }
    CGSize size = [self baseStrHeightWith:FontSize_15];
    NSInteger numLines = [self LinesOfString:self.forum_desc andMaxLines:2 andStringFontSize:FontSize_15 andLineMaxWidth:SCREEN_WIDTH-106];
    _cellHeight = size.height*numLines+basicHeight;
    
    return _cellHeight;
}

-(NSString*)follow_count{
    if (_follow_count) {
        return [NSString stringWithFormat:@"关注 %@",_follow_count];
    }
    return _follow_count;
}

-(NSString*)thread_count{
    if (_thread_count) {
        return [NSString stringWithFormat:@"发贴 %@",_thread_count];
    }
    return _thread_count;
}

@end