//
//  PublishPostResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/30.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface PublishPostResponse : BasicResponse

@end
