//
//  CircleFriendsCell.m
//  IMTest
//
//  Created by chenchen on 16/3/15.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleFriendsCell.h"
#import "CircleFriendsResponse.h"
#import "CC_LabelsOfView.h"

@interface CircleFriendsCell ()

@property (weak, nonatomic) IBOutlet BasicUIImageView *headerIcon;

@property (weak, nonatomic) IBOutlet UIImageView *genderImage;
@property (weak, nonatomic) IBOutlet BasicLabel *name;
@property (weak, nonatomic) IBOutlet BasicLabel *time;
@property (weak, nonatomic) IBOutlet CC_LabelsOfView *labelBackView;
@property (weak, nonatomic) IBOutlet BasicLabel *content;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *labelBackViewHeight;
@property (weak, nonatomic) IBOutlet BasicUIButton *cellClickedBtn;
- (IBAction)cellClickedBtnAction:(UIButton *)sender;

@property (nonatomic,assign) BOOL isMessage;

@end

@implementation CircleFriendsCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self.headerIcon setRaduis];
//    [_labelBackView setStart_x:0 andY:5.0f andInterval:5.0f andLabelHeight:15.0f andEndDistance:10.0f andLabelType:CCBlueFrameLabel];
    self.cellClickedBtn.clipsToBounds = YES;
    self.cellClickedBtn.layer.cornerRadius = 3.0f;
    self.cellClickedBtn.layer.borderColor = RGB(81, 197, 127, 1).CGColor;
    self.cellClickedBtn.layer.borderWidth = 1.0f;
    self.cellClickedBtn.imageFrame = CGRectMake(15, 1, 20, 20);

    self.name.type = LabelFont_17;
    self.time.type = LabelFont_12;
    self.content.type = LabelFont_15;
}

-(void)setCellWith:(CircleFriendsResponse *)model{
    
    self.name.text = model.username;
//    self.labelBackViewHeight.constant = model.labelBackViewHeight;
//    self.time.text = model.recently_online;
    self.content.text = model.signature;
//    [self.labelBackView set_MyLabelsCanChangeRowsWith:[model getForumLabelNames]];
    
    if ([model.gender intValue]==1) {
        self.genderImage.image = [UIImage imageNamed:@"icon_sm"];
    }else{
        self.genderImage.image = [UIImage imageNamed:@"icon_sw"];
    }
    [self.headerIcon sd_setImageWithURL:[NSURL URLWithString:model.avatar] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    
    self.cellClickedBtn.hidden = [model.user_id intValue]==[[[UserProfileManager sharedInstance] getUserId] intValue];
    
    
//    if ([model.isFollow intValue]==1) {
//        [self.cellClickedBtn setBackgroundColor:[UIColor whiteColor]];
//        [self.cellClickedBtn setTitle:@"" forState:UIControlStateNormal];
//        [self.cellClickedBtn setImage:[UIImage imageNamed:@"message"] forState:UIControlStateNormal];
//    }else{
//        [self.cellClickedBtn setTitle:@"+关注" forState:UIControlStateNormal];
//        [self.cellClickedBtn setBackgroundColor:RGB(81, 197, 127, 1)];
//        [self.cellClickedBtn setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
//
//    }
    [self changeBtnState:model.isFollow];
    
    self.isMessage = [model.isFollow intValue];
}

- (IBAction)cellClickedBtnAction:(UIButton *)sender {
    if (_CellBtnClickBlock) {
        _CellBtnClickBlock(self.isMessage);
        if (!self.isMessage) {
            self.isMessage = YES;
        }
    }
}

-(void)changeBtnState:(NSString *)isFollow{
    if ([isFollow intValue]==1) {
//        [self.cellClickedBtn setBackgroundColor:[UIColor whiteColor]];
        self.cellClickedBtn.layer.borderColor = [UIColor whiteColor].CGColor;
        [self.cellClickedBtn setTitle:@"" forState:UIControlStateNormal];
        [self.cellClickedBtn setImage:[UIImage imageNamed:@"n_message"] forState:UIControlStateNormal];
//        self.cellClickedBtn.imageView.hidden = NO;

    }else{
        [self.cellClickedBtn setTitle:@"+ 关注" forState:UIControlStateNormal];
        self.cellClickedBtn.layer.borderColor = RGB(81, 197, 127, 1).CGColor;
//        [self.cellClickedBtn setBackgroundColor:RGB(81, 197, 127, 1)];
        [self.cellClickedBtn setImage:[UIImage imageNamed:@""] forState:UIControlStateNormal];
//        self.cellClickedBtn.imageView.hidden = YES;
    }
}

@end
