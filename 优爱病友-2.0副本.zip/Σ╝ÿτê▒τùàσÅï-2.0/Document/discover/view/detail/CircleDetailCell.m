//
//  CircleDetailCell.m
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "CircleDetailCell.h"
#import "CircleDetailResponse.h"
//#import "BasicUIImageView.h"
//#import "BasicLabel.h"

@interface CircleDetailCell ()

@property (weak, nonatomic) IBOutlet BasicUIImageView *headerImage;
@property (weak, nonatomic) IBOutlet BasicLabel *nickname;
@property (weak, nonatomic) IBOutlet BasicLabel *titileType;

@property (weak, nonatomic) IBOutlet BasicLabel *title;
@property (weak, nonatomic) IBOutlet BasicLabel *content;
@property (weak, nonatomic) IBOutlet BasicLabel *timeAndFrom;
@property (weak, nonatomic) IBOutlet BasicLabel *counts;
@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topViewHeight;

@end

@implementation CircleDetailCell

-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self.headerImage setRaduis];
    [self.titileType setBorder];
    
    self.nickname.type = LabelFont_15;
    self.title.type = LabelFont_16;
    self.content.type = LabelFont_15;
    self.timeAndFrom.type = LabelFont_12;
    self.counts.type = LabelFont_12;
}

-(void)setCellWith:(CircleDetailResponse *)model andFormName:(NSString *)name{
    
    if (name) {
        model.forum_name = name;
    }
    self.title.text = model.title;
    if (model.postInfo==nil) {
        self.content.text = model.content;

    }else{
        self.content.text = model.postInfo.content;
    }
//    self.timeAndFrom.text = model.created_at;
    self.timeAndFrom.attributedText = model.timeFrom;
    self.titileType.text = model.thread_type;
    self.titileType.LYJ_textColor = [model getLabelColor];
    self.counts.text = model.post_count;
    self.nickname.text = model.userInfo.username;
    [self.headerImage sd_setImageWithURL:[NSURL URLWithString:model.userInfo.avatar] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.topViewHeight.constant = model.new_topHeight;
    
}

@end
