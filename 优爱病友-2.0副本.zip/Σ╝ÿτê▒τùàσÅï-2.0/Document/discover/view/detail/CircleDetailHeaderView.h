//
//  CircleDetailHeaderView.h
//  IMTest
//
//  Created by chenchen on 16/3/11.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@class CircleDetailHeaderResponse;
@interface CircleDetailHeaderView : UIView

-(void)setHeaerViewWith:(CircleDetailHeaderResponse*)model;

@property (nonatomic,copy) void (^CircleDetailHeaderImageTapBlock)(UITapGestureRecognizer * sender);
@property (nonatomic,copy) void (^CircleDetailHeaderBtnTapBlocl)(UIButton *sender);

-(void)attentionBtnClickedWith:(CircleDetailHeaderResponse*)model;

@end
