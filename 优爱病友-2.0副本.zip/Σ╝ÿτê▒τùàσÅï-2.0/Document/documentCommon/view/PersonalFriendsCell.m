//
//  PersonalFriendsCell.m
//  IMTest
//
//  Created by chenchen on 16/4/27.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalFriendsCell.h"
#import "PersonalFriendsRequest.h"

@interface PersonalFriendsCell ()
@property (weak, nonatomic) IBOutlet BasicUIImageView *userIcon;
@property (weak, nonatomic) IBOutlet BasicLabel *userName;
@property (weak, nonatomic) IBOutlet BasicUIButton *attentionBtn;//聊天按钮

@property (weak, nonatomic) IBOutlet BasicLabel *signature;
@property (weak, nonatomic) IBOutlet BasicLabel *address;

- (IBAction)attentionBtnPress:(UIButton *)sender;

@property (nonatomic,assign) NSInteger isAttend;
@end

@implementation PersonalFriendsCell

-(void)awakeFromNib{
    [super awakeFromNib];
    [self.userIcon setRaduis];
    self.attentionBtn.clipsToBounds = YES;
    self.attentionBtn.layer.cornerRadius = 4.0f;
    self.attentionBtn.imageFrame = CGRectMake(0, 0, 20, 20);
    self.userName.type = LabelFont_17;
    self.signature.type = LabelFont_15;
}

-(void)setMyCellWith:(PersonalFriends_items *)model{

    [self.userIcon sd_setImageWithURL:[NSURL URLWithString:model.userInfo.avatar] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.signature.text = model.signature;
    self.userName.text = model.userInfo.username;
    self.address.text = model.location;
    
//    if ([model.status intValue]==1) {
//        [self.attentionBtn setTitle:@"已关注" forState:UIControlStateNormal];
//    }else{
//        [self.attentionBtn setTitle:@"关注" forState:UIControlStateNormal];
//
//    }
    
    self.isAttend = [model.status integerValue];
}

- (IBAction)attentionBtnPress:(UIButton *)sender {
    
    if (_AttentionBtnClickedBlock) {
        _AttentionBtnClickedBlock(_isAttend);
    }
}

-(void)changeAttendBtnStateWith:(NSString *)state{
    if ([state intValue]==1) {
        [self.attentionBtn setTitle:@"已关注" forState:UIControlStateNormal];
    }else{
        [self.attentionBtn setTitle:@"关注" forState:UIControlStateNormal];
        
    }
}

-(void)hidenAttendBtnWith:(BOOL)isHide{
    self.attentionBtn.hidden = isHide;
}

@end
