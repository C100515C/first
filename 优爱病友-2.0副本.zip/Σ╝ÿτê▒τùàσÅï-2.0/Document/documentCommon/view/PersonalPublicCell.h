//
//  PersonalPublicCell.h
//  IMTest
//
//  Created by chenchen on 16/4/27.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

static NSString * const PersonalPublic_id = @"PersonalPublic";
@class PersonalPublic_items;
@interface PersonalPublicCell : BasicTableViewCell

-(void)setMyCellWith:(PersonalPublic_items*)model;


@end
