//
//  PersonalAnswersCell.m
//  IMTest
//
//  Created by chenchen on 16/4/26.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalAnswersCell.h"
#import "PersonalAnswersRequest.h"

@interface PersonalAnswersCell ()
@property (weak, nonatomic) IBOutlet BasicUIImageView *userIcon;
@property (weak, nonatomic) IBOutlet BasicLabel *userName;
@property (weak, nonatomic) IBOutlet BasicLabel *postType;
@property (weak, nonatomic) IBOutlet BasicLabel *postTitle;
@property (weak, nonatomic) IBOutlet BasicLabel *content;
@property (weak, nonatomic) IBOutlet BasicLabel *repeatCount;
@property (weak, nonatomic) IBOutlet BasicLabel *praiseCount;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *topViewHeight;

@end

@implementation PersonalAnswersCell
-(void)awakeFromNib{
    [super awakeFromNib];
    
    [self.userIcon setRaduis];
    [self.postType setBorder];
    
    self.userName.type = LabelFont_15;
    self.postTitle.type = LabelFont_16;
    self.content.type = LabelFont_15;
    self.repeatCount.type = LabelFont_12;
    self.praiseCount.type = LabelFont_12;
}

-(void)setMyCellWith:(PersonalAnswers_items*)model{

    
    [self.userIcon sd_setImageWithURL:[NSURL URLWithString:model.userInfo.avatar] placeholderImage:[UIImage imageNamed:DefaultIcon]];
    self.userName.text = model.userInfo.username;
    self.postType.text = model.thread_type;
    self.postType.LYJ_textColor = [model getLabelColor];
    self.postTitle.text = model.thread_title;
    self.topViewHeight.constant = model.topNewHeight;
    
    self.content.text = model.content;
    self.repeatCount.text = model.praise_count;
    self.praiseCount.text = model.praise_count;
}


@end
