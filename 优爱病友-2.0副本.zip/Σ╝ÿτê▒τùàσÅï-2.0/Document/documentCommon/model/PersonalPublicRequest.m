//
//  PersonalPublicRequest.m
//  IMTest
//
//  Created by chenchen on 16/4/27.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalPublicRequest.h"

static const CGFloat BasicHeight = 39.0f;

@implementation PersonalPublicRequest
-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"threads?access-token=%@&",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        self.reqMethod = @"GET";
        //        self.reqMethod = @"POST";
        self.reqClassName = @"PersonalPublics";
    }
    return self;
}
@end

@implementation PersonalPublicsResponse

-(NSMutableArray*)items{
    if (_items==nil) {
        _items = [NSMutableArray array];
    }
    return _items;
}

+(Class)items_class{
    return [PersonalPublic_items class];
}

@end

@implementation PersonalPublic_items

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size = [self getStringSizeWith:self.title fontSize:FontSize_15 showSize:CGSizeMake(SCREEN_WIDTH-18, 2000)];
        _cellHeight = size.height+5+BasicHeight;
        
        return _cellHeight;
    }
    
}

-(NSString*)thread_type{
    
    if ([_thread_type integerValue]==2) {
        return @"吐槽";
        
    }else if ([_thread_type integerValue]==1){
        return @"提问" ;
        
    }else{
        return @"推荐";
    }
}

-(UIColor*)getLabelColor{
    if ([self.thread_type isEqualToString:@"吐槽"]) {
        return [UIColor redColor];
    }else if ([self.thread_type isEqualToString:@"提问"]){
        return [UIColor orangeColor];
    }else{
        return RGB(57, 189,104, 1);
    }
}

-(NSString*)attention_count{
    if (_attention_count) {
        return [NSString stringWithFormat:@"关注 %@",_attention_count];

    }
    return _attention_count;
}

-(NSString*)post_count{
    if (_post_count) {
        return [NSString stringWithFormat:@"回答 %@",_post_count];
        
    }
    return _post_count;
}

@end


@implementation PersonalPublic_meta

@end

@implementation PersonalPublic_userInfo

@end