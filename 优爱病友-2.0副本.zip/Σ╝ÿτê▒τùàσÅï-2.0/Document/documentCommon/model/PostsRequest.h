//
//  PostsRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/24.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface PostsRequest : BaseRequest

@property (nonatomic,copy) NSString *page;

-(id)init;

@end
