//
//  PersonalFriendsRequest.m
//  IMTest
//
//  Created by chenchen on 16/4/27.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalFriendsRequest.h"

static const CGFloat BasicHeight = 38.0f;

@implementation PersonalFriendsRequest

-(id)init{
    self = [super init];
    if (self) {
        
        NSString *urlStr = [NSString stringWithFormat:@"follows?access-token=%@&",[[[UserProfileManager sharedInstance] getToken] urlEncodeForSymbol]];
        self.reqUrlPath = urlStr;
        self.reqMethod = @"GET";
        //        self.reqMethod = @"POST";
        self.reqClassName = @"PersonalFriends";
    }
    return self;
}

@end

@implementation PersonalFriends_items

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size = [self getStringSizeWith:self.signature fontSize:FontSize_15 showSize:CGSizeMake(SCREEN_WIDTH-91, 2000)];
        _cellHeight = size.height+5+BasicHeight;
        
        return _cellHeight;
    }
    
}
@end

@implementation PersonalFriendsResponse
-(NSMutableArray*)items{
    if (_items==nil) {
        _items = [NSMutableArray array];
    }
    return _items;
}

+(Class)items_class{
    return [PersonalFriends_items class];
}

@end

@implementation PersonalFriends_meta
@end

@implementation PersonalFriends_userInfo
@end