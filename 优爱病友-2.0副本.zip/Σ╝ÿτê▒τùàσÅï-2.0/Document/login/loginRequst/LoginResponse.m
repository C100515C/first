//
//  LoginResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/21.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LoginResponse.h"

@implementation LoginResponse

@end
