//
//  AgreementVC.h
//  IMTest
//
//  Created by chenchen on 16/4/15.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface AgreementVC : BasicVC

@end
