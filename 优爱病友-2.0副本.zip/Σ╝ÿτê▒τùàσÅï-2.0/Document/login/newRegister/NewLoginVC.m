//
//  NewLoginVC.m
//  IMTest
//
//  Created by chenchen on 16/4/25.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "NewLoginVC.h"

#import "SingletonServ.h"
#import "LoginRequest.h"
#import "LoginResponse.h"

#import "AppDelegate.h"
#import "RootVC.h"
#import "NewFindPasswordVC.h"


#import "UIViewController+HUD.h"
typedef void(^Login_IMLoginFinish)(BOOL isfinish);
@interface NewLoginVC ()<UITextFieldDelegate,UIAlertViewDelegate,EMClientDelegate>

@property (weak, nonatomic) IBOutlet UITextField *phoneNumber;
@property (weak, nonatomic) IBOutlet UITextField *password;
@property (weak, nonatomic) IBOutlet UIButton *passwordState;
@property (weak, nonatomic) IBOutlet UIButton *forgetPassword;
@property (weak, nonatomic) IBOutlet UIButton *loginBtn;

@property (assign,nonatomic) BOOL showPassword;

@property (nonatomic,strong) LoginResponse *loginModel;
@property (nonatomic,copy) NSString *loginUserName;

- (IBAction)changePasswordState:(UIButton *)sender;

- (IBAction)loginAction:(UIButton *)sender;
- (IBAction)forgetPasswordClicked:(UIButton *)sender;

@end

@implementation NewLoginVC

- (void)viewDidLoad {
    [super viewDidLoad];
    self.tableView.hidden = YES;

    self.title = @"登录";
    
    self.phoneNumber.delegate = self;
    self.password.delegate = self;
    self.showPassword = NO;
    self.password.secureTextEntry = YES;
    self.phoneNumber.clearButtonMode = UITextFieldViewModeAlways;
    self.phoneNumber.clearsOnBeginEditing = YES;
    
    [[EMClient sharedClient] addDelegate:self delegateQueue:nil];

    [self setMyLoginBtn];
    
    [self setNav];
    // Do any additional setup after loading the view from its nib.
}

- (void)didReceiveMemoryWarning {
    [super didReceiveMemoryWarning];
    // Dispose of any resources that can be recreated.
}

-(void)viewWillAppear:(BOOL)animated{
    [super viewWillAppear:animated];
    self.navigationController.navigationBar.barTintColor = G_COLOR_NAVGATION_BACK;
    [MobClick beginLogPageView:@"login"];//("login1"为页面名称，可自定义)

}

-(void)viewWillDisappear:(BOOL)animated{
    [super viewWillDisappear:animated];
    [MobClick endLogPageView:@"login"];
}

-(void)touchesBegan:(NSSet<UITouch *> *)touches withEvent:(UIEvent *)event{
    [super touchesBegan:touches withEvent:event];
    [self.view endEditing:YES];
    
}
#pragma mark - property
-(void)setLoginUserName:(NSString *)loginUserName{
    if (loginUserName) {
        _loginUserName = [CC_NSStringHandle filteringTheBlankSpaceWith:loginUserName];
    }
}

#pragma mark - UI
-(void)setMyLoginBtn{
    
    self.loginBtn.clipsToBounds = YES;
    self.loginBtn.layer.cornerRadius = 3.0f;
}

#pragma mark - EMPushManagerDelegateDevice
// 打印收到的apns信息
-(void)didReceiveRemoteNotification:(NSDictionary *)userInfo
{
    MOSLog(@"%@",userInfo);
}

#pragma mark - btn action
-(void)dismissVC{
    __weak typeof(self) weakself = self;
    AppDelegate *delegate = [UIApplication sharedApplication].delegate;
    if (delegate.isLoginRoot) {
        [weakself loginIMWith:^(BOOL isfinish) {
            [weakself hideHud];
            
            if (isfinish) {
                [delegate goToMain];
            }else{
                [weakself showHint:@"登录失败" yOffset:-200];
            }
        }];
        
    }else{
        [self dismissViewControllerAnimated:YES completion:^{
            
            [weakself loginIMWith:^(BOOL isfinish) {
                [weakself hideHud];
                
                if (isfinish) {
                    AppDelegate *app = [UIApplication sharedApplication].delegate;
                    RootVC *root = (RootVC*)app.window.rootViewController;
                    [root refreshVCWith:3 andNeedHint:YES];
                }
                
            }];
            
            
        }];
    }
}

-(void)loginIMWith:(Login_IMLoginFinish)finish{
    //*
    BOOL isAutoLogin = [EMClient sharedClient].options.isAutoLogin;
    
    if (!isAutoLogin) {
        dispatch_async(dispatch_get_global_queue(DISPATCH_QUEUE_PRIORITY_DEFAULT, 0), ^{
            NSString *userid = [NSString stringWithFormat:@"%@",[[UserProfileManager sharedInstance] getUserId]];
            
            EMError *error = [[EMClient sharedClient] loginWithUsername:userid password:@"123456"];
            dispatch_async(dispatch_get_main_queue(), ^{
                if (!error) {
                    MOSLog(@"登陆成功");
                    //设置成自动登陆
                    [[EMClient sharedClient].options setIsAutoLogin:YES];
                    NSString *name = [[UserProfileManager sharedInstance] getCurUsername];
                    [[EMClient sharedClient] setApnsNickname:name];
                    
                    if (finish) {
                        finish(YES);
                    }
                    
                }else{
                    //                    MOSLog(@"登陆失败=%@",error.errorDescription);
                    if (finish) {
                        finish(NO);
                    }
                }
            });
            
        });
    }else{
        if (finish) {
            finish(YES);
        }
    }
    //*/
}

- (IBAction)loginAction:(UIButton *)sender {
    
    if ([self judgeVerificationCodeWith:self.phoneNumber.text] && [self judgePhoneWith:self.password.text]) {
        [self.phoneNumber resignFirstResponder];
        [self.password resignFirstResponder];
        [self loginRequest];
        
    }else{
        [self showHint:@"昵称和密码不能为空" yOffset:-300];
    }
    
}

-(void)didAutoLoginWithError:(EMError*)error{
    MOSLog(@"自动登陆回掉");
}

- (IBAction)forgetPasswordClicked:(UIButton *)sender {
    NewFindPasswordVC *vc = [[NewFindPasswordVC alloc] init];
    [self.navigationController pushViewController:vc animated:YES];
}

#pragma mark - btn
- (IBAction)changePasswordState:(UIButton *)sender {
    [self changePasswordStateWith:self.showPassword];
    
    self.showPassword = !self.showPassword;
}

-(void)changePasswordStateWith:(BOOL)showPassword{
    
    if (showPassword) {
        [self.passwordState setBackgroundImage:[UIImage imageNamed:@"dlicon_ck2"] forState:UIControlStateNormal];
        
    }else{
        [self.passwordState setBackgroundImage:[UIImage imageNamed:@"dlicon_ck1"] forState:UIControlStateNormal];
        
    }
    self.password.secureTextEntry = showPassword;
    
}


#pragma mark - scroll
-(void)scrollViewDidScroll:(UIScrollView *)scrollView{
    [self.password resignFirstResponder];
    [self.phoneNumber resignFirstResponder];
}

#pragma mark - text field
-(BOOL)textField:(UITextField *)textField shouldChangeCharactersInRange:(NSRange)range replacementString:(NSString *)string{
    
    NSInteger lenth = textField.text.length+string.length;
    if (textField == self.phoneNumber) {
        if (!(lenth<=16)) {
            [self showHint:@"昵称为2～16个字符" yOffset:-400];
            
            return NO;
        }
    }else{
        if (!(lenth<=16)) {
            [self showHint:@"密码为6～16个字符" yOffset:-400];
            
            return NO;
        }
    }
    
    return YES;
}

#pragma mark - net work
-(void)loginRequest{
    
    self.loginUserName = self.phoneNumber.text;
    
    LoginRequest *req = [[LoginRequest alloc] init];
    req.password = self.password.text;
    req.username = self.loginUserName;//self.phoneNumber.text;
    __weak typeof(self) weakself = self;
    [self showHudInView:self.view hint:@"登录中..."];
    
    [[SingletonServ sharedInstance] processDataWithReqModel:req completeBlock:^(Jastor *responseDataModel, ErrorResponse *responeseError) {
        
        if (responeseError==nil) {
            LoginResponse *model = (LoginResponse*)responseDataModel;
            weakself.loginModel = model;

            NSDictionary *dic = @{@"imageUrl":model.avatar,@"signature":@" ",@"gender":@"0",@"isLogin":@(1),@"objectId":model.user_id,@"username":model.phone,@"nickname":model.token,@"address":@" ",@"answerCount":@"0",@"publicCount":@"0",@"friendCount":@"0",@"labels":@[@" ",@" ",@" ",@" "],@"birthdate":@" ",@"addres_id":@" ",@"avatar":model.avatar};
            [[UserProfileManager sharedInstance] storeUserInfor:dic andFinish:^(BOOL finish) {
                [weakself dismissVC];
//                [weakself hideHud];
            }];
            
        }else{
            [weakself showHint:responeseError.msg yOffset:-100];
            [weakself hideHud];
        }
        
    }];
}

#pragma mark - judge str

-(BOOL)judgePhoneWith:(NSString*)num{
    if (self.phoneNumber.text.length>=2 && self.phoneNumber.text.length<=16) {
        return YES;
    }else{
        return NO;
    }
}

-(BOOL)judgeVerificationCodeWith:(NSString*)num{
    
    if (self.password.text.length>=2 && self.password.text.length<=16) {
        return YES;
        
    }else{
        return NO;
    }
}


@end
