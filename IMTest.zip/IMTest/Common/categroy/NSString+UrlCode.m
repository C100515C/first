//
//  NSString+UrlCode.m
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "NSString+UrlCode.h"

@implementation NSString (UrlCode)

- (NSString *)urlEncodeForSymbol {
    
    NSString *token  =  (NSString *)CFBridgingRelease(CFURLCreateStringByAddingPercentEscapes(kCFAllocatorDefault, (CFStringRef)self, NULL, (CFStringRef)@"!$&'()*+,-./:;=?@_~", kCFStringEncodingUTF8));
    
    if (token) {
        return token;
    }
    return @"";
}

@end
