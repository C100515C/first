//
//  UILabel+TapLabel.m
//  MoscoperV3
//
//  Created by mac on 15/10/29.
//  Copyright © 2015年 moscoper. All rights reserved.
//

#import "UILabel+TapLabel.h"
#import <objc/runtime.h>

@implementation UILabel (TapLabel)

- (id<tapLabelDelegate>)delegate {
    id<tapLabelDelegate> object = objc_getAssociatedObject(self, @"delegate");
    
    return object;
}

- (void)setDelegate:(id<tapLabelDelegate>)delegate{
    [self willChangeValueForKey:@"delegate"];
    objc_setAssociatedObject(self, @"delegate", delegate, OBJC_ASSOCIATION_RETAIN_NONATOMIC);
    [self didChangeValueForKey:@"delegate"];
}

-(void)set_LabelTapGesWith:(BOOL)isCanTap andDelegate:(id<tapLabelDelegate>)delegate{
    self.delegate = delegate;
    self.userInteractionEnabled = isCanTap;
    UITapGestureRecognizer *tap = [[UITapGestureRecognizer alloc] initWithTarget:self action:@selector(labelTapAction:)];
    [self addGestureRecognizer:tap];
}

-(void)labelTapAction:(UITapGestureRecognizer*)tap{
    if (self.delegate && [self.delegate respondsToSelector:@selector(tapLabelAction:)]) {
        [self.delegate tapLabelAction:self];
    }
}

@end
