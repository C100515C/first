//
//  MineSetUserInforRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/24.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "MineSetUserInforRequest.h"

@implementation MineSetUserInforRequest

- (id)init
{
    self = [super init];
    if (self) {
        NSString *token = [[UserProfileManager sharedInstance] getLoginToken];
        token =  [token urlEncodeForSymbol];
        self.reqUrlPath = [NSString stringWithFormat:@"users?user_id=%@&access-token=%@",[[UserProfileManager sharedInstance] getUserId],token];
        
        self.reqMethod = @"GET";
//        self.reqMethod = @"POST";
        self.reqClassName = @"MineSetUserInfor";
    }
    return self;
}
@end
