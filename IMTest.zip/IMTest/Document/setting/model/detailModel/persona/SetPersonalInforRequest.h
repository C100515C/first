//
//  SetPersonalInforRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/23.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface SetPersonalInforRequest : BaseRequest

@property (strong, nonatomic) NSString *username;
@property (strong, nonatomic) NSString *gender;
@property (strong, nonatomic) NSString *birthdate;
@property (strong, nonatomic) NSString *province;
@property (strong, nonatomic) NSString *city;
@property (strong, nonatomic) NSString *signature;


- (id)init;

-(void)setParamaWith:(NSArray*)parama withProAndCity:(NSString*)str;

@end
