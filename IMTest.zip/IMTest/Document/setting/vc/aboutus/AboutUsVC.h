//
//  AboutUsVC.h
//  IMTest
//
//  Created by chenchen on 16/4/8.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface AboutUsVC : BasicVC

@end
