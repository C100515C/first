//
//  FamilyCaseClipDetailVC.h
//  IMTest
//
//  Created by chenchen on 16/3/17.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicVC.h"

@interface FamilyCaseClipDetailVC : BasicVC

@end
