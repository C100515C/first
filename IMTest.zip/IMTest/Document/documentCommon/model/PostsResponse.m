//
//  PostsModel.m
//  IMTest
//
//  Created by chenchen on 16/3/1.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PostsResponse.h"

static const CGFloat BasicHeight = 49.0f;//104.0f;
static const CGFloat topNewBasicHeight = 35.0f;

@implementation PostsResponse

-(CGFloat)topNewHeight{
    if (_topNewHeight) {
        return _topNewHeight;
    }else{
        CGSize size = [self getStringSizeWith:self.thread.title fontSize:15.0f showSize:CGSizeMake(SCREEN_WIDTH-56, 2000)];
        _topNewHeight = size.height+5+topNewBasicHeight;
        return _topNewHeight;
    }
}

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
    
        CGSize size = [self getStringSizeWith:_postInfo.content fontSize:14.0f showSize:CGSizeMake(SCREEN_WIDTH-13, 2000)];
        _cellHeight = size.height+BasicHeight+self.topNewHeight;
        return _cellHeight;
    }
}

-(NSString*)sources{
    if (_type) {
        if ([_type intValue]==1) {
            return @"回答了该问题";
        }else if ([_type intValue]==2){
            return @"关注了该问题";
        }else if ([_type intValue]==3){
            return @"收藏了该问题";

        }else if([_type intValue]==4){
            return @"赞同了该回答";

        }else{
            return @"热门";
        }
    }else{
        return @"";
    }
}

-(NSAttributedString*)optionStr{
    if (_optionStr) {
        return _optionStr;
    }else{
        UIColor *col1 = RGB(20, 37, 63, 1);
        NSRange ran1 = NSMakeRange(0, [[_itemInfo  username]length]);
        
        UIColor *col2 = RGB(172, 172, 172, 1);
        NSRange ran2 = NSMakeRange([[_itemInfo  username]length], self.sources.length+1);
        if ([_type intValue]!=5) {
            return [self getNewAttributeStrWith:[NSString stringWithFormat:@"%@ %@",[_itemInfo  username],self.sources] andRangesAndColors:@[@{BaseTextColors:col1,BaseTextRanges:[BasicResponse rangeTransformToDicWith:ran1]},@{BaseTextColors:col2,BaseTextRanges:[BasicResponse rangeTransformToDicWith:ran2]}]];
        }else{
            return [self getNewAttributeStrWith:[NSString stringWithFormat:@"%@",self.sources] andRangesAndColors:@[@{BaseTextColors:col2,BaseTextRanges:[BasicResponse rangeTransformToDicWith:NSMakeRange(0, self.sources.length)]}]];
        }
        
    }
}

-(NSAttributedString*)timeCircleStr{
    if (_timeCircleStr ) {
        return _timeCircleStr;
    }else{
        
        UIColor *col1 = RGB(172, 172, 172, 1);
        NSRange ran1 = NSMakeRange(0, self.updated_at.length+3);
        
        UIColor *col2 = RGB(57, 189,104, 1);
        NSRange ran2 = NSMakeRange(self.updated_at.length+3, self.forum_name.length);
        
        return [self getNewAttributeStrWith:[NSString stringWithFormat:@"%@ 来自%@",self.updated_at,self.forum_name] andRangesAndColors:@[@{BaseTextColors:col1,BaseTextRanges:[BasicResponse rangeTransformToDicWith:ran1]},@{BaseTextColors:col2,BaseTextRanges:[BasicResponse rangeTransformToDicWith:ran2]}]];
        
    }
}

-(UIColor*)getLabelColor{
    if ([_thread.thread_type isEqualToString:@"吐槽"]) {
        return [UIColor redColor];
    }else if ([_thread.thread_type isEqualToString:@"提问"]){
        return [UIColor orangeColor];
    }else{
        return RGB(57, 189,104, 1);
    }
}

@end

@implementation PostsItemListResponse

-(NSMutableArray*)items{
    if (_items==nil) {
        _items = [NSMutableArray array];
    }
    return _items;
}

+(Class)items_class{
    return [PostsResponse class];
}


@end

@implementation PostsPostInforResponse

-(NSString*)content{
    if (_content && _username) {
        NSString *newcontent = [NSString stringWithFormat:@"%@：%@",_username,_content];
        return newcontent;
    }
    return _content;
}

@end

@implementation PostsUserInforResponse

@end

@implementation PostsThreadResponse

-(NSString*)thread_type{
    
    if ([_thread_type integerValue]==2) {
        return @"吐槽";

    }else if ([_thread_type integerValue]==1){
        return @"提问" ;

    }else{
        return @"推荐";
    }
}

@end

@implementation PostsItemListPageResponse

@end
