//
//  PersonalHomepageCell.h
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

@class PersonalHomepageResponse;
@class UserProfileEntity;
static NSString * const PersonalHomepageCell_id = @"personalhomepage";

typedef void (^PersonalHomepageIconTapBlock)(void);

@interface PersonalHomepageCell : BasicTableViewCell

@property (nonatomic,copy) PersonalHomepageIconTapBlock tapBlock;
@property (nonatomic,assign) BOOL isMySelf;
@property (nonatomic,copy) void (^PersonalHeaderLabelTapBlock)(NSInteger index);

-(void)setCellWithModel:(PersonalHomepageResponse*)model;

-(void)setCellWithUserModel:(UserProfileEntity *)model;
@end
