//
//  PostRepeatListResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface PostRepeatListUserInforResponse : BasicResponse
@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *username;
@property (nonatomic,copy) NSString *avatar;
@property (nonatomic,copy) NSString *user_id;

@end

@interface PostRepeatListResponse : BasicResponse

@property (nonatomic,copy) NSString *id;
@property (nonatomic,copy) NSString *content;
@property (nonatomic,copy) NSString *thread_id;
@property (nonatomic,copy) NSString *user_id;
@property (nonatomic,copy) NSString *created_at;
@property (nonatomic,copy) NSString *comment_count;
@property (nonatomic,copy) NSString *status;
@property (nonatomic,copy) NSString *sources;
@property (nonatomic,copy) NSString *praise_count;
@property (nonatomic,copy) NSString *praiseAction;
@property (nonatomic,strong) PostRepeatListUserInforResponse *userInfo;

@end
