
//
//  PersonalHomepageResponse.m
//  IMTest
//
//  Created by chenchen on 16/3/7.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "PersonalHomepageResponse.h"

static const CGFloat BasicHeight = 129.0f;
static const CGFloat font = 12.0f;
static const CGFloat compareFocusWidth = 8.0f;

@implementation PersonalHomepageResponse

-(void)setCellHeight:(CGFloat)cellHeight{
    _cellHeight = cellHeight;
}

-(CGFloat)cellHeight{
    
    if (_cellHeight) {
        return _cellHeight;
    }else{
        
        CGSize size = [self getStringSizeWith:self.signature fontSize:15.0f showSize:CGSizeMake(SCREEN_WIDTH-23, 2000)];
        _cellHeight = size.height+BasicHeight+self.focusLabelHeight;

        return _cellHeight;
    }
}

-(CGFloat)focusLabelHeight{
    if (_focusLabelHeight) {
        return _focusLabelHeight;
    }
    if (self.forumLabel.count!=0) {
        CGFloat x=0,dis_x=5.0f,enddis=15.0f;
        CGFloat height = 20.0f,dis_y = 5.0f;
        
        CGFloat tmpWidth = x;
        int row = 1;
        
        for (NSString *str in [self getForumLabelNames]) {
             CGSize size = [self getStringSizeWith:str fontSize:font showSize:CGSizeMake(100, 2000)];
            tmpWidth = tmpWidth +size.width+dis_x+5;//这个5为Label添加text时，text距离左右边框像素距离
            if (tmpWidth>(SCREEN_WIDTH-compareFocusWidth)-enddis) {//需要减去后面的要留出的宽度
                row ++;
                tmpWidth = x;//tmpWidth-(SCREEN_WIDTH-compareFocusWidth)+enddis;
            }
        }
        _focusLabelHeight = (row*(height+5)+(row-1)*dis_y);//这个5为Label添加text时，text距离上下边框像素距离
        return _focusLabelHeight;
//        return (row*height+(row-1)*dis_y);
    }
    return 30.0f;
}

@end
