//
//  LoginRequest.m
//  IMTest
//
//  Created by chenchen on 16/3/21.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "LoginRequest.h"

@implementation LoginRequest

- (id)init
{
    self = [super init];
    if (self) {
        self.reqUrlPath = @"logins";
        
//        self.reqMethod = @"GET";
        self.reqMethod = @"POST";
        self.reqClassName = @"Login";
    }
    return self;
}

@end
