//
//  RegisterResponse.h
//  IMTest
//
//  Created by chenchen on 16/3/21.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicResponse.h"

@interface RegisterResponse : BasicResponse

@property (strong, nonatomic) NSString *uid;
@property (strong, nonatomic) NSString *phone;
@property (strong, nonatomic) NSString *token;
@property (strong, nonatomic) NSString *avatar;

@end
