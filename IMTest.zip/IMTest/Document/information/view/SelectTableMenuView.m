//
//  SelectTableMenuView.m
//  IMTest
//
//  Created by chenchen on 16/3/3.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "SelectTableMenuView.h"

@interface SelectTableMenuView ()
@property (weak, nonatomic) IBOutlet UIButton *noticeBtn;
@property (weak, nonatomic) IBOutlet UIButton *messageBtn;
@property (weak, nonatomic) IBOutlet UIView *markView;

- (IBAction)notice:(UIButton *)sender;
- (IBAction)message:(UIButton *)sender;

@property (weak, nonatomic) IBOutlet NSLayoutConstraint *markViewCenter_x;
@end

@implementation SelectTableMenuView

-(void)moveMarkLabelWith:(SelectMenuSelectBtn)selectBtn andBtn:(UIButton*)btn{
    CGPoint point = btn.center;
    CGRect frame = btn.frame;

    CGFloat x = point.x-frame.size.width/2.0;

    [UIView animateWithDuration:0.5f animations:^{
        self.markViewCenter_x.constant = x;
    }];
    
}


- (IBAction)notice:(UIButton *)sender {
    
    [self.messageBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [sender setTitleColor:[UIColor darkTextColor] forState:UIControlStateNormal];
    [self moveMarkLabelWith:SelectMenuNoticBtn andBtn:self.noticeBtn];

    if (self.delegate && [self.delegate respondsToSelector:@selector(selectBtnClickedWith:)]) {
        [self.delegate selectBtnClickedWith:SelectMenuNoticBtn];
    }
}

- (IBAction)message:(UIButton *)sender {
    
    [self.noticeBtn setTitleColor:[UIColor lightGrayColor] forState:UIControlStateNormal];
    [sender setTitleColor:[UIColor darkTextColor] forState:UIControlStateNormal];
    [self moveMarkLabelWith:SelectMenuMessageBtn andBtn:self.messageBtn];

    if (self.delegate && [self.delegate respondsToSelector:@selector(selectBtnClickedWith:)]) {
        [self.delegate selectBtnClickedWith:SelectMenuMessageBtn];
    }

}
@end
