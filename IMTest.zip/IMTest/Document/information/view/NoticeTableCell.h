//
//  NoticeTableCell.h
//  IMTest
//
//  Created by chenchen on 16/3/4.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BasicTableViewCell.h"

@class NoticeCellResponse;
@interface NoticeTableCell : BasicTableViewCell
@property (weak, nonatomic) IBOutlet UILabel *nicknameLabel;
@property (weak, nonatomic) IBOutlet UILabel *desContentLabel;
@property (weak, nonatomic) IBOutlet UILabel *timeLabel;

-(void)setCellWithModel:(NoticeCellResponse*)model;

@end
