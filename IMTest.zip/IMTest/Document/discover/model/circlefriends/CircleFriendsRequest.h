//
//  CircleFriendsRequest.h
//  IMTest
//
//  Created by chenchen on 16/3/31.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import "BaseRequest.h"

@interface CircleFriendsRequest : BaseRequest
@property (nonatomic,copy) NSString *page;

-(id)init;
-(void)mySetForum_id:(NSString *)forum_id;

@end
