//
//  LYJToolbar.h
//  IMTest
//
//  Created by chenchen on 16/2/29.
//  Copyright © 2016年 chenchen. All rights reserved.
//

#import <UIKit/UIKit.h>

@protocol LYJToolBarDelegate <NSObject>
@optional
/**
 *  点击发送执行回调
 *
 *  @param currentText 输入的内容
 */
-(void)clickedSendBtn:(NSString*)currentText;

-(void)keyboardAppearWith:(CGFloat)height;
-(void)keyboardDisappearWith:(CGFloat)height;

@end

@interface LYJToolbar : UIToolbar

@property (nonatomic,assign) id<LYJToolBarDelegate>sendDelegate;

@property (nonatomic,copy) NSString *textPlaceholder;
@property (nonatomic,assign) BOOL isNotice;//添加键盘通知 和 开启键盘
/**
 *  收起键盘
 */
-(void)takeBackKeyboard;

-(BOOL)keyboardCurrentAppearStyle;
-(void)keybaordAppear;

@end
